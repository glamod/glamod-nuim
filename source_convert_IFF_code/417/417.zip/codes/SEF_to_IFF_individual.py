#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import glob
import re
import pandas as pd

BASE_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/sangetha_new_data/DerrickMuheki_converted/DRC_daily_and_subdaily_temperature_data/sef_data"

print("Script started")
print("BASE_DIR exists:", os.path.exists(BASE_DIR))

def classify_file(filename):
    name = os.path.basename(filename).lower()
    if "dry_bulb_temp" in name:
        return {"subdir": "dry_bulb_ta", "label": "dry_bulb_temperature"}
    elif "wet_bulb_temp" in name:
        return {"subdir": "wet_bulb_tb", "label": "wet_bulb_temperature"}
    elif "avg_temperature" in name:
        return {"subdir": "mean_temp", "label": "mean_temperature"}
    elif "max_temperature" in name:
        return {"subdir": "max_temp", "label": "maximum_temperature"}
    elif "min_temperature" in name:
        return {"subdir": "min_temp", "label": "minimum_temperature"}
    else:
        return None

def read_sef_header(filepath):
    header = pd.read_csv(filepath, sep="\t", nrows=12, header=None)
    header = header.iloc[:, 0:2]
    header.columns = ["SEF", "Value"]
    return dict(zip(header["SEF"], header["Value"]))

def parse_decimal(x):
    if pd.isna(x):
        return pd.NA
    return pd.to_numeric(str(x).replace(",", "."), errors="coerce")

def extract_orig(meta_value):
    if pd.isna(meta_value):
        return ""
    text = str(meta_value)
    m = re.search(r'orig=([^|]+)', text)
    if not m:
        return ""
    return m.group(1).strip()

def safe_name(x):
    x = str(x).strip()
    x = re.sub(r"\s+", "_", x)
    x = re.sub(r"[^A-Za-z0-9_\-]", "", x)
    return x

def extract_time_from_filename(filename):
    name = os.path.basename(filename)
    m = re.search(r'_(\d{2})h(\d{2})', name, flags=re.IGNORECASE)
    if m:
        return int(m.group(1)), int(m.group(2))
    return 0, 0

all_files = sorted(glob.glob(os.path.join(BASE_DIR, "*.tsv")))
print("TSV files found:", len(all_files))
for f in all_files[:10]:
    print(" -", os.path.basename(f))
    
    output_base = os.path.join(station_dir, "IFF_outputs")
    os.makedirs(output_base, exist_ok=True)

grouped_frames = {}

for filepath in all_files:
    print("\nReading:", os.path.basename(filepath))
    info = classify_file(filepath)
    print("Classification:", info)

    if info is None:
        print("Skipped: not classified")
        continue

    try:
        meta = read_sef_header(filepath)

        source_id = "413"
        station_id = str(meta.get("ID", "")).strip()
        station_name = str(meta.get("Name", "")).strip()
        lat = parse_decimal(meta.get("Lat", ""))
        lon = parse_decimal(meta.get("Lon", ""))
        elev = parse_decimal(meta.get("Alt", ""))

        df = pd.read_csv(filepath, sep="\t", skiprows=12)
        print("Columns:", df.columns.tolist())

        if "Value" not in df.columns:
            raise ValueError("Missing Value column")

        df["Observed_value"] = df["Value"].replace(["NA", "NaN", "nan", ""], pd.NA)
        df["Observed_value"] = pd.to_numeric(df["Observed_value"], errors="coerce")

        if "Meta" in df.columns:
            df["Original_observed_value"] = df["Meta"].apply(extract_orig)
        else:
            df["Original_observed_value"] = ""

        df["Original_observed_value_units"] = "c"
        df["Source_QC_flag"] = df["qc"].astype(str) if "qc" in df.columns else ""
        df["Source_ID"] = source_id
        df["Station_ID"] = station_id
        df["Station_name"] = station_name
        df["Alias_station_name"] = ""
        df["Latitude"] = lat
        df["Longitude"] = lon
        df["Elevation"] = elev
        df["Report_type_code"] = ""
        df["Measurement_code_1"] = ""
        df["Measurement_code_2"] = ""

        df["Year"] = pd.to_numeric(df["Year"], errors="coerce")
        df["Month"] = pd.to_numeric(df["Month"], errors="coerce")
        df["Day"] = pd.to_numeric(df["Day"], errors="coerce")

        if "Hour" in df.columns:
            df["Hour"] = pd.to_numeric(df["Hour"], errors="coerce")
        else:
            hh, mm = extract_time_from_filename(os.path.basename(filepath))
            df["Hour"] = hh

        if "Minute" in df.columns:
            df["Minute"] = pd.to_numeric(df["Minute"], errors="coerce")
        else:
            hh, mm = extract_time_from_filename(os.path.basename(filepath))
            df["Minute"] = mm

        df["Hour"] = df["Hour"].fillna(0)
        df["Minute"] = df["Minute"].fillna(0)

        before = len(df)
        df = df.dropna(subset=["Year", "Month", "Day", "Observed_value"])
        after = len(df)
        print("Rows before drop:", before, "| after drop:", after)

        if after == 0:
            print("No valid rows left after dropping NaN values")
            continue

        df = df[[
            "Source_ID", "Station_ID", "Station_name", "Alias_station_name",
            "Year", "Month", "Day", "Hour", "Minute",
            "Latitude", "Longitude", "Elevation",
            "Observed_value", "Source_QC_flag",
            "Original_observed_value", "Original_observed_value_units",
            "Report_type_code", "Measurement_code_1", "Measurement_code_2"
        ]]

        key = info["subdir"]
        grouped_frames.setdefault(key, []).append(df)
        print("Added to group:", key)

    except Exception as e:
        print("FAILED:", os.path.basename(filepath), "|", e)

print("\nGrouped keys:", grouped_frames.keys())

label_map = {
    "dry_bulb_ta": "dry_bulb_temperature",
    "wet_bulb_tb": "wet_bulb_temperature",
    "mean_temp": "mean_temperature",
    "max_temp": "maximum_temperature",
    "min_temp": "minimum_temperature"
}

for group_name, frames in grouped_frames.items():
    print("\nSaving group:", group_name)
    outdir = os.path.join(OUTPUT_BASE, group_name)
    os.makedirs(outdir, exist_ok=True)

    combined = pd.concat(frames, ignore_index=True)
    print("Combined rows:", len(combined))

    combined["Timestamp"] = pd.to_datetime(
        dict(
            year=pd.to_numeric(combined["Year"], errors="coerce"),
            month=pd.to_numeric(combined["Month"], errors="coerce"),
            day=pd.to_numeric(combined["Day"], errors="coerce"),
            hour=pd.to_numeric(combined["Hour"], errors="coerce"),
            minute=pd.to_numeric(combined["Minute"], errors="coerce")
        ),
        errors="coerce"
    )

    combined = combined.dropna(subset=["Timestamp"])
    combined = combined.sort_values(["Station_ID", "Timestamp"]).reset_index(drop=True)
    combined = combined.drop(columns=["Timestamp"])

    label = label_map[group_name]

    for station_id, group in combined.groupby("Station_ID"):
        station_name = safe_name(group["Station_name"].iloc[0])
        source_id = safe_name(group["Source_ID"].iloc[0])
        outname = f"{source_id}_{station_id}_{station_name}_{label}.psv"
        outpath = os.path.join(outdir, outname)
        group.to_csv(outpath, sep="|", index=False)
        print("Saved:", outpath)

print("\nDone")