gawk 'BEGIN {FS="\t"} $16=="X" || $17=="X" || $18=="X" || $19=="X" || $20=="X" || $21=="X" || $22=="X" || $23=="X" {print $0}' Pub9volA071002.flatfile | gawk 'BEGIN {FS="\t"} substr($1,1,1)!=9 && substr($10,3,1)==" " && substr($9,4,2)<=59 && substr($9,4,2)>=0 && substr($10,4,2)<=59 && substr($10,4,2)>=0 {printf("%s%8.4f%2s%9.4f%2s%5s.0 %s\n",$6,substr($9,1,2)+substr($9,4,2)/60.0,substr($9,6,1),substr($10,1,2)+substr($10,4,2)/60.0,substr($10,6,1),$13,substr($8,1,30))}' > wmopub9vola.tmp1 
gawk 'BEGIN {FS="\t"} $16=="X" || $17=="X" || $18=="X" || $19=="X" || $20=="X" || $21=="X" || $22=="X" || $23=="X" {print $0}' Pub9volA071002.flatfile | gawk 'BEGIN {FS="\t"} substr($1,1,1)!=9 && substr($10,3,1)!=" " && substr($9,4,2)<=59 && substr($9,4,2)>=0 && substr($10,5,2)<=59 && substr($10,5,2)>=0 {printf("%s%8.4f%2s%9.4f%2s%5s.0 %s\n",$6,substr($9,1,2)+substr($9,4,2)/60.0,substr($9,6,1),substr($10,1,3)+substr($10,5,2)/60.0,substr($10,7,1),$13,substr($8,1,30))}' >> wmopub9vola.tmp1
#sed -i 's/    .0/-999.9/g' wmopub9vola.tmp1
gawk 'substr($0,28,6)=="    .0" {print substr($0,1,27) "-999.9" substr($0,34,31)}' wmopub9vola.tmp1 > wmopub9vola.tmp2
gawk 'substr($0,28,6)!="    .0" {print $0}' wmopub9vola.tmp1 >> wmopub9vola.tmp2
gawk '$3=="N" && $5=="E" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, $2, $4, $6, substr($0,35,30))}' wmopub9vola.tmp2 > wmopub9vola.tmp3
gawk '$3=="N" && $5=="W" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, $2, -1.0*$4, $6, substr($0,35,30))}' wmopub9vola.tmp2 >> wmopub9vola.tmp3
gawk '$3=="S" && $5=="E" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, -1.0*$2, $4, $6, substr($0,35,30))}' wmopub9vola.tmp2 >> wmopub9vola.tmp3
gawk '$3=="S" && $5=="W" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, -1.0*$2, -1.0*$4, $6, substr($0,35,30))}' wmopub9vola.tmp2 >> wmopub9vola.tmp3
sort -u -k 1.1,1.11 wmopub9vola.tmp3 > wmopub9vola.tmp4

