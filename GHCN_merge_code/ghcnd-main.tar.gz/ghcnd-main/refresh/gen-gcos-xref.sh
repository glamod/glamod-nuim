./genGcosXref.exe gcos.station.list.prescreened.dupchecked mingle-list.txt ghcnd-stations.txt
./genDataXref.exe /home/mmenne/ghcnd/ ghcnd-stations.txt G /home/mmenne/ghcnd2/ghcnd_por/ gcos.id.noxref gcos.data.xref
cat gcos.id.xref gcos.data.xref > gcos.xref
