# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 12:17:19 2023

@author: snoone
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 15:32:19 2024

@author: snoone
"""

import os
import glob
import pandas as pd
import re

OUTDIR = "D:/AEMET_spanish_hist_sub_daily/extracted_files/DirV/JLC/DirV/data/out/wd"

os.chdir("D:/AEMET_spanish_hist_sub_daily/extracted_files/DirV/JLC/DirV/data/test")
extension = '.csv'



all_filenames = [i for i in glob.glob('*{}'.format(extension))]
def remove_non_utf8_chars(text):
    return re.sub(r'[^\x00-\x7F]+', '', text)
for filename in all_filenames:
    df = pd.read_csv(filename, sep=';',skiprows=1, header=None, encoding='latin-1')  # Reading CSV with ';' separator and no header
  
        # Selecting and renaming specified columns
    df = df.iloc[:, :33]  # Selecting first 33 columns
    df.columns = ["Station_ID", "Year", "Month", "Day", "Station_name", "Elevation", "Province",
                  "Longitude", "Latitude", "00","1", "2", "3","4","5", "6","7", "8", "9","10","11", "12","13", "14", "15",
                  "16", "17","18","19", "20","21", "22", "23"]  # Renaming columns
        # Remove non-UTF characters from Station_name column using regex
    df['Station_name'] = df['Station_name'].apply(remove_non_utf8_chars)
        # Replace commas with dots in Latitude and Longitude columns
    df['Latitude'] = df['Latitude'].str.replace(',', '.')
    df['Longitude'] = df['Longitude'].str.replace(',', '.')
    # Adding additional columns with empty values
    df['Report_type_code'] = ''
    df['Measurement_code_1'] = ''
    df['Measurement_code_2'] = ''
    df["Minute"] = "00"
    df["Alias_station_name"] = ""
    df["Source_QC_flag"] = ""
    df['Source_ID'] = '400'
  
        
     
#extract temp @00 am 
    df_temp00=df
    df_temp00 =df_temp00[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","00",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp00["Hour"]="00" 
    df_temp00= df_temp00.rename(columns=({'00':'Observed_value'}))
    df_temp00["Original_observed_value"]=df_temp00["Observed_value"]
    df_temp00["Original_observed_value_units"]='mm'
    df_temp00["Observed_value"] = pd.to_numeric(df_temp00["Observed_value"],errors='coerce')
   # df_temp00["Observed_value"]=df_temp00["Observed_value"]/10
    
    df_temp00 = df_temp00[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @1 am 
    df_temp1=df
    df_temp1 =df_temp1[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","1",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp1["Hour"]="1" 
    df_temp1= df_temp1.rename(columns=({'1':'Observed_value'}))
    df_temp1["Original_observed_value"]=df_temp1["Observed_value"]
    df_temp1["Original_observed_value_units"]='mm'
    df_temp1["Observed_value"] = pd.to_numeric(df_temp1["Observed_value"],errors='coerce')
    #df_temp1["Observed_value"]=df_temp1["Observed_value"]/10
    
    df_temp1 = df_temp1[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @2 am 
    df_temp2=df
    df_temp2 =df_temp2[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","2",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp2["Hour"]="2" 
    df_temp2= df_temp2.rename(columns=({'2':'Observed_value'}))
    df_temp2["Original_observed_value"]=df_temp2["Observed_value"]
    df_temp2["Original_observed_value_units"]='mm'
    df_temp2["Observed_value"] = pd.to_numeric(df_temp2["Observed_value"],errors='coerce')
    #df_temp2["Observed_value"]=df_temp2["Observed_value"]/10
    
    df_temp2 = df_temp2[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @3 am 
    df_temp3=df
    df_temp3 =df_temp3[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","3",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp3["Hour"]="3" 
    df_temp3= df_temp3.rename(columns=({'3':'Observed_value'}))
    df_temp3["Original_observed_value"]=df_temp3["Observed_value"]
    df_temp3["Original_observed_value_units"]='mm'
    df_temp3["Observed_value"] = pd.to_numeric(df_temp3["Observed_value"],errors='coerce')
    #df_temp3["Observed_value"]=df_temp3["Observed_value"]/10
    
    df_temp3 = df_temp3[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @4 am 
    df_temp4=df
    df_temp4 =df_temp4[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","4",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp4["Hour"]="4" 
    df_temp4= df_temp4.rename(columns=({'4':'Observed_value'}))
    df_temp4["Original_observed_value"]=df_temp4["Observed_value"]
    df_temp4["Original_observed_value_units"]='mm'
    df_temp4["Observed_value"] = pd.to_numeric(df_temp4["Observed_value"],errors='coerce')
    #df_temp4["Observed_value"]=df_temp4["Observed_value"]/10
    
    df_temp4 = df_temp4[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @5 am 
    df_temp5=df
    df_temp5 =df_temp5[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","5",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp5["Hour"]="5" 
    df_temp5= df_temp5.rename(columns=({'5':'Observed_value'}))
    df_temp5["Original_observed_value"]=df_temp5["Observed_value"]
    df_temp5["Original_observed_value_units"]='mm'
    df_temp5["Observed_value"] = pd.to_numeric(df_temp5["Observed_value"],errors='coerce')
    #df_temp5["Observed_value"]=df_temp5["Observed_value"]/10
    
    df_temp5 = df_temp5[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @6 am 
    df_temp6=df
    df_temp6 =df_temp6[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","6",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp6["Hour"]="6" 
    df_temp6= df_temp6.rename(columns=({'6':'Observed_value'}))
    df_temp6["Original_observed_value"]=df_temp6["Observed_value"]
    df_temp6["Original_observed_value_units"]='mm'
    df_temp6["Observed_value"] = pd.to_numeric(df_temp6["Observed_value"],errors='coerce')
    #df_temp6["Observed_value"]=df_temp6["Observed_value"]/10
    
    df_temp6 = df_temp6[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
 
    
  ##extract presssure @7  
    df_temp7=df
    df_temp7 =df_temp7[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","7",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp7["Hour"]="7" 
    df_temp7= df_temp7.rename(columns=({'7':'Observed_value'}))
    df_temp7["Original_observed_value"]=df_temp7["Observed_value"]
    df_temp7["Original_observed_value_units"]='mm'
    df_temp7["Observed_value"] = pd.to_numeric(df_temp7["Observed_value"],errors='coerce')
    #df_temp7["Observed_value"]=df_temp7["Observed_value"]/10
    
    df_temp7= df_temp7[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @8 am 
    df_temp8=df
    df_temp8 =df_temp8[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","8",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp8["Hour"]="8" 
    df_temp8= df_temp8.rename(columns=({'8':'Observed_value'}))
    df_temp8["Original_observed_value"]=df_temp8["Observed_value"]
    df_temp8["Original_observed_value_units"]='mm'
    df_temp8["Observed_value"] = pd.to_numeric(df_temp8["Observed_value"],errors='coerce')
    #df_temp8["Observed_value"]=df_temp8["Observed_value"]/10
    
    df_temp8 = df_temp8[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @9 am 
    df_temp9=df
    df_temp9 =df_temp9[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","9",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp9["Hour"]="9" 
    df_temp9= df_temp9.rename(columns=({'9':'Observed_value'}))
    df_temp9["Original_observed_value"]=df_temp9["Observed_value"]
    df_temp9["Original_observed_value_units"]='mm'
    df_temp9["Observed_value"] = pd.to_numeric(df_temp9["Observed_value"],errors='coerce')
    #df_temp9["Observed_value"]=df_temp9["Observed_value"]/10
    
    df_temp9 = df_temp9[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @10 am 
    df_temp10=df
    df_temp10 =df_temp10[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","10",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp10["Hour"]="10" 
    df_temp10= df_temp10.rename(columns=({'10':'Observed_value'}))
    df_temp10["Original_observed_value"]=df_temp10["Observed_value"]
    df_temp10["Original_observed_value_units"]='mm'
    df_temp10["Observed_value"] = pd.to_numeric(df_temp10["Observed_value"],errors='coerce')
    #df_temp10["Observed_value"]=df_temp10["Observed_value"]/10
    
    df_temp10 = df_temp10[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @11 am 
    df_temp11=df
    df_temp11 =df_temp11[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","11",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp11["Hour"]="11" 
    df_temp11= df_temp11.rename(columns=({'11':'Observed_value'}))
    df_temp11["Original_observed_value"]=df_temp11["Observed_value"]
    df_temp11["Original_observed_value_units"]='mm'
    df_temp11["Observed_value"] = pd.to_numeric(df_temp11["Observed_value"],errors='coerce')
    #df_temp11["Observed_value"]=df_temp11["Observed_value"]/10
    
    df_temp11 = df_temp11[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @12 am 
    df_temp12=df
    df_temp12 =df_temp12[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","12",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp12["Hour"]="12" 
    df_temp12= df_temp12.rename(columns=({'12':'Observed_value'}))
    df_temp12["Original_observed_value"]=df_temp12["Observed_value"]
    df_temp12["Original_observed_value_units"]='mm'
    df_temp12["Observed_value"] = pd.to_numeric(df_temp12["Observed_value"],errors='coerce')
    #df_temp12["Observed_value"]=df_temp12["Observed_value"]/10
    
    df_temp12 = df_temp12[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @00 pm 
    df_temp13=df
    df_temp13 =df_temp13[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","13",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp13["Hour"]="13" 
    df_temp13= df_temp13.rename(columns=({'13':'Observed_value'}))
    df_temp13["Original_observed_value"]=df_temp13["Observed_value"]
    df_temp13["Original_observed_value_units"]='mm'
    df_temp13["Observed_value"] = pd.to_numeric(df_temp13["Observed_value"],errors='coerce')
    #df_temp13["Observed_value"]=df_temp13["Observed_value"]/10
    
    df_temp13 = df_temp13[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @14 pm 
    df_temp14=df
    df_temp14 =df_temp14[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","14",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp14["Hour"]="14" 
    df_temp14= df_temp14.rename(columns=({'14':'Observed_value'}))
    df_temp14["Original_observed_value"]=df_temp14["Observed_value"]
    df_temp14["Original_observed_value_units"]='mm'
    df_temp14["Observed_value"] = pd.to_numeric(df_temp14["Observed_value"],errors='coerce')
    #df_temp14["Observed_value"]=df_temp14["Observed_value"]/10
    
    df_temp14 = df_temp14[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @15 pm 
    df_temp15=df
    df_temp15 =df_temp15[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","15",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp15["Hour"]="15" 
    df_temp15= df_temp15.rename(columns=({'15':'Observed_value'}))
    df_temp15["Original_observed_value"]=df_temp15["Observed_value"]
    df_temp15["Original_observed_value_units"]='mm'
    df_temp15["Observed_value"] = pd.to_numeric(df_temp15["Observed_value"],errors='coerce')
    #df_temp15["Observed_value"]=df_temp15["Observed_value"]/10
    
    df_temp15 = df_temp15[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @16 pm 
    df_temp16=df
    df_temp16 =df_temp16[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","16",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp16["Hour"]="16" 
    df_temp16= df_temp16.rename(columns=({'16':'Observed_value'}))
    df_temp16["Original_observed_value"]=df_temp16["Observed_value"]
    df_temp16["Original_observed_value_units"]='mm'
    df_temp16["Observed_value"] = pd.to_numeric(df_temp16["Observed_value"],errors='coerce')
    #df_temp16["Observed_value"]=df_temp16["Observed_value"]/10
    
    df_temp16 = df_temp16[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @17 pm 
    df_temp17=df
    df_temp17 =df_temp17[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","17",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp17["Hour"]="17" 
    df_temp17= df_temp17.rename(columns=({'17':'Observed_value'}))
    df_temp17["Original_observed_value"]=df_temp17["Observed_value"]
    df_temp17["Original_observed_value_units"]='mm'
    df_temp17["Observed_value"] = pd.to_numeric(df_temp17["Observed_value"],errors='coerce')
    #df_temp17["Observed_value"]=df_temp17["Observed_value"]/10
    
    df_temp17 = df_temp17[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @18 pm 
    df_temp18=df
    df_temp18 =df_temp18[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","18",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp18["Hour"]="18" 
    df_temp18= df_temp18.rename(columns=({'18':'Observed_value'}))
    df_temp18["Original_observed_value"]=df_temp18["Observed_value"]
    df_temp18["Original_observed_value_units"]='mm'
    df_temp18["Observed_value"] = pd.to_numeric(df_temp18["Observed_value"],errors='coerce')
    #df_temp18["Observed_value"]=df_temp18["Observed_value"]/10
    
    df_temp18 = df_temp18[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @19 pm 
    df_temp19=df
    df_temp19 =df_temp19[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","19",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp19["Hour"]="19" 
    df_temp19= df_temp19.rename(columns=({'19':'Observed_value'}))
    df_temp19["Original_observed_value"]=df_temp19["Observed_value"]
    df_temp19["Original_observed_value_units"]='mm'
    df_temp19["Observed_value"] = pd.to_numeric(df_temp19["Observed_value"],errors='coerce')
    #df_temp19["Observed_value"]=df_temp19["Observed_value"]/10
    
    df_temp19 = df_temp19[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @20 pm 
    df_temp20=df
    df_temp20 =df_temp20[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","20",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp20["Hour"]="20" 
    df_temp20= df_temp20.rename(columns=({'20':'Observed_value'}))
    df_temp20["Original_observed_value"]=df_temp20["Observed_value"]
    df_temp20["Original_observed_value_units"]='mm'
    df_temp20["Observed_value"] = pd.to_numeric(df_temp20["Observed_value"],errors='coerce')
   # df_temp20["Observed_value"]=df_temp20["Observed_value"]/10
    
    df_temp20 = df_temp20[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @21 pm 
    df_temp21=df
    df_temp21 =df_temp21[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","21",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp21["Hour"]="21" 
    df_temp21= df_temp21.rename(columns=({'21':'Observed_value'}))
    df_temp21["Original_observed_value"]=df_temp21["Observed_value"]
    df_temp21["Original_observed_value_units"]='mm'
    df_temp21["Observed_value"] = pd.to_numeric(df_temp21["Observed_value"],errors='coerce')
    #df_temp21["Observed_value"]=df_temp21["Observed_value"]/10
    
    df_temp21 = df_temp21[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @22 pm 
    df_temp22=df
    df_temp22 =df_temp22[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","22",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp22["Hour"]="22" 
    df_temp22= df_temp22.rename(columns=({'22':'Observed_value'}))
    df_temp22["Original_observed_value"]=df_temp22["Observed_value"]
    df_temp22["Original_observed_value_units"]='mm'
    df_temp22["Observed_value"] = pd.to_numeric(df_temp22["Observed_value"],errors='coerce')
    #df_temp22["Observed_value"]=df_temp22["Observed_value"]/10
    
    df_temp22 = df_temp22[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    ##extract temp @23 pm 
    df_temp23=df
    df_temp23 =df_temp23[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","23",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_temp23["Hour"]="23" 
    df_temp23= df_temp23.rename(columns=({'23':'Observed_value'}))
    df_temp23["Original_observed_value"]=df_temp23["Observed_value"]
    df_temp23["Original_observed_value_units"]='mm'
    df_temp23["Observed_value"] = pd.to_numeric(df_temp23["Observed_value"],errors='coerce')
    #df_temp23["Observed_value"]=df_temp23["Observed_value"]/10
    
    df_temp23 = df_temp23[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]

    
        
        

    merged_temp=pd.concat([df_temp00,df_temp1,df_temp2,df_temp3,df_temp4,df_temp5,df_temp6,df_temp7,
                           df_temp8,df_temp9,df_temp10,df_temp11,df_temp12,df_temp13,df_temp14,df_temp15,
                           df_temp16,df_temp17,df_temp18,df_temp19,df_temp20,df_temp21,df_temp22,df_temp23], axis=0)
        # Remove rows where Observed_value is 88 no data
    merged_temp = merged_temp[merged_temp['Observed_value'] != 88]
    
    # Identify rows where Observed_value is 99
    mask = merged_temp['Observed_value'] == 99
    # Identify rows where Observed_value is 0
    mask2 = merged_temp['Observed_value'] == 0
    
    # Replace -3 with 0 in the Observed_value column
    merged_temp.loc[mask, 'Measurement_code_1'] = "Variable wind, not clear direction"

    
    # Set Measurement_code_1 to "calm" where Observed_value was 0
    merged_temp.loc[mask2, 'Measurement_code_1'] = 'calm'
    #set value to correct si units
    #merged_temp["Observed_value"] = pd.to_numeric(merged_temp["Observed_value"],errors='coerce')
    #merged_temp["Observed_value"]=merged_temp["Observed_value"]/10
    
    
    
    merged_temp=merged_temp.dropna(subset = ['Observed_value'])
    # Round the 'Observed_value' column to no decimal places
    merged_temp['Observed_value'] = pd.to_numeric(merged_temp['Observed_value'])
    merged_temp['Observed_value'] = merged_temp['Observed_value'].round(0).astype(int)
       
    merged_temp = merged_temp[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    merged_temp = merged_temp.astype(str)
    # Combine 'Year', 'Month', and 'Day' into a single column 'date_column'
    merged_temp['date_column'] = merged_temp['Year']+ '-' + merged_temp['Month'].astype(str).str.zfill(2)  + '-' + merged_temp['Day'].astype(str).str.zfill(2)
    merged_temp = merged_temp.sort_values(by='date_column')
    merged_temp = merged_temp.drop(columns=['date_column'])  # Drop the auxiliary 'date_column' after sorting
        
    
    #save output file   
    cdm_type=("_wind_direction_"+filename)
     
    a = merged_temp['Station_ID'].unique()
    print (a)
    outname = os.path.join(OUTDIR,cdm_type)
      #with open(filename, "w") as outfile:
    merged_temp.to_csv(outname+".csv", index=False, sep=",")

   
    
   


