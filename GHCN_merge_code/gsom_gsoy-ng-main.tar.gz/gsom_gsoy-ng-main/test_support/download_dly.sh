#!/bin/bash

# For partial testing (only a subset of stations), this will read in
# ghcnd-stations.txt and grab the dailys (.dly) for the stations
# defined. This will aid in testing on the CI/CD pipeline.
#
# usage: $  ./download_dly.sh ghcnd-stations

data_path=/c/NCEI_Data/GSOM/data-input

# Read in station id
filename="$1"
while read -r id rest || [ -n "$id" ]; do
    name=$id
    curl -O -s --output-dir "$data_path"/ https://www.ncei.noaa.gov/pub/data/ghcn/daily/all/$id.dly
done < "$filename"

# Tar the files for putting on server
tar -C "$data_path" -czf ./container-support/input_dly.tar.gz  .