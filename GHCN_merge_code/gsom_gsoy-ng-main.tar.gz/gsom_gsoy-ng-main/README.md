
# Global Summary of the Month/Year: The Next Generation

## Usage



# GSOM

## Summary
The Global Summary Of The Month (GSOM) Data Files contain quality controlled monthly
summaries of more than 50 elements (max temp, snow, etc.) computed from stations in
the Global Historical Climatology Network (GHCN)-Daily dataset. These include non-US
stations, providing a global product from 1763 to present that is updated weekly.
This is not to be confused with GHCN-Monthly, which only contains temperature and
precipitation elements and which include bias corrected data (which are not available
in the first release of GSOM/GSOY).

# GSOY

## Summary
The Global Summary Of The Year (GSOY) Data Files contain quality controlled annual summaries of more than 50 elements (max temp, snow, etc.) computed from stations in the Global Historical Climatology Network (GHCN)-Daily dataset.  These include non-US stations, providing a global product from 1763 to present that is updated weekly. Annual averages in the GSOY Data Files are computed from equally weighted months; (e.g, no weighting of months by number of days).

## Inputs
- Station File: `ghcnd-stations.txt`
- Monthly data file: `*.csv`

_where `*` means station name_

## Outputs
- GSOY Output: `*.csv`

## Command-Line ARGS
Program has ability to be passed in file paths for input/output files. See below for an example:

## Links
- [GSOY Landing Page](https://www.ncei.noaa.gov/access/metadata/landing-page/bin/iso?id=gov.noaa.ncdc:C00947)