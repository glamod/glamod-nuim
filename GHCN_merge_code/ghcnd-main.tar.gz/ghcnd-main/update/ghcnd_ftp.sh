#!/bin/sh

mode=$1
#"por" or "upd"
run_status=$2
#"test" or "live"

if [ "${mode}" = "por" -o "${run_status}" != "live" ]
then
echo "ftp not allowed when mode=por or run_status not equal to live: mode=${mode}, run_status=${run_status}"
exit
fi

if [ -s ${PREFIX}new-por.txt ]
then
new_por="yes"
else
new_por="no"
fi

cd $PREFIX

chmod -R g+rx,o+rx ghcnd_all
chmod -R g+rx,o+rx ghcnd_gsn
chmod -R g+rx,o+rx ghcnd_hcn

rm -f ghcnd_all.tar.gz
tar -czf ghcnd_all.tar.gz ghcnd_all ghcnd-version.txt
cp -p ghcnd_all.tar.gz /ghcn-daily
rm -f ghcnd_gsn.tar.gz
tar -czf ghcnd_gsn.tar.gz ghcnd_gsn ghcnd-version.txt
cp -p ghcnd_gsn.tar.gz /ghcn-daily
rm -f ghcnd_hcn.tar.gz
tar -czf ghcnd_hcn.tar.gz ghcnd_hcn ghcnd-version.txt
cp -p ghcnd_hcn.tar.gz /ghcn-daily
cp -p ghcnd-version.txt /ghcn-daily

if [ "${new_por}" = "yes" ]
then
#echo "del ghcnd-inventory.txt" >> ftpin
#echo "put ghcnd-inventory.txt" >> ftpin
cp -p ghcnd-inventory.txt /ghcn-daily
#echo "del ghcnd-stations.txt" >> ftpin
#echo "lcd input4sys" >> ftpin
#echo "put ghcnd-stations.txt" >> ftpin
#echo "lcd ${PREFIX}" >> ftpin
cp -p ${PREFIX}input4sys/ghcnd-stations.txt /ghcn-daily
cp -p ${PREFIX}input4sys/mingle-list.txt /ghcn-daily
cd ${PREFIX}ghcnd_all
for i in *
do
cp -p $i /ghcn-daily/all
done
fi

cd ${PREFIX}ghcnd_gsn
cp -p *.dly /ghcn-daily/gsn
#echo "open ftp0.ncdc.noaa.gov" > ftpin
#echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
#echo "cd "${ftpdatapath}"/gsn" >> ftpin
#echo "bin" >> ftpin
#echo "mdel *.dly" >> ftpin
#echo "mput *.dly" >> ftpin
#echo "quit" >> ftpin
#numfiles2ftp=`ls *.dly | wc | gawk '{print $1}'`
#echo "Starting to ftp ${numfiles2ftp} files from ghcnd_gsn" `date`
#ftp -in < ftpin
#rm ftpin

cd ${PREFIX}ghcnd_hcn
cp -p *.dly /ghcn-daily/hcn
#echo "open ftp0.ncdc.noaa.gov" > ftpin
#echo "user anonymous Matthew.Menne.noaa.gov" >> ftpin
#echo "cd "${ftpdatapath}"/hcn" >> ftpin
#echo "bin" >> ftpin
#echo "mdel *.dly" >> ftpin
#echo "mput *.dly" >> ftpin
#echo "quit" >> ftpin
#numfiles2ftp=`ls *.dly | wc | gawk '{print $1}'`
#echo "Starting to ftp ${numfiles2ftp} files from ghcnd_hcn" `date`
#ftp -in < ftpin
#rm ftpin

if [ "${new_por}" = "no" ]
then
cd ${PREFIX}ghcnd_upd
cp -p *.dly /ghcn-daily/all
#cd ${PREFIX}ghcnd_all
#echo "open ftp0.ncdc.noaa.gov" > ftpin
#echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
#echo "cd "${ftpdatapath} >> ftpin
#echo "cd "${ftpdatapath}"/all" >> ftpin
#echo "bin" >> ftpin
#for i in *.dly
# do
#  sum_all=`md5sum ${i} | gawk '{print $1}'`
#  if [ ${new_por} = "no" ]
#  then
#  sum_por=`md5sum ${PREFIX}ghcnd_por/${i} | gawk '{print $1}'`
#  elif [ ${new_por} = "yes" ]
#  then
#  sum_por=0
#  if [ -s ${PREFIX}ghcnd_por_old/$i ]
#  then
#  sum_por=`md5sum ${PREFIX}ghcnd_por_old/${i} | gawk '{print $1}'`
#  fi
#  fi
#  if [ "${sum_all}" !=  "${sum_por}" ]
#  then
#  echo "del "${i} >> ftpin
#  echo "put "${i} >> ftpin
#  fi
# done
#echo "quit" >> ftpin
#numfiles2ftp=`grep put ftpin | wc | gawk '{print $1}'`
#echo "Starting to ftp ${numfiles2ftp} files from ghcnd_all with new_por = $new_por" `date`
#ftp -in < ftpin
#rm ftpin
fi
