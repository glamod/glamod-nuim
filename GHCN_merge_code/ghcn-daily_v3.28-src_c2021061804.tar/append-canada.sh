PREFIX=$1
rm -rf ${PREFIX}canada/rawghcnd
mkdir -p ${PREFIX}canada/rawghcnd
for i in `ls ${PREFIX}canada/archive/por/rawghcnd`
do
gawk 'substr($0,12,4)<2019 || (substr($0,12,4)==2019 && substr($0,16,2) <= "05") {print $0}' ${PREFIX}canada/archive/por/rawghcnd/$i > ${PREFIX}canada/rawghcnd/$i
#gawk 'substr($0,12,4)<2018 {print $0}' ${PREFIX}canada/archive/por/rawghcnd/$i > ${PREFIX}canada/rawghcnd/$i
done
for i in `ls ${PREFIX}canada/archive/upd/rawghcnd`
do
gawk 'substr($0,12,6)>=201906 {print $0}' ${PREFIX}canada/archive/upd/rawghcnd/$i >> ${PREFIX}canada/rawghcnd/$i
done
