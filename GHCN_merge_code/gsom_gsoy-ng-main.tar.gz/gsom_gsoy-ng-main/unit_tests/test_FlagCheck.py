import polars as pl
from gsom.FlagCheck import FlagCheck

def test_missing4Consecutive():
    fc = FlagCheck()

    
    data = {'daily_values': [[-14.74, 2.34, 1.69, 9.35, 13.28, 21.04, 21.03],
                              [-9999.0, -9999.0, 1.69, 9.35, 13.28, 21.04, 21.03],
                              [-9999.0, -9999.0, -9999.0, 9.35, 13.28, 21.04, 21.03],
                              [-9999.0, -9999.0, -9999.0, -9999.0, 13.28, 21.04, 21.03],
                              [-14.74, 2.34, 1.69, 9.35, 13.28, 21.04, 21.03],
                              [-9999.0, -9999.0, -9999.0, 9.35, 13.28, 21.04, 21.03],
                              [-9999.0, -9999.0, -9999.0, 9.35, 13.28, 21.04, 21.03],
                              [-14.74, 2.34, 1.69, -9999.0, -9999.0, -9999.0, -9999.0],
                              [-14.74, 2.34, 1.69, 9.35, 13.28, 21.04, 21.03],
                              [-14.74, -9999.0, 1.69, -9999.0, -9999.0, 21.04,-9999.0]
                              ], 
            'qc_flags': [ ['', '', '', '', '', '', ''],
                         ['', '', '', '', '', 'x', 'x'],
                         ['', '', '', '', 'x', 'x', 'x'],
                         ['', '', '', '', '', '', ''],
                         ['x', 'x', 'x', 'x', '', '', ''],
                         ['', '', '', 'x', '', '', ''],
                         ['', '', '', '', 'x', '', 'x'],
                         ['', '', '', '', '', '', ''],
                         ['', '', '', 'x', 'x', 'x', 'x'],
                         ['', '', '', '', '', '', '']
                          ]
        }
    df = pl.DataFrame(data, schema={'daily_values': pl.List(pl.Float64), 'qc_flags': pl.List(pl.String)})
    df = fc.missing4Consecutive(df)

    expectedSeries = pl.Series('missing_4_consecutive', [False, False, False, True, True, True, False, True, True, False])
    print(df['missing_4_consecutive'])

    assert df['missing_4_consecutive'].equals(expectedSeries) is True
