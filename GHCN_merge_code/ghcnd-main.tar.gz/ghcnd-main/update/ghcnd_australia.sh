export PREFIX=$1
export lib_dir=$2
#Get the Australian data
echo "Starting get-australia.sh" `date`
${lib_dir}get-australia.sh ${PREFIX}
echo "Starting gen-rawdata-australia.sh" `date`
${lib_dir}gen-rawdata-australia.sh ${PREFIX} upd
echo "Starting rf_australia2ghcnd.exe" `date`
${lib_dir}rf_australia2ghcnd.exe ${PREFIX}

