#Added raws archive to list of rawghcnd sources that are only updated in the por 02/27/2013
#raws data are updated for separate intevals by the por the upd processes 02/27/2013

basedir=$1
backupdir=$2

rm -f ${basedir}new-por.txt

cd ${backupdir}

old_size=0

if [ -s ghcnd-backup.tar ]
then
old_backup=`ls -l ghcnd-backup.tar`
#echo ${old_backup}
old_size=`echo ${old_backup} | gawk '{print $5}'`
fi

echo "Old ghcnd-backup.tar file size=${old_size}"

#wget -N -o wget-ghcnd-backup.log ftp://ncdcftp.ncdc.noaa.gov/pub/upload/7days/ghcnd-backup.tar
cp -p /ncdcftp/7days/ghcnd-backup.tar .

new_size=0
if [ -s ghcnd-backup.tar ]
then
new_backup=`ls -l ghcnd-backup.tar`
#echo ${new_backup}
new_size=`echo ${new_backup} | gawk '{print $5}'`
fi

echo "New ghcnd-backup.tar file size=${new_size}"

if [ "${new_backup}" = "${old_backup}" ]
then
echo "No new backup of por files available"
elif [ ${new_size} -lt ${old_size} ]
then
echo "New backup tar file size, ${new_size}, is smaller than the old backup size, ${old_size}"
else
echo "Replacing por files"
rm *.tar.gz
tar xf ghcnd-backup.tar
tar xzf ghcnd-por.tar.gz
if [ -s ghcnd_por ]
then
rm -rf ${basedir}ghcnd_por_old &
rm -rf ${basedir}ghcnd_all 
wait
mv ${basedir}ghcnd_por ${basedir}ghcnd_por_old
mv ghcnd_por ${basedir}
cp -rp ${basedir}ghcnd_por ${basedir}ghcnd_all &
else
echo "ghcnd_por directory was not untarred from ghcnd-backup.tar...terminating"
exit
fi
if [ -s ghcnd-inventory.txt ]
then
mv ghcnd-inventory.txt ${basedir}
fi

tar xzf input4sys.tar.gz
if [ -s input4sys ]
then
rm -r ${basedir}input4sys
mv input4sys ${basedir}
fi

tar xzf clim.tar.gz
if [ -s clim ]
then
rm -r ${basedir}clim
mv clim ${basedir}
fi

for src in `echo "3207 3210 australia eca gcos papercoop raws"` 

do

if [ "${src}" = "raws" ]
then
tar xzf ${src}-archive.tar.gz
else
tar xzf ${src}-rawghcnd.tar.gz
fi
if [ -s ${src} ]
then
rm -r ${basedir}${src}/rawghcnd
mv ${src} ${basedir}
fi

done

echo "new por" > ${basedir}new-por.txt

wait
fi
