#

export PREFIX="/home/mmenne/ghcnd2/"

export maxyr=2009

export ftpdatapath="/pub/data/ghcn/daily/test"

echo "Starting post format_check.exe" `date`
${PREFIX}format_check.exe post ${PREFIX}ghcnd-stations.txt ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

if [ "$(/usr/bin/du -b format_check_post.log | gawk '{print $1}')" -gt 0 ] 
then
echo "WARNING!!! Formatting error detected in post QC mode: Content of log file follows"
cat format_check_post.log
echo "Moving qc1out to qc1outold"
rm -rf ${PREFIX}qc1outold
mv ${PREFIX}qc1out ${PREFIX}qc1outold
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
echo "por" | ${PREFIX}ghcnd_archive.sh
echo "Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
exit
fi

echo "Starting check_size.sh for this por run" `date`
echo "${PREFIX}qc3out/" "${PREFIX}ghcnd_por/" | ${PREFIX}check_size.sh 

if [ -s ${PREFIX}qc3out ]
then
echo "WARNING!!! Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
echo "por" | ${PREFIX}ghcnd_archive.sh
exit
fi

echo "Starting make_gsn_hcn.exe" `date`
${PREFIX}make_gsn_hcn.exe $PREFIX por

echo "Starting ghcndinv.exe" `date`
${PREFIX}ghcndinv.exe ${PREFIX}ghcnd_por/ ${PREFIX}ghcnd-stations.txt

rm -r ${PREFIX}ghcnd_all
cp -rp ghcnd_por ghcnd_all

#echo "Starting ghcnd_ftp.sh" `date`
#echo "por" | ${PREFIX}ghcnd_ftp.sh

echo "Starting ghcnd_archive.sh" `date`
echo "por" | ${PREFIX}ghcnd_archive.sh

echo "Starting genclim.exe" `date`
${PREFIX}genclim.exe ${PREFIX} ${PREFIX}ghcnd-stations.txt

echo "Starting gen-timing-flags.sh" `date`
${PREFIX}gen-timing-flags.sh

echo "ghcnd_por.sh finshed at" `date`


