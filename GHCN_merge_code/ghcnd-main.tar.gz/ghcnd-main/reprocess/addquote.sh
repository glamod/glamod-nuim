#!/bin/sh
fn=$1
sed -i 's/,/","/g' ${fn}
sed -i 's/$/"/g' ${fn}
sed -i 's/^/"/' ${fn}
