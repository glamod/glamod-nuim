ls -1 /home/mmenne/ghcnd2/papercoop/rawdata/* | grep dly | sort -u > /home/mmenne/ghcnd2/papercoop-rawdata.test
