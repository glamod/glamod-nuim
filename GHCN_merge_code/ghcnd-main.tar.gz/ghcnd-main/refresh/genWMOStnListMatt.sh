gawk '$3=="N" && $5=="E" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, $2, $4, $6, substr($0,41,30))}' wmopub9vola.tmp > wmopub9vola.matt
gawk '$3=="N" && $5=="W" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, $2, -1.0*$4, $6, substr($0,41,30))}' wmopub9vola.tmp >> wmopub9vola.matt
gawk '$3=="S" && $5=="E" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, -1.0*$2, $4, $6, substr($0,41,30))}' wmopub9vola.tmp >> wmopub9vola.matt
gawk '$3=="S" && $5=="W" {printf("%s%9.4f%10.4f%7.1f %s\n", $1, -1.0*$2, -1.0*$4, $6, substr($0,41,30))}' wmopub9vola.tmp >> wmopub9vola.matt


