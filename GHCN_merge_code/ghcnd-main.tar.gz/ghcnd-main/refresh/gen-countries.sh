for i in `cat ghcnd-fips.txt`; do gawk 'BEGIN {FS="\t"} $3=="'$i'" {print $3,$1}' ng-ia.fips.raw >> ghcnd-countries.tmp; done
#Have two FIPS codes for Syria...need to remove.
