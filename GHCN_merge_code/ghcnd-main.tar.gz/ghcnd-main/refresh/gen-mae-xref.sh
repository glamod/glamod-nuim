./genWbanXref.exe mshr20071221.txt mae.station.list.prescreened.dupchecked mingle-list.txt mae.id.xref mae.id.noxref
./genDataXref.exe /home/mmenne/ghcnd/ ghcnd-stations.txt M /home/mmenne/ghcnd2/ghcnd_por/ mae.id.noxref mae.data.xref
cat mae.id.xref mae.data.xref > mae.xref
