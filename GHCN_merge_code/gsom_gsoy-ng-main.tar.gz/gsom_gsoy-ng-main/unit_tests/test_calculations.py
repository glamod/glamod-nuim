import polars as pl
from gsoy import YearlyCalculations
from itertools import repeat


'''
Test cases for YearlyCalculations.py

Functions take dataframe of all elements for that specific year

CLDD & HTDD elements are processed first and take all years worth of
info for that element.

If empty element data in dataframe, will be None
If empty data in flag data, will be ''
'''

def test_getFlag():
    # Test get blank flag
    flagList = []
    flagList.extend(repeat('I',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[-1],11)
    assert flag == ''

    # Test get one flag from ('I')
    flag = YearlyCalculations.getFlag(s,[0],11)
    assert flag == 'I'

    flag = YearlyCalculations.getFlag(s,[1],11)
    assert flag == ''

    # Test get one flag from ('X,I')
    flagList = []
    flagList.extend(repeat('X,I',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[0],11)
    assert flag == 'X'

    # Test get one flag from ('X,I'); different position
    flag = YearlyCalculations.getFlag(s,[1],11)
    assert flag == 'I'

    # Test get one flag from (',I')
    flagList = []
    flagList.extend(repeat('X,I',11))
    flagList.append(',X')
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[1],11)
    assert flag == 'X'

    flag = YearlyCalculations.getFlag(s,[0],11)
    assert flag == ''

    # Test get multiple flags from ()
    flagList = []
    flagList.extend(repeat('X,I',11))
    flagList.append(',')
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[1],11)
    assert flag == ''

    # Test get blank flag from multiple
    flagList = []
    flagList.extend(repeat(',,,7,3,3',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[3,4,5],11)
    assert flag == '7,3,3'

    flagList = []
    flagList.extend(repeat(',,,7,3,',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[3,4,5],11)
    assert flag == '7,3,'

    flagList = []
    flagList.extend(repeat(',,,7,3,',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[3,4,5],11)
    assert flag == '7,3,'

    flagList = []
    flagList.extend(repeat(',,,7,3',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[3,4,5],11)
    assert flag == '7,3,'

    flagList = []
    flagList.extend(repeat(',,,7',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[3,4,5],11)
    assert flag == '7,,'

    flagList = []
    flagList.extend(repeat(',,',12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[3,4,5],11)
    assert flag == ',,'

    flagList = []
    flagList.extend(repeat(None,12))
    s = pl.Series('attribute', flagList)
    flag = YearlyCalculations.getFlag(s,[3,4,5],11)
    assert flag == ',,'



def test_calcYearTotal():
    # Invalid data (skipValidCheckElem) (0 data points)
    elemStr = 'DYFG'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat(None,12))
    data = {elemStr: flagList, 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.String, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcYearTotal(df, elemStr)
    assert tupleUnderTest == None

    # Invalid data (< 12 data points) 
    elemStr = 'TAVG'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat('',12))
    data = {elemStr: ['-14.74',None,'1.69','9.35','13.28','21.04','22.93','20.77','17.52','15.65','4.17','-11.76'], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.String, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcYearTotal(df, elemStr)
    assert tupleUnderTest == None

    # DYFG w/ 1 data point
    elemStr = 'DYFG'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat(None,12))
    data = {elemStr: [None,None,None,None,None,None,None,None,None,'4',None,None], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.String, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcYearTotal(df, elemStr)
    assert tupleUnderTest.value == '4'
    assert tupleUnderTest.flag == ''  # Always a blank flag

    # DYFG w/ 12 data points
    data = {elemStr: ['3','1','2','3','12','4','2','4','1','4','7','4'], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.String, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcYearTotal(df, elemStr)
    assert tupleUnderTest.value == str(sum(map(int,data[elemStr])))
    assert tupleUnderTest.flag == ''

    # Normal element with summed
    elemStr = 'TAVG'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat(',7',12))
    data = {elemStr: ['-14.74','5.87','1.69','9.35','13.28','21.04','22.93','20.77','17.52','15.65','4.17','-11.76'], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.String, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcYearTotal(df, elemStr)
    assert tupleUnderTest.value == '8.81'
    assert tupleUnderTest.flag == '7'

    # Test element w/o taking mean
    elemStr = 'DX90'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat(',I',12))
    data = {elemStr: ['0','0','18','30','12','4','21','0','17','2','3','4'], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.String, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcYearTotal(df, elemStr)
    assert tupleUnderTest.value == str(sum(map(int,data[elemStr])))
    assert tupleUnderTest.flag == 'I'

'''
def test_calc_CLDD_HTDD():
    outputDict = dict(dict())
    headers = set()

    # Valid data CLDD (northHem == True), just one year to test
    elemStr = 'CLDD'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat('2,I',12))
    yearsStr = 'DATE'
    yearsList = ['1955-01-01','1955-02-01','1955-03-01','1955-04-01','1955-05-01','1955-06-01','1955-07-01','1955-08-01','1955-09-01','1955-10-01','1955-11-01','1955-12-01']
    data = {yearsStr: yearsList,
            elemStr: ['25.3','13.4','130.2','190.5','266.4','351.8','478','422.8','373.5','270','159.8','68.6'], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={yearsStr: pl.Date, elemStr: pl.String, flagStr: pl.String})
    df.head(5)
    YearlyCalculations.calc_CLDD_HTDD(df, ['1955'], elemStr, True, outputDict, headers)
    # 2750.3
'''
    
def test_calcSpecificMonth():
    # CDSD & HDSD elements

    # Invalid data
    elemStr = 'CDSD'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat('I',12))
    data = {elemStr: [25.3,38.7,168.9,None,625.8,977.6,1455.6,1878.4,2251.9,2521.9,2681.7,None], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.Float64, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcSpecificMonth(df, 'CDSD', True)
    assert tupleUnderTest == None

    # (CDSD & isNorthHem =True)
    elemStr = 'CDSD'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat('I',12))
    data = {elemStr: [25.3,38.7,168.9,359.4,625.8,977.6,1455.6,1878.4,2251.9,2521.9,2681.7,2750.3], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.Float64, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcSpecificMonth(df, 'CDSD', True)
    assert tupleUnderTest.value == str(2750.3)
    assert tupleUnderTest.flag == 'I'

    ## Empty Flag
    elemStr = 'CDSD'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat('',12))
    data = {elemStr: [25.3,38.7,168.9,359.4,625.8,977.6,1455.6,1878.4,2251.9,2521.9,2681.7,2750.3], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.Float64, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcSpecificMonth(df, 'CDSD', True)
    assert tupleUnderTest.value == str(2750.3)
    assert tupleUnderTest.flag == ''
    
    # CDSD & isNorthHem =False
    elemStr = 'CDSD'
    flagStr = elemStr+'_ATTRIBUTES'
    flagList = []
    flagList.extend(repeat('I',12))
    data = {elemStr: [25.3,38.7,168.9,359.4,625.8,977.6,1455.6,1878.4,2251.9,2521.9,2681.7,2750.3], 
            flagStr: flagList
        }
    df = pl.DataFrame(data, schema={elemStr: pl.Float64, flagStr: pl.String})
    tupleUnderTest = YearlyCalculations.calcSpecificMonth(df, 'CDSD', False)
    assert tupleUnderTest.value == str(977.6)
    assert tupleUnderTest.flag == 'I'

def test_getMin():
    data = {'CDSD': [ 3.2, 1.0, 2.4, 5.0, 1.0, 7.0 ]}
    df = pl.DataFrame(data)
    tupleUnderTest = YearlyCalculations.getMin(df, 'CDSD')
    assert tupleUnderTest.value == 1.0
    assert tupleUnderTest.valueIndex == 4
    assert tupleUnderTest.sameValueFound == True

'''
def test_getMaxWithTrace():
    data = {'CDSD': [ 0.0, -1.0, -2.0, -3.0 ], 
            'CDSD_ATTRIBUTES': ['3,,4,03,X', ',,4,32,,', ',,,01,X', '1,,4,01,,']}
    df = pl.DataFrame(data)
    tupleUnderTest = YearlyCalculations.getMaxWithTrace(df, 'CDSD')
    assert tupleUnderTest.value == 0.0
    assert tupleUnderTest.valueIndex == 0
    assert tupleUnderTest.sameValueFound == False
    assert tupleUnderTest.traceFound == False
'''