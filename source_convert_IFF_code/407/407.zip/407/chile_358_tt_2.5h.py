#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'


os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera")

df=pd.read_excel("Faro de la Punta de Caldera(1870).xlsx",skiprows = 3,sheet_name="1870") 
df["Source_ID"]="358"
df["Station_ID"]="358-00002"
df["Alias_station_name"]="Null"
df["Station_name"]="aro de la Punta de Caldera "
df["Latitude"]= "-27.0512"
df["Longitude"]= "-70.8517"
df["Elevation"]= "25.5"
df['Year'] = df["ΥΕΑR"]
df['Month'] = df['M0NTH'] 
df['Day'] = df['DAY']
df["Hour"]="2"
df["Minute"]="30"
df["Source_QC_flag"]=""
df['Original_observed_value_units']="C"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''

df["Observed_value"]=df["2 1/2 h_t"]
df['Original_observed_value']=df["2 1/2 h_t"]
#df["Observed_value"]=df["TERMOMETRO 2 1/2 h."]
#df['Original_observed_value']=df["TERMOMETRO 2 1/2 h."]

df.dropna(subset = ["Observed_value"], inplace=True)
df = df.astype({"Year": int})
df = df.astype({"Month": int})
df = df.astype({"Day": int})
#df = df.astype({"Hour": int})
#df = df.astype({"Minute": int})
#df.fillna("NULL",inplace=True)
#df = df.fillna()
##df.drop(df.tail(4).index,inplace=True)
#df['Year'].replace('', np.nan, inplace=True)
#df.dropna(subset=['Year'], inplace=True)

#df = df.astype({"Year": int})
#df = df.astype({"Month": int})
##df = df.astype({"Day": int})
#df = df.astype({"Hour": int})

#remove rows with  o obervaed values

df["Observed_value"] = pd.to_numeric(df["Observed_value"],errors='coerce')
#df = df.astype({"Observed_value": int})
#df['Observed_value'].astype(str).astype(int)
#df["Observed_value"]= df["Observed_value"]-32
#df["Observed_value"]= df["Observed_value"]*5
#df["Observed_value"]= df["Observed_value"]/9
#df['Observed_value']=df["Observed_value"]* 1.3332239 
df["Observed_value"]= df["Observed_value"].round(1)
df['Observed_value'].replace('', np.nan, inplace=True)
df.dropna(subset=['Observed_value'], inplace=True)

df["Timestamp2"] = df["Year"].map(str) + "-" + df["Month"].map(str)+ "-" + df["Day"].map(str)  
df["Timestamp"] = df["Timestamp2"].map(str)+ " " + df["Hour"].map(str)+":"+df["Minute"].map(str) 


df.drop(columns=["Timestamp2"])
df['Timestamp'] =  pd.to_datetime(df['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df['Timestamp'] = df['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')
df['Year'] = df['Timestamp'].dt.year 
df['Month'] = df['Timestamp'].dt.month 
df['Day'] = df['Timestamp'].dt.day 
df['Hour'] = df['Timestamp'].dt.hour 
df['Minute'] = df['Timestamp'].dt.minute
df['Seconds'] = df['Timestamp'].dt.second
    

df['Minute'] = df['Minute'].astype('str')
df.Minute[df.Minute == "0"] = "00"
df= df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]


df['Original_observed_value']= round(df['Original_observed_value'],2)
df['Observed_value']= round(df['Observed_value'],1)

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera/sef/tt")

df.to_csv("358-00002_temperature_358_1870_2.csv", index=False, sep=",")


import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'


os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera")

df=pd.read_excel("Faro de la Punta de Caldera(1870).xlsx",skiprows = 3,sheet_name="1870") 
df["Source_ID"]="358"
df["Station_ID"]="358-00002"
df["Alias_station_name"]="Null"
df["Station_name"]="aro de la Punta de Caldera "
df["Latitude"]= "-27.0512"
df["Longitude"]= "-70.8517"
df["Elevation"]= "25.5"
df['Year'] = df["ΥΕΑR"]
df['Month'] = df['M0NTH'] 
df['Day'] = df['DAY']
df["Hour"]="2"
df["Minute"]="30"
df["Source_QC_flag"]=""
df['Original_observed_value_units']="C"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''

df["Observed_value"]=df["9 h_t"]
df["Original_observed_value"]=df["9 h_t"]
#df["Observed_value"]=df["TERMOMETRO 2 1/2 h."]
#df['Original_observed_value']=df["TERMOMETRO 2 1/2 h."]

df.dropna(subset = ["Observed_value"], inplace=True)
df = df.astype({"Year": int})
df = df.astype({"Month": int})
df = df.astype({"Day": int})
#df = df.astype({"Hour": int})
#df = df.astype({"Minute": int})
#df.fillna("NULL",inplace=True)
#df = df.fillna()
##df.drop(df.tail(4).index,inplace=True)
#df['Year'].replace('', np.nan, inplace=True)
#df.dropna(subset=['Year'], inplace=True)

#df = df.astype({"Year": int})
#df = df.astype({"Month": int})
##df = df.astype({"Day": int})
#df = df.astype({"Hour": int})

#remove rows with  o obervaed values

df["Observed_value"] = pd.to_numeric(df["Observed_value"],errors='coerce')
#df = df.astype({"Observed_value": int})
#df['Observed_value'].astype(str).astype(int)
#df["Observed_value"]= df["Observed_value"]-32
#df["Observed_value"]= df["Observed_value"]*5
#df["Observed_value"]= df["Observed_value"]/9
#df['Observed_value']=df["Observed_value"]* 1.3332239 
df["Observed_value"]= df["Observed_value"].round(1)
df['Observed_value'].replace('', np.nan, inplace=True)
df.dropna(subset=['Observed_value'], inplace=True)

df["Timestamp2"] = df["Year"].map(str) + "-" + df["Month"].map(str)+ "-" + df["Day"].map(str)  
df["Timestamp"] = df["Timestamp2"].map(str)+ " " + df["Hour"].map(str)+":"+df["Minute"].map(str) 


df.drop(columns=["Timestamp2"])
df['Timestamp'] =  pd.to_datetime(df['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df['Timestamp'] = df['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')
df['Year'] = df['Timestamp'].dt.year 
df['Month'] = df['Timestamp'].dt.month 
df['Day'] = df['Timestamp'].dt.day 
df['Hour'] = df['Timestamp'].dt.hour 
df['Minute'] = df['Timestamp'].dt.minute
df['Seconds'] = df['Timestamp'].dt.second
    

df['Minute'] = df['Minute'].astype('str')
df.Minute[df.Minute == "0"] = "00"
df= df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]


df['Original_observed_value']= round(df['Original_observed_value'],2)
df['Observed_value']= round(df['Observed_value'],1)

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera/sef/tt")

df.to_csv("358-00002_temperature_358_1870_9.csv", index=False, sep=",")

import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'


os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera")

df=pd.read_excel("Faro de la Punta de Caldera(1870).xlsx",skiprows = 3,sheet_name="1870") 
df["Source_ID"]="358"
df["Station_ID"]="358-00002"
df["Alias_station_name"]="Null"
df["Station_name"]="aro de la Punta de Caldera "
df["Latitude"]= "-27.0512"
df["Longitude"]= "-70.8517"
df["Elevation"]= "25.5"
df['Year'] = df["ΥΕΑR"]
df['Month'] = df['M0NTH'] 
df['Day'] = df['DAY']
df["Hour"]="2"
df["Minute"]="30"
df["Source_QC_flag"]=""
df['Original_observed_value_units']="C"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''


df["Observed_value"]=df["21 h_t"]
df["Original_observed_value"]=df["21 h_t"]
#df["Observed_value"]=df["TERMOMETRO 2 1/2 h."]
#df['Original_observed_value']=df["TERMOMETRO 2 1/2 h."]

df.dropna(subset = ["Observed_value"], inplace=True)
df = df.astype({"Year": int})
df = df.astype({"Month": int})
df = df.astype({"Day": int})
#df = df.astype({"Hour": int})
#df = df.astype({"Minute": int})
#df.fillna("NULL",inplace=True)
#df = df.fillna()
##df.drop(df.tail(4).index,inplace=True)
#df['Year'].replace('', np.nan, inplace=True)
#df.dropna(subset=['Year'], inplace=True)

#df = df.astype({"Year": int})
#df = df.astype({"Month": int})
##df = df.astype({"Day": int})
#df = df.astype({"Hour": int})

#remove rows with  o obervaed values

df["Observed_value"] = pd.to_numeric(df["Observed_value"],errors='coerce')
#df = df.astype({"Observed_value": int})
#df['Observed_value'].astype(str).astype(int)
#df["Observed_value"]= df["Observed_value"]-32
#df["Observed_value"]= df["Observed_value"]*5
#df["Observed_value"]= df["Observed_value"]/9
#df['Observed_value']=df["Observed_value"]* 1.3332239 
df["Observed_value"]= df["Observed_value"].round(1)
df['Observed_value'].replace('', np.nan, inplace=True)
df.dropna(subset=['Observed_value'], inplace=True)

df["Timestamp2"] = df["Year"].map(str) + "-" + df["Month"].map(str)+ "-" + df["Day"].map(str)  
df["Timestamp"] = df["Timestamp2"].map(str)+ " " + df["Hour"].map(str)+":"+df["Minute"].map(str) 


df.drop(columns=["Timestamp2"])
df['Timestamp'] =  pd.to_datetime(df['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df['Timestamp'] = df['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')
df['Year'] = df['Timestamp'].dt.year 
df['Month'] = df['Timestamp'].dt.month 
df['Day'] = df['Timestamp'].dt.day 
df['Hour'] = df['Timestamp'].dt.hour 
df['Minute'] = df['Timestamp'].dt.minute
df['Seconds'] = df['Timestamp'].dt.second
    

df['Minute'] = df['Minute'].astype('str')
df.Minute[df.Minute == "0"] = "00"
df= df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]


df['Original_observed_value']= round(df['Original_observed_value'],2)
df['Observed_value']= round(df['Observed_value'],1)

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera/sef/tt")

df.to_csv("358-00002_temperature_358_1870_21.csv", index=False, sep=",")






