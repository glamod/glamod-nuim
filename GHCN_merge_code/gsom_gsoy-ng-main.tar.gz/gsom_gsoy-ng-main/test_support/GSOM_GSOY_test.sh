#! /bin/bash

# Author: Emily Cox
# Date 7/17/2024
# Summary: Shell script to test output of refactored code
#          against orginal code to ensure output remains
#          the same during development.
#
# This is assuming unix based system or git for windows (git bash).
# Also assuming that data is in correct files.
# Will only test .csv output; ignoring other files.
#
# cmd args: <no args> - Will run both tests 
#             gsom    - Will only run GSOM test
#             gsoy    - Will only run GSOY test
#
# ex. usage: $ ./GSOM_GSOY_test.sh gsom
#

# Where data lives
testResultsOutput="/c/NCEI_Data/test_results.txt"

gsom_data_expected=/c/data/ops/gsom_gsoy_new/output-monthly-csv/
gsom_data_actual="/c/NCEI_Data/GSOM/data-output/"

gsoy_data_expected=/c/data/ops/gsom_gsoy_new/output-yearly-csv/
gsoy_data_actual="/c/NCEI_Data/GSOY/data-output/"

# clear out old file
echo "" > "$testResultsOutput"

# Figure out what test to do
gsomTest=true
gsoyTest=true

if [[ "$1" == "gsom" ]]; then
	gsoyTest=false
elif [[ "$1" == "gsoy" ]]; then
	gsomTest=false
fi

# --------------------------------------------------------------------------
# Testing output of GSOM
# --------------------------------------------------------------------------

if [[ "$gsomTest" = true ]]; then

echo "-----------------------------------------------------------------------------" >> "$testResultsOutput"
echo "Testing output of GSOM" >> "$testResultsOutput"
echo "-----------------------------------------------------------------------------" >> "$testResultsOutput"
echo "" >> "$testResultsOutput"
echo "----- Testing GSOM --------"

GSOM_FilesCount=$(find "$gsom_data_actual" -maxdepth 1 -type f -name '*.csv' -printf x | wc -c)
echo "GSOM: $GSOM_FilesCount output files"
echo "GSOM: $GSOM_FilesCount output files" >> "$testResultsOutput"
diff -r -x '*.mly' $gsom_data_expected "$gsom_data_actual" >> "$testResultsOutput"

if [[ $? == 0 ]] && [[ $GSOM_FilesCount != 0 ]]; then
    echo "GSOM: Files Match. PASS"
    echo "GSOM: Files Match. PASS" >> "$testResultsOutput"
	echo "" >> "$testResultsOutput"
else
    echo "GSOM: Files Don't Match. FAIL"
	#echo "" >> "$testResultsOutput"
	echo "GSOM: Files Don't Match. FAIL" >> "$testResultsOutput"
	echo "" >> "$testResultsOutput"
fi

fi

# --------------------------------------------------------------------------
# Testing output of GSOY
# --------------------------------------------------------------------------

if [[ "$gsoyTest" = true ]]; then

echo "-----------------------------------------------------------------------------" >> "$testResultsOutput"
echo "Testing output of GSOY" >> "$testResultsOutput"
echo "-----------------------------------------------------------------------------" >> "$testResultsOutput"
echo "" >> "$testResultsOutput"
echo "----- Testing GSOY --------"

GSOY_FilesCount=$(find "$gsoy_data_actual" -maxdepth 1 -type f -name '*.csv' -printf x | wc -c)
echo "GSOY: $GSOY_FilesCount output files"
echo "GSOY: $GSOY_FilesCount output files" >> "$testResultsOutput"
diff -r -x '*.dat' $gsoy_data_expected "$gsoy_data_actual" >> "$testResultsOutput"

if [[ $? == 0 ]]  && [[ $GSOY_FilesCount != 0 ]]; then
    echo "GSOY: Files Match. PASS"
    echo "GSOY: Files Match. PASS" >> "$testResultsOutput"
else
    echo "GSOY: Files Don't Match. FAIL"
	#echo "" >> "$testResultsOutput"
	echo "GSOY: Files Don't Match. FAIL" >> "$testResultsOutput"
fi

fi