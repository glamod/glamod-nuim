#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Constitucion")

df=pd.read_excel("Constitucion(1869).xlsx",skiprows = 1,sheet_name="1869") 
df["Source_ID"]="358"
df["Station_ID"]="358-00001"
df["Alias_station_name"]="Null"
df["Station_name"]="Constitucion"
df["Latitude"]= "-35.3"
df["Longitude"]= "-72.4"
df["Elevation"]= "14"
df['Year'] = df['ΥΕΑR']
df['Month'] = df['M0NTH'] 
df['Day'] = df['DAY']
df["HOUR"]=df["HOUR"]
df['HOUR'] = df['HOUR'].astype('str')

df[['Hour', 'Minute']] = df["HOUR"].str.split('.', expand=True)
df['Minute'] = df['Minute'].astype('str')
df.Minute[df.Minute == "0"] = "00"
df.Minute[df.Minute == "5"] = "30"

df["Alias_station_name"]=df["Alias_station_name"]
df["Source_QC_flag"]=""
df['Original_observed_value_units']="F"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''
df["Observed_value"]=df["TEMP"]
df['Original_observed_value']=df["TEMP"]
df = df.dropna(subset=['Observed_value'])
df = df.astype({"Year": int})
df = df.astype({"Month": int})
df = df.astype({"Day": int})
#df = df.astype({"Hour": int})
#df.fillna("NULL",inplace=True)
#df = df.fillna()
##df.drop(df.tail(4).index,inplace=True)
#df['Year'].replace('', np.nan, inplace=True)
#df.dropna(subset=['Year'], inplace=True)

#df = df.astype({"Year": int})
#df = df.astype({"Month": int})
##df = df.astype({"Day": int})
#df = df.astype({"Hour": int})

#remove rows with  o obervaed values

df["Observed_value"] = pd.to_numeric(df["Observed_value"],errors='coerce')
df = df.astype({"Observed_value": int})
df['Observed_value'].astype(str).astype(int)
df["Observed_value"]= df["Observed_value"]-32
df["Observed_value"]= df["Observed_value"]*5
df["Observed_value"]= df["Observed_value"]/9
#df['Observed_value']=df["Observed_value"]* 33.86389
df["Observed_value"]= df["Observed_value"].round(2)
df['Observed_value'].replace('', np.nan, inplace=True)
df.dropna(subset=['Observed_value'], inplace=True)


df["Timestamp2"] = df["Year"].map(str) + "-" + df["Month"].map(str)+ "-" + df["Day"].map(str)  
df["Timestamp"] = df["Timestamp2"].map(str)+ " " + df["Hour"].map(str)+":"+df["Minute"].map(str) 
#join offset to sttaion id for tiemstamp conversion
df.drop(columns=["Timestamp2"])

df= df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2", "Timestamp"]]

df['Timestamp'] =  pd.to_datetime(df['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df['Timestamp'] = df['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')
df['Year'] = df['Timestamp'].dt.year 
df['Month'] = df['Timestamp'].dt.month 
df['Day'] = df['Timestamp'].dt.day 
df['Hour'] = df['Timestamp'].dt.hour 
df['Minute'] = df['Timestamp'].dt.minute
df['Seconds'] = df['Timestamp'].dt.second
    
##delete unwanted columns 
df = df.drop(columns="Timestamp")
df['Minute'] = df['Minute'].astype('str')
df.Minute[df.Minute == "0"] = "00"
df= df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]
                 

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Constitucion/sef/tt")
df.to_csv("358-00001_temperature_358.csv", index=False, sep=",")

#############################

##
