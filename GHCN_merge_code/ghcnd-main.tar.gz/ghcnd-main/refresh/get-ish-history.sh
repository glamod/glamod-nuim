path=$1
cp -p ${path}ish-history.txt ${path}ish-history.txt.old
wget -N -P${path} ftp://ftp0.ncdc.noaa.gov/pub/data/noaa/ish-history.txt
