# Written by Menne May 2011

PREFIX=$1
echo "Base path = "${PREFIX}
if [ -s $PREFIX/3207/archive ]
then
rm -rf ${PREFIX}3207/rawghcnd
mkdir ${PREFIX}3207/rawghcnd
fi
for i in `cut -c1-11 ${PREFIX}/3207/archive/* | sort -u`; do grep -h "^$i" ${PREFIX}/3207/archive/* >> ${PREFIX}/3207/rawghcnd/$i.dly; done
