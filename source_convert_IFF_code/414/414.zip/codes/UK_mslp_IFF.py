#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
MSL pressure IFF code for ALL stations
One output file per station
"""

import pandas as pd
import os
import re
import glob

# =========================================
# SETTINGS
# =========================================
SOURCE_ID = "414"

STATIONDATA_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/midas_uk-hourly-weather-obs_v202507_FLAT/midas_uk-hourly-weather-obs_v202507/stationdata"

OUTDIR = os.path.join(STATIONDATA_DIR, "IFF_msl_pressure_ALL_STATIONS")
os.makedirs(OUTDIR, exist_ok=True)

# OPTIONAL: clear old outputs
for old_file in glob.glob(os.path.join(OUTDIR, "*.psv")):
    os.remove(old_file)

for old_file in glob.glob(os.path.join(OUTDIR, "*.csv")):
    os.remove(old_file)

# =========================================
# VARIABLE SETTINGS
# =========================================
POSSIBLE_PRESSURE_COLS = [
    "msl_pressure",
    "msl_pres",
    "prmsl",
    "mean_sea_level_pressure",
    "mean_sea_level_pres"
]

UNIT = "hPa"

# =========================================
# HELPERS
# =========================================
def clean_value(x):
    if pd.isna(x):
        return None

    x = str(x).strip()

    if x in ["", "NA", "N/A", "NaN", "nan", "NULL", "null", "--", "-", ".", "-.", "*"]:
        return None

    x = re.sub(r"[^0-9.\-]", "", x)

    if x in ["", ".", "-", "-."]:
        return None

    try:
        val = float(x)
    except Exception:
        return None

    if val in [-9999, -999, -99]:
        return None

    return val


def get_csv_cell(line, idx):
    parts = line.strip().split(",")
    return parts[idx].strip() if idx < len(parts) else ""


def get_station_name(filename, station_id):
    base = os.path.basename(filename).replace(".csv", "")
    pattern = rf"_{station_id}_(.*?)_qcv"
    m = re.search(pattern, base)

    if m:
        return m.group(1).replace("_", "-").title()

    return station_id


def find_column(df, possible_cols):
    for col in possible_cols:
        if col in df.columns:
            return col
    return None


def parse_midas_datetime_auto(series, filename=""):
    s = series.astype(str).str.strip()

    formats = [
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%d/%m/%Y %H:%M:%S",
        "%d/%m/%Y %H:%M",
        "%d/%m/%Y",
        "%Y-%m-%d",
    ]

    best_dt = None
    best_valid = -1

    for fmt in formats:
        dt = pd.to_datetime(s, format=fmt, errors="coerce")
        valid = dt.notna().sum()

        if valid > best_valid:
            best_valid = valid
            best_dt = dt

    if best_valid == 0:
        dt_dayfirst = pd.to_datetime(s, errors="coerce", dayfirst=True)
        dt_monthfirst = pd.to_datetime(s, errors="coerce", dayfirst=False)

        best_dt = dt_dayfirst if dt_dayfirst.notna().sum() >= dt_monthfirst.notna().sum() else dt_monthfirst

    return best_dt


# =========================================
# FIND ALL STATIONS
# =========================================
station_folders = sorted([
    f for f in glob.glob(os.path.join(STATIONDATA_DIR, "*"))
    if os.path.isdir(f) and os.path.basename(f).isdigit()
])

print(f"Total stations found: {len(station_folders)}")

failed_files = []
saved_station_count = 0

# =========================================
# LOOP THROUGH ALL STATIONS
# =========================================
for station_folder in station_folders:

    station_id = os.path.basename(station_folder)
    csv_files = sorted(glob.glob(os.path.join(station_folder, "*.csv")))

    print("\n==============================")
    print(f"Station: {station_id}")

    if not csv_files:
        continue

    station_data = []

    for FILE in csv_files:

        try:
            with open(FILE, "r", encoding="utf-8", errors="ignore") as f:
                raw_lines = [next(f).rstrip("\n") for _ in range(283)]
        except:
            failed_files.append([station_id, FILE, "Header read failed"])
            continue

        lat = pd.to_numeric(get_csv_cell(raw_lines[16], 2), errors="coerce")
        lon = pd.to_numeric(get_csv_cell(raw_lines[16], 3), errors="coerce")
        elev = pd.to_numeric(get_csv_cell(raw_lines[17], 2), errors="coerce")

        station_name = get_station_name(FILE, station_id)

        try:
            df = pd.read_csv(FILE, skiprows=283)
        except:
            failed_files.append([station_id, FILE, "CSV read failed"])
            continue

        df.columns = df.columns.astype(str).str.strip()

        pressure_col = find_column(df, POSSIBLE_PRESSURE_COLS)

        if pressure_col is None:
            failed_files.append([station_id, FILE, "Pressure column missing"])
            continue

        date_col = None
        for c in ["ob_time", "ob_end_time", "time", "date", "Date"]:
            if c in df.columns:
                date_col = c
                break

        if date_col is None:
            failed_files.append([station_id, FILE, "Date column missing"])
            continue

        df["Date"] = parse_midas_datetime_auto(df[date_col])

        df["Year"] = df["Date"].dt.year.astype("Int64")
        df["Month"] = df["Date"].dt.month.astype("Int64")
        df["Day"] = df["Date"].dt.day.astype("Int64")
        df["Hour"] = df["Date"].dt.hour.fillna(0).astype("Int64")
        df["Minute"] = df["Date"].dt.minute.fillna(0).astype("Int64")

        df["Observed_value"] = df[pressure_col].apply(clean_value)
        df["Observed_value"] = pd.to_numeric(df["Observed_value"], errors="coerce").round(1)

        df["Original_observed_value"] = df["Observed_value"]
        df["Original_observed_value_units"] = UNIT

        df["Source_ID"] = SOURCE_ID
        df["Station_ID"] = station_id
        df["Station_name"] = station_name

        df["Latitude"] = round(float(lat), 3) if pd.notna(lat) else ""
        df["Longitude"] = round(float(lon), 3) if pd.notna(lon) else ""
        df["Elevation"] = int(float(elev)) if pd.notna(elev) else ""

        df = df.dropna(subset=["Observed_value", "Year", "Month", "Day"])

        if len(df) == 0:
            continue

        df = df[[
            "Source_ID", "Station_ID", "Station_name",
            "Year", "Month", "Day", "Hour", "Minute",
            "Latitude", "Longitude", "Elevation",
            "Observed_value",
            "Original_observed_value", "Original_observed_value_units"
        ]]

        station_data.append(df)

    if not station_data:
        continue

    station_df = pd.concat(station_data, ignore_index=True)

    station_df = station_df.sort_values(
        by=["Year", "Month", "Day", "Hour", "Minute"]
    )

    station_df = station_df.fillna("")

    outname = f"{station_id}_msl_pressure_{SOURCE_ID}.psv"
    station_df.to_csv(os.path.join(OUTDIR, outname), sep="|", index=False)

    saved_station_count += 1
    print(f"Saved {outname}")


# =========================================
# LOG + SUMMARY
# =========================================
if failed_files:
    pd.DataFrame(failed_files, columns=["Station_ID", "File", "Reason"]) \
        .to_csv(os.path.join(OUTDIR, "failed_msl_pressure_files_ALL.csv"), index=False)

print("\nDONE")
print(f"Stations processed: {len(station_folders)}")
print(f"Stations saved: {saved_station_count}")
print(f"Output: {OUTDIR}")