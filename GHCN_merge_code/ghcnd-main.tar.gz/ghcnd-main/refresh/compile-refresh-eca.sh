#!/bin/sh
# compile programs required by refresh-unspecified-with-list.sh.
# created 6 October 2010 by Imke Durre

compile_dir=$1 # directory where source code is located and executables will be placed
mod_file=$2 # path and name of module to use

lf95path=/usr/local/lf6481/bin/

${lf95path}lf95 ${mod_file} ${compile_dir}gen-eca-stninfo.f95 -o ${compile_dir}gen-eca-stninfo.exe --ap
${lf95path}lf95 ${mod_file} ${compile_dir}pre_screen.f95 -o ${compile_dir}pre_screen.exe --ap
${lf95path}lf95 ${mod_file} ${compile_dir}intrasource_dupchk.f95 -o ${compile_dir}intrasource_dupchk.exe --ap
${lf95path}lf95 ${mod_file} ${compile_dir}strip_source.f95 -o ${compile_dir}strip_source.exe 
${lf95path}lf95 ${mod_file} ${refresh_dir}mingle.f95 -o ${refresh_dir}mingle.exe 
${lf95path}lf95 ${mod_file} ${compile_dir}gen-coord-xref.f95 -o ${compile_dir}gen-coord-xref.exe 
${lf95path}lf95 ${mod_file} ${compile_dir}gen-data-xref.f95 -o ${compile_dir}gen-data-xref.exe --ap
${lf95path}lf95 ${mod_file} ${compile_dir}gen-meta-xref.f95 -o ${compile_dir}gen-meta-xref.exe 
${lf95path}lf95 ${mod_file} ${compile_dir}add_stns.f95 -o ${compile_dir}add_stns.exe 
${lf95path}lf95 ${mod_file} ${compile_dir}setGSNfield.f95 -o ${compile_dir}setGSNfield.exe 

