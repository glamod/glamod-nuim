#

export PREFIX=$1

run_status=$2
#"sync" or "test"

export timestamp=2019010917

# MINGLE THE DATA
echo "starting mingle.exe" `date`
${PREFIX}mingle.exe $PREFIX ${PREFIX}input4sys/mingle-list.txt

# APPLY DATZILLA TICKETS EXCEPT FOR "UNFLAG" CASES
echo "Starting datzilla.exe with pre" `date`
${PREFIX}datzilla.exe pre ${PREFIX}datzilla/datzilla.rawdata.pre.inv ${PREFIX} ${PREFIX}datzilla/rawdata/ ${PREFIX}mingled/ ${PREFIX}datzillaoutpre/

#COPY DATZILLA OUTPUT FILES TO MINGLED DIRECTORY
cp -p ${PREFIX}datzillaoutpre/*.dly ${PREFIX}mingled

# PRE FORMAT CHECK
echo "Starting pre format_check.exe" `date`
${PREFIX}format_check.exe pre ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}mingled/ ${PREFIX}rawghcnd/ ${PREFIX}format_check_pre.log

# QC1, QC2 and QC3

echo "Starting qc1.exe" `date`
${PREFIX}qc1.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt M por

echo "Starting rf_stn2time.exe" `date`
${PREFIX}rf_stn2time.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt

echo "Starting qc2.exe" `date`
${PREFIX}qc2.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt M por

echo "Starting qc3.exe" `date`
${PREFIX}qc3.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt por

# APPLY DATZILLA TICKETS FOR "UNFLAG" CASES
echo "Starting datzilla.exe with post" `date`
${PREFIX}datzilla.exe post ${PREFIX}datzilla/datzilla.rawdata.post.inv ${PREFIX} ${PREFIX}datzilla/rawdata/ ${PREFIX}qc3out/ ${PREFIX}datzillaoutpost/

#COPY DATZILLA OUTPUT FILES TO QC3OUT DIRECTORY
cp -p ${PREFIX}datzillaoutpost/*.dly ${PREFIX}qc3out


echo "Starting post format_check.exe" `date`
${PREFIX}format_check.exe post ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

if [ "$(/usr/bin/du -b format_check_post.log | gawk '{print $1}')" -gt 0 ] 
then
echo "WARNING!!! Formatting error detected in post QC mode: Content of log file follows"
cat format_check_post.log
echo "Moving qc1out to qc1outold"
rm -rf ${PREFIX}qc1outold
mv ${PREFIX}qc1out ${PREFIX}qc1outold
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh por no 
echo "Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
exit
fi

echo "Starting check_size.sh for this por run" `date`
echo "${PREFIX}qc3out/" "${PREFIX}ghcnd_por/" | ${PREFIX}check_size.sh 

if [ -s ${PREFIX}qc3out ]
then
echo "WARNING!!! Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh por no 
exit
fi

echo "Starting make_gsn_hcn.exe" `date`
${PREFIX}make_gsn_hcn.exe $PREFIX por

echo "Starting ghcndinv.exe" `date`
${PREFIX}ghcndinv.exe ${PREFIX} ${PREFIX}ghcnd_por/ ${PREFIX}input4sys/ghcnd-stations.txt

rm -r ${PREFIX}ghcnd_all
cp -rp ghcnd_por ghcnd_all

vernum=`cat ${PREFIX}input4sys/version-number.txt`

echo $vernum-por-$timestamp > ${PREFIX}input4sys/por-version.txt
echo "The current version of GHCN Daily is $vernum-por-$timestamp (i.e, a period of record reprocess that started at $timestamp [yyyymmddhh] UTC; yyyy=year; mm=month; dd=day; hh=hour)." > ${PREFIX}ghcnd-version.txt

echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh por ${run_status} /home/mmenne/backup/ghcnd2/

echo "Starting genclim.exe" `date`
${PREFIX}genclim.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations.txt

if [ "${run_status}" = "sync" ]
then
echo "Starting gen-info2sync-with-upd.sh" `date`
${PREFIX}gen-info2sync-with-upd.sh ${PREFIX} /home/mmenne/backup/ghcnd2/
fi

echo "ghcnd_por.sh finished at" `date`


