import logging
import boto3
import awswrangler as wr
import duckdb
import pandas as pd
import os
from typing import List, Tuple, Dict, Any

# --- CONFIG ---
INPUT_BUCKET = "ghcnh-iff-parquet"
PRIORITY_CSV = "ghcnh-mingle-list.csv"
CHUNK_SIZE = 1
MANIFEST_S3_PATH = "s3://ghcnh-mingled/manifests/ghcnh-file-manifest.parquet"

# --- LOGGING ---
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# --- HELPER FUNCTIONS ---
def setup_duckdb_s3():
    con = duckdb.connect(database=":memory:")
    con.execute("SET home_directory='/tmp'")
    con.execute("INSTALL httpfs; LOAD httpfs;")
    sess = boto3.Session()
    creds = sess.get_credentials().get_frozen_credentials()
    con.execute(f"SET s3_region='{sess.region_name}';")
    con.execute(f"SET s3_access_key_id='{creds.access_key}';")
    con.execute(f"SET s3_secret_access_key='{creds.secret_key}';")
    if creds.token:
        con.execute(f"SET s3_session_token='{creds.token}';")
    return con

def load_priority_map(path: str) -> Dict[str, List[Tuple[str, str]]]:
    df = pd.read_csv(
        path, header=None, names=['station','source_station','priority','source_id'],
        dtype={'station': str, 'source_station': str, 'priority': int, 'source_id': str}
    )
    df[['station','source_station']] = df[['station','source_station']].apply(lambda s: s.str.strip())
    df.sort_values('priority', inplace=True)
    mapping = df.groupby('station')[['source_id','source_station']].apply(lambda g: list(zip(g.source_id, g.source_station))).to_dict()
    logger.info(f"Loaded priority map for {len(mapping)} stations from {path}")
    return mapping


def get_station_period_of_record(station: str, priority_list: List[Tuple[str, str]]) -> Tuple[Any, Any]:
    logger.info(f"Determining period of record for station {station} using manifest...")
    con = setup_duckdb_s3()
    try:
        priority_df = pd.DataFrame(priority_list, columns=['source_id', 'source_station'])
        con.register('priority_df_raw', priority_df)

        file_list_query = f"""
            WITH priority_df AS (
                SELECT 
                    TRIM(CAST(source_id AS VARCHAR)) AS source_id, 
                    TRIM(CAST(source_station AS VARCHAR)) AS source_station 
                FROM priority_df_raw
            )
            SELECT m.s3_uri
            FROM read_parquet('{MANIFEST_S3_PATH}') AS m
            INNER JOIN priority_df AS p 
                ON TRIM(m.source_id) = p.source_id 
               AND TRIM(m.source_station) = p.source_station
        """
        relevant_files_df = con.execute(file_list_query).df()
        
        if relevant_files_df.empty:
            logger.warning(f"No files found in manifest for station {station} after join. Check for data type or value mismatches.")
            return None, None

        relevant_uris = relevant_files_df['s3_uri'].tolist()

        logger.info(f"--- Starting Pre-flight Data-Check for station {station} ---")
        total_record_count = 0
        valid_timestamp_count = 0
        
        for uri in relevant_uris:
            try:
                # --- MODIFIED: This check now perfectly mirrors the downstream processing script's filter ---
                count_result = con.execute(f"""
                    SELECT COUNT(*)
                    FROM read_parquet('{uri}')
                    WHERE try_cast(Hour AS INTEGER) BETWEEN 0 AND 23
                      AND try_cast(Minute AS INTEGER) BETWEEN 0 AND 59
                """).fetchone()
                
                total_count_result = con.execute(f"SELECT COUNT(*) FROM read_parquet('{uri}')").fetchone()

                if count_result and count_result[0] is not None:
                    valid_timestamp_count += count_result[0]
                
                if total_count_result and total_count_result[0] is not None:
                    total_record_count += total_count_result[0]

            except Exception as e:
                logger.warning(f"Pre-flight check could not process file '{uri}'. Error: {e}")
                continue
        
        # --- MODIFIED: Updated log message for clarity ---
        log_summary = (f"PreFlightCheck: station='{station}', "
                       f"totalRecords={total_record_count}, "
                       f"validTimestampRecords={valid_timestamp_count}")
        logger.info(log_summary)

        if valid_timestamp_count == 0 and total_record_count > 0:
            logger.warning(f"CRITICAL: For station {station}, no records with valid timestamps (Hour and Minute) were found. This will result in no output files.")
        
        min_overall_year, max_overall_year = 9999, 0
        
        logger.info(f"--- Starting year range calculation for station {station} ---")
        for uri in relevant_uris:
            try:
                # This query should also use the same WHERE clause to be consistent
                result = con.execute(f"""
                    SELECT MIN(try_cast(Year AS BIGINT)), MAX(try_cast(Year AS BIGINT))
                    FROM read_parquet('{uri}')
                    WHERE try_cast(Hour AS INTEGER) BETWEEN 0 AND 23
                      AND try_cast(Minute AS INTEGER) BETWEEN 0 AND 59
                """).fetchone()
                
                logger.info(f"File '{os.path.basename(uri)}' min/max year result: {result}")

                if result and result[0] is not None:
                    min_overall_year = min(min_overall_year, int(result[0]))
                    max_overall_year = max(max_overall_year, int(result[1]))

            except Exception as e:
                logger.error(f"Could not process Parquet file '{uri}'. Error: {e}", exc_info=True)
                continue 

        if min_overall_year == 9999 or max_overall_year == 0:
            logger.warning(f"For station {station}, no valid period of record found despite having {valid_timestamp_count} records with valid timestamps.")
            return None, None

        logger.info(f"Determined period of record for {station}: {min_overall_year}-{max_overall_year}")
        return int(min_overall_year), int(max_overall_year)
            
    finally:
        con.close()

# --- LAMBDA HANDLER ---
def lambda_handler(event, context):
    logger.info(f"Received event in start_job: {event}")
    station_id = event['station_id']
    
    script_dir = os.environ.get("LAMBDA_TASK_ROOT", ".")
    priority_csv_path = os.path.join(script_dir, PRIORITY_CSV)

    priority_map = load_priority_map(priority_csv_path)
    plist = priority_map.get(station_id)
    if not plist:
        raise ValueError(f"No sources found for station {station_id} in priority map")
    
    min_year, max_year = get_station_period_of_record(station_id, plist)
    
    if min_year is None:
        return {"status": "NO_DATA", "station_id": station_id}
        
    years_to_process = list(range(min_year, max_year + 1))
    year_chunks = [years_to_process[i:i + CHUNK_SIZE] for i in range(0, len(years_to_process), CHUNK_SIZE) if years_to_process[i:i + CHUNK_SIZE]]
    
    return {
        "station_id": station_id,
        "min_year": min_year,
        "max_year": max_year,
        "year_chunks": year_chunks
    }

