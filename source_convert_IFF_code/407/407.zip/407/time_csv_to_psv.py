# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import glob
import pandas as pd
import csv


##import all csv files in current dir that need timezone changing to GMT based on hours offset 
os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Copiapo/sef/slp")
extension = 'psv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
#combine all files in the list
df3 = pd.concat([pd.read_csv(f,delimiter='|') for f in all_filenames])

##write output combined


df3["Timestamp2"] = df3["Year"].map(str) + "-" + df3["Month"].map(str)+ "-" + df3["Day"].map(str)  
df3["Timestamp"] = df3["Timestamp2"].map(str)+ " " + df3["Hour"].map(str)+":"+df3["Minute"].map(str) 


df3.drop(columns=["Timestamp2"])
df3['Timestamp'] =  pd.to_datetime(df3['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df3['Timestamp'] = df3['Timestamp'].dt.tz_localize('Etc/GMT+6').dt.tz_convert('GMT')
df3['Year'] = df3['Timestamp'].dt.year 
df3['Month'] = df3['Timestamp'].dt.month 
df3['Day'] = df3['Timestamp'].dt.day 
df3['Hour'] = df3['Timestamp'].dt.hour 
df3['Minute'] = df3['Timestamp'].dt.minute
df3['Seconds'] = df3['Timestamp'].dt.second


df3 = df3[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]
df3.to_csv("combined.csv",index=False)
with open('combined.csv') as fin:    
    csvin = csv.DictReader(fin)
    #csvin.columns = [x.replace(' ', '_') for x in csvin.columns]  
    # Category -> open file lookup
    outputs = {}
    for row in csvin:
        cat = row['Station_ID']
        # Open a new file and write the header
        if cat not in outputs:
            fout = open ('{}_station_level_pressure_358.psv'.format(cat), "w", newline = "")
            dw = csv.DictWriter(fout, fieldnames=csvin.fieldnames,delimiter='|')
            dw.writeheader()
            outputs[cat] = fout, dw
        # Always write the row
        outputs[cat][1].writerow(row)
    # Close all the files
    for fout, _ in outputs.values():
        fout.close()
