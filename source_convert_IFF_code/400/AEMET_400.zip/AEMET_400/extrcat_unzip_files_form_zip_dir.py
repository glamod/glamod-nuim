# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 11:25:27 2024

@author: snoone
"""

import zipfile
import os

# Define the path to the zip file
zip_file_path = r"D:\AEMET_spanish_hist_sub_daily\JLC.zip"

# Define the path to save the extracted file
output_folder = r"D:\AEMET_spanish_hist_sub_daily\extracted_files"
output_file_path = os.path.join(output_folder, "JLC/Presion/Presion_Cuenca_0.csv")

# Ensure the output folder exists, create if necessary
os.makedirs(output_folder, exist_ok=True)

# Open the zip file
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    # Extract the specific file to the output folder
    zip_ref.extract("JLC/Presion/Presion_Cuenca_0.csv", output_folder)

print(f"File extracted and saved to: {output_file_path}")
