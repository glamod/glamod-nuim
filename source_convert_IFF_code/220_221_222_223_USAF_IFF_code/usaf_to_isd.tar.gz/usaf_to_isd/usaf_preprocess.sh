#!/bin/bash

# change directory to location of input/output files

cd $GEN3_RUNDIR


# filter for only the sources that we need
# wildcard needed in filename because v3.01 csv files might be named with '03' or '03.01'

sed '/,AFWA,\|,CANA,\|,CMANS,\|,FAA,\|,ICAO,\|,WMO,/!d' usaf-swo-03*_${dateRange}_sfc_obs.csv > sfc_obs.csv

sed '/,AFWA,\|,CANA,\|,CMANS,\|,FAA,\|,ICAO,\|,WMO,/!d' usaf-swo-03*_${dateRange}_cld_lyr.csv > cld_lyr.csv

sed '/,AFWA,\|,CANA,\|,CMANS,\|,FAA,\|,ICAO,\|,WMO,/!d' usaf-swo-03*_${dateRange}_quality.csv > quality.csv

sed '/,AFWA,\|,CANA,\|,CMANS,\|,FAA,\|,ICAO,\|,WMO,/!d' usaf-swo-03*_${dateRange}_ocn_meas.csv > ocn_meas.csv

sed '/,AFWA,\|,CANA,\|,CMANS,\|,FAA,\|,ICAO,\|,WMO,/!d' usaf-swo-03*_${dateRange}_extreme.csv > extremes.csv

sed '/,AFWA,\|,CANA,\|,CMANS,\|,FAA,\|,ICAO,\|,WMO,/!d' usaf-swo-03*_${dateRange}_visibility.csv > visibility.csv


# sort_files_usaf_gen3.sh
# **** note the sort commands are slightly different for each file
# input: raw USAF CSV files  
/bin/sort  -T $sort_tmp -S 3G -t, -k 2,2 -k 1,1 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n sfc_obs.csv > sfc_obs.metoc

/bin/sort  -T $sort_tmp -S 3G -t, -k 2,2 -k 1,1 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n cld_lyr.csv > cld_lyr.metoc

/bin/sort  -T $sort_tmp -S 3G -t, -k 2,2 -k 1,1 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 6n,6n -k 7n,7n -k 4,4 quality.csv > quality.metoc

/bin/sort  -T $sort_tmp -S 3G -t, -k 2,2 -k 1,1 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n ocn_meas.csv > ocn_meas.metoc

/bin/sort  -T $sort_tmp -S 3G -t, -k 2,2 -k 1,1 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n extremes.csv > extremes.metoc

/bin/sort  -T $sort_tmp -S 3G -t, -k 2,2 -k 1,1 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 7n,7n -k 8n,8n visibility.csv > visibility.metoc


# gen3_clean_csv_files.sh
# input: *metoc files
# "cleans them" with this: 
#        logIt "Cleaning the "$1" file for problematic characters (e.g., double-quotes and non-printables)..."
tr -d '"' < sfc_obs.metoc | tr -cd [:print:]'\n' > sfc_obs.clean
tr -d '"' < cld_lyr.metoc | tr -cd [:print:]'\n' > cld_lyr.clean
tr -d '"' < quality.metoc | tr -cd [:print:]'\n' > quality.clean
tr -d '"' < ocn_meas.metoc | tr -cd [:print:]'\n' > ocn_meas.clean
tr -d '"' < extremes.metoc | tr -cd [:print:]'\n' > extremes.clean
tr -d '"' < visibility.metoc | tr -cd [:print:]'\n' > visibility.clean
# then moves *.clean files back to same input file names (sfc_obs.metoc, etc)


# netplat_to_awswban.java 
# does a lot of stuff we won't need right now and writes the files to *.metoc.out (e.g. sfc_obs.metoc.out)
# Instead of calling java code, just removing MESOS lines with bash as that's the only part we need
sed '/MESOS/d' sfc_obs.clean > sfc_obs.metoc.out
sed '/MESOS/d' cld_lyr.clean > cld_lyr.metoc.out
sed '/MESOS/d' quality.clean > quality.metoc.out
sed '/MESOS/d' ocn_meas.clean > ocn_meas.metoc.out
sed '/MESOS/d' extremes.clean > extremes.metoc.out
sed '/MESOS/d' visibility.clean > visibility.metoc.out

# sort_files_awswban.sh  
# more stuff we don't need now and writes files to *.gen3 (e.g. sfc_obs.gen3)
# **** note the sort commands are slightly different for each file

/bin/sort  -T $sort_tmp -S 3G -t, -k 1,1 -k 2,2 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n sfc_obs.metoc.out > sfc_obs.gen3

/bin/sort  -T $sort_tmp -S 3G -t, -k 1,1 -k 2,2 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n cld_lyr.metoc.out > cld_lyr.gen3

/bin/sort  -T $sort_tmp -S 3G -t, -k 1,1 -k 2,2 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 6n,6n -k 7n,7n quality.metoc.out > quality.gen3

/bin/sort  -T $sort_tmp -S 3G -t, -k 1,1 -k 2,2 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n ocn_meas.metoc.out > ocn_meas.gen3

/bin/sort  -T $sort_tmp -S 3G -t, -k 1,1 -k 2,2 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 5n,5n -k 6n,6n extremes.metoc.out > extremes.gen3

/bin/sort  -T $sort_tmp -S 3G -t, -k 1,1 -k 2,2 -k 3.5n,3.8n -k 3.3n,3.4n -k 3.1n,3.2n -k 3.9n,3.12n -k 4,4 -k 7n,7n -k 8n,8n visibility.metoc.out > visibility.gen3

