echo "Starting ftp-ghcnd-flags.sh at " `date`

qc1file=`ls $HOME/ghcnd2/archive/qc1*por*.flags | tail -1`
qc2file=`ls $HOME/ghcnd2/archive/qc2*por*.flags | tail -1`
qc3file=`ls $HOME/ghcnd2/archive/qc3*por*.flags | tail -1`

cat ${qc1file} ${qc2file} ${qc3file} | sort > $HOME/ghcnd2/ghcnd-qc-flags.txt

echo "open ncdcftp" > ftpin
echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
echo "cd upload/2days" >> ftpin
echo "lcd /home/mmenne/ghcnd2" >> ftpin
echo "put ghcnd-qc-flags.txt" >> ftpin
echo "quit" >> ftpin
ftp -in < ftpin

echo "Finished ftp-ghcnd-flags.sh at " `date`
