./add_stns.exe /home/mmenne/ghcnd/ mingle-list.txt 3200.station.list.dupchkd 3210.station.list.dupchkd 1 /home/mmenne/ghcnd/3200/rawghcnd/ 
