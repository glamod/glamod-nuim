#!/bin/bash

# This is the setup script for GSOM/GSOY
# This only needs to run once to setup the venv

# Use a python virtual environment
python3.12 -m venv /data/ops/gsom_gsoy_ng/code/gsom-y_env
source /data/ops/gsom_gsoy_ng/code/gsom-y_env/bin/activate

# Install requirements into venv
pip install -r requirements.txt
