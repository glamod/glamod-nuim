#Created by Menne/Durre December 2011

PREFIX=$1

#
if [ -s ${PREFIX}download/datzilla ]
then
rm -r ${PREFIX}download/datzilla
fi

mkdir -p ${PREFIX}download/datzilla

wget -o${PREFIX}download/get-datzilla.ftp.log -P${PREFIX}download/datzilla ftp://ncdcftp.ncdc.noaa.gov/upload/7days/????????Corr.txt



