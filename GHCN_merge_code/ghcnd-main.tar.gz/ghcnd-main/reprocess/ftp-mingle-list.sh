echo "Starting ftp-mingle-list.sh at " `date`

echo "open ncdcftp" > ftpin
echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
echo "cd upload/7days" >> ftpin
echo "lcd /home/mmenne/ghcnd2/input4sys" >> ftpin
echo "dele mingle-list.txt" >> ftpin
echo "put mingle-list.txt" >> ftpin
echo "quit" >> ftpin
ftp -in < ftpin

echo "Finished ftp-mingle-list.sh at " `date`
