dsi=$1
src_code=$2
list_dir=$3
refresh_dir=/data/makelist/

echo "Starting refresh-wban.sh for ${dsi} on " `date`

echo "Copying latest backup file from ncdcftp/7days"
cp -p /ncdcftp/ghcnd-backup.tar /data/backup

echo "Untarring rawghcnd source directories on " `date`
${refresh_dir}untar-sources-rawghcnd.sh ${refresh_dir}source-list.txt /data/backup/ ${refresh_dir}

echo "Getting earliest of data for source ${dsi}" `date`
cut -c12-15 ${refresh_dir}${dsi}/rawghcnd/* | sort -u > ${refresh_dir}${dsi}-years.txt 

firstyear=`head -1 ${refresh_dir}${dsi}-years.txt`
sed 's/integer,parameter::iMinYr=1750/integer,parameter::iMinYr='${firstyear}'/' ${refresh_dir}ghcndmod.f95 > ${refresh_dir}ghcndmod4refresh.f95

#need to change to gcompile
#${refresh_dir}compile-refresh-wban.sh ${refresh_dir} ${refresh_dir}ghcndmod4refresh.f95

if [ ${list_dir} != ${refresh_dir} ]
then
cp -p ${list_dir}ghcnd-countries.txt ${refresh_dir}ghcnd-countries.txt
fi

cp -p ${list_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.txt.old
cp -p ${list_dir}mingle-list.txt ${refresh_dir}mingle-list.txt.old

cp -p ${refresh_dir}ghcnd-stations.txt.old ${refresh_dir}ghcnd-stations.txt
cp -p ${refresh_dir}mingle-list.txt.old ${refresh_dir}mingle-list.txt

cd ${refresh_dir}

#Get the latest MASTER-STN-HIST.TXT file and ISH History file
#${refresh_dir}get-mshr.sh ${refresh_dir}
${refresh_dir}get-ish-history.sh ${refresh_dir}
#Keep a copy of last ${dsi} list of stations with data
cp -p ${refresh_dir}${dsi}.inv ${refresh_dir}${dsi}.inv.old
#Make a new ${dsi} list of stations with data
mv -f ${refresh_dir}${dsi}-stations.txt ${refresh_dir}${dsi}-stations.old
ls ${refresh_dir}${dsi}/rawghcnd | cut -c7-11 > ${refresh_dir}${dsi}.inv
echo "Starting gen-wban-station-info.exe on " `date`
${refresh_dir}gen-wban-stninfo.exe ${dsi} ${refresh_dir} ${refresh_dir}ghcnd-countries.txt
if [ ! -s ${refresh_dir}${dsi}-stations.txt ]
then
echo "${dsi}-stations.txt was not created...exiting script" `date`
exit
fi
echo "Starting pre_screen.exe on" `date`
${refresh_dir}pre_screen.exe ${refresh_dir}${dsi}/ ${refresh_dir}${dsi}-stations.txt ${dsi}
echo "Starting intrasource_dupchk.exe on" `date`
${refresh_dir}intrasource_dupchk.exe ${refresh_dir}${dsi}/ ${refresh_dir}${dsi}-stations-prescreened.txt ${dsi}
echo "Starting strip_source.exe on" `date`
${refresh_dir}strip_source.exe ${src_code} ${refresh_dir}mingle-list.txt ${refresh_dir}ghcnd-stations.txt 
echo "Starting mingle.exe to create version of GHCN-Daily without ${dsi} on " `date`
${refresh_dir}mingle.exe ${refresh_dir} ${refresh_dir}mingle-list-no-${src_code}.txt 
echo "Starting gen-wban-xref.exe on" `date`
${refresh_dir}gen-wban-xref.exe MASTER-STN-HIST.TXT ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.id.noxref
echo "Starting gen-data-xref.exe on" `date`
${refresh_dir}gen-data-xref.exe ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${src_code} ${refresh_dir}mingled/ ${refreshed_dir}${dsi}/rawghcnd/ ${refresh_dir}${dsi}.id.noxref ${refresh_dir}datamatchinfo/ ${refresh_dir}${dsi}.data.xref ${refresh_dir}${dsi}.data.noxref
echo "catting ${dsi}.id.xref and ${dsi}.data.xref" `date`
cat ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.data.xref > ${refresh_dir}${dsi}.xref
echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${src_code} ${refresh_dir}${dsi}.xref ${refresh_dir}input4refresh/mingle-list-custom.txt
echo "Number of stations in ghcnd-stations" `wc ${refresh_dir}ghcnd-stations.txt | cut -c1-7`
mv ${refresh_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.4gsn
echo "Starting setGSNfield.exe on" `date`
${refresh_dir}setGSNfield.exe ${refresh_dir}gsn-ids.txt ${refresh_dir}ghcnd-stations.4gsn ${refresh_dir}ghcnd-stations.4hcn
echo "Starting setHCNfield.exe on" `date`
${refresh_dir}setHCNfield.exe ${refresh_dir}ushcn-ids.txt ${refresh_dir}ghcnd-stations.4hcn ${refresh_dir}ghcnd-stations.4crn
rm ${refresh_dir}crn-ids.txt
for i in `cut -c1-11 ${refresh_dir}crn-stations.txt`; do grep $i ${refresh_dir}mingle-list.txt | grep " R " | cut -c1-11 >> ${refresh_dir}crn-ids.txt; done
echo "Starting setCRNfield.exe on" `date`
${refresh_dir}setCRNfield.exe ${refresh_dir}crn-ids.txt ${refresh_dir}ghcnd-stations.4crn ${refresh_dir}ghcnd-stations.txt
${refresh_dir}remove-sources-rawghcnd.sh ${refresh_dir}source-list.txt ${refresh_dir}
echo "Finished refresh-wban.sh for ${dsi} on " `date`

