#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import glob
import pandas as pd

# =====================================================
# PATHS
# =====================================================
BASE_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/sangetha_new_data/DerrickMuheki_converted/DRC_daily_and_subdaily_temperature_data/sef_data/IFF_output"

OUTFILE = os.path.join(BASE_DIR, "Congo_inventory.csv")

VARIABLE_FOLDERS = {
    "dry_bulb_temperature": "dry_bulb",
    "wet_bulb_temperature": "wet_bulb",
    "mean_temperature": "mean_temperature",
    "minimum_temperature": "minimum_temperature",
    "maximum_temperature": "maximum_temperature"
}

# =====================================================
# STORAGE
# =====================================================
station_inventory = {}

# =====================================================
# LOOP THROUGH VARIABLES
# =====================================================
for folder_name, variable_name in VARIABLE_FOLDERS.items():

    folder_path = os.path.join(BASE_DIR, folder_name)

    if not os.path.exists(folder_path):
        print(f"Folder missing: {folder_path}")
        continue

    files = sorted(glob.glob(os.path.join(folder_path, "*.psv")))

    print(f"\n{variable_name}: {len(files)} files")

    for file in files:

        try:
            df = pd.read_csv(file, sep="|", dtype=str)

            if df.empty:
                continue

            # -----------------------------------------
            # numeric time columns
            # -----------------------------------------
            for col in ["Year", "Month", "Day"]:
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce")

            # -----------------------------------------
            # start/end year
            # -----------------------------------------
            valid_years = df["Year"].dropna()

            if len(valid_years) == 0:
                continue

            start_year = int(valid_years.min())
            end_year = int(valid_years.max())

            # -----------------------------------------
            # station metadata
            # -----------------------------------------
            station_id = df["Station_ID"].iloc[0]
            source_id = df["Source_ID"].iloc[0]
            station_name = df["Station_name"].iloc[0]

            lat = df["Latitude"].iloc[0]
            lon = df["Longitude"].iloc[0]
            elev = df["Elevation"].iloc[0]

            # -----------------------------------------
            # initialize station row
            # -----------------------------------------
            if station_id not in station_inventory:

                station_inventory[station_id] = {
                    "Source_ID": source_id,
                    "Station_ID": station_id,
                    "Station_name": station_name,
                    "Latitude": lat,
                    "Longitude": lon,
                    "Elevation": elev
                }

            # -----------------------------------------
            # add variable years
            # -----------------------------------------
            station_inventory[station_id][f"{variable_name}_start_year"] = start_year
            station_inventory[station_id][f"{variable_name}_end_year"] = end_year

            print(f"Added: {station_id} | {variable_name}")

        except Exception as e:
            print(f"Failed: {os.path.basename(file)} | {e}")

# =====================================================
# CREATE FINAL INVENTORY
# =====================================================
inventory = pd.DataFrame(station_inventory.values())

inventory = inventory.sort_values("Station_ID")

inventory.to_csv(OUTFILE, index=False)

print("\nDONE")
print("Inventory saved to:")
# %%
print(OUTFILE)
