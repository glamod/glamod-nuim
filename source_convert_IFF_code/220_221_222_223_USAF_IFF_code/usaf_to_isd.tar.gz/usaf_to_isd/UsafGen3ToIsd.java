/*
*  This class converts USAF Gen3 input files to ISD formatted files.
*  Code is a modified version of a Java class from ISDPS Integrated Surface Dataset 
*  Processing System            
*    Program: usaf_gen3_to_isd.java                                           
*    Created: 07/07/2008 Tom Whitehurst
*    Modified: 2020-2021 Diana Kantor                                    
*/
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.Reader;
import java.io.*;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Vector;
import java.util.List;
import java.util.Date;
import java.util.Arrays;
import java.util.ArrayList;
import java.text.NumberFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;

public class UsafGen3ToIsd
{
    static String script_name   = "UsafGen3ToIsd.java";
    static String sDateTimeNow  = "";
    static String sResult = null;
    static String id1                  = null;
    static int    iObsCounter = 0;
    static int    id2CounterEQ = 0;
    static int    id2CounterNE = 0;
    static int    id3CounterEQ = 0;
    static int    id3CounterNE = 0;
    static int    id4CounterEQ = 0;
    static int    id4CounterNE = 0;
    static int    id5CounterEQ = 0;
    static int    id5CounterNE = 0;
    static int    id6CounterEQ = 0;
    static int    id6CounterNE = 0;

    static boolean bVerboseHold  = false;
    static boolean bVerbose      = false;
    static FileOutputStream fLog = null;

    /*
     * Main process                                             
     */
    public static void main(String[] args) throws IOException 
    {
        String [] obs_line          = new String[184];				 
        String [] cld_lyr_line      = new String[113];			
        String [] ocn_meas_line     = new String[65];			
        String [] extremes_line     = new String[56];			
        String [] quality_line      = new String[15];			
        String [] visibility_line   = new String[22];			
        String date;                                 
        String infilename1          = null;
        String infilename2          = null;
        String infilename3          = null;
        String infilename4          = null;
        String infilename5          = null;
        String infilename6          = null;                             
        String id2                  = null;
        String id3                  = null;
        String id4                  = null;
        String obs                  = null;
        String id5                  = null;
        String id1Hold              = null;                             
        String id1Hold2             = null;                              
        String id6                  = null;                             

        String obs1                 = "";
        String obs2                 = "";
        String obs3                 = "";
        String obs4                 = "";
        String obs5                 = "";
        String obs6                 = "";
        String obs7                 = "";
        String obs8                 = "";                               

        String [] Line1             = new String[184]; 				 
        String [] Line2             = new String[113];			
        String [] Line3             = new String[65];			
        String [] Line4             = new String[56];			
        String [] Line5             = new String[15];			
        String [] Line6             = new String[22];			

        String datatype             = null;
        String control              = null;
        String mandantory           = null;
        String additional           = null;

        CSVReader in1               = null;
        CSVReader in2               = null;
        CSVReader in3               = null;
        CSVReader in4               = null;
        CSVReader in5               = null;
        CSVReader in6               = null;                             

        double lat1                 = -99.000;
        double lat2                 = -99.000;
        double lat3                 = -99.000;
        double lat4                 = -99.000;
        double lat5                 = -99.000;
        double lon1                 = -999.000;
        double lon2                 = -999.000;
        double lon3                 = -999.000;
        double lon4                 = -999.000;
        double lon5                 = -999.000;

        String wban;
        String filePath             = "";
        BufferedWriter out;

        String wrkdir               = System.getenv("GEN3_RUNDIR")+"/";
        String logdir               = System.getenv("GEN3_LOGDIR");

        fLog = new FileOutputStream (logdir+"/"+script_name+".log", true);  // Append mode.

        // Get timedate.
        java.util.Date now = new java.util.Date();
        sDateTimeNow=now.toString();
        logIt(fLog, "main(): INFO - Begin usaf gen3 to ISD");

        //collect files names
        String [] files             = filenames();
        logIt(fLog, "main(): INFO - Found "+files.length+" files");

        // Find sfc_obs file and get 1st record. 
        String blkstn   = "";                                     
        for (int i=0;i< files.length;i++)                          
        {
            if (files[i].endsWith("sfc_obs.gen3"))
            {
                logIt(fLog, "main(): INFO - Preparing ["+files[i]+"]");
                datatype    = "obs_hdr";
                infilename1 = wrkdir + files[i];
                in1         = new CSVReader(new FileReader(infilename1));
                Line1       = in1.readNext();
                blkstn      = Line1[0];                                             
                id1Hold2    = Line1[0]+Line1[1];                                   
                sResult     = id1Hold2;                                            
                id1         = getID(Line1,"obs_hdr");
                iObsCounter++;
            }
        }

        for (int i=0;i< files.length;i++)
        {
            logIt(fLog, "main(): INFO - Preparing ["+files[i]+"]");
            if (files[i].endsWith("cld_lyr.gen3"))
            {
                datatype    = "cld_lyr_hdr";
                infilename2 = wrkdir + files[i];
                in2         = new CSVReader(new FileReader(infilename2));
                Line2       = in2.readNext();
                id2         = getID(Line2,"cld_lyr_hdr");
                if (id2 == null)
                {
                    logIt(fLog, "main(): INFO - Line2==null");
                    id2     = "";
                }
                else
                {
                    logIt(fLog, "main(): INFO - Line2=["+Line2[0]+","+Line2[1]+","+Line2[2]+","+Line2[3]+","+Line2[4]+","+Line2[5]+","+Line2[6]+"] id2=["+id2+"] loop");
                }
            }
            else if (files[i].endsWith("extremes.gen3"))
            {
                datatype    = "extremes_hdr";
                infilename4 = wrkdir + files[i];
                in4         = new CSVReader(new FileReader(infilename4));
                Line4       = in4.readNext();
                id4         = getID(Line4,"extremes_hdr");
                if (id4 == null)
                {
                    logIt(fLog, "main(): INFO - Line4==null");
                    id4     = "";
                }
                else
                {
                    logIt(fLog, "main(): INFO - Line4=["+Line4[0]+","+Line4[1]+","+Line4[2]+","+Line4[3]+","+Line4[4]+","+Line4[5]+","+Line4[6]+"] id4=["+id4+"] loop");
                }
            }
            else if (files[i].endsWith("ocn_meas.gen3"))
            {
                datatype    = "ocn_meas_hdr";
                infilename3 = wrkdir + files[i];
                in3         = new CSVReader(new FileReader(infilename3));
                Line3       = in3.readNext();
                id3         = getID(Line3,"ocn_meas_hdr");
                if (id3 == null)
                {
                    logIt(fLog, "main(): INFO - Line3==null");
                    id3     = "";
                }
                else
                {
                    logIt(fLog, "main(): INFO - Line3=["+Line3[0]+","+Line3[1]+","+Line3[2]+","+Line3[3]+","+Line3[4]+","+Line3[5]+","+Line3[6]+"] id3=["+id3+"] loop");
                }
            }
            else if (files[i].endsWith("quality.gen3"))
            {
                datatype    = "quality_hdr";
                infilename5 = wrkdir + files[i];
                in5         = new CSVReader(new FileReader(infilename5));
                Line5       = in5.readNext();
                id5         = getID(Line5,"quality_hdr");
                if (id5 == null)
                {
                    logIt(fLog, "main(): INFO - Line5==null");
                    id5     = "";
                }
                else
                {
                    logIt(fLog, "main(): INFO - Line5=["+Line5[0]+","+Line5[1]+","+Line5[2]+","+Line5[3]+","+Line5[4]+","+Line5[5]+","+Line5[6]+"] id5=["+id5+"] loop");
                }
            }
            else if (files[i].endsWith("visibility.gen3"))              
            {                                                           
                datatype    = "visibility_hdr";                         
                infilename6 = wrkdir + files[i];                        
                in6         = new CSVReader(new FileReader(infilename6));                
                Line6       = in6.readNext();                           
                id6         = getID(Line6,"visibility_hdr");            
                if (id6 == null)
                {
                    logIt(fLog, "main(): INFO - Line6==null");
                    id6     = "";
                }
                else
                {
                    logIt(fLog, "main(): INFO - Line6=["+Line6[0]+","+Line6[1]+","+Line6[2]+","+Line6[3]+","+Line6[4]+","+Line6[5]+","+Line6[6]+"] id6=["+id6+"] loop");
                }
            }
        }

        date            = id1.substring(6,14);
        obs1            = control(Line1);
        obs2            = mandantory(Line1);
        obs3            = additional("obs_hdr",Line1);
        logIt(fLog, "main(): INFO - id1=["+id1+"]");
        logIt(fLog, "main(): INFO - id2=["+id2+"]");
        logIt(fLog, "main(): INFO - id3=["+id3+"]");
        logIt(fLog, "main(): INFO - id4=["+id4+"]");
        logIt(fLog, "main(): INFO - id5=["+id5+"]");
        logIt(fLog, "main(): INFO - id6=["+id6+"]");
        if (id1.equals(id2))
        {
            obs4        = additional("cld_lyr_hdr",Line2);
            logIt(fLog, "main(): INFO - obs4=["+obs4+"]");
        }
        if (id1.equals(id3))
        {
            obs5        = additional("ocn_meas_hdr",Line3);
            logIt(fLog, "main(): INFO - obs5=["+obs5+"]");
        }
        if (id1.equals(id4))
        {
           obs6         = additional("extremes_hdr",Line4);
            logIt(fLog, "main(): INFO - obs6=["+obs6+"]");
        }
        if (id1.equals(id6))                                                                    
        {
           obs8         = additional("visibility_hdr",Line6);                                   
            logIt(fLog, "main(): INFO - obs8=["+obs8+"]");
        }
        if (id1.equals(id5))
        {
            while(id1.equals(id5))
            {
                {
                    obs7+=additional("quality_hdr",Line5);
                    logIt(fLog, "main(): INFO - obs7=["+obs7+"]");
                }
                Line5   = in5.readNext();
                id5     = getID(Line5,"quality_hdr");
            }
            obs7        = "EQD"+obs7;
        }
        obs             = processobs(obs1,obs2,obs3,obs4,obs5,obs6,obs7,obs8,Line1);            
        obs4            = "";
        obs5            = "";
        obs6            = "";
        obs7            = "";
        obs8            = "";                                                                   

        if(args.length > 0){
            filePath    = args[0];
        }
        else{
            System.err.println("Argument must be provided");
            System.exit(3);
        }

        out             = new BufferedWriter(new FileWriter(filePath));
        obsWrite(obs,out);
        //end the tests

        // Set up number format
        NumberFormat formatter = new DecimalFormat("##,###,###");

        int qqq=0;
        int qqqTotal=0;
        int qqqMax=24999;   // Regular reporting interval.

        while ((Line1 = in1.readNext()) != null)
        {
            iObsCounter++;
            qqq++;
            qqqTotal++;

            if (qqqTotal ==      5 ||    // Additional reporting intervals.
                qqqTotal ==     25 ||
                qqqTotal ==    100 ||
                qqqTotal ==   1000 ||
                qqqTotal ==   5000 ||
                qqqTotal ==  10000)
            {
                logIt(fLog, "main(): INFO - Processed "+formatter.format(qqqTotal)+" obs");
            }

            if (qqq>qqqMax)
            {
                logIt(fLog, "main(): INFO - Processed "+formatter.format(qqqTotal)+" obs");
                qqq=0;
            }

            id1Hold         = Line1[0]+Line1[1];                                
            sResult         = id1Hold;                                          
            try
            {
                id1             = getID(Line1,"obs_hdr");
                id1Hold2        = Line1[0]+Line1[1];                                

                obs1            = control(Line1);
                obs2            = mandantory(Line1);
                obs3            = additional("obs_hdr",Line1);
            }
            catch(Exception e)
            {
                System.out.println("ERROR: Bad ID and obs read. Skipping line. ");
            }

            while (id2 != null && id1.compareTo(id2)>=0)
            {
                if (id1.equals(id2))
                {
                    obs4    = additional("cld_lyr_hdr",Line2);
                    Line2   = in2.readNext();
                    id2CounterEQ++;
                    id2     = getID(Line2,"cld_lyr_hdr");
                    break;
                }
                else
                {
                    Line2   = in2.readNext();
                    id2CounterNE++;
                    id2     = getID(Line2,"cld_lyr_hdr");
                }
            }
            while (id3 != null && id1.compareTo(id3)>=0)
            {
                if (id1.equals(id3)) 
                {
                    obs5    = additional("ocn_meas_hdr",Line3);
                    Line3   = in3.readNext();
                    id3CounterEQ++;
                    id3     = getID(Line3,"ocn_meas_hdr");
                    break;
                }   
                else
                {
                    Line3   = in3.readNext();
                    id3CounterNE++;
                    id3     = getID(Line3,"ocn_meas_hdr");
                }
            }

            while (id4 != null && id1.compareTo(id4)>=0)
            {
                if (id1.equals(id4))
                {
                    obs6    = additional("extremes_hdr",Line4);
                    Line4   = in4.readNext(); 
                    id4CounterEQ++;
                    id4     = getID(Line4,"extremes_hdr");
                    break;
                }    
                else
                {
                    Line4   = in4.readNext(); 
                    id4CounterNE++;
                    id4     = getID(Line4,"extremes_hdr");
                }
            }
            while (id6 != null && id1.compareTo(id6)>=0)                
            {                                                           
                if (id1.equals(id6))                                    
                {                                                       
                    obs8    = additional("visibility_hdr",Line6);       
                    Line6   = in6.readNext();                           
                    id6CounterEQ++;
                    id6     = getID(Line6,"visibility_hdr");            
                    break;                                              
                }                                                       
                else                                                    
                {                                                       
                    Line6   = in6.readNext();                           
                    id6CounterNE++;
                    id6     = getID(Line6,"visibility_hdr");            
                }                                                       
            }                                                           
            while (id5 != null && id1.compareTo(id5)>=0)
            {
                if (id1.equals(id5))
                {
                    while(id1.equals(id5))
                    {
                        obs7+=additional("quality_hdr",Line5);
                        Line5   = in5.readNext();
                        id5CounterEQ++;
                        id5     = getID(Line5,"quality_hdr");
                    }
                    obs7        = "EQD"+obs7;
                    break;
                }
                else
                {
                    Line5=in5.readNext();
                    id5CounterNE++;
                    id5=getID(Line5,"quality_hdr");
                }
            }

            obs=processobs(obs1,obs2,obs3,obs4,obs5,obs6,obs7,obs8,Line1);               
            obs4="";
            obs5="";
            obs6="";
            obs7="";
            obs8="";                                                    

            obsWrite(obs,out);
        }

        logIt(fLog, "main(): INFO - Processed "+formatter.format(qqqTotal)+" obs, total.");

        out.close();

        logIt(fLog, "main(): INFO - id2CounterEQ=["+id2CounterEQ+"]");
        logIt(fLog, "main(): INFO - id2CounterNE=["+id2CounterNE+"]");
        logIt(fLog, "main(): INFO - id3CounterEQ=["+id3CounterEQ+"]");
        logIt(fLog, "main(): INFO - id3CounterNE=["+id3CounterNE+"]");
        logIt(fLog, "main(): INFO - id4CounterEQ=["+id4CounterEQ+"]");
        logIt(fLog, "main(): INFO - id4CounterNE=["+id4CounterNE+"]");
        logIt(fLog, "main(): INFO - id5CounterEQ=["+id5CounterEQ+"]");
        logIt(fLog, "main(): INFO - id5CounterNE=["+id5CounterNE+"]");
        logIt(fLog, "main(): INFO - id6CounterEQ=["+id6CounterEQ+"]");
        logIt(fLog, "main(): INFO - id6CounterNE=["+id6CounterNE+"]");
        logIt(fLog, "main(): INFO - Began usaf gen3 to ISD at=["+sDateTimeNow+"]");
        now = new java.util.Date();
        sDateTimeNow=now.toString();
        logIt(fLog, "main(): INFO - Ended usaf gen3 to ISD at=["+sDateTimeNow+"]");

        fLog.close();
    }  // End of main

   /*
    * Takes file identifier and a record from that file and extracts specific info that will      
    * identify the record for comparison with records from the other files in this batch.         
    */
    public static String getID(String[] str, String datatype) 
    {
        String id = new String();
        String idStr = new String();
        String lat = "";                                                
        String lon = "";                                                
        if (str == null)
        {
            id = null;
            return id;
        }
        if (datatype.equals("quality_hdr"))                                  
        {                                                                    
            lat  = frmt(str[5].substring(0,5),6,1,1000);                     
            lon  = frmt(str[6].substring(0,6),7,1,1000);                     
        }                                                                    
        else        
        {                                                         
            if (datatype.equals("visibility_hdr"))                      
            {                                                           
                lat  = frmt(str[6].substring(0,5),6,1,1000);              
                lon  = frmt(str[7].substring(0,6),7,1,1000);             
            }                                                           
            else                                                        
            {
                lat  = frmt(str[4].substring(0,5),6,1,1000);           
                lon  = frmt(str[5].substring(0,6),7,1,1000);           
            } 
        }

        // Padding/altering IDs to facilitate use of existing ISD formatting code
        // where IDs are expected to be 11 characters
        int strIdLength = str[0].length() + str[1].length() + 1;
        int fullLength = 11;
        idStr = str[0] + "_" + str[1];
        if(strIdLength>fullLength)
            idStr = idStr.substring(0,fullLength);
        else
        {
            int padCount = fullLength - strIdLength;
            for (int i=0; i<padCount; i++)
            {
                idStr = idStr + "_";
            }
        }

        //Validate ID string against network type
        if(str[1].equals("WMO"))
        {
            if(!str[0].matches("-?\\d+") || str[0].length()!=5)
            {
                System.out.println("WMO ID is not 5 character numeric: " + str[0]);
                idStr += "_BAD_ID";
            }
        }
        else if(str[1].equals("ICAO"))
        {
            if(!str[0].matches("^[a-zA-Z0-9]*$") || str[0].length()>4)
            {
                System.out.println("ICAO ID is not 3-4 character alphanumeric: " + str[0]);
                idStr += "_BAD_ID";
            }
        }
        else if(str[2].length() < 8)
        {
            System.out.println("ERROR: Malformed line during ID creation: " + str[0] + "," + str[1] + "," + str[2] + "," + str[3]);
        }
        
        str[0] = idStr;
        str[1] = "";
        id=idStr+(str[2].substring(4,8))+str[2].substring(2,4)+str[2].substring(0,2)+str[2].substring(8,12)+str[3];   
        return id;
    }  // End of getID

   /*
    * Looks in directory and builds list of files ending with ".gen3". These files       
    * are later processed individually.                                                                     
    */
    public static String [] filenames() 
    {
        File dir = new File(System.getenv("GEN3_RUNDIR")+"/");

        FilenameFilter filter = new FilenameFilter()
        {
            public boolean accept(File dir, String name)
            {
                return name.endsWith(".gen3");
            }
        };

        String[] children = dir.list(filter);
        if (children == null)
        {
            System.out.println(script_name+"=>filenames(): WARNING - children == null");
        }
        else
        {
            for (int i=0; i<children.length; i++)
            {
                // Get filename of file or directory
                String filename = children[i];
                logIt(fLog, "filenames(): INFO - Found "+filename);
            }
        }

        return children;
    }  // End of filenames

   /* 
    * Returns a string padded with a sign (as necessary) and leading zeros.   
    */
    public static String zfill(String element, int len, int sgn) 
    {
        String pzeros   = "+0000000";
        String nzeros   = "-0000000";
        String zeros    = "0000000";
        String value    = "";

        if (sgn == 0)
        {
            if (element.length() < len)
                value=zeros.substring(0,(len - element.length()))+element;
            else
                value=element;
        }
        else if (sgn == 1)
        {
            if (element.substring(0,1).equals("-"))
                value=nzeros.substring(0,(len - (element.length() -1)))+element.substring(1);
            else
            {   // Prevents error message and system crash
                if(len<element.length()) 
                	len = element.length();
                value=pzeros.substring(0,(len - element.length()))+element;
            }
        }
        else if (sgn == 2)
        {
            if (element.substring(0,1).equals("-"))
                value=nzeros.substring(0,(len - (element.length() -1)))+element.substring(1);
            else
                value=zeros.substring(0,(len - element.length()))+element;
        }

        return value;
    }  // End of zfill

   /*
    * Returns a string consisting of a sign (as necessary) and the rest nines.                    
    */
    public static String nfill(String element, int len, int sgn) 
    {
        String pnines   = "+9999999";
        String nines    = "9999999";
        String value    = "";

        if (sgn == 0)
            value   = nines.substring(0,len);
        else if (sgn == 1)
            value   = pnines.substring(0,len);

        return value;
    }  // End of nfill

   /*
    * Returns a string padded with trailing spaces as necessary.                                  
    */
    public static String sfill(String element, int len) 
    {
        String spaces   = "       ";
        String value    = "";

        if (element.length() < len)
            value   = element+spaces.substring(0,(len - element.length()));
        else
            value   = element;

        return value;
    }  // End of sfill

   /*
    * Returns a string representation of a floating point number multiplied by some factor.
    */
    public static String cnvflt(String element, int fac) 
    {
        int    ielement;
        float  felement;
        String selement;
        // Check for case of non-numeric inputs.
        try     
        {
            felement    = Float.valueOf(element.trim()).floatValue() * fac;
            ielement    = (int)Math.round(felement);
            selement    = String.valueOf(ielement);
        }
        catch (Exception e)  
        {
            System.out.println(script_name+"=>cnvflt(): ERROR - id1=["+id1+"] element=["+element+"]  fac=["+fac+"]");
            System.out.println("Error: " + e);                               
            return "ERROR"; 
        }

        return selement;
    }  // End of cnvflt

   /* 
    * Sorts the Additional data section                   
    */
    public static String srtaddln(String alpha) 
    {
        int     [] bs       = new int[100];
        String  [] labels   = new String[100];
        String  [] addgrps  = new String[100];
// FUTURE NOTE - We need to correct this use of hard-coded element codes ASAP.
//               It should be data-driven, preferably from the Oracle database.
        String  [] aGroups  = new String[] {
            "AA1","AA2","AA3","AA4","AB1","AC1","AD1","AE1","AG1","AH1","AJ1","AK", "AL1","AL2","AL3",
            "AL4","AM1","AN1","AU1","AW1","AW2","AW3","AX", "AY1","AY2","AZ1","AZ2","ED1","GA1","GA2",
            "GA3","GA4","GA5","GA6","GD1","GD2","GD3","GD4","GD5","GD6","GE1","GF1","GG1","GG2","GG3",
            "GG4","GG5","GG6","GJ1","GK1","GL1","HL1","IA1","IA2","KA1","KA2","KB1","KB2","KB3","KC1",
            "KC2","KD1","KD2","KE1","MA1","MD1","ME1","MG1","MH1","MK1","MV1","MV2","MV3","MV4","MV5",
            "MV6","MV7","MW1","MW2","MW3","MW4","MW5","MW6","MW7","OA1","OA2","OA3","OC1","OD1","OD2",
            "OD3","OE1","OE2","OE3","SA1","UA1","UG1","UG2","WA1","WD1","WG1","WJ1" };

// These are listed above but not in Additional code...		
//    		"GD5","GD6",
//        	"GG6",

// These are in the ISD Format Doc but not listed above...	
//            "AH2","AH3","AH4","AH5","AH6",
//            "AI2","AI3","AI4","AI5","AI6",
//            "AK1",		// Above has AK without the 1
//            "AO1","AO2","AO3","AO4",
//            "AP1","AP2","AP3","AP4",
//            "AU2","AU3","AU4","AU5","AU6","AU7","AU8","AU9",
//            "AW4",
//            "AX1",		// Above has AX without the 1
//            "AX2","AX3","AX4","AX5","AX6",
//            "CB1","CB2",
//            "CF1","CF2","CF3",
//            "CG1","CG2","CG3",
//            "CH1","CH2",
//            "CI1",
//            "CN1",
//            "CN2",
//            "CN3",
//            "CN4",
//            "CR1",
//            "CT1","CT2","CT3",
//            "CU1","CU2","CU3",
//            "CV1","CV2","CV3",
//            "CW1",
//            "CX1","CX2","CX3",
//            "CO1","CO2","CO3","CO4","CO5","CO6","CO7","CO8","CO9",
//            "GH1",
//            "GM1",
//            "GN1",
//            "GO1",
//            "GP1",
//            "GQ1",
//            "GR1",
//            "IB1","IB2",
//            "IC1",
//            "KF1",
//            "KG1","KG2",
//            "MF1",
//            "OB1","OB2",
//            "RH1","RH2","RH3",
//            "RHX",
//            "ST1",

        int k=0;
        for(int j=0;j < alpha.length(); j++) 
        {
            if(alpha.charAt(j) >= 'A' &&  alpha.charAt(j) <= 'Z')
            { 
                try
                {
                    if (Arrays.binarySearch(aGroups,alpha.substring(j,j+3)) >= 0)
                    {
                        bs[k]=j;
                        k++;
                        j=j+2;
                    }
                }   
                catch(Exception e)
                {
                    System.out.println("ERROR: processing string " + alpha + " with message " + e.getMessage());
                }  
            }
        }

        k=k-1;
        for(int l=0;l<=k;l++){
            labels[l]=alpha.substring(bs[l],bs[l]+3);
            if(l == (k))
                addgrps[l]=alpha.substring(bs[l]);
            else
                addgrps[l]=alpha.substring(bs[l],bs[l+1]);
        }

        Arrays.sort(labels,0,k+1);

        String sortedalpha="";

        for (int n=0;n<=k;n++)
        {
            for (int p=0;p<=k;p++)
            {
                if (addgrps[p].startsWith(labels[n]))
                {
                    sortedalpha+=addgrps[p];
                    break;
                }
            }
        }

        return sortedalpha;
    }  // End of srtaddln

   /* 
    * Returns a string after padding with spaces or zeros to a specified length.     
    */
    public static String frmt(String element, int len, int sgn, int fac) 
    {
        String value;

        if (element.equals(""))
            value   = nfill(element,len,sgn);
        else
            value   = zfill(cnvflt(element,fac),len,sgn);
        if (value.equals("ERROR"))
        {
            bVerbose=true;
            logIt(fLog, "frmt(): FATAL ERROR - Numeric conversion error. element=["+element+"] len=["+len+"] sgn=["+sgn+"]");
            System.out.println(script_name+"=>A problem occurred with ob=["+id1+"]");   // 2014-08-27  ras  (Temp)
        }

        return value;
    }  // End of frmt

   /* 
    * Constructs the control string for the record.
    * 
    * Sample Control input:
    *      723150,03812,21052013025400,FM-15,35.4361940,-82.5418060,5,1,A,0,659.89,,0,,0,C,1,0.0,1,,,,0,4,,0,,0,N,1,16093,1,P,1,18.3,1,17.2,1,1017.800,1
    */
    public static String control(String []line) 
    {
        String control;
        String blkstn;
        String elev;
        String lat;
        String lon;
        String call;
        String type;
        String vers;								

        lat     = frmt(line[4],6,1,1000);    
        lon     = frmt(line[5],7,1,1000);    
        elev    = frmt(line[10],5,1,1);

        if (line[3].equals(""))
            type    = "99999";
        else
            type    = sfill(line[3],5);

        if (line[11].equals(""))
            call    = "99999";
        else
            call    = sfill(line[11],5);

        if (line[12].equals(""))
            vers    = "9999";		
        else								
            vers    = sfill(line[12],4);		
        
        control     = line[0]+line[1]+line[2].substring(4,8)+line[2].substring(2,4)+line[2].substring(0,2)+
                      line[2].substring(8,12)+'4'+lat+lon+type+elev+call+vers;

        return control;
    }  // End of control

   /*
    * Constructs the string of mandatory elements for a record.
    */
    public static String mandantory(String [] line) 
    {
        String mandantory;

        if (line[13].equals("")) line[13] = "999";
        if (line[14].equals("")) line[14] = "9";
        if (line[15].equals("")) line[15] = "9";
        if (line[18].equals("")) line[18] = "9";
        if (line[25].equals("")) line[25] = "9";             
        if (line[26].equals("")) line[26] = "9";             
        if (line[28].equals("")) line[28] = "9";             
        if (line[31].equals("")) line[31] = "9";             
        if (line[32].equals("")) line[32] = "9";             
        if (line[33].equals("")) line[33] = "9";             
        if (line[35].equals("")) line[35] = "9";             
        if (line[37].equals("")) line[37] = "9";             
        if (line[39].equals("")) line[39] = "9";             

        String dir  = frmt(line[13],3,0,1);
        String spd  = frmt(line[17],4,0,10);
        String cc   = frmt(line[24],5,0,1); 
        String vsby = frmt(line[30],6,0,1); 
        String db   = frmt(line[34],5,1,10);
        String dp   = frmt(line[36],5,1,10);
        String slp  = frmt(line[38],5,0,10);

        mandantory  = dir+line[14]+line[15]+spd+line[18]+cc+line[25]+line[26]+line[28]+  
                      vsby+line[31]+line[32]+line[33]+db+line[35]+dp+line[37]+slp+line[39];     

        return mandantory;
    }  // End of mandantory

   /*
    * Constructs the string of additional elements for a record.   
    */
    public static String additional(String datatype, String []line) 
    {
        String additional="";
        if (datatype.equals("cld_lyr_hdr"))
        {
            //GA section
            if (line[9].length()>0||line[11].length()>0||line[13].length()>0)		
            {
                if (line[9].equals("/"))
                {
                    line[9]="10";
                }
                if (line[13].equals("/"))
                {
                    line[13]="10";
                }
                String skc=frmt(line[9],2,0,1);							
                String skh=frmt(line[11],6,1,1);						
                String skt=frmt(line[13],2,0,1);						
                if (line[10].equals(""))line[10]="9";					
                if (line[12].equals(""))line[12]="9";					
                if (line[14].equals(""))line[14]="9";					
                additional+="GA1"+skc+line[10]+skh+line[12]+skt+line[14];
            }

            if (line[15].length()>0||line[17].length()>0||line[19].length()>0)		
            {
                if (line[15].equals("/"))
                {
                    line[15]="10";
                }
                if (line[19].equals("/"))
                {
                    line[19]="10";
                }
                String skc=frmt(line[15],2,0,1);						
                String skh=frmt(line[17],6,1,1);						
                String skt=frmt(line[19],2,0,1);						
                if (line[16].equals(""))line[16]="9";					
                if (line[18].equals(""))line[18]="9";					
                if (line[20].equals(""))line[20]="9";					
                additional+="GA2"+skc+line[16]+skh+line[18]+skt+line[20];
            }

            if (line[21].length()>0||line[23].length()>0||line[25].length()>0)		
            {
                if (line[21].equals("/"))
                {
                    line[21]="10";
                }
                if (line[25].equals("/"))
                {
                    line[25]="10";
                }
                String skc=frmt(line[21],2,0,1);						
                String skh=frmt(line[23],6,1,1);						
                String skt=frmt(line[25],2,0,1);						
                if (line[22].equals(""))line[22]="9";					
                if (line[24].equals(""))line[24]="9";					
                if (line[26].equals(""))line[26]="9";					
                additional+="GA3"+skc+line[22]+skh+line[24]+skt+line[26];
            }

            if (line[27].length()>0||line[29].length()>0||line[31].length()>0)		
            {
                if (line[27].equals("/"))
                {
                    line[27]="10";
                }
                if (line[31].equals("/"))
                {
                    line[31]="10";
                }
                String skc=frmt(line[27],2,0,1);						
                String skh=frmt(line[29],6,1,1);						
                String skt=frmt(line[31],2,0,1);						
                if (line[28].equals(""))line[28]="9";					
                if (line[30].equals(""))line[30]="9";					
                if (line[32].equals(""))line[32]="9";					
                additional+="GA4"+skc+line[28]+skh+line[30]+skt+line[32];
            }

            if (line[33].length()>0||line[35].length()>0||line[37].length()>0)		
            {
                if (line[33].equals("/"))
                {
                    line[33]="10";
                }
                if (line[37].equals("/"))
                {
                    line[37]="10";
                }
                String skc=frmt(line[33],2,0,1);						
                String skh=frmt(line[35],6,1,1);						
                String skt=frmt(line[37],2,0,1);						
                if (line[34].equals(""))line[34]="9";					
                if (line[36].equals(""))line[36]="9";					
                if (line[38].equals(""))line[38]="9";					
                additional+="GA5"+skc+line[34]+skh+line[36]+skt+line[38];
            }
  
            if (line[39].length()>0||line[41].length()>0||line[43].length()>0)		
            {
                if (line[39].equals("/"))
                {
                    line[39]="10";
                }
                if (line[43].equals("/"))
                {
                    line[43]="10";
                }
                String skc=frmt(line[39],2,0,1);						
                String skh=frmt(line[41],6,1,1);						
                String skt=frmt(line[43],2,0,1);						
                if (line[40].equals(""))line[40]="9";					
                if (line[42].equals(""))line[42]="9";					
                if (line[44].equals(""))line[44]="9";					
                additional+="GA6"+skc+line[40]+skh+line[42]+skt+line[44];
            }
            //GD section
            if (line[45].length()>0||line[47].length()>0||line[49].length()>0)		
            {
                String ht=frmt(line[45],6,1,1);							
                if (line[47].equals(""))line[47]="9";					
                if (line[48].equals(""))line[48]="9";					
                if (line[46].equals(""))line[46]="9";					
                if (line[49].equals(""))line[49]="9";					
                additional+="GD1"+line[47]+"99"+line[48]+ht+line[46]+line[49];		
            }

            if (line[51].length()>0||line[53].length()>0||line[55].length()>0)		
            {
                String ht=frmt(line[51],6,1,1);							
                if (line[53].equals(""))line[53]="9";					
                if (line[54].equals(""))line[54]="9";					
                if (line[52].equals(""))line[52]="9";					
                if (line[55].equals(""))line[55]="9";					
                additional+="GD2"+line[53]+"99"+line[54]+ht+line[52]+line[55];		
            }

            if (line[57].length()>0||line[59].length()>0||line[61].length()>0)		
            {
                String ht=frmt(line[57],6,1,1);							
                if (line[59].equals(""))line[59]="9";					
                if (line[60].equals(""))line[60]="9";					
                if (line[58].equals(""))line[58]="9";					
                if (line[61].equals(""))line[61]="9";					
                additional+="GD3"+line[59]+"99"+line[60]+ht+line[58]+line[61];		
            }

            if (line[63].length()>0||line[65].length()>0||line[67].length()>0)		
            {
                String ht=frmt(line[63],6,1,1);							
                if (line[65].equals(""))line[65]="9";					
                if (line[66].equals(""))line[66]="9";					
                if (line[64].equals(""))line[64]="9";					
                if (line[67].equals(""))line[67]="9";					
                additional+="GD4"+line[65]+"99"+line[66]+ht+line[64]+line[67];		
            }

            //GE section                                                                                        
            if (line[109].length()>0||line[110].length()>0||line[111].length()>0||line[112].length()>0)         
            {                                                                                                   
                String vert=sfill(line[110],6);			        		
                String uppr=frmt(line[111],6,1,1);					
                String lowr=frmt(line[112],6,1,1);					
                if (line[109].equals(""))line[109]="9";		        				        
                additional+="GE1"+line[109]+vert+uppr+lowr;                                                     
            }                                                                                                   

            // NOTE: GD5 and GD6 are in the srtaddln function but not in the 
            // gen3 USAF format, so no code above to handle them.

            //GG section
            if (line[69].length()>0||line[71].length()>0||line[73].length()>0||line[75].length()>0)	
            {
                if (line[69].equals("/"))
                {
                    line[69]="10";
                }
                if (line[73].equals("/"))
                {
                    line[73]="10";
                }
                String cov=frmt(line[69],2,0,1);										
                String ht=frmt(line[71],5,0,1);											
                String typ=frmt(line[73],2,0,1);										
                String top=frmt(line[75],2,0,1);										
                if (line[70].equals(""))line[70]="9";									
                if (line[72].equals(""))line[72]="9";									
                if (line[74].equals(""))line[74]="9";									
                if (line[76].equals(""))line[76]="9";									
                additional+="GG1"+cov+line[70]+ht+line[72]+typ+line[74]+top+line[76];	
            }

            if (line[77].length()>0||line[79].length()>0||line[81].length()>0||line[83].length()>0)	
            {
                if (line[77].equals("/"))
                {
                    line[77]="10";
                }
                if (line[81].equals("/"))
                {
                    line[81]="10";
                }
                String cov=frmt(line[77],2,0,1);										
                String ht=frmt(line[79],5,0,1);											
                String typ=frmt(line[81],2,0,1);										
                String top=frmt(line[83],2,0,1);										
                if (line[78].equals(""))line[78]="9";									
                if (line[80].equals(""))line[80]="9";									
                if (line[82].equals(""))line[82]="9";									
                if (line[84].equals(""))line[84]="9";									
                additional+="GG2"+cov+line[78]+ht+line[80]+typ+line[82]+top+line[84];	
            }

            if (line[85].length()>0||line[87].length()>0||line[89].length()>0||line[91].length()>0)	
            {
                if (line[85].equals("/"))
                {
                    line[85]="10";
                }
                if (line[89].equals("/"))
                {
                    line[89]="10";
                }
                String cov=frmt(line[85],2,0,1);										
                String ht=frmt(line[87],5,0,1);											
                String typ=frmt(line[89],2,0,1);										
                String top=frmt(line[91],2,0,1);										
                if (line[86].equals(""))line[86]="9";									
                if (line[88].equals(""))line[88]="9";									
                if (line[90].equals(""))line[90]="9";									
                if (line[92].equals(""))line[92]="9";									
                additional+="GG3"+cov+line[86]+ht+line[88]+typ+line[90]+top+line[92];	
            }

            if (line[93].length()>0||line[95].length()>0||line[97].length()>0||line[99].length()>0)	
            {
                if (line[93].equals("/"))
                {
                    line[93]="10";
                }
                if (line[97].equals("/"))
                {
                    line[97]="10";
                }
                String cov=frmt(line[93],2,0,1);										
                String ht=frmt(line[95],5,0,1);											
                String typ=frmt(line[97],2,0,1);										
                String top=frmt(line[99],2,0,1);										
                if (line[94].equals(""))line[94]="9";		
                if (line[96].equals(""))line[96]="9";		
                if (line[98].equals(""))line[98]="9";		
                if (line[100].equals(""))line[100]="9";			
                additional+="GG4"+cov+line[94]+ht+line[96]+typ+line[98]+top+line[100];	
            }

            if (line[101].length()>0||line[103].length()>0||line[105].length()>0||line[107].length()>0)	
            {
                if (line[101].equals("/"))
                {
                    line[101]="10";
                }
                if (line[105].equals("/"))
                {
                    line[105]="10";
                }
                String cov=frmt(line[101],2,0,1);										
                String ht=frmt(line[103],5,0,1);										
                String typ=frmt(line[105],2,0,1);										
                String top=frmt(line[107],2,0,1);										
                if (line[102].equals(""))line[102]="9";		
                if (line[104].equals(""))line[104]="9";		
                if (line[106].equals(""))line[106]="9";		
                if (line[108].equals(""))line[108]="9";		
                additional+="GG5"+cov+line[102]+ht+line[104]+typ+line[106]+top+line[108];
            }

           // NOTE: GG6 is in the srtaddln function but not in the gen3 USAF format, 
           // so no code above to handle it.

        } // cld_lyr_hdr
        else if (datatype.equals("extremes_hdr"))
        {
            String grp  = "";
            String tp   = "";
            String et   = "";
            String dur  = "";

            //KA1 & KA2 section
            if(line[9].length()>0&&line[15].length()>0)	
            {
                if (line[9].equals("N")&&line[15].equals("M"))		
                {
                    tp=frmt(line[17],3,0,10);			
                    et=frmt(line[19],5,1,10);			
                    if (line[15].equals(""))line[15]="9";			// This can never be true.  12/28/2012  ras
                    if (line[20].equals(""))line[20]="9";
                    grp="KA1";
                    additional+=grp+tp+line[15]+et+line[20];		
                    tp=frmt(line[11],3,0,10);			
                    et=frmt(line[13],5,1,10);			
                    if (line[9].equals(""))line[9]="9";				// This can never be true.  12/28/2012  ras
                    if (line[14].equals(""))line[14]="9";
                    grp="KA2";
                    additional+=grp+tp+line[9]+et+line[14];
                }
                else
                {
                    tp=frmt(line[11],3,0,10);			
                    et=frmt(line[13],5,1,10);			
                    if (line[9].equals(""))line[9]="9";				// This can never be true.  12/28/2012  ras
                    if (line[14].equals(""))line[14]="9";
                    grp="KA1";
                    additional+=grp+tp+line[9]+et+line[14];
                    tp=frmt(line[17],3,0,10);			
                    et=frmt(line[19],5,1,10);			
                    if (line[15].equals(""))line[15]="9";			// This can never be true.  12/28/2012  ras
                    if (line[20].equals(""))line[20]="9";
                    grp="KA2";
                    additional+=grp+tp+line[15]+et+line[20];		
                }
            }
            else if(line[9].length()>0||line[15].length()>0)		
            {
                if(line[9].length()>0)					
                {
                    tp=frmt(line[11],3,0,10);			
                    et=frmt(line[13],5,1,10);			
                    if (line[9].equals(""))line[9]="9";	
                    if (line[14].equals(""))line[14]="9";
                    grp="KA1";
                    additional+=grp+tp+line[9]+et+line[14];
                }
                else
                {
                    tp=frmt(line[17],3,0,10);			
                    et=frmt(line[19],5,1,10);			
                    if (line[15].equals(""))line[15]="9";
                    if (line[20].equals(""))line[20]="9";
                    grp="KA1";
                    additional+=grp+tp+line[15]+et+line[20];		
                }
            }

            //KA3 & KA4 section								
            if(line[21].length()>0&&line[27].length()>0)
            {
                if (line[21].equals("N")&&line[27].equals("M"))
                {
                    tp=frmt(line[29],3,0,10);
                    et=frmt(line[31],5,1,10);
                    if (line[27].equals(""))line[27]="9";			// This can never be true.  12/28/2012  ras
                    if (line[32].equals(""))line[32]="9";
                    grp="KA3";
                    additional+=grp+tp+line[27]+et+line[32];
                    tp=frmt(line[23],3,0,10);
                    et=frmt(line[25],5,1,10);
                    if (line[21].equals(""))line[21]="9";			// This can never be true.  12/28/2012  ras
                    if (line[26].equals(""))line[26]="9";
                    grp="KA4";
                    additional+=grp+tp+line[21]+et+line[26];
                }
                else
                {
                    tp=frmt(line[23],3,0,10);
                    et=frmt(line[25],5,1,10);
                    if (line[21].equals(""))line[21]="9";			// This can never be true.  12/28/2012  ras
                    if (line[26].equals(""))line[26]="9";
                    grp="KA3";
                    additional+=grp+tp+line[21]+et+line[26];
                    tp=frmt(line[29],3,0,10);
                    et=frmt(line[31],5,1,10);
                    if (line[27].equals(""))line[27]="9";			// This can never be true.  12/28/2012  ras
                    if (line[32].equals(""))line[32]="9";
                    grp="KA4";
                    additional+=grp+tp+line[27]+et+line[32];
                }
            }
            else if(line[21].length()>0||line[27].length()>0)
            {
                if(line[21].length()>0)
                {
                    tp=frmt(line[23],3,0,10);
                    et=frmt(line[25],5,1,10);
                    if (line[21].equals(""))line[21]="9";
                    if (line[26].equals(""))line[26]="9";
                    grp="KA3";
                    additional+=grp+tp+line[21]+et+line[26];
                }
                else
                {
                    tp=frmt(line[29],3,0,10);
                    et=frmt(line[31],5,1,10);
                    if (line[27].equals(""))line[27]="9";
                    if (line[32].equals(""))line[32]="9";
                    grp="KA3";
                    additional+=grp+tp+line[27]+et+line[32];
                }
            }

            //OD1 section                                                                   
            if (line[33].length()>0||line[35].length()>0||line[37].length()>0||line[39].length()>0) 
            {                                                                               
                String dur1=frmt(line[35],2,0,1);					    
                String obp=frmt(line[37],4,0,10);					    
                String wdr=frmt(line[39],3,0,1);					    
                if (line[33].equals(""))line[33]="9";					    
                if (line[38].equals(""))line[38]="9";					    
                additional+="OD1"+line[33]+dur1+obp+line[38]+wdr;		    	    
            }

            //OD2 section
            if (line[40].length()>0||line[42].length()>0||line[44].length()>0||line[46].length()>0) 
            {                                                                               
                String dur1=frmt(line[42],2,0,1);					    
                String obp=frmt(line[44],4,0,10);					    
                String wdr=frmt(line[46],3,0,1);					    
                if (line[40].equals(""))line[40]="9";					    
                if (line[45].equals(""))line[45]="9";					    
                additional+="OD2"+line[40]+dur1+obp+line[45]+wdr;		    	    
            }

            //OD3 section
            if (line[47].length()>0||line[49].length()>0||line[51].length()>0||line[53].length()>0) 
            {                                                                               
                String dur1=frmt(line[49],2,0,1);					    
                String obp=frmt(line[51],4,0,10);					    
                String wdr=frmt(line[53],3,0,1);					    
                if (line[47].equals(""))line[47]="9";					    
                if (line[52].equals(""))line[52]="9";					    
                additional+="OD3"+line[47]+dur1+obp+line[52]+wdr;		    	    
            }

        } // extremes_hdr 
        else if (datatype.equals("ocn_meas_hdr"))
        {
            //UA section
            if (line[11].length()>0||line[12].length()>0||line[14].length()>0||line[16].length()>0)	
            {
                String prd=frmt(line[12],2,0,1);					
                String wh=frmt(line[14],3,0,10);					
                String st=frmt(line[16],2,0,1);						
                if (line[11].equals(""))line[11]="9";	
                if (line[15].equals(""))line[15]="9";				
                if (line[17].equals(""))line[17]="9";				
                additional+="UA1"+line[11]+prd+wh+line[15]+st+line[17];
            }
            //UG1 section
            if (line[18].length()>0||line[20].length()>0||line[22].length()>0)	
            {
                String prd=frmt(line[18],2,0,1);					
                String wh=frmt(line[20],3,0,10);					
                String sdr=frmt(line[22],3,0,1);					
                if (line[21].equals(""))line[21]="9";				
                additional+="UG1"+prd+wh+sdr+line[21];				
            }
            //UG2 section
            if (line[24].length()>0||line[26].length()>0||line[28].length()>0)	
            {
                String prd=frmt(line[24],2,0,1);					
                String wh=frmt(line[26],3,0,10);					
                String sdr=frmt(line[28],3,0,1);					
                if (line[27].equals(""))line[27]="9";				
                additional+="UG2"+prd+wh+sdr+line[27];				
            }
            //WA section
            if (line[30].length()>0||line[32].length()>0||line[34].length()>0)	
            {
                String wh=frmt(line[32],3,0,10);					

                if (line[30].equals(""))line[30]="9";				
                if (line[34].equals(""))line[34]="9";				
                if (line[33].equals(""))line[33]="9";				
                additional+="WA1"+line[30]+wh+line[34]+line[33];	
            }
            //WG section
            if (line[36].length()>0||line[38].length()>0||line[39].length()>0||line[40].length()>0||line[41].length()>0)	
            {
                String wg1=frmt(line[36],2,0,1);					
                String wg2=frmt(line[38],2,0,1);					
                String wg3=frmt(line[39],2,0,1);					
                String wg4=frmt(line[40],2,0,1);					
                String wg5=frmt(line[41],2,0,1);					
                additional+="WG1"+wg1+wg2+wg3+wg4+wg5+" ";
            }
            //WD section
            if (line[42].length()>0||line[44].length()>0||line[46].length()>0||line[52].length()>0||	
                line[47].length()>0||line[48].length()>0||line[56].length()>0||line[57].length()>0)		
            {
                if (line[46].equals("/"))
                {
                    line[46]="99";
                }
                String brg=frmt(line[42],2,0,1);					
                String con1=frmt(line[44],3,0,1);					
                String con2=frmt(line[46],2,0,1);					
                String dev=frmt(line[52],2,0,1);					
                String grw=frmt(line[56],3,0,1);					
                String ibg=frmt(line[57],3,0,1);					
                if (line[47].equals(""))line[47]="9";				
                if (line[48].equals(""))line[48]="9";				
                if (line[50].equals(""))line[50]="9";				
                if (line[54].equals(""))line[54]="9";				
                if (line[55].equals(""))line[55]="9";				
                additional+="WD1"+brg+con1+con2+line[47]+line[48]+line[50]+dev+line[54]+grw+ibg+line[55];	
            }

            //WJ section                                                                                
            if (line[58].length()>0||line[59].length()>0||line[60].length()>0||line[61].length()>0||    
                line[62].length()>0||line[63].length()>0||line[64].length()>0)	                        
            {                                                                                           
                String iceth=frmt(line[58],3,0,1);							
                String disch=frmt(line[59],5,0,1);							
                String pri=sfill(line[60],2);		        					
                String sec=sfill(line[61],2);		        					
                String hgt=frmt(line[62],5,1,1);						
                String und=sfill(line[63],1);		        					
                String lvl=sfill(line[64],1);		        					
                additional+="WJ1"+iceth+disch+pri+sec+hgt+und+lvl;			        	
            }                                                                                           
        } // ocn_meas_hdr
        else if (datatype.equals("quality_hdr"))
        {
            String qtyp=sfill(line[12],6);					
            String orig=sfill(line[10],6);			
            String rejectID=line[4];        						              
            boolean bGood=true;                                                                        
            if (rejectID.length() == 3)
            {
                if (rejectID.substring(0,1).equals("C") || rejectID.substring(0,1).equals("D") || rejectID.substring(0,1).equals("Q"))
                {
//                    rejectID="Q"+rejectID.substring(1,3);
                }
                else
                {
                    logIt(fLog, "Quality section: ERROR - line[4]=["+line[4]+"]. REJECTID value error. Skipping...");
//                    System.exit(88);  // TODO decide if this is important for any reason.
                    bGood = false;
                }
            }
            else
            {
                if (rejectID.length() == 2)      // Problem with data prior to 08/01/2013
                {
                    if (rejectID.substring(0,1).equals("C") || rejectID.substring(0,1).equals("D") || rejectID.substring(0,1).equals("Q"))
                    {
                        String rejectID_prefix = rejectID.substring(0,1);

                        rejectID=frmt(line[4].substring(1,2),2,0,1);
                        rejectID=rejectID_prefix+rejectID;
                    }
                    else
                    {
                        if (rejectID.substring(0,2).matches("\\d+")) 
                        {
                            rejectID=frmt(line[4],2,0,1);
                            rejectID="Q"+rejectID;
                        }
                        else
                        {
                            logIt(fLog, "Quality section: ERROR - line[4]=["+line[4]+"]. REJECTID value error. Skipping...");
                            bGood = false;
                        }
                    }
                }
                else
                {
                    if (rejectID.length() == 1)
                    {
                        if (rejectID.substring(0,1).matches("\\d+"))   // Must be numeric. 
                        {
                            rejectID=frmt(line[4],2,0,1);
                            rejectID="Q"+rejectID;
                        }
                        else
                        {
                            logIt(fLog, "Quality section: ERROR - line[4]=["+line[4]+"]. REJECTID value error. Skipping...");
                            bGood = false;
                        }
                    }
                    else
                    {
                        logIt(fLog, "Quality section: ERROR - line[4]=["+line[4]+"]. REJECTID length error. Skipping...");
//                    System.exit(89);
                        bGood = false;
                    }
                }
            }
            if (bGood)                                               
            {
                additional+=rejectID+orig+line[11]+qtyp;
            }
        } // quality_hdr
        else if (datatype.equals("obs_hdr"))
        {
            //AA section
            additional="";

            if (line[40].length()>0||line[42].length()>0||line[44].length()>0)	
            {
                String dur=frmt(line[40],2,0,1);					
                String prcp=frmt(line[42],4,0,10);					
                if ( prcp.length() > 4 )                                             
                {                                                                    
                    prcp = prcp.substring(0,4);                                      
                }                                                                    
                if (line[43].equals(""))line[43]="9";				
                if (line[44].equals(""))line[44]="9";				
                additional+="AA1"+dur+prcp+line[44]+line[43];		
            }
           
            if (line[46].length()>0||line[48].length()>0||line[50].length()>0)	
            {
                String dur=frmt(line[46],2,0,1);					
                String prcp=frmt(line[48],4,0,10);					
                if ( prcp.length() > 4 )                                             
                {                                                                    
                    prcp = prcp.substring(0,4);                                      
                }                                                                    
                if (line[49].equals(""))line[49]="9";				
                if (line[50].equals(""))line[50]="9";				
                additional+="AA2"+dur+prcp+line[50]+line[49];		
            }
            
            if (line[52].length()>0||line[54].length()>0||line[56].length()>0)	
            {
                String dur=frmt(line[52],2,0,1);					
                String prcp=frmt(line[54],4,0,10);					
                if ( prcp.length() > 4 )                                             
                {                                                                    
                    prcp = prcp.substring(0,4);                                      
                }                                                                    
                if (line[55].equals(""))line[55]="9";				
                if (line[56].equals(""))line[56]="9";				
                additional+="AA3"+dur+prcp+line[56]+line[55];		
            }
           
            if (line[58].length()>0||line[60].length()>0||line[62].length()>0)	
            {
                String dur=frmt(line[58],2,0,1);					
                String prcp=frmt(line[60],4,0,10);					
                if ( prcp.length() > 4 )                                             
                {                                                                    
                    prcp = prcp.substring(0,4);                                      
                }                                                                    
                if (line[61].equals(""))line[61]="9";				
                if (line[62].equals(""))line[62]="9";				
                additional+="AA4"+dur+prcp+line[62]+line[61];		
            }
            //AC section
            if (!line[64].equals("")||line[66].length()>0)			
            {
                if (line[64].equals(""))line[64]="9";				
                if (line[66].equals(""))line[66]="9";				
                if (line[67].equals(""))line[67]="9";				
                additional+="AC1"+line[64]+line[66]+line[67];		
            }
            //AG section
            if (line[68].length()>0||line[70].length()>0)			
            {
                String ep =frmt(line[70],3,0,1);					
                if (line[68].equals(""))line[68]="9";				
                additional+="AG1"+line[68]+ep;						
            }
            //AJ section
            if (line[72].length()>0||line[74].length()>0||line[76].length()>0||line[78].length()>0)	
            {
                String snd =frmt(line[72],4,0,1);					
                String sndw =frmt(line[76],6,0,10);					
                if (line[73].equals(""))line[73]="9";				
                if (line[74].equals(""))line[74]="9";				
                if (line[77].equals(""))line[77]="9";				
                if (line[78].equals(""))line[78]="9";				
                additional+="AJ1"+snd+line[74]+line[73]+sndw+line[78]+line[77];	
            }
            //HL section
            if (!line[80].equals(""))								
            {
                String hl1=frmt(line[80],3,0,10);					
                additional+="HL1"+hl1+"9";
            }
            //AL section
            if (line[85].length()>0||line[81].length()>0||line[83].length()>0)	
            {
                String dur=frmt(line[85],2,0,1);					
                String snf=frmt(line[81],3,0,1);					
                if (line[82].equals(""))line[82]="9";		
                if (line[83].equals(""))line[83]="9";		
                additional+="AL1"+dur+snf+line[83]+line[82];		
            }

            if (line[91].length()>0||line[87].length()>0||line[89].length()>0)	
            {
                String dur=frmt(line[91],2,0,1);					
                String snf=frmt(line[87],3,0,1);					
                if (line[88].equals(""))line[88]="9";				
                if (line[89].equals(""))line[89]="9";				
                additional+="AL2"+dur+snf+line[89]+line[88];		
            }

            if (line[97].length()>0||line[93].length()>0||line[95].length()>0)	
            {
                String dur=frmt(line[97],2,0,1);					
                String snf=frmt(line[93],3,0,1);					
                if (line[94].equals(""))line[94]="9";				
                if (line[95].equals(""))line[95]="9";				
                additional+="AL3"+dur+snf+line[95]+line[94];		
            }

            if (line[103].length()>0||line[99].length()>0||line[101].length()>0)	
            {
                String dur=frmt(line[103],2,0,1);					
                String snf=frmt(line[99],3,0,1);					
                if (line[100].equals(""))line[100]="9";				
                if (line[101].equals(""))line[101]="9";				
                additional+="AL4"+dur+snf+line[101]+line[100];		
            }
            //AW section
            if (!line[119].equals(""))								
            {
                String awx=zfill(line[119],2,0);					
                if (line[120].equals(""))line[120]="9";				
                additional+="AW1"+awx+line[120];					
            }
            if (!line[121].equals(""))				
            {
                String awx=zfill(line[121],2,0);					
                if (line[122].equals(""))line[122]="9";				
                additional+="AW2"+awx+line[122];					
            }
            if (!line[123].equals(""))								
            {
                String awx=zfill(line[123],2,0);					
                if (line[124].equals(""))line[124]="9";				
                additional+="AW3"+awx+line[124];		
            }
            //AY section
            if (!line[125].equals("")||line[127].length()>0)		
            {
                String dur=frmt(line[127],2,0,1);					
                if (line[126].equals(""))line[126]="9";				
                if (line[128].equals(""))line[128]="9";				
                additional+="AY1"+line[125]+line[126]+dur+line[128];
            }
            if (!line[129].equals("")||line[131].length()>0)		
            {
                String dur=frmt(line[131],2,0,1);					
                if (line[130].equals(""))line[130]="9";				
                if (line[132].equals(""))line[132]="9";				
                additional+="AY2"+line[129]+line[130]+dur+line[132];
            }
            //AZ section
            if (!line[133].equals("")||line[135].length()>0)		
            {
                String dur=frmt(line[135],2,0,1);					
                if (line[134].equals(""))line[134]="9";				
                if (line[136].equals(""))line[136]="9";				
                additional+="AZ1"+line[133]+line[134]+dur+line[136];
            }
            if (!line[137].equals("")||line[139].length()>0)		
            {
                String dur=frmt(line[139],2,0,1);					
                if (line[138].equals(""))line[138]="9";				
                if (line[140].equals(""))line[140]="9";				
                additional+="AZ2"+line[137]+line[138]+dur+line[140];
            }
            
            //ED section was commented out/removed

            //GF  section
            if (line[141].length()>0||line[143].length()>0||line[147].length()>0||line[145].length()>0||line[149].length()>0||line[151].length()>0)	
            {
                if (line[141].equals("/"))                                                              
                {
                    line[141]="10";
                    logIt(fLog, "GF Section: INFO - line[141] = '/'. Changed to '10'");      
                }
                if (line[143].equals("/"))                                                       
                {
                    line[143]="10";
                    logIt(fLog, "GF Section: INFO - line[143] = '/'. Changed to '10'");     
                }
                if (line[147].equals("/"))
                {
                    line[147]="99";
                }
                if (line[149].equals("/"))
                {
                    line[149]="99";
                }
                if (line[151].equals("/"))
                {
                    line[151]="99";
                }
               String gf0   = frmt(line[141],2,0,1);				
               String gf1   = frmt(line[143],2,0,1);				
               String gf2   = frmt(line[147],2,0,1);				
               String gf3   = frmt(line[145],5,0,1);				
               String gf4   = frmt(line[149],2,0,1);				
               String gf5   = frmt(line[151],2,0,1);				

               if (line[142].equals("")) line[142] = "9";			
               if (line[144].equals("")) line[144] = "9";			
               if (line[146].equals("")) line[146] = "9";			
               if (line[148].equals("")) line[148] = "9";			
               if (line[150].equals("")) line[150] = "9";			
               if (line[152].equals("")) line[152] = "9";			
               additional+="GF1"+gf0+"99"+line[142]+gf1+line[144]+gf2+line[148]+gf3+line[146]+gf4+line[150]+gf5+line[152];	
            }
            //GJ section
            if (!line[153].equals(""))								
            {
                String gj1 =zfill(line[153],4,0);					
                additional+="GJ1"+gj1+"9";
            }
            //IA1 section
            if (!line[154].equals(""))								
            {
                String ia1=zfill(line[154],2,0);					
                if (line[155].equals(""))line[155]="9";				
                additional+="IA1"+ia1+line[155];					
            }
            //IA2 section
            if (line[159].length()>0||line[156].length()>0)			
            {
                String md1 =frmt(line[159],3,0,10);					
                String md2 =frmt(line[156],5,1,10);					
                if (line[157].equals(""))line[157]="9";				
                additional+="IA2"+md1+md2+line[157];				
            }
            //MA section
            if (line[161].equals("")&& line[163].equals(""))		
            {
            }else{
                String ma1 =frmt(line[161],5,0,10);					
                String ma2 =frmt(line[163],5,0,10);					
                if (line[162].equals(""))line[162]="9";				
                if (line[164].equals(""))line[164]="9";				
                additional+="MA1"+ma1+line[162]+ma2+line[164];		
            }
            //MD section
            if (line[165].length()>0||line[167].length()>0||line[169].length()>0)	
            {
                // Drop leading sign
                if ( line[167].length()>0 )                                         
                {                                                                   
                    if ( line[167].substring(0,1).equals("-") )                     
                    {                                                               
                        line[167] = line[167].substring(1,line[167].length());      
                    }                                                               
                }
                String md1 =    frmt(line[167],3,0,10);				
                String md2 =    frmt(line[169],4,1,10);				

                if (line[165].equals("")) line[165] = "9";			
                if (line[166].equals("")) line[166] = "9";			
                if (line[168].equals("")) line[168] = "9";			
                if (line[170].equals("")) line[170] = "9";			
                additional+="MD1"+line[165]+line[166]+md1+line[168]+md2+line[170];	
            }
            //ME section
            if ( (!line[172].equals("")) || (line[174].length()>0) )		
            {
                if ( line[172].equals("") )                                         
                {                                                                   
                    line[172] = "9";                                                
                }                                                                   
                String ht=frmt(line[174],4,0,1);					
                if ( ht.length()<4 )                                                
                {                                                                   
                    logIt(fLog, "obs_hdr(): INFO - Record Nbr=["+iObsCounter+"] [ME1: ht length less than 4=["+ht+"]");  
                }                                                                   
                if (line[175].equals(""))line[175]="9";				
                additional+="ME1"+line[172]+ht+line[175];			
            }
            //MW section
            if (!line[105].equals(""))								
            {
                String mw1=zfill(line[105],2,0);					
                if (line[106].equals(""))line[106]="9";				
                additional+="MW1"+mw1+line[106];					
            }
            if (!line[107].equals(""))								
            {
                String mw2=zfill(line[107],2,0);					
                if (line[108].equals(""))line[108]="9";				
                additional+="MW2"+mw2+line[108];					
            }
            if (!line[109].equals(""))								
            {
                String mw3=zfill(line[109],2,0);					
                if (line[110].equals(""))line[110]="9";		
                additional+="MW3"+mw3+line[110];					
            }
            if (!line[111].equals(""))								
            {
                String mw4=zfill(line[111],2,0);					
                if (line[112].equals(""))line[112]="9";				
                additional+="MW4"+mw4+line[112];					
            }
            if (!line[113].equals(""))								
            {
                String mw5=zfill(line[113],2,0);					
                if (line[114].equals(""))line[114]="9";				
                additional+="MW5"+mw5+line[114];					
            }
            if (!line[115].equals(""))								
            {
                String mw6=zfill(line[115],2,0);					
                if (line[116].equals(""))line[116]="9";				
                additional+="MW6"+mw6+line[116];					
            }
            if (!line[117].equals(""))								
            {
                String mw7=zfill(line[117],2,0);					
                if (line[118].equals(""))line[118]="9";				
                additional+="MW7"+mw7+line[118];					
            }
            //OC section
            if (!line[21].equals(""))								
            {
                String gst =frmt(line[21],4,0,10);					
                if (line[22].equals(""))line[22]="9";				
                additional+="OC1"+gst+line[22];						
            }
            //SA section
            if (!line[176].equals(""))								
            {
                String sst=frmt(line[176],4,1,10);					
                if (line[177].equals(""))line[177]="9";				
                additional+="SA1"+sst+line[177];					
            }
        } // obs_hdr 
        else if (datatype.equals("visibility_hdr"))                             
        {                                                                       
            //ED section
            if (!line[18].equals("")||!line[19].equals("")||line[20].length()>0)
            {
                String dir;
                String vrng;

                if (line[18].equals(""))                                        
                {
                    dir="99";
                }
                else
                {
                    dir=zfill(line[18],2,0);                                    
                }

                vrng="99";
                try    // Check for case of non-numeric inputs. 
                {
                    vrng=frmt(line[20],4,0,1);                                  
                }
                catch (Exception e)
                {
                    System.out.println(script_name+"=>call to frmt(): ERROR - line[20]=["+line[20]+"] For ob=["+line[0]+","+line[1]+","+line[2]+"]");  
                    System.out.println("Error: " + e);
                    System.exit(14);
                }

                if (line[19].equals(""))line[19]="9";                           
                additional+="ED1"+dir+line[19]+vrng+"9";                        
            }
        } // visibility_hdr        

        return additional;
    }   // End of additional

   /*
    * Assembles the output record after first sorting the Additional section. 
    */
    public static String processobs(String obs1, String obs2, String obs3, String obs4, String obs5, 
                                    String obs6, String obs7, String obs8, String [] Line1) 
    {
        String value    = "";
        String srtvalue = "";
        String sRemark999 = "";     // Truncate remarks to max length of 999. 

        if(obs3 != null && !"".equals(obs3))
            value += obs3;
        if(obs4 != null && !"".equals(obs4))
            value += obs4;
        if(obs5 != null && !"".equals(obs5))
            value += obs5;
        if(obs6 != null && !"".equals(obs6))
            value += obs6;
        if(obs8 != null && !"".equals(obs8))                            
            value += obs8;                                              

        srtvalue=srtaddln(value);

        if(srtvalue.length() >0)
            srtvalue="ADD"+srtvalue;

        if(Line1[178].length()>0||Line1[179].length()>0||Line1[180].length()>0)		 
            srtvalue = srtvalue+"REM";

        if(!Line1[178].substring(0).equals(""))				
        {
            sRemark999 = Line1[178];
            int     a1  = sRemark999.length();
            if (a1 > 999)
            {
                sRemark999 = Line1[178].substring(0,999);    // Grab first 999 chars.
                a1 = sRemark999.length();				     // Reset length after truncate.
                logIt(fLog, "processobs(): INFO - ["+Line1[0]+","+Line1[1]+","+Line1[2]+","+Line1[3]+","+Line1[4]+","+Line1[5]+"] SYN Remark truncated from "+Line1[178].length()+" to "+a1+" characters");
                logIt(fLog, "processobs(): INFO - Before=["+Line1[178]+"]");
                logIt(fLog, "processobs(): INFO -  After=["+sRemark999+"]");
            }
            String  a1a = Integer.toString(a1);
            String  l1  = zfill(a1a,3,0);
            srtvalue    = srtvalue+"SYN"+l1+sRemark999;		
        }

        if(!Line1[179].substring(0).equals(""))				
        {
            sRemark999 = Line1[179];
            int     a2  = sRemark999.length();
            if (a2 > 999)
            {
                sRemark999 = Line1[179].substring(0,999);    // Grab first 999 chars. 
                a2 = sRemark999.length();				     // Reset length after truncate.
                logIt(fLog, "processobs(): INFO - ["+Line1[0]+","+Line1[1]+","+Line1[2]+","+Line1[3]+","+Line1[4]+","+Line1[5]+"] MET Remark truncated from "+Line1[179].length()+" to "+a2+" characters");
                logIt(fLog, "processobs(): INFO - Before=["+Line1[179]+"]");
                logIt(fLog, "processobs(): INFO -  After=["+sRemark999+"]");
            }
            String  a2a = Integer.toString(a2);
            String  l2  = zfill(a2a,3,0);
            srtvalue    = srtvalue+"MET"+l2+sRemark999;					  
        }

        if(!Line1[180].substring(0).equals(""))				
        {
            sRemark999 = Line1[180];
            int     a3  = sRemark999.length();
            if (a3 > 999)
            {
                sRemark999 = Line1[180].substring(0,999);   // Grab first 999 chars.
                a3 = sRemark999.length();				    // Reset length after truncate.
                logIt(fLog, "processobs(): INFO - ["+Line1[0]+","+Line1[1]+","+Line1[2]+","+Line1[3]+","+Line1[4]+","+Line1[5]+"] AWY Remark truncated from "+Line1[180].length()+" to "+a3+" characters");
                logIt(fLog, "processobs(): INFO - Before=["+Line1[180]+"]");
                logIt(fLog, "processobs(): INFO -  After=["+sRemark999+"]");
            }
            String  a3a = Integer.toString(a3);
            String  l3  = zfill(a3a,3,0);
            srtvalue    = srtvalue+"AWY"+l3+sRemark999;					      
        }

        if(obs7 != null && !"".equals(obs7))
            srtvalue=srtvalue+obs7;

        int     reclen  = srtvalue.length();
        String  reclen1 = ""+reclen;
        String  sreclen = zfill(reclen1,4,0);
	    if(reclen>0)
            srtvalue=sreclen+obs1+obs2+srtvalue;
	    else
            srtvalue=sreclen+obs1+obs2;

        return srtvalue;
    }   // End of processobs

   /*
    * Writes a record to the output file handle.                                     
    */
    private static void obsWrite(String obs, BufferedWriter out) 
    {
        try
        {
            out.write(obs);
            out.write("\n");
        } catch (IOException e) {
            System.out.println(script_name+"=>obsWrite(): FATAL ERROR - IOException:");
            e.printStackTrace();
            System.exit(12);
        }
    }  // End of obsWrite

   /*
    * Append records to the log file.
    */
    public static int logIt(FileOutputStream p_fLog, String p_sIn)
    {
        int iRetCode=99;                 // Set default return code to something crazy.
        String sMessageFormatted="";

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:SSS");  
        Date now = new Date();
        sMessageFormatted=format.format(now)+" "+script_name+" - "+p_sIn;        

        if (bVerbose)
        {
            System.out.println(sMessageFormatted);  // Verbose mode will echo message to screen
        }

        try {
            new PrintStream(p_fLog).println (sMessageFormatted);                      
            iRetCode=0;                            // Good.
        }
        catch (Exception e) {
            System.err.println(script_name+": FATAL ERROR - Unspecified Exception in logIt. Error=[" + e.getMessage()+"]");
            System.err.println(script_name+": Stack trace follows:");
            e.printStackTrace();
            iRetCode=13;
            System.exit(13);
        }
        return iRetCode;
    }  // End of logIt

}  // End of Class
