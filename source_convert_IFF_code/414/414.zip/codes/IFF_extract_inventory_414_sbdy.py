# -*- coding: utf-8 -*-
"""
Hourly inventory builder for all variables (station-based)

Creates:
1. Per-variable inventory CSVs
2. Combined master inventory CSV

@author: snoone
"""

from pathlib import Path
import pandas as pd

# -------------------------------------------------
# Base paths
# -------------------------------------------------

ROOT_DIR = Path(
    r"C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/midas_uk-hourly-weather-obs_v202507_FLAT/midas_uk-hourly-weather-obs_v202507/stationdata"
)

# Variable folders are inside IFF
BASE_DIR = ROOT_DIR / "IFF"

MASTER_OUTPUT = BASE_DIR / "master_sub_daily_414_inventory.csv"

# Holds all variable inventories
variable_inventories = []

# -------------------------------------------------
# Iterate through variable folders
# -------------------------------------------------
for variable_dir in BASE_DIR.iterdir():

    # Skip non-directories
    if not variable_dir.is_dir():
        continue

    # Skip unwanted folders
    if variable_dir.name.lower() in [
        "meta",
        "inventory"
    ]:
        continue

    print("\n================================================")
    print(f"Processing variable: {variable_dir.name}")

    # -------------------------------------------------
    # Find ALL PSV files recursively
    # -------------------------------------------------
    psv_files = list(variable_dir.rglob("*.psv"))

    print(f" -> Found {len(psv_files)} PSV files")

    if not psv_files:
        continue

    records = []

    # -------------------------------------------------
    # Read each PSV file
    # -------------------------------------------------
    for file in psv_files:

        print(f"Reading: {file.name}")

        try:

            # -------------------------------------------------
            # Read PSV
            # -------------------------------------------------
            df = pd.read_csv(
                file,
                delimiter="|",
                dtype={
                    "Station_ID": str,
                    "Source_ID": str
                },
                low_memory=False
            )

            # Skip empty files
            if df.empty:
                print(" -> Empty file")
                continue

            # Preserve leading zeros
            df["Station_ID"] = (
                df["Station_ID"]
                .astype(str)
                .str.zfill(5)
            )

            # -------------------------------------------------
            # Required columns
            # -------------------------------------------------
            required_cols = [
                "Year",
                "Month",
                "Day",
                "Hour",
                "Source_ID",
                "Station_ID",
                "Station_name",
                "Latitude",
                "Longitude",
                "Elevation",
            ]

            missing = [
                c for c in required_cols
                if c not in df.columns
            ]

            if missing:
                print(f" -> Missing columns: {missing}")
                continue

            # -------------------------------------------------
            # Create timestamp
            # -------------------------------------------------
            df["Timestamp"] = pd.to_datetime(
                {
                    "year": df["Year"],
                    "month": df["Month"],
                    "day": df["Day"],
                    "hour": df["Hour"],
                },
                errors="coerce"
            )

            # Remove invalid timestamps
            df = df.dropna(subset=["Timestamp"])

            if df.empty:
                print(" -> No valid timestamps")
                continue

            # -------------------------------------------------
            # Sort chronologically
            # -------------------------------------------------
            df = df.sort_values("Timestamp")

            first = df.iloc[0]
            last = df.iloc[-1]

            # -------------------------------------------------
            # Create inventory record
            # -------------------------------------------------
            records.append({
                "Source_ID": first["Source_ID"],
                "Station_ID": first["Station_ID"],
                "Station_name": first["Station_name"],
                "Latitude": first["Latitude"],
                "Longitude": first["Longitude"],
                "Elevation": first["Elevation"],
                f"{variable_dir.name}_start": first["Year"],
                f"{variable_dir.name}_end": last["Year"],
            })

        except Exception as e:

            print(f" -> ERROR reading {file.name}")
            print(e)

    # -------------------------------------------------
    # Save per-variable inventory
    # -------------------------------------------------
    print(f" -> Created {len(records)} inventory records")

    if not records:
        continue

    var_df = pd.DataFrame(records)

    # Preserve leading zeros
    var_df["Station_ID"] = (
        var_df["Station_ID"]
        .astype(str)
        .str.zfill(5)
    )

    var_df["Source_ID"] = (
        var_df["Source_ID"]
        .astype(str)
    )

    # Remove duplicate stations
    var_df = var_df.drop_duplicates(
        subset=[
            "Source_ID",
            "Station_ID"
        ]
    )

    # Sort stations
    var_df = var_df.sort_values("Station_ID")

    # -------------------------------------------------
    # Save per-variable inventory
    # -------------------------------------------------
    var_output = (
        BASE_DIR /
        f"{variable_dir.name}_inventory.csv"
    )

    var_df.to_csv(
        var_output,
        index=False
    )

    print(f" -> Saved: {var_output.name}")

    # Store inventory
    variable_inventories.append(var_df)

# -------------------------------------------------
# Build master inventory
# -------------------------------------------------
print("\n================================================")
print("Building master inventory")

if not variable_inventories:

    print("❌ No inventories were created.")

else:

    # Start with first inventory
    master_df = variable_inventories[0]

    # Merge remaining inventories
    for df in variable_inventories[1:]:

        master_df = master_df.merge(
            df,
            on=[
                "Source_ID",
                "Station_ID",
                "Station_name",
                "Latitude",
                "Longitude",
                "Elevation",
            ],
            how="outer"
        )

    # Preserve leading zeros again
    master_df["Station_ID"] = (
        master_df["Station_ID"]
        .astype(str)
        .str.zfill(5)
    )

    # Remove duplicates
    master_df = master_df.drop_duplicates(
        subset=[
            "Source_ID",
            "Station_ID"
        ]
    )

    # Sort stations
    master_df = master_df.sort_values("Station_ID")

    # -------------------------------------------------
    # Save master inventory
    # -------------------------------------------------
    master_df.to_csv(
        MASTER_OUTPUT,
        index=False
    )

    print("\n✔ Master inventory created:")
    print(MASTER_OUTPUT)

    print(f"\nTotal stations: {len(master_df):,}")
    print(f"Total variables merged: {len(variable_inventories)}")