#!/bin/bash

python3.12 -m pytest