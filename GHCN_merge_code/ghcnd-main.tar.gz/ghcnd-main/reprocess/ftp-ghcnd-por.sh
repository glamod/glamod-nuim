#

export PREFIX=/home/mmenne/ghcnd2/
export ftpdatapath="/pub/data/ghcn/daily"

cd ${PREFIX}ghcnd_all
echo "open ftp0.ncdc.noaa.gov" > ftpin
echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
echo "cd "${ftpdatapath} >> ftpin
echo "cd "${ftpdatapath}"/all" >> ftpin
echo "bin" >> ftpin
for i in *.dly
 do
  echo "del "${i} >> ftpin
  echo "put "${i} >> ftpin
 done
echo "quit" >> ftpin
ftp -in < ftpin
rm ftpin
