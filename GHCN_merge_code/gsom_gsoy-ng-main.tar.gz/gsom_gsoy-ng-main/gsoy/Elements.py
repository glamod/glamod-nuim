import polars as pl
from enum import Enum
from collections import namedtuple

class CompareMethod:

    LESS_THAN = 0
    LESS_THAN_EQUAL_TO = 1
    EQUAL_TO = 2
    GREATER_THAN = 3
    GREATER_THAN_EQUAL_TO = 4
    NONE = 5

'''
Class that holds values used by elements for calculating.

flagPositions - Index of the flags from input files that get carried to output files 
precision - How many decimal places to round to
takeMean - If the total is averaged or not
'''
class Elements(Enum):

    AWND = ([1],1,True)
    CDSD = ([0],1,False)
    CLDD = ([1],1,False)
    DP01 = ([1],0,False)
    DP10 = ([1],0,False)
    DP1X = ([1],0,False)
    DSND = ([-1],0,False)
    DSNW = ([1],0,False)
    DT00 = ([1],0,False)
    DT32 = ([1],0,False)
    DX32 = ([1],0,False)
    DX70 = ([1],0,False)
    DX90 = ([1],0,False)

    DYFG = ([-1],0,False)
    DYHF = ([-1],0,False)
    DYTS = ([-1],0,False)

    EMNT = ([1],1,False)
    EMSD = ([2],0,False)
    EMSN = ([2],0,False)
    EMXP = ([2],1,False)
    EMXT = ([1],1,False)

    EVAP = ([3],1,False)
    HDSD = ([0],1,False)
    HTDD = ([1],1,False)

    HN01 = ([3,4,5],1,False)
    HN02 = ([3,4,5],1,False)
    HN03 = ([3,4,5],1,False)
    HN04 = ([3,4,5],1,False)
    HN05 = ([3,4,5],1,False)
    HN06 = ([3,4,5],1,False)
    HN07 = ([3,4,5],1,False)
    HN08 = ([3,4,5],1,False)
    HN09 = ([3,4,5],1,False)
    HX01 = ([3,4,5],1,False)
    HX02 = ([3,4,5],1,False)
    HX03 = ([3,4,5],1,False)
    HX04 = ([3,4,5],1,False)
    HX05 = ([3,4,5],1,False)
    HX06 = ([3,4,5],1,False)
    HX07 = ([3,4,5],1,False)
    HX08 = ([3,4,5],1,False)
    HX09 = ([3,4,5],1,False)
    LN01 = ([3,4,5],1,False)
    LN02 = ([3,4,5],1,False)
    LN03 = ([3,4,5],1,False)
    LN04 = ([3,4,5],1,False)
    LN05 = ([3,4,5],1,False)
    LN06 = ([3,4,5],1,False)
    LN07 = ([3,4,5],1,False)
    LN08 = ([3,4,5],1,False)
    LN09 = ([3,4,5],1,False)
    LX01 = ([3,4,5],1,False)
    LX02 = ([3,4,5],1,False)
    LX03 = ([3,4,5],1,False)
    LX04 = ([3,4,5],1,False)
    LX05 = ([3,4,5],1,False)
    LX06 = ([3,4,5],1,False)
    LX07 = ([3,4,5],1,False)
    LX08 = ([3,4,5],1,False)
    LX09 = ([3,4,5],1,False)
    MN01 = ([3,4,5],1,True)
    MN02 = ([3,4,5],1,True)
    MN03 = ([3,4,5],1,True)
    MN04 = ([3,4,5],1,True)
    MN05 = ([3,4,5],1,True)
    MN06 = ([3,4,5],1,True)
    MN07 = ([3,4,5],1,True)
    MN08 = ([3,4,5],1,True)
    MN09 = ([3,4,5],1,True)

    MNPN = ([3],2,True)

    MX01 = ([3,4,5],1,True)
    MX02 = ([3,4,5],1,True)
    MX03 = ([3,4,5],1,True)
    MX04 = ([3,4,5],1,True)
    MX05 = ([3,4,5],1,True)
    MX06 = ([3,4,5],1,True)
    MX07 = ([3,4,5],1,True)
    MX08 = ([3,4,5],1,True)
    MX09 = ([3,4,5],1,True)

    MXPN = ([3],2,True)

    PRCP = ([3],1,False)
    PSUN = ([1],1,True)
    SNOW = ([3],0,False)

    TAVG = ([1],2,True)
    TMAX = ([3],2,True)
    TMIN = ([3],2,True)
    TSUN = ([1],0,False)

    WDMV = ([3],0,False)

    WSF1 = ([1],1,False)
    WSF2 = ([1],1,False)
    WSF5 = ([1],1,False)
    WSFG = ([1],1,False)
    WSFM = ([1],1,False)

    def __init__(self, flagPositions, decimalPlaces, takeMean):
        self.flagPositions = flagPositions
        self.decimalPlaces = decimalPlaces
        self.takeMean = takeMean

class ElementsDataType:
    dataTypeDict = {
        'STATION':pl.String,
        'DATE':pl.String,
        'AWND':pl.String, 
        'AWND_ATTRIBUTES':pl.String,
        'CDSD':pl.Float64, 
        'CDSD_ATTRIBUTES':pl.String,
        'CLDD':pl.String, 
        'CLDD_ATTRIBUTES':pl.String,
        'DP01':pl.String, 
        'DP01_ATTRIBUTES':pl.String,
        'DP10':pl.String, 
        'DP10_ATTRIBUTES':pl.String,
        'DP1X':pl.String, 
        'DP1X_ATTRIBUTES':pl.String,
        'DSND':pl.String, 
        'DSND_ATTRIBUTES':pl.String,
        'DSNW':pl.String, 
        'DSNW_ATTRIBUTES':pl.String,
        'DT00':pl.String,
        'DT00_ATTRIBUTES':pl.String,
        'DT32':pl.String,
        'DT32_ATTRIBUTES':pl.String,
        'DX32':pl.String, 
        'DX32_ATTRIBUTES':pl.String,
        'DX70':pl.String, 
        'DX70_ATTRIBUTES':pl.String,
        'DX90':pl.String, 
        'DX90_ATTRIBUTES':pl.String,
        'DYFG':pl.String, 
        'DYFG_ATTRIBUTES':pl.String, 
        'DYHF':pl.String, 
        'DYHF_ATTRIBUTES':pl.String, 
        'DYTS':pl.String, 
        'DYTS_ATTRIBUTES':pl.String,
        'DYNT':pl.String, 
        'DYNT_ATTRIBUTES':pl.String,
        'DYSD':pl.String, 
        'DYSD_ATTRIBUTES':pl.String,
        'DYSN':pl.String, 
        'DYSN_ATTRIBUTES':pl.String,
        'DYXP':pl.String, 
        'DYXP_ATTRIBUTES':pl.String,
        'DYXT':pl.String, 
        'DYXT_ATTRIBUTES':pl.String,
        'EMNT':pl.Float64, 
        'EMNT_ATTRIBUTES':pl.String,
        'EMSD':pl.Float64, 
        'EMSD_ATTRIBUTES':pl.String,
        'EMSN':pl.Float64, 
        'EMSN_ATTRIBUTES':pl.String,
        'EMXP':pl.Float64, 
        'EMXP_ATTRIBUTES':pl.String,
        'EMXT':pl.Float64, 
        'EMXT_ATTRIBUTES':pl.String,
        'EVAP':pl.String, 
        'EVAP_ATTRIBUTES':pl.String,
        'HDSD':pl.Float64, 
        'HDSD_ATTRIBUTES':pl.String,

        'HN01':pl.Float64, 
        'HN01_ATTRIBUTES':pl.String,
        'HN02':pl.Float64, 
        'HN02_ATTRIBUTES':pl.String,
        'HN03':pl.Float64, 
        'HN03_ATTRIBUTES':pl.String,
        'HN04':pl.Float64, 
        'HN04_ATTRIBUTES':pl.String,
        'HN05':pl.Float64, 
        'HN05_ATTRIBUTES':pl.String,
        'HN06':pl.Float64, 
        'HN06_ATTRIBUTES':pl.String,
        'HN07':pl.Float64, 
        'HN07_ATTRIBUTES':pl.String,
        'HN08':pl.Float64, 
        'HN08_ATTRIBUTES':pl.String,
        'HN09':pl.Float64, 
        'HN09_ATTRIBUTES':pl.String,

        'HTDD':pl.String, 
        'HTDD_ATTRIBUTES':pl.String,

        'HX01':pl.Float64, 
        'HX01_ATTRIBUTES':pl.String,
        'HX02':pl.Float64, 
        'HX02_ATTRIBUTES':pl.String,
        'HX03':pl.Float64, 
        'HX03_ATTRIBUTES':pl.String,
        'HX04':pl.Float64, 
        'HX04_ATTRIBUTES':pl.String,
        'HX05':pl.Float64, 
        'HX05_ATTRIBUTES':pl.String,
        'HX06':pl.Float64, 
        'HX06_ATTRIBUTES':pl.String,
        'HX07':pl.Float64, 
        'HX07_ATTRIBUTES':pl.String,
        'HX08':pl.Float64, 
        'HX08_ATTRIBUTES':pl.String,
        'HX09':pl.Float64, 
        'HX09_ATTRIBUTES':pl.String,

        'LN01':pl.Float64, 
        'LN01_ATTRIBUTES':pl.String,
        'LN02':pl.Float64, 
        'LN02_ATTRIBUTES':pl.String,
        'LN03':pl.Float64, 
        'LN03_ATTRIBUTES':pl.String,
        'LN04':pl.Float64, 
        'LN04_ATTRIBUTES':pl.String,
        'LN05':pl.Float64, 
        'LN05_ATTRIBUTES':pl.String,
        'LN06':pl.Float64, 
        'LN06_ATTRIBUTES':pl.String,
        'LN07':pl.Float64, 
        'LN07_ATTRIBUTES':pl.String,
        'LN08':pl.Float64, 
        'LN08_ATTRIBUTES':pl.String,
        'LN09':pl.Float64, 
        'LN09_ATTRIBUTES':pl.String,

        'LX01':pl.Float64, 
        'LX01_ATTRIBUTES':pl.String,
        'LX02':pl.Float64, 
        'LX02_ATTRIBUTES':pl.String,
        'LX03':pl.Float64, 
        'LX03_ATTRIBUTES':pl.String,
        'LX04':pl.Float64, 
        'LX04_ATTRIBUTES':pl.String,
        'LX05':pl.Float64, 
        'LX05_ATTRIBUTES':pl.String,
        'LX06':pl.Float64, 
        'LX06_ATTRIBUTES':pl.String,
        'LX07':pl.Float64, 
        'LX07_ATTRIBUTES':pl.String,
        'LX08':pl.Float64, 
        'LX08_ATTRIBUTES':pl.String,
        'LX09':pl.Float64, 
        'LX09_ATTRIBUTES':pl.String,

        'MN01':pl.String, 
        'MN01_ATTRIBUTES':pl.String,
        'MN02':pl.String, 
        'MN02_ATTRIBUTES':pl.String,
        'MN03':pl.String, 
        'MN03_ATTRIBUTES':pl.String,
        'MN04':pl.String, 
        'MN04_ATTRIBUTES':pl.String,
        'MN05':pl.String, 
        'MN05_ATTRIBUTES':pl.String,
        'MN06':pl.String, 
        'MN06_ATTRIBUTES':pl.String,
        'MN07':pl.String, 
        'MN07_ATTRIBUTES':pl.String,
        'MN08':pl.String, 
        'MN08_ATTRIBUTES':pl.String,
        'MN09':pl.String, 
        'MN09_ATTRIBUTES':pl.String,

        'MNPN':pl.String, 
        'MNPN_ATTRIBUTES':pl.String,

        'MX01':pl.String, 
        'MX01_ATTRIBUTES':pl.String,
        'MX02':pl.String, 
        'MX02_ATTRIBUTES':pl.String,
        'MX03':pl.String, 
        'MX03_ATTRIBUTES':pl.String,
        'MX04':pl.String, 
        'MX04_ATTRIBUTES':pl.String,
        'MX05':pl.String, 
        'MX05_ATTRIBUTES':pl.String,
        'MX06':pl.String, 
        'MX06_ATTRIBUTES':pl.String,
        'MX07':pl.String, 
        'MX07_ATTRIBUTES':pl.String,
        'MX08':pl.String, 
        'MX08_ATTRIBUTES':pl.String,
        'MX09':pl.String, 
        'MX09_ATTRIBUTES':pl.String,

        'MXPN':pl.String, 
        'MXPN_ATTRIBUTES':pl.String,
        'PRCP':pl.String, 
        'PRCP_ATTRIBUTES':pl.String,
        'PSUN':pl.String, 
        'PSUN_ATTRIBUTES':pl.String,
        'SNOW':pl.String, 
        'SNOW_ATTRIBUTES':pl.String,
        'TAVG':pl.String, 
        'TAVG_ATTRIBUTES':pl.String,
        'TMAX':pl.String, 
        'TMAX_ATTRIBUTES':pl.String,
        'TMIN':pl.String, 
        'TMIN_ATTRIBUTES':pl.String,
        'TSUN':pl.String,
        'TSUN_ATTRIBUTES':pl.String,
        'WDF1':pl.String, 
        'WDF1_ATTRIBUTES':pl.String,
        'WDF2':pl.String, 
        'WDF2_ATTRIBUTES':pl.String,
        'WDF5':pl.String, 
        'WDF5_ATTRIBUTES':pl.String,
        'WDFG':pl.String, 
        'WDFG_ATTRIBUTES':pl.String,
        'WDFM':pl.String, 
        'WDFM_ATTRIBUTES':pl.String,
        'WDMV':pl.String, 
        'WDMV_ATTRIBUTES':pl.String,
        'WSF1':pl.Float64, 
        'WSF1_ATTRIBUTES':pl.String,
        'WSF2':pl.Float64, 
        'WSF2_ATTRIBUTES':pl.String,
        'WSF5':pl.Float64, 
        'WSF5_ATTRIBUTES':pl.String,
        'WSFG':pl.Float64, 
        'WSFG_ATTRIBUTES':pl.String,
        'WSFM':pl.Float64, 
        'WSFM_ATTRIBUTES':pl.String
    }