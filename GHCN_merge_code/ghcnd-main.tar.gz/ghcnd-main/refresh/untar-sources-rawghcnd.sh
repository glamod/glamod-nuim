source_list=$1
tar_dir=$2
refresh_dir=$3
for source in `cat ${source_list}`
do
tar xzf ${tar_dir}${source}-rawghcnd.tar.gz -C ${refresh_dir}
done

