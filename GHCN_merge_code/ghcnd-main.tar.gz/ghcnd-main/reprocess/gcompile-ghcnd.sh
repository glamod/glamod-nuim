modulefile=$1
PREFIX=$2

#ulimit -s unlimited

#lf95path=/usr/local/lf6481/bin/

gfortran ${lib_dir}${modulefile} ${lib_dir}get_hprcc.f95 -o ${lib_dir}get_hprcc.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}rf_hprcc2ghcnd.f95 -o ${lib_dir}rf_hprcc2ghcnd.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}get-cocorahs.f95 -o ${lib_dir}get-cocorahs.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}rf-cocorahs2ghcnd.f95 -o ${lib_dir}rf-cocorahs2ghcnd.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}m_datetime.f95 ${lib_dir}get-snotel-nrcs-rf2ghcnd.f95 -o ${lib_dir}get-snotel-nrcs-rf2ghcnd.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}get-raws-data.f95 -o ${lib_dir}get-raws-data.exe --free-line-length-185
gfortran ${lib_dir}${modulefile} ${lib_dir}rf-raws2ghcnd.f95 -o ${lib_dir}rf-raws2ghcnd.exe 
#gfortran ${lib_dir}${modulefile} ${lib_dir}rf-papercoop2ghcnd.f95 -o ${lib_dir}rf-papercoop2ghcnd.exe --ap
gfortran ${lib_dir}${modulefile} ${lib_dir}rf_australia2ghcnd.f95 -o ${lib_dir}rf_australia2ghcnd.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}rf-eca2ghcnd.f95 -o ${lib_dir}rf-eca2ghcnd.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}get_crn.f95 -o ${lib_dir}get_crn.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}rf_crn2ghcnd.f95 -o ${lib_dir}rf_crn2ghcnd.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}rf-cf62ghcnd.f95 -o ${lib_dir}rf-cf62ghcnd.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}get_gsod.f95 -o ${lib_dir}get_gsod.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}rf_gsod2ghcnd.f95 -o ${lib_dir}rf_gsod2ghcnd.exe 
#gfortran ${lib_dir}${modulefile} ${lib_dir}getgcos_rf2ghcnd.f95 -o ${lib_dir}getgcos_rf2ghcnd.exe --ap
gfortran ${lib_dir}${modulefile} ${lib_dir}mingle.f95 -o ${lib_dir}mingle.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}datzilla.f95 -o ${lib_dir}datzilla.exe
#gfortran ${lib_dir}${modulefile} ${lib_dir}rf-3210edits4datzilla.f95 -o ${lib_dir}rf-3210edits4datzilla.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}format_check.f95 -o ${lib_dir}format_check.exe
gfortran ${lib_dir}${modulefile} ${lib_dir}qc1.f95 -o ${lib_dir}qc1.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}rf_stn2time.f95 -o ${lib_dir}rf_stn2time.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}qc2.f95 -o ${lib_dir}qc2.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}qc3.f95 -o ${lib_dir}qc3.exe 
gfortran ${lib_dir}${modulefile} ${lib_dir}make_gsn_hcn.f95 -o ${lib_dir}make_gsn_hcn.exe 
#gfortran ${lib_dir}${modulefile} ${lib_dir}get_32xx.f95 -o ${lib_dir}get_32xx.exe
#gfortran ${lib_dir}${modulefile} ${lib_dir}rf320x_to_ghcnd.f95 -o ${lib_dir}rf320x_to_ghcnd.exe --ap
#gfortran ${lib_dir}${modulefile} ${lib_dir}rf3210or3211_to_ghcnd.f95 -o ${lib_dir}rf3210or3211_to_ghcnd.exe --ap
gfortran ${lib_dir}${modulefile} ${lib_dir}m_datetime.f95 ${lib_dir}rf-isdsod2ghcnd.f95 -o ${lib_dir}rf-isdsod2ghcnd.exe 
gfortran ${lib_dir}ghcndmod.f95 ${lib_dir}ghcndinv.f95 -o ${lib_dir}ghcndinv.exe 
gfortran ${lib_dir}ghcndmod.f95 ${lib_dir}genclim.f95 -o ${lib_dir}genclim.exe
gfortran ${lib_dir}ghcndmod.f95 ${lib_dir}append_upd2por.f95 -o ${lib_dir}append_upd2por.exe 
#gfortran ${lib_dir}ghcndmod.f95 ${lib_dir}rf_isd2day.f95 -o ${lib_dir}rf_isd2day.exe --ap
#gfortran ${lib_dir}ghcndmod.f95 ${lib_dir}check4timing.f95 -o ${lib_dir}check4timing.exe --ap

