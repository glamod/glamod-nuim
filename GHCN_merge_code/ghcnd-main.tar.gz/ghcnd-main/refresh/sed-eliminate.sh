for i in `cut -c1-11 dups2eliminate.txt`
do
cp -p cocorahs-stations-prescreened.txt cocorahs-stations-prescreened.tmp
sed '/'"^${i}"'/d' cocorahs-stations-prescreened.tmp > cocorahs-stations-prescreened.txt
done
