# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 12:14:49 2024

@author: snoone
"""

import zipfile
import os

# Define the path to the zip file
zip_file_path = r"D:\AEMET_spanish_hist_sub_daily\JLC.zip"

# Define the path to save the extracted directory
output_folder = r"D:\AEMET_spanish_hist_sub_daily\extracted_files\VelV"

# Ensure the output folder exists, create if necessary
os.makedirs(output_folder, exist_ok=True)

# Open the zip file
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    # Iterate over all files in the zip
    for file_info in zip_ref.infolist():
        # Check if the file is in the desired directory
        if file_info.filename.startswith("JLC/VelV/") and not file_info.is_dir():
            # Extract the file to the output folder
            zip_ref.extract(file_info, output_folder)

print(f"Directory extracted and saved to: {output_folder}")
