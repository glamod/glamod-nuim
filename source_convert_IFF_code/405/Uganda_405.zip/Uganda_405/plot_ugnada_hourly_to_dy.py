# -*- coding: utf-8 -*-
"""
Created on Thu Feb 20 15:31:01 2025

@author: snoone
"""
import pandas as pd
import matplotlib.pyplot as plt
import os

# File paths
file1 = r'C:\Users\snoone\Dropbox\OLD_BELGIAN_AFRICAN_DARE_INVENTORY\data_for_transcribing_2023\UGANDA\chosen_forms_uganda\admin\IFF\slp_Rob\wmo.csv'
file2 = r'C:\Users\snoone\Dropbox\OLD_BELGIAN_AFRICAN_DARE_INVENTORY\data_for_transcribing_2023\UGANDA\chosen_forms_uganda\admin\IFF\slp_Rob\rob.csv'

# Load the data
df1 = pd.read_csv(file1)
df2 = pd.read_csv(file2)

# Combine Year, Month, Day into a single datetime column
df1['Date'] = pd.to_datetime(df1[['Year', 'Month', 'Day']])
df2['Date'] = pd.to_datetime(df2[['Year', 'Month', 'Day']])

# Calculate daily average pressure
daily_avg1 = df1.groupby('Date')['Observed_value'].mean().reset_index(name='Daily_Avg_Pressure_File1')
daily_avg2 = df2.groupby('Date')['Observed_value'].mean().reset_index(name='Daily_Avg_Pressure_File2')

# Plotting
plt.figure(figsize=(12, 6))
plt.plot(daily_avg1['Date'], daily_avg1['Daily_Avg_Pressure_File1'], label='Students_WMO_2024_data', marker='o')
plt.plot(daily_avg2['Date'], daily_avg2['Daily_Avg_Pressure_File2'], label='ACRE_data', marker='x')
plt.xlabel('Date')
plt.ylabel('Daily Average Pressure')
plt.title('Daily Average Pressure comparison between Student WMO data with ACRE data')
plt.legend()
plt.grid()
plt.tight_layout()

# Save the plot as a high-resolution JPEG
output_path = os.path.dirname(file1)  # Get the directory of the files
jpeg_path = os.path.join(output_path, 'daily_avg_pressure_comparison.jpg')
plt.savefig(jpeg_path, format='jpeg', dpi=300)  # High resolution (300 dpi)
plt.show()

print(f"Plot saved as {jpeg_path}")


