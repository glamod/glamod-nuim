./get-latest-por-files.sh /home/mmenne/ghcnd2/ /home/mmenne/backup/ghcnd2/
echo "new_por="$new_por
