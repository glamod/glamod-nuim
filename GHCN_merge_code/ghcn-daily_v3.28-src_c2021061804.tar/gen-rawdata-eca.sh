PREFIX=$1

# Remove and re-create the directory where a original station files will be stored.
rm -rf ${PREFIX}eca/rawdata
mkdir -p ${PREFIX}eca/rawdata

# Create an inventory of the downloaded zip files.
ls ${PREFIX}eca/archive/*.zip > ${PREFIX}eca.zip.archive.inv

# Unzip each file.
for i in `cat ${PREFIX}eca.zip.archive.inv`
do
unzip -q -d${PREFIX}eca/rawdata $i
rm -f ${PREFIX}eca/rawdata/*sources.txt
#rm -f ${PREFIX}eca/rawdata/*info.txt
rm -f ${PREFIX}eca/rawdata/elements.txt
done

