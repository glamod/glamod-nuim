echo "Starting refresh-australia.sh on " `date`

dsi=australia
src_code=D
#list_dir=/home/mmenne/ghcnd2/input4sys/
list_dir=/home/mmenne/ghcnd/input4sys/
refresh_dir=/home/mmenne/ghcnd/makelist/
data_dir=/home/mmenne/ghcnd/${dsi}/

#${refresh_dir}compile-refresh-australia.sh ${refresh_dir}

cp -p ${list_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.txt.old
cp -p ${list_dir}mingle-list.txt ${refresh_dir}mingle-list.txt.old

cp -p ${refresh_dir}ghcnd-stations.txt.old ${refresh_dir}ghcnd-stations.txt
cp -p ${refresh_dir}mingle-list.txt.old ${refresh_dir}mingle-list.txt

cd ${refresh_dir}

#Run rf_unquarantined2ghcnd.exe
${refresh_dir}rf_unquarantined2ghcnd.exe /home/mmenne/ghcnd/
#Keep a copy of last ${dsi} list of stations with data
cp -p ${refresh_dir}${dsi}.inv ${refresh_dir}${dsi}.inv.old
#Make a new ${dsi} list of stations with data
mv -f ${refresh_dir}${dsi}-stations.txt ${refresh_dir}${dsi}-stations.old
ls ${data_dir}rawghcnd > ${refresh_dir}${dsi}.inv
echo "Starting gen-wmo-station-info.exe on " `date`
${refresh_dir}gen-wmo-stninfo.exe ${dsi} ${refresh_dir}
if [ ! -s ${refresh_dir}${dsi}-stations.txt ]
then
echo "${dsi}-stations.txt was not created...exiting script" `date`
exit
fi
echo "Starting pre_screen.exe on" `date`
${refresh_dir}pre_screen.exe ${data_dir} ${refresh_dir}${dsi}-stations.txt ${dsi}
cut -c12-15 ${data_dir}rawghcnd/* | sort -u > ${refresh_dir}${dsi}-years.txt 
echo "Starting intrasource_dupchk.exe on" `date`
${refresh_dir}intrasource_dupchk.exe ${data_dir} ${refresh_dir}${dsi}-stations-prescreened.txt ${dsi}
echo "Starting strip_source.exe on" `date`
${refresh_dir}strip_source.exe ${src_code}
echo "Starting gen-wmo-xref.exe on" `date`
${refresh_dir}gen-wmo-xref.exe ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.id.noxref
echo "Starting genDataXref.exe on" `date`
${refresh_dir}genDataXref.exe ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${src_code} /home/mmenne/ghcnd2/ghcnd_all/ ${data_dir}rawghcnd/ ${refresh_dir}${dsi}.id.noxref ${refresh_dir}${dsi}.data.xref
echo "catting ${dsi}.id.xref and ${dsi}.data.xref" `date`
cat ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.data.xref > ${refresh_dir}${dsi}.xref
echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${src_code} ${refresh_dir}${dsi}.xref
echo "Number of stations in ghcnd-stations" `wc ${refresh_dir}ghcnd-stations.txt | cut -c1-7`
echo "Finished refresh-coop.sh for ${dsi} on " `date`

