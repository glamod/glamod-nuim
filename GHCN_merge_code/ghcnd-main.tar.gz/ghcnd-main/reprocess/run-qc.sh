export PREFIX=/data/
export lib_dir=/data/ops/lib/

echo "Starting gen-datzilla-rawdata.sh" `date`
${lib_dir}gen-datzilla-rawdata.sh ${PREFIX}

# MINGLE THE DATA
echo "starting mingle.exe" `date`
${lib_dir}mingle.exe $PREFIX ${PREFIX}input4sys/mingle-list.txt

# APPLY DATZILLA TICKETS EXCEPT FOR "UNFLAG" CASES
echo "Starting datzilla.exe with pre" `date`
${lib_dir}datzilla.exe pre ${PREFIX}datzilla/datzilla.rawdata.pre.inv ${PREFIX} ${PREFIX}datzilla/rawdata/ ${PREFIX}mingled/ ${PREFIX}datzillaoutpre/

#COPY DATZILLA OUTPUT FILES TO MINGLED DIRECTORY
cp -p ${PREFIX}datzillaoutpre/*.dly ${PREFIX}mingled

# PRE FORMAT CHECK
echo "Starting pre format_check.exe" `date`
${lib_dir}format_check.exe pre ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}mingled/ ${PREFIX}rawghcnd/ ${PREFIX}format_check_pre.log

# QC1, QC2 and QC3

echo "Starting qc1.exe" `date`
${lib_dir}qc1.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt M por

echo "Starting rf_stn2time.exe" `date`
${lib_dir}rf_stn2time.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt

echo "Starting qc2.exe" `date`
${lib_dir}qc2.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt M por

echo "Starting qc3.exe" `date`
${lib_dir}qc3.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt por

# APPLY DATZILLA TICKETS FOR "UNFLAG" CASES
echo "Starting datzilla.exe with post" `date`
${lib_dir}datzilla.exe post ${PREFIX}datzilla/datzilla.rawdata.post.inv ${PREFIX} ${PREFIX}datzilla/rawdata/ ${PREFIX}qc3out/ ${PREFIX}datzillaoutpost/

#COPY DATZILLA OUTPUT FILES TO QC3OUT DIRECTORY
cp -p ${PREFIX}datzillaoutpost/*.dly ${PREFIX}qc3out

