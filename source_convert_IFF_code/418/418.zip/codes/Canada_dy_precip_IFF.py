#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May  8 14:33:39 2026

@author: sangethaedathil
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Canada SEF TSV → IFF for dy_precip

Input:
dy_precip/*.tsv

Station ID source:
meta_&_other/station_ids.xlsx

"""

import os
import glob
import re
import pandas as pd
import numpy as np

# =================================================
# SETTINGS
# =================================================

SOURCE_ID = "418"
VARIABLE_NAME = "dy_precip"

INPUT_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/solonskys_canada_new_PRIORITY/dy_precip"

STATION_ID_FILE = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/solonskys_canada_new_PRIORITY/meta_&_other/station_ids.xlsx"

OUTDIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/solonskys_canada_new_PRIORITY/IFF/dy_precip"

os.makedirs(OUTDIR, exist_ok=True)

# =================================================
# CLEAR OLD OUTPUTS
# =================================================

for f in glob.glob(os.path.join(OUTDIR, "*.psv")):
    os.remove(f)

for f in glob.glob(os.path.join(OUTDIR, "*.csv")):
    os.remove(f)

print("Old output files cleared.")

# =================================================
# READ STATION ID EXCEL
# =================================================

station_df = pd.read_excel(STATION_ID_FILE)
station_df.columns = [str(c).strip() for c in station_df.columns]

print("Station ID Excel columns found:")
print(station_df.columns.tolist())

possible_name_cols = [
    "Station_name", "station_name", "Station Name", "station name",
    "Name", "name", "Station", "station"
]

possible_id_cols = [
    "Station_ID", "station_id", "Station ID", "station id",
    "ID", "id"
]

station_name_col = None
station_id_col = None

for col in possible_name_cols:
    if col in station_df.columns:
        station_name_col = col
        break

for col in possible_id_cols:
    if col in station_df.columns:
        station_id_col = col
        break

if station_name_col is None:
    raise ValueError("Could not find station name column in station_ids.xlsx")

if station_id_col is None:
    raise ValueError("Could not find station ID column in station_ids.xlsx")

print(f"Using station name column: {station_name_col}")
print(f"Using station ID column: {station_id_col}")

station_df[station_name_col] = station_df[station_name_col].astype(str).str.strip()
station_df[station_id_col] = station_df[station_id_col].astype(str).str.strip()

station_lookup = dict(zip(station_df[station_name_col], station_df[station_id_col]))

station_lookup_lower = {
    str(k).strip().lower(): str(v).strip()
    for k, v in station_lookup.items()
}

# =================================================
# FUNCTIONS
# =================================================

def read_sef_tsv(file_path):
    """
    Reads one SEF TSV file.

    Metadata is above the table.
    Data table starts with:
    Year    Month    Day    Hour    Minute
    """

    with open(file_path, "r", encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    metadata = {}
    header_index = None

    for i, line in enumerate(lines):
        clean_line = line.strip()
        parts = clean_line.split("\t")

        if len(parts) >= 2:
            key = parts[0].strip()
            value = parts[1].strip()

            if key in ["ID", "Name", "Lat", "Lon", "Alt", "Source", "Vbl", "Stat", "Unit"]:
                metadata[key] = value

        if clean_line.startswith("Year\tMonth\tDay\tHour\tMinute"):
            header_index = i
            break

    if header_index is None:
        raise ValueError("Could not find data header: Year Month Day Hour Minute")

    df = pd.read_csv(file_path, sep="\t", skiprows=header_index)
    df.columns = [str(c).strip() for c in df.columns]

    return df, metadata


def clean_numeric(series):
    """
    Cleans numeric values.
    """

    s = series.astype(str).str.strip()

    s = s.replace(
        ["", "NA", "N/A", "NaN", "nan", "NULL", "null",
         "--", "-", ".", "-.", "*"],
        pd.NA
    )

    s = s.str.replace(r"[^0-9.\-]", "", regex=True)

    out = pd.to_numeric(s, errors="coerce")
    out = out.mask(out.isin([-9999, -999, -99]))

    return out


def extract_original_value_keep_same(meta_text):
    """
    Extracts original observed value from Meta column
    and keeps it exactly as written.

    Example:
    orig=0.4 inches|Local time: 0700|QC flag: None

    returns:
    0.4
    """

    if pd.isna(meta_text):
        return ""

    text = str(meta_text)

    match = re.search(r"orig=([^\|]+)", text)

    if not match:
        return ""

    original = match.group(1).strip()

    # Remove common unit text, keep number exactly
    original = re.sub(r"\s*(mm|MM|cm|CM|inches|inch|in|IN)$", "", original).strip()

    return original


def extract_original_unit(meta_text):
    """
    Extracts original unit from Meta column.

    Example:
    orig=0.4 inches|Local time: 0700|QC flag: None

    returns:
    inches
    """

    if pd.isna(meta_text):
        return ""

    text = str(meta_text)

    match = re.search(r"orig=[^\|]*\s([A-Za-z]+)", text)

    if match:
        return match.group(1).strip()

    return ""


def get_station_id(station_name):
    """
    Gets assigned station ID from station_ids.xlsx.
    """

    station_name = str(station_name).strip()

    if station_name in station_lookup:
        return station_lookup[station_name]

    lower_name = station_name.lower()

    if lower_name in station_lookup_lower:
        return station_lookup_lower[lower_name]

    return ""


def safe_int(series):
    return pd.to_numeric(series, errors="coerce").astype("Int64")


def keep_metadata_value(value):
    """
    Keeps latitude, longitude and elevation exactly as written in TSV metadata.
    """

    if value is None:
        return ""

    return str(value).strip()


# =================================================
# PROCESS ALL TSV FILES
# =================================================

tsv_files = sorted(glob.glob(os.path.join(INPUT_DIR, "*.tsv")))

print(f"\nFound {len(tsv_files)} dy_precip TSV files")

failed_files = []
missing_station_ids = []

station_data = {}

for FILE in tsv_files:

    filename = os.path.basename(FILE)

    print("\n==============================")
    print(f"Processing: {filename}")

    try:
        df, meta = read_sef_tsv(FILE)

        required_cols = ["Year", "Month", "Day", "Hour", "Minute", "Value"]
        missing_cols = [c for c in required_cols if c not in df.columns]

        if missing_cols:
            failed_files.append([filename, f"Missing columns: {missing_cols}"])
            print(f"FAILED: Missing columns: {missing_cols}")
            continue

        station_name = meta.get("Name", "").strip()
        station_id = get_station_id(station_name)

        if station_id == "":
            missing_station_ids.append([filename, station_name])
            print(f"WARNING: Station ID missing for station name: {station_name}")
            station_id = "NO_STATION_ID_" + station_name.replace(" ", "_")
    
        # dy_precip value from TSV Value column
        df["Observed_value"] = clean_numeric(df["Value"]).round(1)
        
        # Original observed value from Meta column
        if "Meta" in df.columns:
            df["Original_observed_value"] = df["Meta"].apply(extract_original_value_keep_same)
            df["Original_observed_value_units"] = df["Meta"].apply(extract_original_unit)
        else:
            df["Original_observed_value"] = df["Value"].astype(str).str.strip()
            df["Original_observed_value_units"] = meta.get("Unit", "")
        
        # -------------------------------------------------
        # REMOVE INVALID / EMPTY PRECIPITATION VALUES
        # -------------------------------------------------
        
        # Convert original value to numeric for checking
        df["Original_check"] = pd.to_numeric(df["Original_observed_value"], errors="coerce")
        
        # Keep only rows where:
        # 1. Observed_value is not empty
        # 2. Observed_value is not 0
        # 3. Original value is not empty
        # 4. Original value is not 0
        df = df[
            df["Observed_value"].notna() &
            (df["Observed_value"] != 0) &
            df["Original_check"].notna() &
            (df["Original_check"] != 0)
        ].copy()
        
        # Remove helper column
        df = df.drop(columns=["Original_check"])

        if len(df) == 0:
            failed_files.append([filename, "No valid observed values"])
            print("No valid observed values")
            continue

        iff = pd.DataFrame(index=df.index)

        iff["Source_ID"] = SOURCE_ID
        iff["Station_ID"] = station_id
        iff["Station_name"] = station_name
        iff["Alias_station_name"] = ""

        iff["Year"] = safe_int(df["Year"])
        iff["Month"] = safe_int(df["Month"])
        iff["Day"] = safe_int(df["Day"])
        iff["Hour"] = safe_int(df["Hour"])
        iff["Minute"] = safe_int(df["Minute"])

        # Keep metadata exactly as in TSV
        iff["Latitude"] = keep_metadata_value(meta.get("Lat", ""))
        iff["Longitude"] = keep_metadata_value(meta.get("Lon", ""))
        iff["Elevation"] = keep_metadata_value(meta.get("Alt", ""))

        iff["Observed_value"] = df["Observed_value"]
        iff["Source_QC_flag"] = ""

        iff["Original_observed_value"] = df["Original_observed_value"]
        iff["Original_observed_value_units"] = df["Original_observed_value_units"]

        iff["Report_type_code"] = ""
        iff["Measurement_code_1"] = ""
        iff["Measurement_code_2"] = ""

        iff = iff[[
            "Source_ID",
            "Station_ID",
            "Station_name",
            "Alias_station_name",
            "Year",
            "Month",
            "Day",
            "Hour",
            "Minute",
            "Latitude",
            "Longitude",
            "Elevation",
            "Observed_value",
            "Source_QC_flag",
            "Original_observed_value",
            "Original_observed_value_units",
            "Report_type_code",
            "Measurement_code_1",
            "Measurement_code_2"
        ]]

        if station_id not in station_data:
            station_data[station_id] = []

        station_data[station_id].append(iff)

        print(f"Added rows: {len(iff)} for station {station_id} / {station_name}")

    except Exception as e:
        failed_files.append([filename, str(e)])
        print(f"FAILED: {filename} --> {e}")


# =================================================
# SAVE ONE IFF FILE PER STATION
# =================================================

print("\n==============================")
print("Saving individual station IFF files")
print("==============================")

saved_station_count = 0

for station_id, df_list in station_data.items():

    station_df = pd.concat(df_list, ignore_index=True)

    station_df = station_df.sort_values(
        by=["Year", "Month", "Day", "Hour", "Minute"]
    )

    station_df = station_df.fillna("")

    safe_station_id = str(station_id).strip().replace("/", "_")

    outname = f"{safe_station_id}_{VARIABLE_NAME}_{SOURCE_ID}.psv"
    outpath = os.path.join(OUTDIR, outname)

    station_df.to_csv(outpath, sep="|", index=False)

    saved_station_count += 1

    print(f"Saved: {outname} | rows: {len(station_df)}")


# =================================================
# SAVE LOGS
# =================================================

if failed_files:
    failed_log = os.path.join(OUTDIR, "failed_dy_precip.csv")

    pd.DataFrame(
        failed_files,
        columns=["File", "Reason"]
    ).to_csv(failed_log, index=False)

    print(f"\nFailed log saved: {failed_log}")

if missing_station_ids:
    missing_log = os.path.join(OUTDIR, "missing_station_ids_dy_precip.csv")

    pd.DataFrame(
        missing_station_ids,
        columns=["File", "Station_name"]
    ).to_csv(missing_log, index=False)

    print(f"Missing station ID log saved: {missing_log}")


print("\nDONE")
print(f"Input folder: {INPUT_DIR}")
print(f"Output folder: {OUTDIR}")
print(f"TSV files found: {len(tsv_files)}")
print(f"Individual station IFF files saved: {saved_station_count}")
print(f"Failed files: {len(failed_files)}")
print(f"Missing station IDs: {len(missing_station_ids)}")