import polars as pl
import polars.selectors as cs
import tarfile

from gsom.SOM_Constants import ELEMENT_NAMES, FLAG_STR, DATE_COL_NAME
from gsom.SOM_Constants import SOM_ElementsDataType as som_dataType
from gsom.SOM_Constants import Pxxx_mapping as pm

def SOM_PathsToDict(SOM_Paths: list):
    '''Function will take paths and put them in the '''
    pathsDict = dict([])
    for p in SOM_Paths:
        if 'max_short_dur_precip' in p:
            pathsDict.setdefault('max_short_dur_precip',[]).append(p)
        elif 'month_greatest_precip' in p:
            pathsDict.setdefault('month_greatest_precip',[]).append(p)
        elif 'month_total_precip' in p:
            pathsDict.setdefault('month_total_precip',[]).append(p)
        elif 'month_greatest_snowdepth' in p:
            pathsDict.setdefault('month_greatest_snowdepth',[]).append(p)
        elif 'month_greatest_snowfall' in p:
            pathsDict.setdefault('month_greatest_snowfall',[]).append(p)
        elif 'month_total_snowfall' in p:
            pathsDict.setdefault('month_total_snowfall',[]).append(p)
        elif 'month_max_slp' in p:
            pathsDict.setdefault('month_max_slp',[]).append(p)
        elif 'month_min_slp' in p:
            pathsDict.setdefault('month_min_slp',[]).append(p)
    return pathsDict

def readInSOM(tar: tarfile.TarFile, som_filePaths: list, elementSchema) -> pl.DataFrame:
    df_som = None
    df_temp = None
    for path in som_filePaths:
        with tar.extractfile(path) as csv_file:
            df_temp = pl.read_csv(csv_file, 
                        schema_overrides=elementSchema,
                        null_values='None')
            df_temp = df_temp.with_columns(
                pl.concat_str([pl.col('Year'),
                            pl.col('Month')]
                            ).alias(DATE_COL_NAME),  # This will change to 'DATE'
            )
        if df_som is None:
            df_som = df_temp
        else:
            # Need to join df_temp with df
            df_som = pl.concat([df_som, df_temp])
    #drop dups
    df_som = df_som.unique(subset=DATE_COL_NAME, keep='any', maintain_order=True)
    return df_som

def monthMinMaxSLP(tar: tarfile.TarFile, som_filePaths: list, elementSchema, elementName: str) -> pl.DataFrame:
    df_som = readInSOM(tar, som_filePaths, elementSchema)
    # Need to turn 'attribute data' and make single column
    df_som = df_som.with_columns(
        pl.concat_str([pl.col('Day_of_month'),
                        pl.col('Time_of_day')],
                        separator='-',
                        ).alias('date_time')
    )
    df_som = df_som.with_columns(
        pl.concat_str([pl.col('Source_QC_flag'),
                        pl.col('date_time')],
                        separator=',',
                        ).alias(ELEMENT_NAMES[elementName]+FLAG_STR)
    )
    df_som = df_som.rename({'SLP_hPa':ELEMENT_NAMES[elementName]})
    # Make new dataframe with only relevant columns
    df_som = df_som.select([ELEMENT_NAMES[elementName],DATE_COL_NAME,ELEMENT_NAMES[elementName]+FLAG_STR])
    return df_som

def monthGreatestTotalElements(tar: tarfile.TarFile, som_filePaths: list, elementSchema, elementName: str) -> pl.DataFrame:
    df_som = readInSOM(tar, som_filePaths, elementSchema)
    if elementName in ['month_total_precip', 'month_total_snowfall']:
        df_som = df_som.with_columns(
            pl.concat_str([pl.col('Measurement_code'),
                            pl.col('Source_QC_flag')],
                            separator=',',
                            ).alias(ELEMENT_NAMES[elementName]+FLAG_STR)
        )
    else:
        df_som = df_som.with_columns(
            pl.concat_str([pl.col('Measurement_code'),
                            pl.col('Source_QC_flag'),
                            pl.col('Day_1_2_3')],
                            separator=',',
                            ).alias(ELEMENT_NAMES[elementName]+FLAG_STR)
        )
    df_som = df_som.rename({'Element_data_value':ELEMENT_NAMES[elementName]})
    # Make new dataframe with only relevant columns
    df_som = df_som.select([ELEMENT_NAMES[elementName],DATE_COL_NAME,ELEMENT_NAMES[elementName]+FLAG_STR])

    return df_som

def somToDataFrame(tar: tarfile.TarFile, som_csv_paths: list, outputDF: pl.DataFrame, stationID: str) -> pl.DataFrame:
    eightDigitStationID = stationID[3:]
    if eightDigitStationID[0:3] != '000':
        return outputDF # Means no som file for this station
    # Put leading zeros if ID is less than 5 digits
    fiveDigitStationID = eightDigitStationID[3:]
    # Need to make list of station som files
    SOM_Paths = [s for s in som_csv_paths if fiveDigitStationID in s]
    if not SOM_Paths:
        return outputDF # Means no som file for this station
    pathsDict = SOM_PathsToDict(SOM_Paths)
    # Step 1: read each station file and load it into outputDF
    for elementName, som_filePaths in pathsDict.items():
        # Need to figure out which element this is
        if elementName == 'month_greatest_precip':
            df_som = monthGreatestTotalElements(tar, som_filePaths, som_dataType.month_greatest_precip, elementName)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)

        elif elementName == 'month_greatest_snowdepth':
            df_som = monthGreatestTotalElements(tar, som_filePaths, som_dataType.month_greatest_snowdepth, elementName)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)

        elif elementName == 'month_greatest_snowfall':
            df_som = monthGreatestTotalElements(tar, som_filePaths, som_dataType.month_greatest_snowfall, elementName)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)

        elif elementName == 'month_total_precip':
            df_som = monthGreatestTotalElements(tar, som_filePaths, som_dataType.month_total_precip, elementName)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)

        elif elementName == 'month_total_snowfall':
            df_som = monthGreatestTotalElements(tar, som_filePaths, som_dataType.month_total_snowfall, elementName)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)
        
        elif elementName == 'month_max_slp':
            df_som = monthMinMaxSLP(tar, som_filePaths, som_dataType.month_max_slp, elementName)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)

        elif elementName == 'month_min_slp':
            df_som = monthMinMaxSLP(tar, som_filePaths, som_dataType.month_min_slp, elementName)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)

        elif elementName == 'max_short_dur_precip':
            df_som = readInSOM(tar, som_filePaths, som_dataType.max_short_dur_precip)
            # Need to turn 'attribute data' and make single column
            expr_list = [
                pl.concat_str([pl.col(pm.indexToPrefix[i] + '_Measurement_code_1'),
                               pl.col(pm.indexToPrefix[i] + '_Source_QC_flag'),
                               pl.col(pm.indexToPrefix[i] + '_Ending-day-time')],
                               separator=','
                               ).alias(pm.prefixToElementName[ pm.indexToPrefix[i] ] + FLAG_STR)
                               for i in range(1,13)
            ]
            df_som = df_som.with_columns(expr_list)
            # Need to rename AHx_Duration_minutes ---> Pxxx
            df_som = df_som.rename(pm.renameElements)
            # Make new dataframe with only relevant columns
            df_som = df_som.select(cs.starts_with('P'), DATE_COL_NAME)
            # add to existing dataframe in correct row (by year/month)
            outputDF = outputDF.join(df_som, on=DATE_COL_NAME, how='full',coalesce=True)


    return outputDF