#Created by Menne November 2011

PREFIX=$1
lib_dir=$2

#
if [ -s ${PREFIX}download/3207 ]
then
rm -r ${PREFIX}download/3207
fi

mkdir -p ${PREFIX}download/3207

cp -p /pub-download/wxcoder3*.dly /${PREFIX}download/3207

${lib_dir}update-archive2.sh ${PREFIX}download/3207 ${PREFIX}3207/archive 'wxcoder3*.dly'


