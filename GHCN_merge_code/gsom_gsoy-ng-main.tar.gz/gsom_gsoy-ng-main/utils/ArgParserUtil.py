import argparse

def gsoy_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        '-i', '--input',
        help='Input data (GSOM .csv) folder',
        required=True,
    )
    parser.add_argument(
        '-o', '--output',
        help='Output data (GSOY .csv) folder',
        required=True,
    )
    parser.add_argument(
        '-l', '--log',
        help='Status file log folder',
        required=True,
    )
    parser.add_argument(
        '-s', '--stations',
        help='Station file',
        required=True,
    )
    return parser

def gsom_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()

    parser.add_argument(
        '-i', '--input',
        help='Input data (GSOM .csv) folder',
        required=True,
    )
    parser.add_argument(
        '-o', '--output',
        help='Output data (GSOY .csv) folder',
        required=True,
    )
    parser.add_argument(
        '-l', '--log',
        help='Status file log folder',
        required=True,
    )
    parser.add_argument(
        '-s', '--stations',
        help='Station file',
        required=True,
    )
    parser.add_argument(
        '--som',
        help='ASOS SOM file',
        required=True,
    )
    return parser