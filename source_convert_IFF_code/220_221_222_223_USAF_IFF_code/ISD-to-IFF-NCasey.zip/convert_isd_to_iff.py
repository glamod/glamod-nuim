#!/usr/bin/env python3
# coding: utf-8

import sys
import os
import glob
from pathlib import Path
from datetime import datetime
from ISD_ob import ISD_ob
from constants import *
from present_wx_codes import *
import math
import csv

#function definitions
def rm_element_file_if_exists(outdir,outfilend,ele):
    outfile=outdir+ele+'/'+outfilend 
    if os.path.exists(outfile):
        os.remove(outfile)
        fmsg='removing existing file...'+outfile
    else:
        fmsg='no file: '+outfile
    return(fmsg)   

def write_header(outfile):
    f=open(outfile,'w')
    f.write(IFF_HEADER)
    f.write('\n')
    f.close()
    return('Header written to: '+outfile)

def write_to_file_csv(ofle,mlist):
    with open(ofle,'a', newline='', encoding='utf-8') as f:
        writer=csv.writer(f,delimiter='|',lineterminator='\n')
        writer.writerow(mlist)
        f.close()
    return()
    
def get_station_source_ids_USAF(ISD_ID):
    platID=ISD_ID.split('_')[0]
    netID=ISD_ID.split('_')[1]
    station_ID=netID+'-'+platID
    source_ID=source_id_dict.get(netID)
    return station_ID,source_ID

def get_station_source_ids_ISD(ISD_ID):
    station_ID=ISD_ID[0:6]+'-'+ISD_ID[6:15]
    #source_ID=source_id_dict.get(rtype)
    return station_ID #,source_ID

def get_standard_element(elem, qcfl, unit):
    standard_list=[elem,qcfl,elem,unit]
    return standard_list

def get_unit_change_element(elemorig,elemnew,qcfl, unitorig):
    unit_change_list=[elemnew,qcfl,elemorig,unitorig]
    return unit_change_list

#TODO: need to divide out ISD vs USAF? plus break up of suspect/error?
def ck_badflag_ISD(ele,elem,qcfl):
    if (qcfl == '2' or qcfl == '3' or qcfl == '6' or qcfl == '7'):
        #print(ele,'error or suspect:', elem,qcfl)
        return True

def get_keys_from_value(d, val):
    return [k for k, v in d.items() if v == val]

def convertCelsius(fahrenheit):
    celsius = (float(fahrenheit) - 32) * (5/9)
    return celsius

def convertFahrenheit(celsius):
    fahrenheit = float(celsius) * 9/5 + 32
    return fahrenheit

def convertInHg(hPa):
    inhg = float(hPa) * 0.029530
    return inhg

#dkantor: from LCD java code
def roundToInt(value):
    if value is not None:
        if value - math.floor(value) < 0.5:
                roundedInt = math.floor(value)
        else:
                roundedInt = math.ceil(value)
        return roundedInt
    else:
        return None

#dkantor: from LCD java code
def roundValue(value, precision):
    if value is not None:
        roundedVal = roundToInt(value*((10**precision))) / (10**precision)
        # Intention is to match this java rounding method from LCD code
        # Math.round(outputValue * Math.pow(10, precision)) / Math.pow(10, precision);
        return roundedVal
    else:
        return None

#select elements
#TODO: set elements
elements=['temperature','dew_point_temperature','wind_direction','wind_speed','sea_level_pressure','station_level_pressure','altimeter','wind_gust','pressure_3hr_change',\
          'sky_cover_1','sky_cover_2','sky_cover_3','sky_cov_baseht_1','sky_cov_baseht_2','sky_cov_baseht_3','visibility','precipitation','pres_wx_AU1','pres_wx_AU2','pres_wx_AU3','pres_wx_AW1',\
          'pres_wx_AW2','pres_wx_AW3','pres_wx_MW1','pres_wx_MW2','pres_wx_MW3','relative_humidity','wet_bulb_temperature','snow_depth','snow_depth_liq_equiv','snow_accumulation','REM']
#elements=['snow_depth','snow_depth_liq_equiv','snow_accumulation']
elements=['snow_accumulation']
elements=['snow_depth','snow_depth_liq_equiv','snow_accumulation']

#select dataset to run
dataset='USAF'
#dataset='ASOS'
#dataset='3280' 
#dataset='mexico'
#dataset='CDMP_3850'
#dataset='CDMP_3851'
#dataset='CDMP_3853'
print(dataset)

#compile station list/input files/output dir
if (dataset == '3280'): # for 3280 999999- files from /3505_01/isd-2013
    input_dir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\sample999999\\'
    outdir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\sample999999\output-files\\'
    #input_dir='/data3/999999-3280-isd_2013/data/'   #linuxall
    #outdir='/data3/999999-3280-isd_2013/IFF/'     #linuxall
    #input_dir='./input/'   #linux
    #outdir='./output/' #linux
    files=glob.glob(input_dir+'999999-*')
    filenames=sorted([os.path.basename(i) for i in files])
    stn0=[str(i[0:12]) for i in filenames]
    stns=sorted(set(stn0))
elif (dataset == 'mexico'): #Mexico 3505_01 ISD-formatted data but likely not merged into main ISD archive 
    #tried to work on using Path class but gave up for now: 
    #input_dir=Path('C:/Users/Nancy.Casey/Desktop/Python-ISD/Mexico-3505_01/')
    #outdir=Path('/Users/Nancy.Casey/Desktop/Python-ISD/Mexico-3505_01/output-files/')
    #print(os.listdir(os.path.abspath(outdir)))
    input_dir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\Mexico-3505_01\\'
    outdir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\Mexico-3505_01\output-files\\'
    #input_dir='/data/country_data/mexico/input/'   #linuxall
    #outdir='/data/country_data/mexico/IFF/'     #linuxall
    files=glob.glob(input_dir+'mexico*')
    filenames=sorted([os.path.basename(i) for i in files])
    stn0=[str(i[7:19]) for i in filenames]
    stns=sorted(set(stn0))
elif (dataset == 'CDMP_3850'): #CDMP 3850/3851/3853 ISD-formatted data but likely not merged into main ISD archive
#elif (dataset == 'CDMP_3851'): 
#elif (dataset == 'CDMP_3853'): 
    input_dir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\\'+dataset+'\\'
    outdir=input_dir+'\output-files\\'
    #input_dir='/data/'+dataset+'/'+cdmp_id+'/3505_01_ISD_input_data/'   #linuxall
    #outdir='/data/'+dataset+'/'+cdmp_id+'/IFF/'     #linuxall
    #outdir='./output/' #linux
    #input_dir='./input/'   #linux
    files=glob.glob(input_dir+'??????-?????-????')
    filenames=sorted([os.path.basename(i) for i in files])
    stn0=[str(i[0:12]) for i in filenames]
    stns=sorted(set(stn0))
elif (dataset == 'ASOS'):
    input_dir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\ASOS\input\\'
    outdir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\ASOS\output-files\\'
    #input_dir='./input/'  #linux
    #outdir='./output/' #linux
    #files=glob.glob(input_dir+'sample-NOAA-SWO_ISD_Q*xx*dat') ## this is a subset -- every 1000th line; includes SOD/SOM, etc
    #files=glob.glob(input_dir+'sample-NOAA-SWO_ISD_Q*.dat') ## this is a subset -- every 1000th line; includes SOD/SOM, etc
    #files=glob.glob(input_dir+'NOAA-SWO_ISD_QCL1_DFTY_s20200101_e20200804_c20200804T113045.dat')
    files=glob.glob(input_dir+'NOAA-SWO_ISD_QCL1_DFTY_*.dat') #linux
    filenames=sorted([os.path.basename(i) for i in files])
    print(filenames)
elif (dataset == 'USAF'):
    input_dir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\USAF\input\\'
    outdir=r'C:\Users\Nancy.Casey\Desktop\Python-ISD\USAF\output\\'
    #outdir='./output/' #linux
    #input_dir='./input/'   #linux
    #files=glob.glob(input_dir+'usaf_*ALs.isd*')
    files=glob.glob(input_dir+'usaf_*.isd')
    filenames=sorted([os.path.basename(i) for i in files])
else:
    sys.exit('no dataset selected') 

#Use QC dictionary for USAF; ISD for other datasets
if (dataset == 'USAF'):
    qc_dict=qc_USAF_dict  
else:
    qc_dict=qc_ISD_dict

#1 loop: input files to process
for filen in filenames:
    fle=input_dir+filen
    
    logtime=datetime.now()
    print(logtime.strftime("%Y-%m-%d %H:%M:%S"), filen)

    #2 loop: read ob line-by-line
    obs = ISD_ob(fle)
    for ob in obs: 
            meta1 = ob[0]
            data1 = ob[1]
            data_qc1=ob[2]
            remark1= ob[3]
            
            #TODO: for static datasets: remove existing station-element file so there's no unintended concatenation and create file w hdr
            if (dataset == 'USAF'):
                stationID=get_station_source_ids_USAF(meta1.get('ISD_STN_ID'))[0]
                srcID=get_station_source_ids_USAF(meta1.get('ISD_STN_ID'))[1]
            elif (dataset == 'ASOS'):
                srcID=source_id_dict.get(data_source_ISD_dict.get(meta1.get('source')))
                stationID=get_station_source_ids_ISD(meta1.get('ISD_STN_ID'))
            else:
                srcID=source_id_dict.get(dataset)
                stationID=get_station_source_ids_ISD(meta1.get('ISD_STN_ID'))
                
            if srcID is None:
                print(meta1.get('source'),meta1.get('rpt_type'),stationID,srcID,'src not used')
                continue

            rpt_type=meta1.get('rpt_type')
            if (dataset != 'USAF' and (rpt_type == "SOD  " or rpt_type == "SOM  ")):
                #print(srcID,rpt_type, 'skip')
                continue

            #get metadata list (no station_name in ISD)
            metaprint=[
                    srcID,\
                    stationID,\
                    '',\
                    meta1.get('call_id',''),\
                    meta1.get('year'),\
                    meta1.get('month'),\
                    meta1.get('day'),\
                    meta1.get('hour'),\
                    meta1.get('minute'),\
                    str(meta1.get('latitude')),\
                    str(meta1.get('longitude')),\
                    str(meta1.get("elev_m"))]

            for element in elements:
                #get all element data (data/codes)
                #call functions to extract/format data  **changed int to str for all elements below
                dataprint=['None']  
                codeprint=[''] #for many elements, there is no measurement_code_1    
                codeprint2=[''] #for many elements, there is no measurement_code_2; so far just visibility
                #LCD processing: https://drive.google.com/file/d/1ZtO7bpPkUn4vf-jEUABUU4ZOAZzaSiuo/view?usp=sharing
                #LCD convert-format-standard-result: https://drive.google.com/file/d/1fHwZ6mgF7mcwjpNHvaZ9uEYkD_YktmoF/view?usp=sharing
                if (element == 'temperature'): # changed temps to strings
                            dataprint=get_standard_element(str(data1.get('temp_degC')),qc_dict.get(data_qc1.get('temp_degC'),'X-Missing-QC'),'celsius')
                elif (element == 'dew_point_temperature'):
                            dataprint=get_standard_element(str(data1.get('dewpt_degC')),qc_dict.get(data_qc1.get('dewpt_degC')),'celsius')
                            #TODO: add default 'qc-missing' for all elements in case code in ISD is not in a dictionary (like temperature)? so far it's not necessary but may be good for future - esp static datasets
                elif (element == 'wind_direction'):
                    #LCD: if wdir not NA/empty *or* type is equal to C or V:
                            # if C put 000 for wdir; 
                            # if V put "VRB" see C:\Users\Nancy.Casey\Desktop\GHCNh+Copernicus\LCD\01010099999.xlsx for example
                            #ISD format doc:  If a value of 9 appears with a wind speed of 0000, this indicates calm winds
                                #this logic is passed into wdir measurement code as well
                            #ISD format doc:  If wind type code = V, then 999 indicates variable wind direction
                            # will need to deal with "VRB" in wdir from some sources
                            wspd=str(data1.get('wind_speed_ms'))
                            wdir=str(data1.get('wind_dir'))
                            windtype=str(data1.get('wind_type'))
                            wdirQC=qc_dict.get('wind_dir')
                            #if (wspd != '0.0' and wdir=='999' and windtype == '9'): 
                            #TODO: NANCY ck wind logic for USAF - removed line above 6/24/21
                            if ((wspd == 'None' and wdir=='999' and windtype != 'C') or wdir=='000'): #wdir should never be 000 but need a check for it for USAF and perhaps others
                                dataprint=['None']
                            else: 
                                if (wspd == '0.0' and windtype=='9'):
                                    codeprint=[wind_code_dict.get('C')]
                                    #print('9 to C for 0 windspeed',wspd,windtype,codeprint)
                                else:
                                    codeprint=[wind_code_dict.get(windtype)]                            
                                dataprint=get_standard_element(str(data1.get('wind_dir')),qc_dict.get(data_qc1.get('wind_dir')),'degrees')
                            #print(meta1.get('USAF_WBAN'),wspd,wdir,windtype,wind_code_dict.get(windtype),dataprint,codeprint)
                elif (element =='wind_speed'):
                    #LCD: if wspd not NA/empty *or* type is equal to C or V:
                            #if C change to 0 but makes no changes/mention of V again 
                            #ISD format doc:  If a value of 9 appears with a wind speed of 0000, this indicates calm winds
                                #this logic is passed into wdir measurement code as well
                            #ISD format doc:  If wind type code = V, then 999 indicates variable wind direction
                            wspd=str(data1.get('wind_speed_ms'))
                            windtype=str(data1.get('wind_type'))
                            if (wspd == '0.0' and windtype=='9'):
                                codeprint=[wind_code_dict.get('C')]
                                #print('9 to C for 0 windspeed',wspd,windtype,codeprint)
                            else:
                                codeprint=[wind_code_dict.get(windtype)]
                            dataprint=get_standard_element(wspd,qc_dict.get(data_qc1.get('wind_speed_ms')),'m/s')
                elif (element == 'sea_level_pressure'):
                            dataprint=get_standard_element(str(data1.get('mslp_hPa')),qc_dict.get(data_qc1.get('mslp_hPa')),'mb')
                elif (element == 'station_level_pressure'):
                            dataprint=get_standard_element(str(data1.get('stnp_hPa')),qc_dict.get(data_qc1.get('stnp_hPa')),'mb')
                elif (element == 'altimeter'):
                            dataprint=get_standard_element(str(data1.get('altimeter_hPa')),qc_dict.get(data_qc1.get('altimeter_hPa')),'mb')
                elif (element == 'wind_gust'):
                            dataprint=get_standard_element(str(data1.get('wind_gust_ms')),qc_dict.get(data_qc1.get('wind_gust_ms')),'m/s')            
                #combined pressure_3hr_change and pressure_tendency (LCD +/- will need to be dealt with after IFF processing)
                elif (element == 'pressure_3hr_change'):
                            prestendcode=data1.get('pressure_tendency_code')
                            pres3hrchange=str(data1.get('pressure_3hr_change_hPa'))
                            codeprint=[atm_pres_tend_code_dict.get(str(prestendcode))]
                            if (codeprint[0] is not None):
                                codeprint=codeprint
                            else: 
                                codeprint[0]='None'
                                #TODO: should this be X-None?
                            if (prestendcode is not None):
                                if (int(prestendcode) > 4):
                                    pres3hrchange='-'+pres3hrchange
                            dataprint=get_standard_element(pres3hrchange,qc_dict.get(data_qc1.get('pressure_3hr_change_hPa')),'mb')       
                elif (element == 'precipitation'):
    #Matt: need to substitute "T" for LCD value if code is 2 (right now mcode contains "2-Trace" and precip is value (usually[always?] 0.0)
                            precip1hrdur={}
                            for n in [1,2,3,4]:
                                precip1hrdur[n]=str(data1.get('precip_'+str(n)+'_dur_h'))
                            if '1' in precip1hrdur.values():
                                keys1hr = get_keys_from_value(precip1hrdur, '1')
                                for key in keys1hr:
                                    precip1hr=str(data1.get('precip_'+str(key)+'_amt_mm'))
                                    precip1hrcode=str(data1.get('precip_'+str(key)+'_cond'))
                                    #if len(keys1hr) > 1:
                                    #    print(key, metaprint, precip1hrdur,precip1hr,precip1hrcode)
                                    if dataset == 'USAF':
                                        codeprint=[precip_code_USAF_dict.get(precip1hrcode)]
                                    else:
                                        codeprint=[precip_code_ISD_dict.get(precip1hrcode)]
                                    dataprint=get_standard_element(str(data1.get('precip_'+str(key)+'_amt_mm')),qc_dict.get(data_qc1.get('precip_'+str(key))),'mm')
                            else:
                                dataprint=['None']
                elif (element[0:9] == 'sky_cover'):
                            for n in [1,2,3]: 
                                if (element == 'sky_cover_'+str(n)):
                                    skycovlyr=str(data1.get('sky_cov_layer_'+str(n)+'_cov_code')) 
                                    skycovlyrd=sky_cover_LCD_dict.get(skycovlyr)
                                    codeprint=[sky_cover_long_dict.get(skycovlyr)]
                                    dataprint=get_standard_element(skycovlyrd,qc_dict.get(data_qc1.get('sky_cov_layer_'+str(n)+'_cov_code')),'code')
                                    #testing
                                    #if(meta1.get('USAF_WBAN') == '78925000404'):
                                    #    print(element,n,metaprint,dataprint,codeprint)
                elif (element[0:14] == 'sky_cov_baseht'):
                            for n in [1,2,3]:  
                                if (element == 'sky_cov_baseht_'+str(n)):
                                    dataprint=get_standard_element(str(data1.get('sky_cov_layer_'+str(n)+'_base_ht')),qc_dict.get(data_qc1.get('sky_cov_layer_'+str(n)+'_base_ht')),'meters')
                elif (element == 'visibility'):
                            codeprint2=''
                            dataprint=get_standard_element(str(data1.get('vis_km')),qc_dict.get(data_qc1.get('vis_km')),'km')
                            vis_var_type_code=str(data1.get('vis_var'))
                            vis_var_type_QC=data_qc1.get('vis_var')
                            if dataset == 'USAF':
                                codeprint=[vis_var_type_USAF_dict.get(vis_var_type_code)]
                            else:
                                codeprint=[vis_var_type_ISD_dict.get(vis_var_type_code)]
                            if vis_var_type_QC is not None:
                                codeprint2=[str(qc_dict.get(vis_var_type_QC))]
            #LCD: for AU/MW the number_code:definition is not used (only AW); instead just the definition
                elif (element[0:10] == 'pres_wx_AU'):
                            for n in [1,2,3]:
                                if (element == 'pres_wx_AU'+str(n)):
                                    wx_intensity=str(data1.get('weather_'+str(n)+'_intensity'))
                                    wx_desc=str(data1.get('weather_'+str(n)+'_descriptor'))
                                    wx_precip=str(data1.get('weather_'+str(n)+'_precip'))
                                    wx_obsc=str(data1.get('weather_'+str(n)+'_obscuration'))
                                    wx_other=str(data1.get('weather_'+str(n)+'_other')) 
                                    #wx_combo=str(data1.get('weather_'+str(n)+'_combo'))  #weather_combo isn't used in LCD code
                                    wx_i=AU_intensity_dict.get(wx_intensity)
                                    wx_d=AU_desc_dict.get(wx_desc)
                                    wx_p=AU_precip_dict.get(wx_precip)
                                    wx_ob=AU_obsc_dict.get(wx_obsc)
                                    wx_other=AU_other_dict.get(wx_other)
                                    AUlist0=[wx_i,wx_d,wx_p,wx_ob,wx_other]
                                    if (not any(AUlist0)):
                                        dataprint=[None]
                                    else:
                                        AUlist=''.join(list(filter(None,AUlist0)))
                                        AUlist1=list(filter(None,AUlist0))
                                        #print(AUlist0,AUlist1,AUlist)
                                        dataprint=get_standard_element(AUlist,qc_dict.get(data_qc1.get('weather_'+str(n))),'code')
                                        codeprint0=[AU_mcode_dict[k] for k in AUlist1 if k in AU_mcode_dict]
                                        codeprint=['_'.join(codeprint0)]
                elif (element[0:10] == 'pres_wx_AW'):
                            for n in [1,2,3]:
                                if (element == 'pres_wx_AW'+str(n)):
                                    AW_ele=str(data1.get('auto_weather_'+str(n))) 
                                    AW_lcd=AW_LCD_dict.get(AW_ele)
                                    if (not any(AW_ele)):                            
                                        dataprint=[None]
                                    else:
                                        dataprint=get_standard_element(AW_lcd,qc_dict.get(data_qc1.get('auto_weather_'+str(n))),'code')
                                        #using LCD/ISD combined codes
                                        codeprint=[AW_LCD_ISD_combined_dict.get(AW_lcd)]
                                    #if (AW_ele != 'None'):
                                        #print(outfilend,dataprint, AW_ele, AW_lcd, codeprint)
                elif (element[0:10] == 'pres_wx_MW'):
                            for n in [1,2,3]:
                                if (element == 'pres_wx_MW'+str(n)):
                                    MW_ele=str(data1.get('SYNOP_weather_'+str(n))) 
                                    MW_lcd=MW_LCD_dict.get(MW_ele)
                                    if (not any(MW_ele)):                            
                                        dataprint=[None]
                                    else:
                                        dataprint=get_standard_element(MW_lcd,qc_dict.get(data_qc1.get('SYNOP_weather_'+str(n))),'code')
                                        codeprint=[MW_LCD_ISD_combined_dict.get(MW_lcd)]
                                    #if (MW_ele != 'None'):
                                    #   print(outfilend,dataprint, MW_ele, MW_lcd,codeprint)            
                elif (element == 'relative_humidity'):
    #NOTE: in LCD: if airtemp or dewpt are suspect/error; code removes those indicators and keeps values for temps -- and calculates RH with no flag indication
    #LCD RH does not use getStandardResult method so no “s” for suspect is ever appended to final RH output. 
    #LCD RH calculation is made even if component temps are suspect; however if a component(s) is given error flag, RH is put as ‘*’ 
    #I calc RH no matter what qc flags of components, even erroneous; flags are in qc-code
    #TODO: Matt: use qc_dict for USAF? issue with USAF flags 4 and 5
                            airtemp=data1.get('temp_degC')                  #in tenths (no rounding needed)
                            airtempQC=data_qc1.get('temp_degC')
                            dewtemp=data1.get('dewpt_degC')             #in tenths (no rounding needed)
                            dewtempQC=data_qc1.get('dewpt_degC')
                            if (airtemp is not None and dewtemp is not None):
                                #originally incorporated a non-LCD RH formula from: https://www.quora.com/How-do-you-find-the-relative-humidity-percentage-if-the-dew-point-temperature-is-20-degrees-Celsius-and-the-temperature-is-18-degrees-Celsius
                                #kept it here just to compare values to make sure LCD calc is close.
                                relhum_other=int(roundValue(100*(math.exp((17.625*dewtemp)/(243.04+dewtemp))/math.exp((17.625*airtemp)/(243.04+airtemp))),0))
                                relhum = int(roundValue((((112.0 - (0.1 *airtemp) + dewtemp) / (112.0 + (0.9 * airtemp)))**8) * 100.0, 0))
                                #if (relhum != relhum_other):
                                #   print('disagree',metaprint, relhum,relhum_other)
                                if (relhum > 100 or relhum <1):
                                    qc_code='out-of-range'
                                    #print(qc_code, relhum)
                                    #print(metaprint,'RH:', relhum, 'airtemp:',airtemp,'dewtemp:',dewtemp,qc_dict.get(data_qc1.get('temp_degC')),qc_dict.get(data_qc1.get('dewpt_degC')),qc_code)
                                elif (ck_badflag_ISD('RH_airtemp',airtemp,airtempQC) or ck_badflag_ISD('RH_dewpt',dewtemp,dewtempQC)):
                                    qc_code='flag_Ta-'+airtempQC+'_Td-'+dewtempQC
                                    #print(qc_code,airtempQC,dewtempQC)
                                    #print(metaprint,'RH:', relhum, 'airtemp:',airtemp,'dewtemp:',dewtemp,qc_dict.get(data_qc1.get('temp_degC')),qc_dict.get(data_qc1.get('dewpt_degC')),qc_code)
                                else:
                                    qc_code=''
                                #print('RH:', relhum, 'airtemp:',airtemp,'dewtemp:',dewtemp,qc_dict.get(data_qc1.get('temp_degC')),qc_dict.get(data_qc1.get('dewpt_degC')),qc_code)
                                dataprint=get_standard_element(str(relhum),qc_code,'percent')
                            else:
                                #print('No RH calculation: ','airtemp:',airtemp,'dewtemp:',dewtemp,qc_dict.get(data_qc1.get('temp_degC')),qc_dict.get(data_qc1.get('dewpt_degC')))
                                dataprint=['None']
                            codeprint=['Derived']                            
                elif (element == 'wet_bulb_temperature'):
                            #LCD wetbulb calculation is made even if component temps are suspect ('s' is removed); however if any of 3 are erroneous, WB not calculated and put as ‘*’ 
                            #LCD wetbulb does not use getStandardResult method so no “s” for suspect is ever appended to final wet bulb output. 
    #TODO: Matt: use qc_dict for USAF? issue with USAF flags 4 and 5
                            airtempC=data1.get('temp_degC')                     #in tenths (no rounding needed)
                            airtempQC=data_qc1.get('temp_degC')
                            dewtempC=data1.get('dewpt_degC')                #in tenths (no rounding needed)
                            dewtempQC=data_qc1.get('dewpt_degC')
                            spHp=data1.get('stnp_hPa')                              #in tenths (no rounding needed)
                            spQC=data_qc1.get('stnp_hPa')
                            if (airtempC is not None and dewtempC is not None and spHp is not None):
                                airtempF = roundToInt(convertFahrenheit(airtempC))          #LCD code uses degF in whole numbers as input for air/dew temps
                                dewtempF = roundToInt(convertFahrenheit(dewtempC))
                                spHg=roundValue(convertInHg(spHp),2)                                #LCD code uses 100ths for station pressure as input
                                #uses Java doubles in LCD
                                wetbulbF = 0.0
                                a = (airtempF - dewtempF) * 0.1
                                b = a - 1.0
                                c = a**2
                                if (airtempF < 0):
                                    wetbulbF = airtempF - (0.034 * a - 0.006 * c) * (0.6 * (airtempF + dewtempF) - 2.0 * spHg + 108.0);
                                else:
                                    wetbulbF = airtempF - (0.034 * a - 0.00072 * a * b) * (airtempF + dewtempF - 2.0 * spHg + 108.0);
                                #convert wet bulb to C and round to tenths
                                wetbulbC = roundValue(convertCelsius(wetbulbF),1)
                                if (ck_badflag_ISD('WB_air',airtempC,airtempQC) or ck_badflag_ISD('WB_dew',dewtempC,dewtempQC) or ck_badflag_ISD('WB_stnp',spHp,spQC)):
                                    qc_code='flag_Ta-'+airtempQC+'_Td-'+dewtempQC+'_stnP-'+spQC
                                    #print(metaprint,'wetbulb', 'airtemp:',airtempQC,'dewtemp:',dewtempQC,'stnp',spQC,qc_code)
                                else:
                                    qc_code=''
                                dataprint=get_standard_element(str(wetbulbC),qc_code,'celsius')
                            else: 
                                dataprint=['None']
                            codeprint=['Derived']
                            #print(airtempC,airtempF,dewtempC,dewtempF,spHp,spHg,wetbulbF, 'final',wetbulbC, dataprint)
                elif (element == 'snow_depth'):
                            snow_depth_cm=data1.get('snow_depth_cm')
                            if snow_depth_cm is not None:
                                snow_depth_mm=str(int(snow_depth_cm)*10.)   #per Matt, convert from cm to mm for IFFs
                                snow_depth_qc0=data_qc1.get('snow_depth_cm')
                                snow_depth_qc=qc_dict.get(snow_depth_qc0)
                                snowdepthcode=data1.get('snow_depth_cond')
#TODO: ask Matt if we should exclude any 0.0 values (see if/else below or change it somehow)
                                dataprint=get_unit_change_element(int(snow_depth_cm),snow_depth_mm,snow_depth_qc,'cm')
                                #if (snow_depth_mm=='0.0' and snowdepthcode=='9' and snow_depth_qc0=='9'):
                                #        dataprint=['None']
                                #else:
                                #        dataprint=get_unit_change_element(int(snow_depth_cm),snow_depth_mm,snow_depth_qc,'cm')
                                codeprint=''
                                if dataset == 'USAF':
#TODO: do we need the before/after statement? or is the mcode lookup the same throughout POR?
                                    codeprint=[snow_depth_code_USAF_dict.get(snowdepthcode)]
                                    #if int(meta1.get('date')) >= 20130501:
                                    #    codeprint=[snow_depth_code_USAF_dict.get(snowdepthcode)]
                                    #else:
                                    #    codeprint=[snow_depth_code_USAF_dict.get(snowdepthcode)]
                                else:
                                    codeprint=[snow_code_ISD_dict.get(snowdepthcode)]
                            else:
                                dataprint=['None']
                            if (dataprint != ['None']):
                                print('snow-depth',stationID,meta1.get('date'),meta1.get('hour'),meta1.get('minute'),rpt_type,dataprint,codeprint)
                elif (element == 'snow_depth_liq_equiv'):
#TODO: ----------> make sure but probably don't need for difference in dict condition type for pre/post May2013 <---------------------------------
                            snow_depth_liq_equiv_mm=data1.get('snow_depth_liq_equiv_mm')
                            if snow_depth_liq_equiv_mm is not None:
                                snow_depth_liq_equiv_qc0=data_qc1.get('snow_depth_liq_equiv_mm')
                                snow_depth_liq_equiv_qc=qc_dict.get(snow_depth_liq_equiv_qc0)
                                snowdepthlecode=data1.get('snow_depth_liq_equiv_cond')
#TODO: ask Matt if we should exclude any 0.0 values (see if/else below or change it somehow)
                                dataprint=get_standard_element(snow_depth_liq_equiv_mm,snow_depth_liq_equiv_qc,'mm')
                                #if (snow_depth_liq_equiv_mm==0.0 and snowdepthlecode=='9' and snow_depth_liq_equiv_qc0=='9'):
                                #        dataprint=['None']
                                #        #print('water-Removed:', snow_depth_liq_equiv_mm,snowdepthlecode,snow_depth_liq_equiv_qc0, type(snow_depth_liq_equiv_mm), type(snowdepthlecode),type(snow_depth_liq_equiv_qc0))
                                #else:
                                #        dataprint=get_standard_element(snow_depth_liq_equiv_mm,snow_depth_liq_equiv_qc,'mm')
                                codeprint=''
                                if dataset == 'USAF':
                                    codeprint=[snow_depth_liq_equiv_code_USAF_dict.get(snowdepthlecode)]
                                else:
                                    codeprint=[snow_depth_liq_equiv_code_ISD_dict.get(snowdepthlecode)]
                            else:
                                dataprint=['None']
                            if (dataprint != ['None']):
                                print('snow-water',stationID,meta1.get('date'),meta1.get('hour'),meta1.get('minute'),rpt_type,dataprint,codeprint)
                elif (element == 'snow_accumulation'):
                            snowaccumdur4={}
                            for n in [1,2,3,4]:
                                snowaccumdur4[n]=str(data1.get('snow_accumulation_'+str(n)+'_dur_h'))
#TODO; ask Matt - what do about durations of 99 and if there's multiples
                            if ('6' in snowaccumdur4.values() or '99' in snowaccumdur4.values()):
                                if '6' in snowaccumdur4.values():
                                    key = get_keys_from_value(snowaccumdur4,'6') # 6 takes precedence over 99     
                                elif '99' in snowaccumdur4.values():
                                    key = get_keys_from_value(snowaccumdur4,'99') # 6 takes precedence over 99
                                if (len(key) > 1):
                                    print('----->',snowaccumdur4, data1.get('snow_accumulation_'+str(key[0])+'_depth_cm'), data1.get('snow_accumulation_'+str(key[1])+'_depth_cm'))
                                #uses first key
                                snow_accum_cm=data1.get('snow_accumulation_'+str(key[0])+'_depth_cm')
                                if (snow_accum_cm is not None):
                                    snow_accum_mm=str(int(snow_accum_cm)*10.)   #per Matt, convert from cm to mm for IFFs
                                    snowaccumcode=str(data1.get('snow_accumulation_'+str(key[0])+'_cond'))
                                    snow_accum_durh=str(data1.get('snow_accumulation_'+str(key[0])+'_dur_h'))
                                    snow_accum_qc=str(data_qc1.get('snow_accumulation_'+str(key[0])+'_depth_cm'))
#TODO: ask Matt if we should exclude any 0.0 values (see if/else below or change it somehow)
                                    dataprint=get_unit_change_element(snow_accum_cm,snow_accum_mm,qc_dict.get(snow_accum_qc),'cm')
                                    #if (snow_accum_mm=='0.0' and snowaccumcode=='9' and snow_accum_durh=='99' and snow_accum_qc=='9'):
                                    #    dataprint=['None']
                                    #else:
                                    #    dataprint=get_unit_change_element(snow_accum_cm,snow_accum_mm,qc_dict.get(snow_accum_qc),'cm')
                                    codeprint=''
                                    if dataset == 'USAF':
#TODO: do we need the before/after statement? or is the mcode lookup the same throughout POR?
                                        codeprint=[snow_accum_code_USAF_dict.get(snowaccumcode)]
                                        #if int(meta1.get('date')) >= 20130501:
                                        #    codeprint=[snow_accum_code_USAF_dict.get(snowaccumcode)]
                                        #else:
                                        #    codeprint=[snow_accum_code_USAF_dict.get(snowaccumcode)]
                                    else:
                                        codeprint=[snow_code_ISD_dict.get(snowaccumcode)]
                                    codeprint2=[str(snow_accum_durh)+'-hr']
                                    if (dataprint != ['None']):
                                        print('snow-accum',stationID,meta1.get('date'),meta1.get('hour'),meta1.get('minute'),rpt_type,dataprint,codeprint, codeprint2,snowaccumdur4,key)
                            else:
                                dataprint=['None']
                elif (element == 'REM'):
                #added AWY; USAF has this for WMO IDs and perhaps others (but only SYN and MET appear to be in ASOS)
                            dataprint0=list(filter(None,[remark1.get('SYN'), remark1.get('MET'), remark1.get('AWY')]))
                            if (dataprint0):
                                dataprint=dataprint0
                                print('REMARKS',stationID,meta1.get('date'),meta1.get('hour'),meta1.get('minute'),rpt_type,dataprint)
                            else:
                                dataprint=['None']
                else:
                            sys.exit('No element')

                if (dataprint[0] != 'None' and dataprint[0] is not None):       #added None (non-string) to accommodate sky_cover_1/2/3
                    #compile output    
                    rptprint=rpt_type_dict[(meta1.get('rpt_type')).strip()]
                    dsrcprint=src_code_dict[(meta1.get('source')).strip()]
                    rpt_dsrc_print=[(rptprint+'_'+dsrcprint)]
                    masterlist=metaprint+dataprint+rpt_dsrc_print+codeprint+codeprint2

                    #write to file
                    p = Path(outdir+element)
                    p.mkdir(exist_ok=True)
                    outfilend=stationID+'-'+element+'-'+srcID+'.psv'
                    outfile=outdir+element+'/'+outfilend
                    if not os.path.exists(outfile):
                            hmsg=write_header(outfile)
                    ##static datasets (**now need to remove existing output IFFs for static datasets before re-running)
                        #fmsg=rm_element_file_if_exists(outdir,outfilend,element)

                    write_to_file_csv(outfile,masterlist)
    #TODO: have a way to show if process quit before processing the entire file completed?
