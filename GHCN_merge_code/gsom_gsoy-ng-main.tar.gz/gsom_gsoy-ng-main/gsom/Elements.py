#TODO This will get moved to ElementCalculations
from enum import Enum

class Elements(Enum):
    #Instantiate the elements with these parameters
    #String-ID = To prevent "aliasing" of enum values
    #Calc = How do we summarize the daily values?
    #Parameters - [Scale, Decimal Places]
    #     String-ID,  Parameters
    #Average Dew Point
    ADPT = ( "ADPT", {"scale": .1, "roundTo":2})
    #Monthly Average Sea Level Pressure
    ASLP = ( "ASLP", {"scale": .1, "roundTo":1})
    #Monthly Average Station Level Pressure
    ASTP = ( "ASTP", {"scale": .1, "roundTo":1})
    #Monthly Average Wet Bulb Temperature 
    AWBT = ( "AWBT", {"scale": .1, "roundTo":2})
    #/Monthly Average Wind Speed 
    AWND = ( "AWND", {"scale": .1, "roundTo":2})
    #Cooling Degree Days (season-to-date) 
    CDSD = ( "CDSD", {"scale": .1, "roundTo":2})
    #Cooling Degree Days
    CLDD = ( "CLDD", {})
    #Days with >= 0.1 inch/2.54 millimeters in the month
    DAPR = ( "DAPR", {})
    #Day(s) with max snow
    DASF = ( "DASF", {})
    #Day(s) with minimum temp 
    DATN = ( "DATN", {})
    #Day(s) with max temp 
    DATX = ( "DATX", {})
    #Days w/ >= 0.01 inch rain 
    DP01 = ( "DP01", {})
    #Days w/ >= 0.1 inch rain 
    DP10 = ( "DP10", {})
    #Days w/ >= 1.0 inch rain 
    DP1X = ( "DP1X", {})
    #Days w/ >= 1.0 inch snow depth 
    DSND = ( "DSND", {})
    #Days w/ >= 1.0 inch snow fall 
    DSNW = ( "DSNW", {})
    #Days w/ min temp <= -17.8 C/0 F 
    DT00 = ( "DT00", {})
    #Days w/ min temp <= 0 C/32 F 
    DT32 = ( "DT32", {})
    #Days w/ max temp <= 0 C/32 F 
    DX32 = ( "DX32", {})
    #Days w/ max temp >= 21 C/70 F 
    DX70 = ( "DX70", {})
    #Days w/max temp >= 32 C/90 F 
    DX90 = ( "DX90", {})
    #Days w/fog 
    DYFG = ( "DYFG", {})
    #Days w/heavy fog
    DYHF = ( "DYHF", {}) 
    #Days with Thunderstorms
    DYTS = ( "DYTS", {}) 
    #day of month extreme min temp
    DYNT = ( "DYNT", {}) 
    #day of month highest snow depth
    DYSD = ( "DYSD", {}) 
    #day of month highest snow fall
    DYSN = ( "DYSN", {}) 
    #day of month highest total precip
    DYXP = ( "DYXP", {}) 
    #day of month extreme max temp
    DYXT = ( "DYXT", {}) 
    #extreme min temperature
    EMNT = ( "EMNT", {}) 
    #extreme max snow depth
    EMSD = ( "EMSD", {}) 
    #extreme max snow fall
    EMSN = ( "EMSN", {}) 
    #highest precipitation
    EMXP = ( "EMXP", {})  
    #extreme max temperature
    EMXT = ( "EMXT", {}) 
    #total monthly evaporation to tenths of mm
    EVAP = ( "EVAP", {"scale": .1, "round_to":1}) 
    #heating degree, season-to-date
    HDSD = ( "HDSD", {}) 
    #HNxy (highest min soil temp)
    HN = ( "HN", {}) 
    #heating degree days. temp less than 65 f
    HTDD = ( "HTDD", {}) 
    # HXxy (highest max soil temp)
    HX = ( "HX", {}) 
    #LNxy (lowest min soil temp for the month)
    LN = ( "LN", {}) 
    #LXxy (lowest max soil temp)
    LX = ( "LX", {}) 
    # Multi-Day Precip
    MDPR = ( "MDPR", {}) 
    #Multi-Day Min Temperature
    MDTN = ( "MDTN", {})  
    #Multi-Day Max Temperature
    MDTX = ( "MDTX", {}) 
    #Multi-day snow fall
    MDSF = ( "MDSF", {}) 
    #MNxy (monthly mean min soil temp)
    MN = ( "MN", {}) 
    #monthly mean temp of evap pan water
    MNPN = ( "MNPN", {"scale": .1, "round_to":2})
    #MXxy (monthly mean max soil temp)
    MX = ( "MX", {}) 
    #monthly max temp of evap pan water
    MXPN = ( "MXPN", {"scale": .1, "round_to":2}) 
    #total monthly precipitation
    PRCP = ( "PRCP", {})  
    #average daily percent of possible sunshine
    PSUN = ( "PSUN", {"scale": 1, "round_to":1}) 
    #relative humidity, month average
    RHAV = ( "RHAV", {"scale": 1, "round_to":0}) 
    #relative humidity, min month average
    RHMN = ( "RHMN", {"scale": 1, "round_to":0}) 
    #relative humidity, max month average
    RHMX = ( "RHMX", {"scale": 1, "round_to":0}) 
    #Soil minimums???
    SN = ( "SN", {}) 
    #total monthly snow in mm
    SNOW = ( "SNOW", {})
    ##TODO Was Snow Depth commented out on purpose?
    SNWD = ( "SNWD", {}) 
    #Soil maximums???
    SX = ( "SX", {})
    #average monthly temp
    TAVG = ( "TAVG", {}) 
    #monthly mean max temp
    TMAX = ( "TMAX", {})
    #monthly mean min temp
    TMIN = ( "TMIN", {}) 
    #daily total sunshine in minutes
    TSUN = ( "TSUN", {"scale": 1, "round_to":0})  
    #wind direction, fastest 1 minute
    WDF1 = ( "WDF1", {}) 
    #wind direction, fastest 2 minute
    WDF2 = ( "WDF2", {})
    #wind direction, fastest 5 minute
    WDF5 = ( "WDF5", {})
    #wind direction for peak wind gust speed
    WDFG = ( "WDFG", {}) 
    #wind direction max speed, fastest mile
    WDFM = ( "WDFM", {}) 
    #Total Monthly Wind Movement Over Evaporation Pan
    WDMV = ( "WDMV", {"scale": 1, "round_to":0})
    #Fastest 1 minute wind speed for month
    WSF1 = ( "WSF1", {"scale": 1, "round_to":1}) 
    #Fastest 2 minute wind speed for month
    WSF2 = ( "WSF2", {"scale": 1, "round_to":1})
    #Fastest 5 minute wind speed for month
    WSF5 = ( "WSF5", {"scale": 1, "round_to":1})
    #Max Wind Gust for Month
    WSFG = ( "WSFG", {"scale": 1, "round_to":1}) 
    #max wind speed, fastest mile
    WSFM = ( "WSFM", {"scale": 1, "round_to":1}) 
    #Days with fog, written as DYFG
    WT01 = ( "WT01", {}) 
    #Days with heavy fog, written as DYHF
    WT02 = ( "WT02", {}) 
    #Days with thunder storms, written as DYTS
    WT03 = ( "WT03", {}) 

    def __init__(self, str_code, params):
        #global calc
        self.str_code=str_code#prevents the members from being aliased if similar value
        self.parameters = params
        self.boundsCheck = False
        self.bounds = [-89.4, 56.7]
        self.scale = 1



# Some Elements will need bounds checks for their QC flags
Elements.EVAP.boundsCheck = True
Elements.EVAP.bounds = [0, 4500]
Elements.MNPN.boundsCheck = True
Elements.MXPN.boundsCheck = True
Elements.EVAP.ignoreConsecutiveMisses = True

# TODO Find out if we can just always have wind direction use own flag
Elements.WDFG.parentFlag = True