# -*- coding: utf-8 -*-
"""
Created on Wed Apr  9 10:15:09 2025

@author: snoone
"""

import pandas as pd
import os
import glob

# Define the input folder where the CSV files are stored
input_folder = r'C:\Users\snoone\Dropbox\NEW_DATA_SOURCES_r8_\Yuri_B_New_data_use\All_Giessen_rescue_data\Giessen_new data\China_Years_Nanking_sbdy\China_Years_Nanking\out'

# Define the output folder where the combined CSV files will be saved
output_folder = r'C:\Users\snoone\Dropbox\NEW_DATA_SOURCES_r8_\Yuri_B_New_data_use\All_Giessen_rescue_data\Giessen_new data\China_Years_Nanking_sbdy\China_Years_Nanking\out\combined'

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# Get the list of all CSV files in the input folder
csv_files = glob.glob(os.path.join(input_folder, '*.csv'))

# Dictionary to store DataFrames by the prefix (before first underscore)
data_dict = {}

# Loop through each CSV file
for csv_file in csv_files:
    # Extract the prefix (string before first underscore) from the filename
    filename = os.path.basename(csv_file)
    prefix = filename.split('_')[0]
    
    # Read the CSV file, skipping the first 3 rows and keeping only one header
    df = pd.read_csv(csv_file, skiprows=3)
    
    # Add the DataFrame to the dictionary based on the prefix
    if prefix in data_dict:
        data_dict[prefix].append(df)
    else:
        data_dict[prefix] = [df]

# Loop through each prefix group and save the combined CSV for that prefix
for prefix, dfs in data_dict.items():
    # Concatenate the DataFrames for this prefix
    combined_df = pd.concat(dfs, ignore_index=True)
    
    # Optionally, add a column with the prefix name if needed
    combined_df['Source'] = prefix
    
    # Define the output path for the combined CSV file named after the prefix
    output_csv = os.path.join(output_folder, f'{prefix}.csv')
    
    # Save the combined DataFrame to a new CSV file
    combined_df.to_csv(output_csv, index=False)
    
    print(f'Combined CSV for {prefix} saved to {output_csv}')
