# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 12:17:19 2023

@author: snoone
"""

import os
import glob
import pandas as pd

# Define output directory
OUTDIR = "E:/NEW_DATA_SOURCES_r8_/ACRE_africa_403/IFF"
os.chdir("E:/NEW_DATA_SOURCES_r8_/ACRE_africa_403/")

# Define file extension to look for
extension = '.csv'

# Get all files with the specified extension
all_filenames = [i for i in glob.glob(f'*{extension}')]

# Process each file
for filename in all_filenames:
    try:
        # Read the CSV file
        df = pd.read_csv(filename)

        # Add additional columns
        df["Source_ID"] = "403"
        df["Station_ID"] = "403-00001"
        df["Station_name"] = "Tamatava"
        df["Alias_station_name"] = ""
        df["Latitude"] = "-18.1492"
        df["Longitude"] = "49.40234"
        df["Elevation"] = "3.3"
        df["Source_QC_flag"] = ""
        df["Original_observed_value"] = ""
        df["Original_observed_value_units"] = "hpa"
        df["Report_type_code"] = ""
        df["Measurement_code_1"] = ""
        df["Measurement_code_2"] = ""
        df["Minute"] = "00"

        # Define standard columns for output
        columns = [
            "Source_ID", "Station_ID", "Station_name", "Alias_station_name",
            "Year", "Month", "Day", "Hour", "Minute", "Latitude", "Longitude",
            "Elevation", "Observed_value", "Source_QC_flag",
            "Original_observed_value", "Original_observed_value_units",
            "Report_type_code", "Measurement_code_1", "Measurement_code_2"
        ]

        # Prepare data for specific hours
        merged_slp = []
        for hour, obs_col in zip(["6", "7", "9", "13", "16", "18"], ["6h", "7h", "9h", "13h", "16h", "18h"]):
            if obs_col in df.columns:
                temp_df = df.copy()
                temp_df["Hour"] = hour
                temp_df = temp_df.rename(columns={obs_col: "Observed_value"})
                temp_df["Original_observed_value"] = temp_df["Observed_value"]
                temp_df["Observed_value"] = pd.to_numeric(temp_df["Observed_value"], errors="coerce")
                temp_df = temp_df[columns]
                merged_slp.append(temp_df)

        # Combine all hour-based dataframes
        merged_slp = pd.concat(merged_slp, axis=0).dropna(subset=["Observed_value"])
        # Round the Observed_value column to 2 decimal places
        merged_slp["Observed_value"] = merged_slp["Observed_value"].round(1)
        merged_slp["Original_observed_value"] = merged_slp["Original_observed_value"].round(1)

        # Generate timestamps and adjust timezones
        merged_slp["Timestamp"] = pd.to_datetime(
            merged_slp["Year"].astype(str) + "-" +
            merged_slp["Month"].astype(str) + "-" +
            merged_slp["Day"].astype(str) + " " +
            merged_slp["Hour"].astype(str) + ":" +
            merged_slp["Minute"],
            format="%Y-%m-%d %H:%M"
        )
        merged_slp["Timestamp"] = merged_slp["Timestamp"].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')
        merged_slp["Year"] = merged_slp["Timestamp"].dt.year
        merged_slp["Month"] = merged_slp["Timestamp"].dt.month
        merged_slp["Day"] = merged_slp["Timestamp"].dt.day
        merged_slp["Hour"] = merged_slp["Timestamp"].dt.hour
        merged_slp["Minute"] = merged_slp["Timestamp"].dt.minute
        merged_slp = merged_slp.drop(columns="Timestamp")
        # Combine Year, Month, Day, Hour columns into a new Timestamp column
        merged_slp['Timestamp'] = pd.to_datetime(merged_slp[['Year', 'Month', 'Day', 'Hour']])

        # Sort the DataFrame by the Timestamp column
        merged_slp = merged_slp.sort_values(by='Timestamp')
        # Drop the Timestamp column
        merged_slp = merged_slp.drop(columns=['Timestamp'])

        # Save the output using Station_ID in the filename
        station_id = merged_slp["Station_ID"].iloc[0]  # Get the Station_ID
        source_id = merged_slp["Source_ID"].iloc[0]   # Get the Source_ID
        cdm_type = f"{station_id}_station_level_pressure_{source_id}"  # Update filename format
        
        # Create output file path and save
        outname = os.path.join(OUTDIR, cdm_type)
        merged_slp.to_csv(outname + ".psv", index=False, sep="|")

    except Exception as e:
        print(f"Error processing file {filename}: {e}")

