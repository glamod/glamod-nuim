PREFIX=$1

if [ ! -s ${PREFIX}datzilla/archive ]
then
echo "Datzilla archive does not exist under ${PREFIX}"
exit
fi
rm -rf ${PREFIX}datzilla/rawdata
mkdir ${PREFIX}datzilla/rawdata
for i in `cut -c1-11 ${PREFIX}datzilla/archive/*.txt | sort -u`; do grep -h "^$i" ${PREFIX}datzilla/archive/*.txt | sort -u | sort -n -t, -k 2 -k 3 -k 11 > ${PREFIX}datzilla/rawdata/$i.csv; done
gawk 'BEGIN {FS=","} $4=="4A" || $4=="4B" {print $0}' ${PREFIX}datzilla/rawdata/* | cut -c1-11 | sort -u > ${PREFIX}datzilla/datzilla.rawdata.post.inv
gawk 'BEGIN {FS=","} $4!="4A" && $4!="4B" {print $0}' ${PREFIX}datzilla/rawdata/* | cut -c1-11 | sort -u > ${PREFIX}datzilla/datzilla.rawdata.pre.inv
