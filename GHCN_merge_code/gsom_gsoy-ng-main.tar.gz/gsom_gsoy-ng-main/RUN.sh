#!/bin/bash

# This is the run script for GSOM/GSOY

# Use a python virtual environment
source /data/ops/gsom_gsoy_ng/code/gsom-y_env/bin/activate

# --- GSOM --- #
python3.12 GlobalSummaryOfMonth.py '-i' '/data/ops/gsom_gsoy_ng/ghcnd/ghcnd_all/' \
                                   '-s' '/data/ops/gsom_gsoy_ng/ghcnd/ghcnd-stations.txt' \
                                   '-o' '/data/ops/gsom_gsoy_ng/output-monthly/' \
                                   '-l' '/data/ops/gsom_gsoy_ng/logs/gsom/' \
                                   '--som' '/data/ops/gsom_gsoy_ng/som/SOM_output_20240905.tar.gz'

# --- GSOY --- #
python3.12 GlobalSummaryOfYear.py '-i' '/data/ops/gsom_gsoy_ng/output-monthly/' \
                                  '-s' '/data/ops/gsom_gsoy_ng/ghcnd/ghcnd-stations.txt' \
                                  '-o' '/data/ops/gsom_gsoy_ng/output-yearly/' \
                                  '-l' '/data/ops/gsom_gsoy_ng/logs/gsoy/'