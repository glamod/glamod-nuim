#!/bin/bash

PREFIX=$1
lib_dir=$2
mode=$3
begdate=$4
enddate=$5

rm -rf ${PREFIX}download/raws

mkdir -p ${PREFIX}download/raws

if [ ${mode} = "ref" ]
then

#Step 1: Get station list

cd ${PREFIX}download/raws
rm -f get-raws-step1.log
for cst in $(<${PREFIX}input4sys/raws-states.txt)
do
  cst=$(echo ${cst}|tr [A-Z] [a-z] )'lst.html'
  wget -a get-raws-step1.log -P stnlist -N http://www.raws.dri.edu/$cst
#  read -p "Press any key to continue....."
done

#Step 2: Get station metadata

${lib_dir}get-raws-meta.exe ${PREFIX}download/

echo "${PREFIX}download/raws/metadata/" "${PREFIX}raws/archive/metadata/" | ${lib_dir}check_size.sh

#Step 3: Generate raws station metadata in raws-inv.txt
echo "Starting gen-raws-inv.exe" `date`
$lib_dir}gen-raws-inv.exe ${PREFIX}

fi

#Step 4: Download periods of record

for st in $(ls ${PREFIX}raws/archive/metadata | cut -c1-6)
do
  curl -s  https://raws.dri.edu/cgi-bin/wea_dysimts.pl?${st} | grep 'available data:' >> ${PREFIX}download/raws/dateranges.txt
done

#Step 5:  Download data

if [ ${mode} != "ref" ]
then

echo "starting get-raws-data.exe for ${begdate}-${enddate}" `date`

${lib_dir}get-raws-data.exe ${PREFIX}download/ ${PREFIX}download/raws/dateranges.txt  ${begdate} ${enddate}

nydirs=`ls ${PREFIX}download/raws/data | wc | gawk '{print $1}'`

fi

if [ ${nydirs} != 1 ]
then
echo "Found ${nydirs} year directories in ${PREFIX}download/raws/data...terminating get-raws.sh"
exit 1
fi

if [ ${mode} = "por" ]
then
echo "${PREFIX}download/raws/data/9999/" "${PREFIX}raws/archive/data/${begdate:0:4}/" | ${lib_dir}check_size.sh
elif [ ${mode} = "upd" ]
then
ydir=`ls ${PREFIX}download/raws/data`
echo "${PREFIX}download/raws/data/${ydir}/" "${PREFIX}raws/archive/data/${ydir}/" | ${lib_dir}check_size.sh
fi
exit 0


