PREFIX=$1
rm -rf ${PREFIX}wsod/rawghcnd
cp -rp ${PREFIX}wsod/maed/rawghcnd ${PREFIX}wsod
for file in `ls ${PREFIX}wsod/isdsod/rawghcnd`
do
cat ${PREFIX}wsod/isdsod/rawghcnd/${file} >> ${PREFIX}wsod/rawghcnd/${file}
done
