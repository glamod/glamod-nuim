#!/bin/sh
read newpath oldpath

#Get last run directory size
oldsize=0
if [ -s $oldpath ]
then
oldsize="$(/usr/bin/du -b ${oldpath} | gawk '{print $1}')"
fi

#Get latest run directory size
newsize=0
if [ -s $newpath ]
then
newsize="$(/usr/bin/du -b ${newpath} | gawk '{print $1}')"
fi

sizediff=`expr $newsize - $oldsize`

if [ $sizediff -lt 0 ]
then
echo "WARNING from check_size.sh!!! $newpath is smaller than $oldpath...using $oldpath"
else
rm -rf $oldpath
mv $newpath $oldpath
echo "check_size.sh moved data from $newpath to $oldpath"
fi

