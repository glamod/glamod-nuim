#!/bin/bash

cd $(dirname $0)

tar -xf gsom_gsoy.tar.gz

python3.12 -m ensurepip --default-pip
python3.12 -m pip install -r requirements.txt

./unit_test.sh