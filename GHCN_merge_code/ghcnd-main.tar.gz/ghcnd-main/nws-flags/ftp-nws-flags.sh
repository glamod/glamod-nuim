export local_dir="/data/nws-flags/"
export ftp_data_path="/ghcn-daily/nws/"
cat ${local_dir}*.flags | sort > ${ftp_data_path}WFO-allflags.csv
for wfo in `cat wfo-list.txt`
 do
   sort -r ${local_dir}${wfo}.flags > ${local_dir}${wfo}/${wfo}-allflags.csv
   rm -f ${ftp_data_path}${wfo}/*.csv
   cd ${local_dir}${wfo}
   cp -p *.csv ${ftp_data_path}${wfo}
 done
