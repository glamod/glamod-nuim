./strip_source.exe R mingle-list.txt ghcnd-stations.txt 
./strip_source.exe X mingle-list-no-R.txt ghcnd-stations-no-R.txt 
./strip_source.exe B mingle-list-no-X.txt ghcnd-stations-no-X.txt 
./strip_source.exe M mingle-list-no-B.txt ghcnd-stations-no-B.txt 
./strip_source.exe A mingle-list-no-M.txt ghcnd-stations-no-M.txt 
./strip_source.exe S mingle-list-no-A.txt ghcnd-stations-no-A.txt 

