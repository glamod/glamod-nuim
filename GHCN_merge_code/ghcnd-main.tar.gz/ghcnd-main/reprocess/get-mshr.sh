path=$1
cp -p ${path}MASTER-STN-HIST.TXT ${path}MASTER-STN-HIST.TXT.OLD
wget -N -P${path} ftp://ftp0.ncdc.noaa.gov/pub/data/inventories/MASTER-STN-HIST.TXT 
year=`grep "created on" ${path}MASTER-STN-HIST.TXT | cut -c34-37`
month=`grep "created on" ${path}MASTER-STN-HIST.TXT | cut -c28-29`
day=`grep "created on" ${path}MASTER-STN-HIST.TXT | cut -c31-32`
echo "Using MASTER-STN-HIST.TXT that was created on ${year}/${month}/${day}"
