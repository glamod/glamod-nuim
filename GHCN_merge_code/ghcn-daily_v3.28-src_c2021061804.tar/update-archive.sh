#!/bin/sh
# Update the archive directory of a data source with files from the corresponding download directory that (1) are not yet in the archive directory or (2) have been updated.

# Interpret arguments
download=$1  # directory where newly downloaded files are temporarily stored 
archive=$2  # directory where downloaded files are archived
findstring=$3  # portion of file names to consider copying; may include wildcards

# Check whether the specified download and archive directories exist.
 if [ ! -s ${download} ] 
 then 
 echo "${download} must exist. Terminating 
 update-archive.sh..." 
 exit 
fi

if [ ! -s ${archive} ] 
 then 
 echo "${archive} did not exist yet."
echo "Update-archive.sh copied all of ${download}." 
 mv ${download} ${archive} 
 exit 
fi

# Identify the most recently modified file in the archive directory.
newest=`ls -r -t ${archive} | tail -1`
#count=`ls -r -t ${archive} | wc | cut -c1-7`
#echo "The most recently modified of the ${count} files in the archive was ${newest}."

cwd=`pwd`
cd ${download}
numnewer="$(find . -maxdepth 1 -name "${findstring}" -type f -newer ${archive}/${newest} \! -empty | wc | gawk '{print $1}')"

if [ $numnewer = 0 ]
then
echo "Update-archive.sh moved no files from ${download}."
else

# Find all downloaded files whose modification date is later than the latest
# modification date in the archive directory and that are not empty and move
# them to the archive directory.
find . -maxdepth 1 -name "${findstring}"  -type f -newer ${archive}/${newest} \! -empty -exec mv {} ${archive} \;
echo "Update-archive.sh moved $numnewer files from ${download} to ${archive}." 
fi
cd $cwd

# Print out final message from the script.
newest2=`ls -l -r -t ${archive} | tail -1`
count2=`ls -r -t ${archive} | wc | gawk '{print $1}'`
echo "The most recently modified of the ${count2} file(s) in the archive is:"
echo ${newest2}
#echo "Moved the following files from ${download} to ${archive}:"
#find ${archive} -name "*.*" -newer ${archive}/${newest} -print
