gawk 'substr($0,39,2)=="  " {print substr($0,1,12)"XX0"substr($0,4,35)substr($0,42,47)}' ghcnd-stations.oldids.txt > ghcnd-stations-moveFIPS.txt
gawk 'substr($0,39,2)!="  " {print substr($0,1,12)substr($0,39,2)"0"substr($0,4,35)substr($0,42,47)}' ghcnd-stations.oldids.txt >> ghcnd-stations-moveFIPS.txt
gawk 'substr($0,13,5)=="US000" {print substr($0,1,14)"C00"substr($0,18,80)}' ghcnd-stations-moveFIPS.txt > ghcnd-stations.oldplusnewids.txt
gawk 'substr($0,13,5)=="US001" {print substr($0,1,14)"W00"substr($0,18,80)}' ghcnd-stations-moveFIPS.txt >> ghcnd-stations.oldplusnewids.txt
gawk 'substr($0,13,5)=="XX000" {print substr($0,1,14)"C00"substr($0,18,80)}' ghcnd-stations-moveFIPS.txt >> ghcnd-stations.oldplusnewids.txt
gawk 'substr($0,13,5)=="XX001" {print substr($0,1,14)"W00"substr($0,18,80)}' ghcnd-stations-moveFIPS.txt >> ghcnd-stations.oldplusnewids.txt
gawk 'substr($0,13,2)!="US" && substr($0,13,2)!="XX" {print $0}' ghcnd-stations-moveFIPS.txt >> ghcnd-stations.oldplusnewids.txt
cut -c1-23 ghcnd-stations.oldplusnewids.txt | sort > ghcnd-stations.oldplusnewids.xref
join ghcnd-stations.oldplusnewids.xref mingle-list.oldids.txt | cut -c13-250 | sort | gawk '{print substr($0,1,12),substr($0,13,250)}' > mingle-list.txt
sed -i 's/ 0 425/ 0 000/g' mingle-list.txt
sed -i 's/ 6 425/ 6 000/g' mingle-list.txt
sed -i 's/ H 425/ H 000/g' mingle-list.txt
sed -i 's/ 1 42501/ 1 00000/g' mingle-list.txt
sed -i 's/ A 42501/ A 00000/g' mingle-list.txt
sed -i 's/ B 42501/ B 00000/g' mingle-list.txt
cut -c13-97 ghcnd-stations.oldplusnewids.txt | sort > ghcnd-stations.txt
