import polars as pl
import polars.selectors as cs

from gsom.Elements import Elements

def summarizeMonths(dailyData:pl.DataFrame, isNorthHemisphere:bool) -> dict:
    monthlySummary = dict()
    #print(dailyData)
    #loop through rows in daily data
    for row in range(0, dailyData.height):
        #print(dailyData[row])
        element = dailyData.select( pl.col("Element") )[row].item()
        
        #Check the Elements enum to see if we have an associated calculation
        #Need an OR element.substring(0,2)==SN
        if element in Elements.__members__:

            #We'll use the year month as the key-id in monthlySummary
            yearMonth = dailyData.select( pl.col("Year_Month") )[row].item()
            #Save our primary row
            parentRow = dailyData[row]
            requiredRows = []
            #for required rows, loop thru and grab elements matching year-month
            '''
            for required in Elements[element].requiredElements:
                
                requiredRows.append(dailyData.select(
                    dailyData.filter(
                        pl.col("Element") == required.name, 
                        pl.col("Year_Month") == yearMonth
                        )
                    )
                )
            '''
            # send the parent element and any
            # required rows to the calculation defined in Elements enum
            monthlyRecords = Elements[element].createRecords( parentRow, requiredRows )
            #loop through records in monthlyRecords array and store
            #in monthlySummary dictionary
            for record in monthlyRecords:
                #create a dictionary for the year month if first entry
                if record["element"] not in monthlySummary:
                    monthlySummary[ record["element"] ] = dict()
                #store the record in the year-month dictionary
                output = {}
                output[yearMonth] = record["summary"]
                monthlySummary[ record["element"] ].update(output)

        #print("Monthly Summary = ", monthlySummary)    

    return monthlySummary