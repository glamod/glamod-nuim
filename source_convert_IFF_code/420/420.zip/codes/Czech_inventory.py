#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon May 25 21:24:43 2026

@author: sangethaedathil
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Create CHMI Czech inventory from IFF files

Base folder:
CHMI_data/IFF

Creates one inventory row per station.

Variables included:
- temperature
- relative_humidity
- wind_speed
- wind_direction
- station_level_pressure
- soil_temperature

Output:
CHMI_inventory.csv
"""

import os
import glob
import pandas as pd


# ============================================================
# SETTINGS
# ============================================================

BASE_IFF_DIR = (
    "/Users/sangethaedathil/Library/CloudStorage/"
    "Dropbox/NEW_DATA_SOURCES_r8_/CHMI_data/IFF"
)

OUTPUT_CSV = (
    "/Users/sangethaedathil/Library/CloudStorage/"
    "Dropbox/NEW_DATA_SOURCES_r8_/CHMI_data/"
    "CHMI_inventory.csv"
)

# ============================================================
# VARIABLES
# ============================================================

VARIABLE_FOLDERS = {
    "temperature": "temperature",
    "relative_humidity": "relative_humidity",
    "wind_speed": "wind_speed",
    "wind_direction": "wind_direction",
    "station_level_pressure": "station_level_pressure",
    "soil_temperature": "soil_temperature"
}


# ============================================================
# HELPER
# ============================================================

def clean_text(value):

    if pd.isna(value):
        return ""

    value = str(value).strip()

    if value.lower() in ["nan", "none", "na"]:
        return ""

    return value


# ============================================================
# INVENTORY DICTIONARY
# ============================================================

inventory = {}

print("======================================")
print("Creating CHMI Czech inventory")
print("======================================")


# ============================================================
# LOOP THROUGH VARIABLES
# ============================================================

for variable_name, folder_name in VARIABLE_FOLDERS.items():

    variable_dir = os.path.join(
        BASE_IFF_DIR,
        folder_name
    )

    print(f"\nProcessing: {variable_name}")

    if not os.path.exists(variable_dir):

        print(f"Folder not found: {variable_dir}")

        continue

    psv_files = glob.glob(
        os.path.join(variable_dir, "*.psv")
    )

    print(f"PSV files found: {len(psv_files)}")

    for file in sorted(psv_files):

        try:

            df = pd.read_csv(
                file,
                sep="|",
                dtype=str
            )

            if df.empty:
                continue

            required_cols = [
                "Station_ID",
                "Station_name",
                "Latitude",
                "Longitude",
                "Elevation",
                "Year"
            ]

            missing = [
                col for col in required_cols
                if col not in df.columns
            ]

            if missing:

                print(
                    f"Skipped {os.path.basename(file)} "
                    f"(missing columns: {missing})"
                )

                continue

            # ====================================================
            # STATION INFO
            # ====================================================

            station_id = clean_text(
                df["Station_ID"].iloc[0]
            )

            station_name = clean_text(
                df["Station_name"].iloc[0]
            )

            latitude = clean_text(
                df["Latitude"].iloc[0]
            )

            longitude = clean_text(
                df["Longitude"].iloc[0]
            )

            elevation = clean_text(
                df["Elevation"].iloc[0]
            )

            # ====================================================
            # YEARS
            # ====================================================

            years = pd.to_numeric(
                df["Year"],
                errors="coerce"
            )

            years = years.dropna()

            if len(years) == 0:
                continue

            start_year = int(years.min())

            end_year = int(years.max())

            # ====================================================
            # CREATE STATION ENTRY
            # ====================================================

            if station_id not in inventory:

                inventory[station_id] = {

                    "Station_ID": station_id,

                    "Station_name": station_name,

                    "Latitude": latitude,

                    "Longitude": longitude,

                    "Elevation": elevation
                }

            # ====================================================
            # VARIABLE START/END YEARS
            # ====================================================

            inventory[station_id][
                f"{variable_name}_start_year"
            ] = start_year

            inventory[station_id][
                f"{variable_name}_end_year"
            ] = end_year

        except Exception as e:

            print(
                f"FAILED: {os.path.basename(file)}"
            )

            print(f"Reason: {e}")


# ============================================================
# CREATE FINAL DATAFRAME
# ============================================================

inventory_df = pd.DataFrame(
    inventory.values()
)

# ============================================================
# COLUMN ORDER
# ============================================================

column_order = [

    "Station_ID",
    "Station_name",
    "Latitude",
    "Longitude",
    "Elevation",

    "temperature_start_year",
    "temperature_end_year",

    "relative_humidity_start_year",
    "relative_humidity_end_year",

    "wind_speed_start_year",
    "wind_speed_end_year",

    "wind_direction_start_year",
    "wind_direction_end_year",

    "station_level_pressure_start_year",
    "station_level_pressure_end_year",

    "soil_temperature_start_year",
    "soil_temperature_end_year"
]

# Keep only columns that exist
column_order = [
    col for col in column_order
    if col in inventory_df.columns
]

inventory_df = inventory_df[column_order]

# ============================================================
# SORT
# ============================================================

inventory_df = inventory_df.sort_values(
    by=["Station_ID"]
)

# ============================================================
# SAVE
# ============================================================

inventory_df.to_csv(
    OUTPUT_CSV,
    index=False
)

print("\n======================================")
print("DONE")
print("======================================")
print(f"Stations: {len(inventory_df)}")
print(f"Saved inventory:")
print(OUTPUT_CSV)
print("======================================")