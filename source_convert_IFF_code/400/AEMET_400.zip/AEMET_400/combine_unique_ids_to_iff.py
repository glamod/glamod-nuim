# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 15:53:52 2024

@author: snoone
"""

import os
import pandas as pd

# Define paths
input_dir = r'D:/AEMET_spanish_hist_sub_daily/extracted_files/VelV/JLC/VelV/data/out/ws'
output_dir = r'D:/AEMET_spanish_hist_sub_daily/extracted_files/VelV/JLC/VelV/data/out/ws/IFF'

# Ensure output directory exists
os.makedirs(output_dir, exist_ok=True)

# Get list of all CSV files in the input directory
csv_files = [f for f in os.listdir(input_dir) if f.endswith('.csv')]

for csv_file in csv_files:
    # Read the CSV file
    file_path = os.path.join(input_dir, csv_file)
    df = pd.read_csv(file_path)
    
    # Process data by unique Station_ID
    unique_station_ids = df['Station_ID'].unique()
    for station_id in unique_station_ids:
        station_df = df[df['Station_ID'] == station_id]
        output_file = os.path.join(output_dir, f'{station_id}_wind_speed_400.psv')
        
        # Save or append the data to the output file
        if os.path.exists(output_file):
            station_df.to_csv(output_file, mode='a', sep='|', index=False, header=False)
        else:
            station_df.to_csv(output_file, sep='|', index=False)

print("Processing complete.")
