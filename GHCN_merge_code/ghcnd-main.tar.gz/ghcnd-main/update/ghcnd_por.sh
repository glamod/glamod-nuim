#

export PREFIX=$1

run_status=$2
#"sync" or "test"

export timestamp=`date -u '+%Y%m%d%H'`

yr35daysago=`date -d "35 days ago" +%Y`
mo35daysago=`date -d "35 days ago" +%m`
lastrawsday=`cal ${mo35daysago} ${yr35daysago} | grep -v '[A-Za-z]' | wc -w`

echo "Starting compile-ghcnd.sh" `date`
echo ghcndmod.f95 | ${PREFIX}compile-ghcnd.sh

cd $PREFIX
if [ ! -s download ]
then
mkdir download
fi

find ${PREFIX}archive -maxdepth 1 -name '*inventory*.txt' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.log' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.flags' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.tar.gz' -mtime +31 -exec rm -f {} \;

#GET THE INTERNATIONAL DATA SOURCES

#Get the Australian data
echo "Starting get-australia.sh" `date`
${PREFIX}get-australia.sh ${PREFIX}
echo "Starting gen-rawdata-australia.sh" `date`
${PREFIX}gen-rawdata-australia.sh ${PREFIX} por
echo "Starting rf_australia2ghcnd.exe" `date`
${PREFIX}rf_australia2ghcnd.exe ${PREFIX}

#Get the Canadian Data and append big por download with latest update
echo "Starting get-canada.sh" `date`
${PREFIX}get-canada.sh
${PREFIX}append-canada.sh ${PREFIX}

#Get the ECA Data
echo "Starting get-eca.sh" `date`
${PREFIX}get-eca.sh ${PREFIX}
echo "Starting check_size.sh for eca" `date`
echo "${PREFIX}download/eca/" "${PREFIX}eca/archive/" | ${PREFIX}check_size.sh
echo "Starting gen-rawdata-eca.sh" `date`
${PREFIX}gen-rawdata-eca.sh ${PREFIX} 
echo "Starting rf-eca2ghcnd.exe" `date`
${PREFIX}rf-eca2ghcnd.exe ${PREFIX}

#Get the GCOS Database
echo "Starting getgcos_rf2ghcnd.exe" `date`
${PREFIX}getgcos_rf2ghcnd.exe ${PREFIX}download/ 
echo "Starting check_size.sh for gcos" `date`
echo "${PREFIX}download/gcos/rawghcnd/" "${PREFIX}gcos/rawghcnd/" | ${PREFIX}check_size.sh 
echo "Creating gcos raw ghcnd inventory" `date`
ls ${PREFIX}gcos/rawghcnd | cut -c6-10 > ${PREFIX}gcos.inv

#Get the GSOD and RAWS data
echo "Starting get_gsod.exe" `date`
${PREFIX}get_gsod.exe ${PREFIX}download/ &
echo "Starting get-raws.sh" `date`
${PREFIX}get-raws.sh ${PREFIX} por ${yr35daysago}0101 ${yr35daysago}${mo35daysago}${lastrawsday}
echo "get-raws.sh finished at " `date`
wait

#Reformat GSOD
echo "Starting check_size.sh for gsod" `date`
echo "${PREFIX}download/gsod/rawdata/" "${PREFIX}gsod/rawdata/" | ${PREFIX}check_size.sh 
ls ${PREFIX}/gsod/rawdata > ${PREFIX}gsod.inv
echo "Starting rf_gsod2ghcnd.exe" `date`
${PREFIX}rf_gsod2ghcnd.exe $PREFIX

#Reformat RAWS
echo "Starting gen-rawdata-raws.sh" `date`
${PREFIX}gen-rawdata-raws.sh
cut -c2-3,8-11 ${PREFIX}raws/rawdata/* | gawk '{print substr($0,3,4)substr($0,1,2)}' | sort -u | tail -1 > ${PREFIX}raws/archive/last-date-in-archive.txt
echo "Starting rf-raws2ghcnd.exe" `date`
${PREFIX}rf-raws2ghcnd.exe ${PREFIX}

#GET THE REALTIME SOURCES FOR THE USA

#Get the HPRCC (SHEF) data
echo "Starting get_hprcc.exe" `date`
${PREFIX}get_hprcc.exe ${PREFIX}
echo "Starting rf_hprcc2ghcnd.exe" `date`
${PREFIX}rf_hprcc2ghcnd.exe ${PREFIX}

#Get the CoCoRaHS data
echo "Starting get-cocorahs.exe" `date`
${PREFIX}get-cocorahs.exe ${PREFIX} 20070101 `echo ${timestamp} | cut -c1-8`
echo "Starting rf-cocorahs2ghcnd.exe" `date`
${PREFIX}rf-cocorahs2ghcnd.exe ${PREFIX} 

#Get the Snotel data
echo "Starting get-snotel.exe" `date`
${PREFIX}get-snotel.exe ${PREFIX}download/ ${PREFIX}input4sys/snotel-inv.txt 
rm -rf ${PREFIX}snotel/rawdataold 
rm -rf ${PREFIX}snotel/rawghcndnew 
rm -rf ${PREFIX}snotel/rawghcndold
mv ${PREFIX}snotel/rawdata ${PREFIX}snotel/rawdataold
mv ${PREFIX}snotel/rawghcnd ${PREFIX}snotel/rawghcndold
mv ${PREFIX}download/snotel/rawdata ${PREFIX}snotel
echo "Starting rf-snotel2ghcnd.exe " `date`
${PREFIX}rf-snotel2ghcnd.exe ${PREFIX}
mv ${PREFIX}snotel/rawghcnd ${PREFIX}snotel/rawghcndnew 
mv ${PREFIX}snotel/rawghcndold ${PREFIX}snotel/rawghcnd 
echo "Starting check_size.sh for snotel" `date`
echo "${PREFIX}snotel/rawghcndnew/" "${PREFIX}snotel/rawghcnd/" | ${PREFIX}check_size.sh

#Get the CRN data
echo "Starting get_crn.exe" `date`
${PREFIX}get_crn.exe ${PREFIX}download/
echo "Starting check_size.sh for crn" `date`
echo "${PREFIX}download/crn/rawdata/" "${PREFIX}crn_archive/rawdata/" | ${PREFIX}check_size.sh 
echo "Moving raw data from /crn_arhive/ to /crn/" `date`
rm -rf ${PREFIX}crn/rawdata
mv ${PREFIX}crn_archive/rawdata ${PREFIX}crn/rawdata
echo "Starting rf_crn2ghcnd.exe" `date`
${PREFIX}rf_crn2ghcnd.exe $PREFIX
echo "Moving /crn/rawdata back to /crn_archive/"
mv ${PREFIX}crn/rawdata ${PREFIX}crn_archive/rawdata

#Get the keyed paper coop data
echo "Starting get-papercoop.sh" `date`
${PREFIX}get-papercoop.sh ${PREFIX}
echo "Starting rf-papercoop2ghcnd.exe" `date`
${PREFIX}rf-papercoop2ghcnd.exe ${PREFIX}

#Get the wxcoder data
echo "Starting get-3207.sh" `date`
${PREFIX}get-3207.sh ${PREFIX}
#Parse the monthly wxcoder data into por station files
echo "Starting gen-rawghcnd-3207.sh" `date`
${PREFIX}gen-rawghcnd-3207.sh ${PREFIX}

#GET AND REFORMAT THE ARCHIVED SOURCES FOR THE USA

echo "Starting get-isdsod.sh" `date`
${PREFIX}get-isdsod.sh ${PREFIX} 2006 `echo ${timestamp} | cut -c1-4` &

echo "Starting get_32xx.exe" `date`
${PREFIX}get_32xx.exe ${PREFIX}download/
echo "Starting check_size.sh for 3200" `date`
echo "${PREFIX}download/3200/rawdata/" "${PREFIX}3200/rawdata/" | ${PREFIX}check_size.sh 
echo "Starting rf320x_to_ghcnd.exe for 3200" `date`
${PREFIX}rf320x_to_ghcnd.exe $PREFIX M 3200
echo "Starting check_size.sh for 3206" `date`
echo "${PREFIX}download/3206/rawdata/" "${PREFIX}3206/rawdata/" | ${PREFIX}check_size.sh 
echo "Starting rf320x_to_ghcnd.exe for 3206" `date`
${PREFIX}rf320x_to_ghcnd.exe $PREFIX M 3206
echo "Starting check_size.sh for 3210" `date`
echo "${PREFIX}download/3210/rawdata/" "${PREFIX}3210/rawdata/" | ${PREFIX}check_size.sh 
echo "Starting rf3210or3211_to_ghcnd.exe for 3210" `date`
${PREFIX}rf3210or3211_to_ghcnd.exe $PREFIX M 3210
echo "Starting check_size.sh for 3211" `date`
echo "${PREFIX}download/3211/rawdata/" "${PREFIX}3211/rawdata/" | ${PREFIX}check_size.sh 
echo "Starting rf3210or3211_to_ghcnd.exe for 3211" `date`
${PREFIX}rf3210or3211_to_ghcnd.exe $PREFIX M 3211
wait

${PREFIX}update-archive2.sh ${PREFIX}download/wsod ${PREFIX}wsod/isdsod/archive 'sod*.isd'

echo "Starting rf-isdsod2ghcnd.exe" `date`
${PREFIX}rf-isdsod2ghcnd.exe ${PREFIX} ${PREFIX}input4sys/wsod-stations-utc-offsets.txt

echo "Starting cat-isdsod-maed.sh" `date`
${PREFIX}cat-isdsod-maed.sh ${PREFIX}

#Reformat the latest 3210 edits for Datzilla
echo "Starting rf-3210edits4datzilla.exe" `date`
${PREFIX}rf-3210edits4datzilla.exe $PREFIX M 3210

#GET THE LATEST DATZILLA TICKETS
echo "Starting get-datzilla.sh" `date`
${PREFIX}get-datzilla.sh ${PREFIX}
${PREFIX}update-archive2.sh ${PREFIX}download/datzilla ${PREFIX}datzilla/archive '*Corr.txt'
echo "Starting gen-datzilla-rawdata.sh" `date`
${PREFIX}gen-datzilla-rawdata.sh ${PREFIX}

# MINGLE THE DATA
echo "starting mingle.exe" `date`
${PREFIX}mingle.exe $PREFIX ${PREFIX}input4sys/mingle-list.txt

# APPLY DATZILLA TICKETS EXCEPT FOR "UNFLAG" CASES
echo "Starting datzilla.exe with pre" `date`
${PREFIX}datzilla.exe pre ${PREFIX}datzilla/datzilla.rawdata.pre.inv ${PREFIX} ${PREFIX}datzilla/rawdata/ ${PREFIX}mingled/ ${PREFIX}datzillaoutpre/

#COPY DATZILLA OUTPUT FILES TO MINGLED DIRECTORY
cp -p ${PREFIX}datzillaoutpre/*.dly ${PREFIX}mingled

# PRE FORMAT CHECK
echo "Starting pre format_check.exe" `date`
${PREFIX}format_check.exe pre ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}mingled/ ${PREFIX}rawghcnd/ ${PREFIX}format_check_pre.log

# QC1, QC2 and QC3

echo "Starting qc1.exe" `date`
${PREFIX}qc1.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt M por

echo "Starting rf_stn2time.exe" `date`
${PREFIX}rf_stn2time.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt

echo "Starting qc2.exe" `date`
${PREFIX}qc2.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt M por

echo "Starting qc3.exe" `date`
${PREFIX}qc3.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt por

# APPLY DATZILLA TICKETS FOR "UNFLAG" CASES
echo "Starting datzilla.exe with post" `date`
${PREFIX}datzilla.exe post ${PREFIX}datzilla/datzilla.rawdata.post.inv ${PREFIX} ${PREFIX}datzilla/rawdata/ ${PREFIX}qc3out/ ${PREFIX}datzillaoutpost/

#COPY DATZILLA OUTPUT FILES TO QC3OUT DIRECTORY
cp -p ${PREFIX}datzillaoutpost/*.dly ${PREFIX}qc3out

echo "Starting post format_check.exe" `date`
${PREFIX}format_check.exe post ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

if [ "$(/usr/bin/du -b format_check_post.log | gawk '{print $1}')" -gt 0 ] 
then
echo "WARNING!!! Formatting error detected in post QC mode: Content of log file follows"
cat format_check_post.log
echo "Moving qc1out to qc1outold"
rm -rf ${PREFIX}qc1outold
mv ${PREFIX}qc1out ${PREFIX}qc1outold
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh por no 
echo "Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
exit
fi

echo "Starting check_size.sh for this por run" `date`
echo "${PREFIX}qc3out/" "${PREFIX}ghcnd_por/" | ${PREFIX}check_size.sh 

if [ -s ${PREFIX}qc3out ]
then
echo "WARNING!!! Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh por no 
exit
fi

echo "Starting make_gsn_hcn.exe" `date`
${PREFIX}make_gsn_hcn.exe $PREFIX por

echo "Starting ghcndinv.exe" `date`
${PREFIX}ghcndinv.exe ${PREFIX} ${PREFIX}ghcnd_por/ ${PREFIX}input4sys/ghcnd-stations.txt

rm -r ${PREFIX}ghcnd_all
cp -rp ghcnd_por ghcnd_all

vernum=`cat ${PREFIX}input4sys/version-number.txt`

echo $vernum-por-$timestamp > ${PREFIX}input4sys/por-version.txt
echo "The current version of GHCN Daily is $vernum-por-$timestamp (i.e, a period of record reprocess that started at $timestamp [yyyymmddhh] UTC; yyyy=year; mm=month; dd=day; hh=hour)." > ${PREFIX}ghcnd-version.txt

echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh por ${run_status} /home/mmenne/backup/ghcnd2/

echo "Starting genclim.exe" `date`
${PREFIX}genclim.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations.txt

if [ "${run_status}" = "sync" ]
then
echo "Starting gen-info2sync-with-upd.sh" `date`
${PREFIX}gen-info2sync-with-upd.sh ${PREFIX} /home/mmenne/backup/ghcnd2/
fi

echo "ghcnd_por.sh finished at" `date`


