read modulefile

ulimit -s unlimited

lf95path=/usr/local/lf6481/bin/

${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}get_hprcc.f95 -o ${PREFIX}get_hprcc.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf_hprcc2ghcnd.f95 -o ${PREFIX}rf_hprcc2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}get-cocorahs.f95 -o ${PREFIX}get-cocorahs.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf-cocorahs2ghcnd.f95 -o ${PREFIX}rf-cocorahs2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}m_datetime.f95 ${PREFIX}get-snotel-nrcs-rf2ghcnd.f95 -o ${PREFIX}get-snotel-nrcs-rf2ghcnd.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}get-raws-data.f95 -o ${PREFIX}get-raws-data.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf-raws2ghcnd.f95 -o ${PREFIX}rf-raws2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf-papercoop2ghcnd.f95 -o ${PREFIX}rf-papercoop2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf_australia2ghcnd.f95 -o ${PREFIX}rf_australia2ghcnd.exe 
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf-eca2ghcnd.f95 -o ${PREFIX}rf-eca2ghcnd.exe 
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}get_crn.f95 -o ${PREFIX}get_crn.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf_crn2ghcnd.f95 -o ${PREFIX}rf_crn2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf-cf62ghcnd.f95 -o ${PREFIX}rf-cf62ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}get_gsod.f95 -o ${PREFIX}get_gsod.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf_gsod2ghcnd.f95 -o ${PREFIX}rf_gsod2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}getgcos_rf2ghcnd.f95 -o ${PREFIX}getgcos_rf2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}mingle.f95 -o ${PREFIX}mingle.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}datzilla.f95 -o ${PREFIX}datzilla.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf-3210edits4datzilla.f95 -o ${PREFIX}rf-3210edits4datzilla.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}format_check.f95 -o ${PREFIX}format_check.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}qc1.f95 -o ${PREFIX}qc1.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf_stn2time.f95 -o ${PREFIX}rf_stn2time.exe 
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}qc2.f95 -o ${PREFIX}qc2.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}qc3.f95 -o ${PREFIX}qc3.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}make_gsn_hcn.f95 -o ${PREFIX}make_gsn_hcn.exe 
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}get_32xx.f95 -o ${PREFIX}get_32xx.exe
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf320x_to_ghcnd.f95 -o ${PREFIX}rf320x_to_ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}rf3210or3211_to_ghcnd.f95 -o ${PREFIX}rf3210or3211_to_ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}${modulefile} ${PREFIX}m_datetime.f95 ${PREFIX}rf-isdsod2ghcnd.f95 -o ${PREFIX}rf-isdsod2ghcnd.exe --ap
${lf95path}lf95 ${PREFIX}ghcndmod.f95 ${PREFIX}ghcndinv.f95 -o ${PREFIX}ghcndinv.exe --ap
${lf95path}lf95 ${PREFIX}ghcndmod.f95 ${PREFIX}genclim.f95 -o ${PREFIX}genclim.exe --ap
${lf95path}lf95 ${PREFIX}ghcndmod.f95 ${PREFIX}append_upd2por.f95 -o ${PREFIX}append_upd2por.exe 
${lf95path}lf95 ${PREFIX}ghcndmod.f95 ${PREFIX}rf_isd2day.f95 -o ${PREFIX}rf_isd2day.exe --ap
${lf95path}lf95 ${PREFIX}ghcndmod.f95 ${PREFIX}check4timing.f95 -o ${PREFIX}check4timing.exe --ap
${lf95path}lf95 ${PREFIX}ghcn_canada.f95 -o ${PREFIX}ghcn_canada.exe --ap






