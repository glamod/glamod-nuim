/home/mmenne/ghcnd2/qc3.exe /home/mmenne/ghcnd2/ /home/mmenne/ghcnd2/input4sys/ghcnd-stations.txt por
/home/mmenne/ghcnd2/format_check.exe post /home/mmenne/ghcnd2/input4sys/ghcnd-stations.txt /home/mmenne/ghcnd2/ /home/mmenne/ghcnd2/qc3out/ /home/mmenne/ghcnd2/empty/ /home/mmenne/ghcnd2/format_check_post.log
