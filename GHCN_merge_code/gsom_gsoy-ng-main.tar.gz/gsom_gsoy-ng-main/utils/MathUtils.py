from decimal import Decimal, getcontext, ROUND_HALF_UP
import math
from gsoy.Elements import CompareMethod
from typing import Union

getcontext().rounding = ROUND_HALF_UP

# TODO figure out epilson for math.isclose()

def roundToStr(val: Union[Decimal, float], ndigits: int) -> str:
    if ndigits == 0:
        return str(int(val))
    else:
        return str(round(val, ndigits))

def compareFloat(val: float, valToCompareTo: float, compareMethod: CompareMethod) -> bool:
    match(compareMethod):
        case CompareMethod.LESS_THAN:
            return (val < valToCompareTo)
        case CompareMethod.LESS_THAN_EQUAL_TO:
            return math.isclose(val, valToCompareTo) or (val < valToCompareTo)
        case CompareMethod.EQUAL_TO:
            return math.isclose(val, valToCompareTo)
        case CompareMethod.GREATER_THAN:
            return (val > valToCompareTo)
        case CompareMethod.GREATER_THAN_EQUAL_TO:
            return math.isclose(val, valToCompareTo) or (val > valToCompareTo)