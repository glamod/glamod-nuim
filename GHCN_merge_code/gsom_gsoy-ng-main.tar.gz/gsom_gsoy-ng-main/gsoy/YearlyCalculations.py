import polars as pl
from typing import Union
from gsoy.Elements import Elements
from utils import MathUtils
from collections import namedtuple
from itertools import pairwise
from decimal import Decimal
import logging

statusLog = logging.getLogger(__name__)

# Constants used for indexing / calculations
NUM_MONTHS_YR = 12
NUM_MONTHS_HALF = 6
JAN = 0
JUN = 5
JUL = 6
DEC = 11

FLAG_STR = '_ATTRIBUTES'

skipValidCheckElem = ['DYFG','DYHF','DYTS']

# Mapping of date element to value element
dateElementPair = {'EMNT':'DYNT','EMSD':'DYSD','EMSN':'DYSN','EMXP':'DYXP','EMXT':'DYXT'}

windElementPair = {'WSF1':'WDF1','WSF2':'WDF2','WSF5':'WDF5','WSFG':'WDFG','WSFM':'WDFM'}

# Used to return calculated values to GlobalSummaryOfYear.py
OutputData = namedtuple('OutputData', ['value', 'flag'])
OutputDataWind = namedtuple('OutputDataWind', ['value', 'flag', 'directionElement', 'directionValue', 'directionFlag'])

# Used in getMin, getMax, functions
MinValues = namedtuple('MinValues', ['value', 'valueIndex', 'sameValueFound'])
MaxValues = namedtuple('MaxValues', ['value', 'valueIndex', 'sameValueFound', 'traceFound'])


def getFlag(flagSeries: pl.Series, flagPositions: list, flagIndex: int) -> str:
    if flagPositions[0] == -1: # case for blank flag
        return ""
    gsoyFlags = []
    finalFlag = ""
    try:
        flags = flagSeries[flagIndex].split(",")
        for i in range(0, len(flagPositions)):
            # Check to make sure index is valid and won't cause an exception
            if len(flags) > flagPositions[i]:
                gsoyFlags.append(flags[flagPositions[i]])
                # Just rurning one flag, no comma needed
                if len(flagPositions) == 1:
                    return gsoyFlags[i]
                else:
                    finalFlag += gsoyFlags[i]
                if len(flagPositions)-i > 1:   # Don't put comma on last flag
                    finalFlag += ','
            else:
                # Means we are missing a ',' in the flag. Bad data
                if len(flagPositions) == 1:
                    return finalFlag
                commaCount = finalFlag.count(',')
                if commaCount == (len(flagPositions) - 1):
                    return finalFlag
                else:
                    finalFlag += (((len(flagPositions)-1) - commaCount) * ',')
                    return finalFlag
    except(AttributeError):
        if len(flagPositions) == 1:
            statusLog.debug(f"Got Attribute exception with {finalFlag}")
            return finalFlag
        else:
            finalFlag += ((len(flagPositions)-1) * ',')
            statusLog.debug(f"Got Attribute exception with {finalFlag}")
            return finalFlag
    return finalFlag

def calcYearTotal(inputData: pl.DataFrame, element: str) -> Union[tuple[str, str], None]:
    """
    Calculates the total for the year.

    Parameters
    ----------
    inputData: pl.DataFrame
        Input data frame
    element: str
        Element to calculate the total for
    """
    total = None
    if element in skipValidCheckElem:
        if inputData[element].count() >= 1: # Need just 1 valid data point
            total = sum(map(Decimal, inputData[element].drop_nulls()))
    else:
        if not inputData[element].has_nulls(): # Need all 12 months of valid (not null) data
            if Elements[element].takeMean:
                total = sum(map(Decimal, inputData[element])) / Decimal('12')
            else:
                total = sum(map(Decimal, inputData[element]))
    if total is None: # exit if invalid data
        return None
    else:
        return OutputData(MathUtils.roundToStr(total, Elements[element].decimalPlaces),
                          getFlag(inputData[(element+FLAG_STR)],Elements[element].flagPositions, DEC))
    
def calcYearTotalWithTrace(inputData: pl.DataFrame, element: str):
    traceFound = False
    total = None
    if not inputData[element].has_nulls(): # Need all 12 months of valid (not null) data
        total = sum(map(Decimal, inputData[element]))
    if total is None: # exit if invalid data
        return None
    else:
        # if total == 0 & 'T' found, set trace
        if total == 0.0 and inputData[element+FLAG_STR].str.split_exact(',',1).struct[1].str.contains('T').any():
            traceFound = True
        prevFlag = getFlag(inputData[(element+FLAG_STR)],Elements[element].flagPositions, DEC)
        finalFlag = ''
        if traceFound:
            finalFlag += 'T'
        finalFlag += ',' + prevFlag
        return OutputData(MathUtils.roundToStr(total, Elements[element].decimalPlaces), finalFlag)


def calc_CLDD_HTDD(inputDF: pl.DataFrame, yrs: list, element: str, isNorthHem: bool, outputDict, headers: set):
    if (isNorthHem and element == 'CLDD') or (not isNorthHem and element == 'HTDD'):
        # CLDD Jan - Dec in North Hemisphere; HTDD Jan - Dec in South Hemisphere
        # Go through and get data for each yr
        for yr in yrs:
            yearDF = inputDF.filter(pl.col('DATE').dt.year() == yr)
            elementData = calcYearTotal(yearDF, element)
            if elementData is not None:
                outputDict.setdefault(str(yr),{})[element] = elementData.value
                outputDict.setdefault(str(yr),{})[element + '_ATTRIBUTES'] = elementData.flag
                headers.add(element)
                headers.add(element + '_ATTRIBUTES')

    else: # Need to calculate Jul - Dec of one year and Jan - Jun of next year
        # Will make a tuple of two yrs
        # ex. (1944, 1945), (1945, 1948) ...
        for yr in pairwise(yrs):
            if (yr[1] - yr[0] == 1): # We have connsecutative yrs
                yearsDF = inputDF.filter((pl.col('DATE').dt.year() == yr[0]) | (pl.col('DATE').dt.year() == yr[1]))
                # Need to calculate Jul - Jun
                if not yearsDF[element][JUL:18].has_nulls():
                    total = sum(map(Decimal,yearsDF[element][JUL:18]))
                    # Need to add total and flag to outputDict
                    outputDict.setdefault(str(yr[1]),{})[element] = MathUtils.roundToStr(total, Elements[element].decimalPlaces)
                    outputDict.setdefault(str(yr[1]),{})[element + '_ATTRIBUTES'] = getFlag(yearsDF[(element+FLAG_STR)],Elements[element].flagPositions, 17)
                    headers.add(element)
                    headers.add(element + '_ATTRIBUTES')

def calcSpecificMonth(inputData: pl.DataFrame, element: str, isNorthHem: bool) -> Union[tuple[str, str], None]:
    if isNorthHem:
        if element == 'CDSD':
            monthToGet = DEC
        else:
            monthToGet = JUN
    else:
        if element == 'CDSD':
            monthToGet = JUN
        else:
            monthToGet = DEC
    value = inputData[element][monthToGet]
    if value is None: # exit if invalid data
        return None
    return OutputData(MathUtils.roundToStr(value, Elements[element].decimalPlaces), getFlag(inputData[(element+FLAG_STR)],Elements[element].flagPositions, monthToGet))

def getMin(inputData: pl.DataFrame, element: str):
    sameValueFound = False
    if inputData[element].has_nulls():
        return None
    # Need to find min Value & index.
    # Reversing will find last occurance. Need to then find original index
    minIndex = (inputData[element].len()-1) - inputData[element].reverse().arg_min()
    minValue = inputData[element][minIndex]
    # Need to see if it occured more than once
    if ( (inputData[element] == minValue).sum() ) > 1: # Value occured more than once
        sameValueFound = True
    return MinValues(minValue, minIndex, sameValueFound)

def getMax(inputData: pl.DataFrame, element: str, findTrace: bool):
    sameValueFound = False
    traceFound = False
    if inputData[element].has_nulls():
        return None
    # Need to find max Value & index
    maxIndex = (inputData[element].len()-1) - inputData[element].reverse().arg_max()
    maxValue = inputData[element][maxIndex]
    if findTrace and maxValue == 0:
        # Need to see if Trace is present
        traceIndex = pl.arg_where(
            inputData[element+FLAG_STR].reverse().str.split_exact(',',1).struct[1].str.contains('T') == True,
            eager=True)
        if traceIndex.len() >= 1:  # Trace was found
            maxIndex = (inputData[element+FLAG_STR].len()-1) - traceIndex[0]
            traceFound = True
            # Need to see if value occurred more than once
            if traceIndex.len() > 1:
                sameValueFound = True
        else: # No trace found.
            if ( (inputData[element] == maxValue).sum() ) > 1: # Value occured more than once
                sameValueFound = True
    else:
        # Need to see if it occured more than once
        if ( (inputData[element] == maxValue).sum() ) > 1: # Value occured more than once
            sameValueFound = True
    return MaxValues(maxValue, maxIndex, sameValueFound, traceFound)

def calc_EM(inputData: pl.DataFrame, element: str) -> Union[tuple[str, str], None]:
    elementWithTrace = False
    if element == 'EMNT':
        elementData = getMin(inputData, element)
    elif element == 'EMXT':
        elementData = getMax(inputData, element, False)
    else:
        elementData = getMax(inputData, element, True)
        elementWithTrace = True
    if elementData is not None:
        prevFlag = getFlag(inputData[(element+FLAG_STR)],Elements[element].flagPositions, elementData.valueIndex)
        dateFlag = inputData[dateElementPair[element]][elementData.valueIndex][4:8]
        finalFlag = ''
        if elementWithTrace:
            if elementData.traceFound:
                finalFlag += 'T'
            finalFlag += ','
        finalFlag += (prevFlag + ',' + dateFlag + ',')
        if elementData.sameValueFound or ('+' in inputData[(element+FLAG_STR)][elementData.valueIndex]):
            finalFlag += '+'
        return OutputData(MathUtils.roundToStr(elementData.value, Elements[element].decimalPlaces), finalFlag)
    else:
        return None

def calc_MaxWind(inputData: pl.DataFrame, element: str):
    elementData = getMax(inputData, element, False)
    if elementData is not None:
        prevFlag = getFlag(inputData[(element+FLAG_STR)],Elements[element].flagPositions, elementData.valueIndex)
        return OutputDataWind(
            value=MathUtils.roundToStr(elementData.value, Elements[element].decimalPlaces),
            flag=prevFlag,
            directionElement=windElementPair[element],
            directionValue=inputData[windElementPair[element]][elementData.valueIndex],
            directionFlag=prevFlag)
    else:
        return None

def calc_MinMaxElements(inputData: pl.DataFrame, element: str):
    if element.startswith('HN') or element.startswith('HX'): # For HNxy, HXxy
        elementData = getMax(inputData, element, False)
    else: # For LNxy, LXxy
        elementData = getMin(inputData, element)
    if elementData is not None:
        return OutputData(MathUtils.roundToStr(elementData.value, Elements[element].decimalPlaces),
                          getFlag(inputData[(element+FLAG_STR)],Elements[element].flagPositions, elementData.valueIndex))