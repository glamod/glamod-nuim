#!/bin/sh

rm composite.subset

for i in `cut -c1-11 /home/mmenne/ghcnd/ghcnd-stations.txt`
do
  gawk 'substr($0,1,11)=="'$i'" {print $0}' ghcnd.composite >> composite.subset
done
