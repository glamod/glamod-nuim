PREFIX=$1

if [ -s ${PREFIX}download/australia ]
then
rm -r ${PREFIX}download/australia
fi

mkdir -p ${PREFIX}download/australia

yrmody=`date "+%Y%m%d"`
#yrmo=201007
yr=`date "+%Y"`

wget -o${PREFIX}download/get_australia.ftp.log -P${PREFIX}download/australia -N ftp://ftp.bom.gov.au/anon2/home/ncc/srds/Scheduled_Jobs/DS005_NOAA/DS005_BOM*_12months.zip

for i in `ls ${PREFIX}download/australia | grep "\.zip"`
do
unzip -l ${PREFIX}download/australia/$i > ${PREFIX}zipped-files.list
listsize="$(/usr/bin/du -b ${PREFIX}zipped-files.list | gawk '{print $1}')"
echo "Zipped file list size for $i: "${listsize}
#while [ ${listsize} == 0 ]
#do
#rm old version of zip file
#rm -f ${PREFIX}download/australia/$i
#get $i again, download seems incomplete
#wget -o${PREFIX}download/get_australia.ftp.log -P${PREFIX}download/australia -N ftp://ftp.bom.gov.au/anon2/home/ncc/srds/Scheduled_Jobs/DS005/$i
#done
done

numfiles=`ls ${PREFIX}download/australia | wc | cut -c1-7`

echo "Downloaded ${numfiles} files from BOM ftp site"

cp -p ${PREFIX}download/australia/DS005_BOMdailyrain_12months.zip ${PREFIX}australia/daily_update_archive/DS005_BOMdailyrain_12months_${yrmody}.zip
cp -p ${PREFIX}download/australia/DS005_BOMmmt_12months.zip ${PREFIX}australia/daily_update_archive/DS005_BOMmmt_12months_${yrmody}.zip

#${PREFIX}update-archive2.sh ${PREFIX}download/australia ${PREFIX}australia/update_archive '*.*'

