#!/bin/bash

# Usage statement output if required arguments are not given
display_usage(){
        echo This script requires two input parameters, the location of the input files and the location.
        echo of the output files.
        echo
        echo USAGE: ./usaf_process_dir.sh path/to/input path/to/output
}

# Check that two directory path arguments are supplied and display usage and exit if not.
if [  $# -lt 2 ]
  then
    display_usage
    exit 1
  else
    input_dir=$1
    output_dir=$2
#    version=$3
    echo Processing all tar files in directory $input_dir. Output will be written to $output_dir.
fi

# Get list of tar files in directory with desired pattern
for f in $input_dir/usaf-swo*s*_e*_c*.tar; do 

  echo Processing file: $f
  # Untar and uncompress files
  tar -xvf $f -C $input_dir
  for g in $input_dir/*.{gz,z,Z}; do
    gzip -d $g  
  done

  version="v000"
  if grep -q "\-03\_" <<< "$f"; then 
    version="v300" 
  elif grep -q "\-03\.01\_" <<< "$f"; then 
    version="v301"
  fi

  # Parse out start date, end date, and year from tar file name
  file_type=$(echo $f | awk -F '_' '{print $2}')
  start_date=$(echo $f | grep -Eo '_s[[:digit:]]{8}' | grep -Eo '[[:digit:]]{8}')
  end_date=$(echo $f | grep -Eo '_e[[:digit:]]{8}' | grep -Eo '[[:digit:]]{8}')
  create_date=$(echo $f | grep -Eo '_c[[:digit:]]{14}' | grep -Eo '[[:digit:]]{14}')
  process_year=${end_date:0:4}
  date_range="${start_date}_${end_date}"

  # Set environment variables for Java code
  export GEN3_LOGDIR=/data/ghcnh/usaf_to_isd/log/
  export GEN3_RUNDIR=$input_dir/
  export sort_tmp=$GEN3_RUNDIR/tmp
  export dateRange=$date_range

  # Create output year subdirectory and tmp directory if they don't already exist
  [[ -d $output_dir ]] ||  mkdir $output_dir
  [[ -d $GEN3_RUNDIR/tmp ]] ||  mkdir $GEN3_RUNDIR/tmp
  [[ -d $input_dir/done ]] || mkdir "$input_dir/done"
  # Call usaf_preprocess script
  ./usaf_preprocess.sh 

  # Call Java class and specify fully qualified output file path
  java UsafGen3ToIsd $output_dir/usaf_c${create_date}_s${start_date}_e${end_date}_${file_type}_${version}.isd

  # Remove invalid or unwanted records.
  sed -i '/_BAD_ID/d' $output_dir/usaf_c${create_date}_s${start_date}_e${end_date}_${file_type}_${version}.isd
  
  # Clean up all extracted and created files
  rm $input_dir/*.{csv,clean,metoc,metoc.out,gen3}  
  mv $f "$input_dir/done/"

done

echo Processing complete.

