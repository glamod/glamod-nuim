#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 28 11:17:55 2026

@author: sangethaedathil
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import glob
import pandas as pd
import re

INDIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/sangetha_new_data/Ukraine_converted/ClimUAsd-stn.v2/sef/UA-UHMI_ta"
STATION_MAP_FILE = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/sangetha_new_data/Ukraine_converted/ClimUAsd-stn.v2/stations.csv"
OUTDIR = os.path.join(INDIR, "IFF_output_redone")

os.makedirs(OUTDIR, exist_ok=True)

for old in glob.glob(os.path.join(OUTDIR, "*.psv")):
    os.remove(old)

LOG_FILE = os.path.join(OUTDIR, "failed_files.log")
with open(LOG_FILE, "w", encoding="utf-8") as f:
    f.write("Failed files during conversion:\n")


def clean_text(x):
    if pd.isna(x):
        return ""
    return str(x).strip()


def parse_decimal(x):
    if pd.isna(x):
        return pd.NA
    return pd.to_numeric(str(x).replace(",", "."), errors="coerce")


def extract_orig_raw(meta_value):
    if pd.isna(meta_value):
        return ""
    text = str(meta_value).strip()
    m = re.search(r"orig=([^|]+)", text, flags=re.I)
    if m:
        return m.group(1).strip()
    return text


def extract_orig_number(meta_value):
    text = extract_orig_raw(meta_value)
    if text == "":
        return ""

    text = text.replace(",", ".")
    text = re.sub(r"[^0-9.\-]", "", text)
    text = re.sub(r"\.+", ".", text)
    text = text.rstrip(".")

    if text in ["", ".", "-", "-."]:
        return ""

    return text


def detect_temperature_unit(raw_value):
    """
    Detect temperature unit from original SEF Meta value.
    Examples:
    -9R  -> °R
    -9C  -> °C
    -9°C -> °C
    """
    if pd.isna(raw_value):
        return ""

    text = str(raw_value).strip()

    if re.search(r"°\s*c\b", text, flags=re.I):
        return "°C"

    if re.search(r"\d\s*c\b", text, flags=re.I) or re.search(r"-\d+(?:\.\d+)?c\b", text, flags=re.I):
        return "°C"

    if re.search(r"\d\s*r\b", text, flags=re.I) or re.search(r"-\d+(?:\.\d+)?r\b", text, flags=re.I):
        return "°R"

    return ""


def read_sef_header(filepath):
    header = pd.read_csv(filepath, sep="\t", nrows=12, header=None)
    header = header.iloc[:, 0:2]
    header.columns = ["SEF", "Value"]
    return dict(zip(header["SEF"], header["Value"]))


def normalize_name(s):
    s = clean_text(s).lower()
    s = s.replace("_", " ").replace("-", " ").replace(",", " ").replace(".", " ")
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r"[^\w\s]", "", s)
    return s.strip()


def filename_station_guess(filename):
    base = os.path.basename(filename)
    base = re.sub(r"\.tsv$", "", base, flags=re.I)
    base = re.sub(r"^UA-UHMI[_-]", "", base)
    base = re.sub(r"_ta$", "", base)
    base = re.sub(r"_[0-9]{8}-[0-9]{8}$", "", base)
    return normalize_name(base)


def find_station_columns(df):
    cols = {c.lower(): c for c in df.columns}

    name_col = None
    code_col = None

    for c in ["station_name", "name", "station", "station id", "station_id"]:
        if c in cols:
            name_col = cols[c]
            break

    for c in ["station_id_new", "station_code", "code", "new_code", "id_new"]:
        if c in cols:
            code_col = cols[c]
            break

    return name_col, code_col


def build_station_maps(stations_df, name_col, code_col):
    exact_map = {}
    compact_map = {}

    for _, row in stations_df.iterrows():
        raw_name = clean_text(row[name_col])
        raw_code = clean_text(row[code_col])

        if not raw_name or not raw_code:
            continue

        n1 = normalize_name(raw_name)
        n2 = n1.replace(" ", "")

        exact_map[n1] = raw_code
        compact_map[n2] = raw_code

    return exact_map, compact_map


def find_station_code(station_name, filename_guess, exact_map, compact_map):
    candidates = []

    if station_name:
        n = normalize_name(station_name)
        candidates.append(n)
        candidates.append(n.replace(" ", ""))

    if filename_guess:
        candidates.append(filename_guess)
        candidates.append(filename_guess.replace(" ", ""))

    for cand in candidates:
        if cand in exact_map:
            return exact_map[cand]
        if cand in compact_map:
            return compact_map[cand]

    for cand in candidates:
        if not cand:
            continue

        cand_compact = cand.replace(" ", "")

        for key, code in exact_map.items():
            if cand in key or key in cand:
                return code

        for key, code in compact_map.items():
            if cand_compact in key or key in cand_compact:
                return code

    return None


stations = pd.read_csv(STATION_MAP_FILE)

name_col, code_col = find_station_columns(stations)

if name_col is None or code_col is None:
    raise ValueError(f"Could not detect station columns: {list(stations.columns)}")

stations[name_col] = stations[name_col].astype(str).str.strip()
stations[code_col] = stations[code_col].astype(str).str.strip()

exact_map, compact_map = build_station_maps(stations, name_col, code_col)

all_filenames = sorted(glob.glob(os.path.join(INDIR, "*.tsv")))

print(f"Loaded {len(exact_map)} station mappings")
print(f"Found {len(all_filenames)} TSV files")

frames = []

for filepath in all_filenames:
    filename = os.path.basename(filepath)

    try:
        meta = read_sef_header(filepath)

        station_name = clean_text(meta.get("Name", ""))
        station_guess = filename_station_guess(filename)

        mapped_code = find_station_code(
            station_name,
            station_guess,
            exact_map,
            compact_map
        )

        if not mapped_code:
            raise ValueError(f"No station-code mapping for {station_name} | {station_guess}")

        code_number = mapped_code.split("-")[-1]

        source_id = "416"
        station_id_new = f"416-{code_number}"

        lat = parse_decimal(meta.get("Lat", ""))
        lon = parse_decimal(meta.get("Lon", ""))
        elev = parse_decimal(meta.get("Alt", ""))

        df = pd.read_csv(filepath, sep="\t", skiprows=12)

        if "Value" not in df.columns:
            raise ValueError("Missing Value column")

        df["Observed_value"] = pd.to_numeric(df["Value"], errors="coerce")

        if "Meta" in df.columns:
            df["raw_original"] = df["Meta"].apply(extract_orig_raw)
            df["Original_observed_value"] = df["Meta"].apply(extract_orig_number)
            df["Original_observed_value_units"] = df["raw_original"].apply(detect_temperature_unit)

            non_empty_units = df["Original_observed_value_units"]
            non_empty_units = non_empty_units[non_empty_units.astype(str).str.strip() != ""]

            if len(non_empty_units) > 0:
                file_unit = non_empty_units.mode().iloc[0]
                df.loc[
                    df["Original_observed_value_units"].astype(str).str.strip() == "",
                    "Original_observed_value_units"
                ] = file_unit
        else:
            df["Original_observed_value"] = ""
            df["Original_observed_value_units"] = ""

        df["Source_ID"] = source_id
        df["Station_ID"] = station_id_new
        df["Station_name"] = station_name
        df["Alias_station_name"] = ""
        df["Latitude"] = lat
        df["Longitude"] = lon
        df["Elevation"] = elev
        df["Source_QC_flag"] = ""
        df["Report_type_code"] = ""
        df["Measurement_code_1"] = ""
        df["Measurement_code_2"] = ""

        for col in ["Year", "Month", "Day", "Hour"]:
            if col not in df.columns:
                raise ValueError(f"Missing required time column: {col}")
            df[col] = pd.to_numeric(df[col], errors="coerce")

        if "Minute" in df.columns:
            df["Minute"] = pd.to_numeric(df["Minute"], errors="coerce")
        else:
            df["Minute"] = 0

        df["Minute"] = df["Minute"].fillna(0)

        df = df.replace(r"\|", " ", regex=True)
        df = df.dropna(subset=["Observed_value", "Year", "Month", "Day", "Hour"])

        df["Latitude"] = pd.to_numeric(df["Latitude"], errors="coerce").round(3)
        df["Longitude"] = pd.to_numeric(df["Longitude"], errors="coerce").round(3)
        df["Elevation"] = pd.to_numeric(df["Elevation"], errors="coerce")
        df["Observed_value"] = pd.to_numeric(df["Observed_value"], errors="coerce").round(1)

        df = df[
            [
                "Source_ID",
                "Station_ID",
                "Station_name",
                "Alias_station_name",
                "Year",
                "Month",
                "Day",
                "Hour",
                "Minute",
                "Latitude",
                "Longitude",
                "Elevation",
                "Observed_value",
                "Source_QC_flag",
                "Original_observed_value",
                "Original_observed_value_units",
                "Report_type_code",
                "Measurement_code_1",
                "Measurement_code_2",
            ]
        ]

        df = df.fillna("")
        frames.append(df)

    except Exception as e:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{filename} | {e}\n")
        print(f"Failed: {filename} | {e}")


if not frames:
    print("No valid files processed.")
else:
    combined = pd.concat(frames, ignore_index=True)

    combined["Timestamp"] = pd.to_datetime(
        dict(
            year=pd.to_numeric(combined["Year"], errors="coerce"),
            month=pd.to_numeric(combined["Month"], errors="coerce"),
            day=pd.to_numeric(combined["Day"], errors="coerce"),
            hour=pd.to_numeric(combined["Hour"], errors="coerce"),
            minute=pd.to_numeric(combined["Minute"], errors="coerce"),
        ),
        errors="coerce",
    )

    combined = combined.dropna(subset=["Timestamp"])
    combined = combined.sort_values(["Station_ID", "Timestamp"]).reset_index(drop=True)

    combined["Year"] = combined["Timestamp"].dt.year.astype(int)
    combined["Month"] = combined["Timestamp"].dt.month.astype(int)
    combined["Day"] = combined["Timestamp"].dt.day.astype(int)
    combined["Hour"] = combined["Timestamp"].dt.hour.astype(int)
    combined["Minute"] = combined["Timestamp"].dt.minute.astype(int)

    combined = combined.drop(columns=["Timestamp"])
    combined = combined.fillna("")

    for station_id, group in combined.groupby("Station_ID"):
        outname = f"{station_id}_temperature_416.psv"
        outpath = os.path.join(OUTDIR, outname)
        group.to_csv(outpath, index=False, sep="|")
        print(f"Saved: {outpath}")

    print(f"\nFinished. Check log here: {LOG_FILE}")