# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 12:17:19 2023

@author: snoone
"""

import os 
import glob
import pandas as pd
import csv

OUTDIR = "C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/IFF/cld/out"
os.chdir("C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/completed_forms/all_A/")

extension = 'xlsx'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

 
for filename in all_filenames:
    try:
   
                # Extract year and month from the filename
        base_name = os.path.basename(filename)  # Get the file name without the path
        file_parts = base_name.split('_')  # Split the filename by underscores
        year = file_parts[0]  # First part is the year
        month = file_parts[1]  # Second part is the month

# Read the first 37 rows, skipping the first 5 rows, with no headers initially
        df = pd.read_excel(filename, skiprows=5, header=None, nrows=31,usecols=range(46))
        df.columns = ["Day","slp_7","temp_7","dbt_7","wtb_7","wd_7","wf_7","cf_7","ca_7","we_7","rain_7",
                      "na1","slp_14","temp_14","dbt_14","wtb_14","wd_14","wf_14","cf_14","ca_14","we_14",
                      "na2","slp_21","temp_21","dbt_21","wtb_21","wd_21","wf_21","cf_21","ca_21","we_21",
                      "tmax_21","tmin_21","sun_21","na3","earth_t1m_7","earth_t4m_7","na4","wmile_7","wmile_14",
                      "wmile_21","na5","tr_radiation_them_7","solar_rad_12","solar_rad_bright","1"]
    
        # Drop unnecessary columns
        df = df.drop(columns=["1", "na1", "na2", "na3", "na4", "na5"])
        
                # Add the Year and Month columns to the DataFrame
        df['Year'] = year
        df['Month'] = month
    
        # Add the Year and Month columns to the DataFrame
        df["Source_ID"] = "405"
        df["Station_ID"]="405-00001"
        df["Station_name"]="ENTEBBE"
        df["Alias_station_name"]=""
        df["Latitude"]="0.067"
        df["Longitude"]="32.45"
        df["Elevation"]="1153"
        df["Source_QC_flag"]=""
        df["Original_observed_value"]=""
        df['Original_observed_value_units']="octas"
        df['Report_type_code']=''
        df['Measurement_code_1']=''
        df['Measurement_code_2']='' 
        df["Minute"]="00" 
        
        

    
 
   
        df_a=df
        df_a["Hour"]="07" 
        df_a= df_a.rename(columns=({"ca_7":'Observed_value'}))

        df_a["Original_observed_value"]=df_a["Observed_value"]
        df_a = df_a[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1","Measurement_code_2"]]

    


        df_b=df
        df_b["Hour"]="14" 
        df_b= df_b.rename(columns=({"ca_14":'Observed_value'}))

        df_b["Original_observed_value"]=df_b["Observed_value"]
        df_b = df_b[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]
    
 
  
        df_c=df
        df_c["Hour"]="21" 
        df_c= df_c.rename(columns=({"ca_21":'Observed_value'}))
        df_c["Original_observed_value"]=df_c["Observed_value"]
        df_c = df_c[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]

    
       
        merged=pd.concat([df_a,df_b,df_c], axis=0)
        merged=merged.dropna(subset = ['Observed_value'])
        merged['Observed_value'] = merged['Observed_value'].round(1)



  

    #change time zones
        merged["Timestamp2"] = merged["Year"].map(str) + "-" + merged["Month"].map(str) + "-" + merged["Day"].map(str)
        merged["Timestamp"] = merged["Timestamp2"].map(str) + " " + merged["Hour"].map(str) + ":" + merged["Minute"].map(str)
        merged = merged.drop(columns=["Timestamp2"])
        
        # Handle mixed date formats by letting pandas infer the format
        merged['Timestamp'] = pd.to_datetime(merged['Timestamp'], errors='coerce')
        
        # Localize and convert to GMT
        merged['Timestamp'] = merged['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')
        
        # Sort by Timestamp
        merged = merged.sort_values(by='Timestamp')
        
        # Extract year, month, day, hour, minute, second
        merged['Year'] = merged['Timestamp'].dt.year
        merged['Month'] = merged['Timestamp'].dt.month
        merged['Day'] = merged['Timestamp'].dt.day
        merged['Hour'] = merged['Timestamp'].dt.hour
        merged['Minute'] = merged['Timestamp'].dt.minute
        merged['Seconds'] = merged['Timestamp'].dt.second
        
        # Drop the original Timestamp column
        merged = merged.drop(columns="Timestamp")
        # Drop the original Timestamp column
        merged = merged.drop(columns="Seconds")
        

        
    
        # Save output file
        year = str(merged.iloc[1]["Year"])  # Ensure year is a string
        month = str(merged.iloc[1]["Month"]).zfill(2)  # Ensure month is zero-padded and a string
        date = f"{year}_{month}"  # Format date as "YYYY_MM"
        source_id = str(merged.iloc[1]["Source_ID"])  # Ensure source ID is a string
        cdm_type = f"{date}_cloud_amount_{source_id}"  # Construct file type string
        
        # Ensure output directory exists
        os.makedirs(OUTDIR, exist_ok=True)
        
        # Construct output file name
        outname = os.path.join(OUTDIR, cdm_type)
        
        # Save to CSV with pipe separator
        merged.to_csv(outname + ".psv", index=False, sep="|")
    except:
        continue


    
    
    
