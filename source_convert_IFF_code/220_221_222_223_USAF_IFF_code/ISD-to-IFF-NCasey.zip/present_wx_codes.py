'''
ISD Format Doc

AU1 – AU9 An indicator of up to 9 repeating fields of the following items:

PRESENT-WEATHER-OBSERVATION intensity and proximity code
DOM: A specific domain comprised of the characters in the ASCII character set.
0 = Not Reported
1 = Light (-)
2 = Moderate or Not Reported (no entry in original observation)
3 = Heavy (+)
4 = Vicinity (VC)
9 = Missing

PRESENT-WEATHER-OBSERVATION descriptor code
DOM: A specific domain comprised of the characters in the ASCII character set.
0 = No Descriptor
1 = Shallow (MI)
2 = Partial (PR)
3 = Patches (BC)
4 = Low Drifting (DR)
5 = Blowing (BL)
6 = Shower(s) (SH)
7 = Thunderstorm (TS)
8 = Freezing (FZ)
9 = Missing

PRESENT-WEATHER-OBSERVATION precipitation code
DOM: A specific domain comprised of the characters in the ASCII character set.
00 = No Precipitation
01 = Drizzle (DZ)
02 = Rain (RA)
03 = Snow (SN)
04 = Snow Grains (SG)
05 = Ice Crystals (IC)
06 = Ice Pellets (PL)
07 = Hail (GR)
08 = Small Hail and/or Snow Pellets (GS)
09 = Unknown Precipitation (UP)
99 = Missing

PRESENT-WEATHER-OBSERVATION obscuration code
DOM: A specific domain comprised of the characters in the ASCII character set.
0 = No Obscuration
1 = Mist (BR)
2 = Fog (FG)
3 = Smoke (FU)
4 = Volcanic Ash (VA)
5 = Widespread Dust (DU)
6 = Sand (SA)
7 = Haze (HZ)
8 = Spray (PY)
9 = Missing

PRESENT-WEATHER-OBSERVATION other weather phenomena code
DOM: A specific domain comprised of the characters in the ASCII character set.
0 = None Reported
1 = Well-Developed Dust/Sand Whirls (PO)
2 = Squalls (SQ)
3 = Funnel Cloud, Tornado, Waterspout (FC)
4 = Sandstorm (SS)
5 = Duststorm (DS)
9 = Missing

### not used in LCD
PRESENT-WEATHER-OBSERVATION combination indicator code
DOM: A specific domain comprised of the characters in the ASCII character set.
1 = Not part of combined weather elements
2 = Beginning element of combined weather elements
3 = Combined with previous weather element to form a single weather report
9 = Missing

PRESENT-WEATHER-OBSERVATION quality code
The code that denotes a quality status of the reported PRESENT-WEATHER-OBSERVATION.
DOM: A specific domain comprised of the characters in the ASCII character set.
0 = Passed gross limits
1 = Passed all quality control checks
2 = Suspect
3 = Erroneous
4 = Passed gross limits check, data originate from an NCEI data source
5 = Passed all quality control checks, data originate from an NCEI data source
6 = Suspect, data originate from an NCEI data source
7 = Erroneous, data originate from an NCEI data source
M = Manual change made to value based on information provided by NWS or FAA
9 = Passed gross limits check if element is present
'''

AU_intensity_dict = {
'0':None,                                              #added (not reported)
'1':'-',      #-=-light',
'2':None,                                               #moderate or none -- marked as none b/c it's not used in LCD
'3':'+',      #"+=heavy"',
'4':'VC',     #VC-=-vicinity-(apparent-but-not-at-point-of-observation)'
'9':None }                                            #added (missing)
#The codes above could precede descriptors below

AU_desc_dict= {
'0':None,                                              #added (no descriptor)
'1':'MI',      #MI-=-shallow',
'2':'PR',      #PR-=-partial',
'3':'BC',      #BC-=-patches',
'4':'DR',      #DR-=-low-drifting',
'5':'BL',      #BL-=-blowing',
'6':'SH',      #SH-=-showers',
'7':'TS',      #TS-=-thunderstorm',
'8':'FZ',      #FZ-=-freezing'
'9':None }                                            #added (missing)
#The codes above could precede descriptors below

AU_precip_dict = {
'00':None,                                              #added (No precip)
'01':'DZ:01',      #DZ:01-Drizzle',
'02':'RA:02',      #RA:02-Rain',
'03':'SN:03',      #SN:03-Snow',
'04':'SG:04',      #SG:04-Snow-Grains',
'05':'IC:05',      #IC:05-Ice-Crystals',
'06':'PL:06',      #PL:06-Ice-Pellets',
'07':'GR:07',      #GR:07-Hail',
'08':'GS:08',      #GS:08-Small-Hail-an/or-Snow-Pellets',
'09':'UP:09',      #UP:09-Unknown-Precipitation'
'99':None }                                            #added (missing)

AU_obsc_dict ={
'0':None,                                              #added(no obscuration)
'1':'BR:1',      #BR:1-Mist',
'2':'FG:2',      #FG:2-Fog',
'3':'FU:3',      #FU:3-Smoke',
'4':'VA:4',      #VA:4-Volcanic-Ash',
'5':'DU:5',      #DU:5-Widespread-Dust',
'6':'SA:6',      #SA:6-Sand',
'7':'HZ:7',      #HZ:7-Haze',
'8':'PY:8',      #PY:8-Spray',
'9':None }                                            #added (missing) 

AU_other_dict = {
'0':None,                                              #added (none reported)
'1':'PO:1',      #PO:1-Well-developed-dust/sand-whirls',
'2':'SQ:2',      #SQ:2-Squalls',
'3':'FC:3',      #FC:3-Funnel-CLoud,-Waterspout-or-Tornado',
'4':'SS:4',      #SS:4-Sandstorm',
'5':'DS:5',      #DS:5-Duststorm'
'9':None }                                            #added (missing)

'''
LCD Documentation: Present Weather Appendix

AU codes
If AU codes are present they are listed first for weather type. 
AU codes are acquired from automated weather sensors. 
Codes for precipitation and obscurations are defined below:
'''
AU_mcode_dict = {
'DZ:01':'DZ:01-Drizzle',
'RA:02':'RA:02-Rain',
'SN:03':'SN:03-Snow',
'SG:04':'SG:04-Snow-Grains',
'IC:05':'IC:05-Ice-Crystals',
'PL:06':'PL:06-Ice-Pellets',
'GR:07':'GR:07-Hail',
'GS:08':'GS:08-Small-Hail-an/or-Snow-Pellets',
'UP:09':'UP:09-Unknown-Precipitation',
'BR:1':'BR:1-Mist',
'FG:2':'FG:2-Fog',
'FU:3':'FU:3-Smoke',
'VA:4':'VA:4-Volcanic-Ash',
'DU:5':'DU:5-Widespread-Dust',
'SA:6':'SA:6-Sand',
'HZ:7':'HZ:7-Haze',
'PY:8':'PY:8-Spray',
'PO:1':'PO:1-Well-developed-dust/sand-whirls',
'SQ:2':'SQ:2-Squalls',
'FC:3':'FC:3-Funnel-CLoud,-Waterspout-or-Tornado',
'SS:4':'SS:4-Sandstorm',
'DS:5':'DS:5-Duststorm',
'-':'-=-light',
'+':'"+=heavy"',
'VC':'VC-=-vicinity-(apparent-but-not-at-point-of-observation)',
'MI':'MI-=-shallow',
'PR':'PR-=-partial',
'BC':'BC-=-patches',
'DR':'DR-=-low-drifting',
'BL':'BL-=-blowing',
'SH':'SH-=-showers',
'TS':'TS-=-thunderstorm',
'FZ':'FZ-=-freezing',
None:'None'}
#The codes above ("light" through "freezing") could precede descriptors above

#################################################################################################
'''
AW codes
Depending on equipment used at the location, some automated stations report AW codes either with or instead of AU codes.
AW codes appear after AU codes (separated by a '|") when present. AW codes are defined as follows:
'''
#ISD doc: Codes-20-26-are-used-to-report-precip,-fog,-thunderstorm-at-the-stn-during-the-preceding-hr,-but-not-at-the-time-of-obs.)
#Nancy put in ISD keys when noted (27-29 were incorrect in LCD doc apparently)
#https://drive.google.com/file/d/16vMd0d7LBsnlWDT8VOvGvmNjCCUzgbQu/view?usp=sharing
AW_LCD_ISD_combined_dict={
'00':'00-No-significant-weather-observed',   #ISD added by nancy
'01':'01-Clouds-generally-dissolving-or-becoming-less-developed',               #ISD added by nancy
'02':'02-State-of-sky-on-the-whole-unchanged-during-the-past-hr',               #ISD added by nancy,
'03':'03-Clouds-generally-forming-or-developing-during-the-past-hr',               #ISD added by nancy,
'HZ:04':'HZ:04-Haze,-smoke,-or-dust-in-suspension-in-the-air,-visibility-equal-to-or-greater-than-1km',
'FU:05':'FU:05-Smoke',
'DU:07':'DU:07-Dust-or-sand-raised-by-wind-at-or-near-the-station-at-the-time-of-observation,-but-no-well‑developed-dust-whirl(s)-or-sand-whirl(s),-and-no-duststorm-or-sandstorm-seen-or,-in-the-case-of-ships,-blowing-spray-at-the-station',
'BR:10':'BR:10-Mist',
'11':'11-Diamond-dust',
'12':'12-Distant-lightning',
'SQ:18':'SQ:18-Squalls',
'20':'20-Fog-(during-preceding-hour-but-not-at-time-of-observation)',
'21':'21-Precipitation-(during-preceding-hour-but-not-at-time-of-observation)',
'22':'22-Drizzle-(not-freezing)-or-snow-grains-(during-preceding-hour-but-not-at-time-of-observation)',
'23':'23-Rain-(not-freezing)-(during-preceding-hour-but-not-at-time-of-observation)',
'24':'24-Snow-(during-preceding-hour-but-not-at-time-of-observation)',
'25':'25-Freezing-drizzle-or-freezing-rain-(during-preceding-hour-but-not-at-time-of-observation)',
'26':'26-Thunderstorm-(with-or-without-precipitation)-(during-preceding-hour-but-not-at-time-of-observation)(during-preceding-hour-but-not-at-time-of-observation)',
'27':'27-Blowing-or-drifting-snow-or-sand',               #ISD added by nancy - seemed to be incorrect in LCD doc,
'28':'28-Blowing-or-drifting-snow-or-sand,-visibility-equal-to-or-greater-than-1-km',               #ISD added by nancy - seemed to be incorrect in LCD doc,,
'29':'29-Blowing-or-drifting-snow-or-sand,-visibility-less-than-1-km',               #ISD added by nancy - seemed to be incorrect in LCD doc,
'FG:30':'FG:30-Fog',
'FG:31':'FG:31-Fog-or-ice-fog-in-patches',
'FG:32':'FG:32-Fog-or-ice-fog,-has-become-thinner-during-the-past-hour',
'FG:33':'FG:33-Fog-or-ice-fog,-no-appreciable-change-during-the-past-hour',
'FG:34':'FG:34-Fog-or-ice-fog,-has-begun-or-become-thicker-during-the-past-hour',
'FG:35':'FG:35-Fog,-depositing-rime',
'40':'40-Precipitation',
'41':'41-Precipitation,-slight-or-moderate',
'42':'42-Precipitation,-heavy',
'43':'43-Liquid-precipitation,-slight-or-moderate',
'44':'44-Liquid-precipitation,-heavy',
'45':'45-Solid-precipitation,-slight-or-moderate',
'46':'46-Solid-precipitation,-heavy',
'47':'47-Freezing-precipitation,-slight-or-moderate',
'48':'48-Freezing-precipitation,-heavy',
'DZ:50':'DZ:50-Drizzle',
'DZ:51':'DZ:51-Drizzle,-not-freezing,-slight',
'DZ:52':'DZ:52-Drizzle,-not-freezing,-moderate',
'DZ:53':'DZ:53-Drizzle,-not-freezing,-heavy',
'FZDZ:54':'FZDZ:54-Drizzle,-freezing,-slight',
'FZDZ:55':'FZDZ:55-Drizzle,-freezing,-moderate',
'FZDZ:56':'FZDZ:56-Drizzle,-freezing,-heavy',
'DZ:57':'DZ:57-Drizzle-and-rain,-slight',
'DZ:58':'DZ:58-Drizzle-and-rain,-moderate-or-heavy',
'RA:60':'RA:60-Rain',
'RA:61':'RA:61-Rain,-not-freezing,-slight',
'RA:62':'RA:62-Rain,-not-freezing,-moderate',
'RA:63':'RA:63-Rain,-not-freezing,-heavy',
'FZRA:64':'FZRA:64-Rain,-freezing,-slight',
'FZRA:65':'FZRA:65-Rain,-freezing,-moderate',
'FZRA:66':'FZRA:66-Rain,-freezing,-heavy',
'RA:67':'RA:67-Rain-or-drizzle-and-snow,-slight',
'RA:68':'RA:68-Rain-or-drizzle-and-snow,-moderate-or-heavy',
'SN:70':'SN:70-Snow',
'SN:71':'SN:71-Snow,-slight',
'SN:72':'SN:72-Snow,-moderate',
'SN:73':'SN:73-Snow,-heavy',
'PL:74':'PL:74-Ice-pellets,-slight',
'PL:75':'PL:75-Ice-pellets,-moderate',
'PL:76':'PL:76-Ice-pellets,-heavy',
'SG:77':'SG:77-Snow-grains',
'IC:78':'IC:78-Ice-crystals',
'80':'80-Showers-or-intermittent-precipitation',
'SHRA:81':'SHRA:81-Rain-showers-or-intermittent-rain,-slight',
'SHRA:82':'SHRA:82-Rain-showers-or-intermittent-rain,-moderate',
'SHRA:83':'SHRA:83-Rain-showers-or-intermittent-rain,-heavy',
'SHRA:84':'SHRA:84-Rain-showers-or-intermittent-rain,-violent',
'SHSN:85':'SHSN:85-Snow-showers-or-intermittent-snow,-slight',
'SHSN:86':'SHSN:86-Snow-showers-or-intermittent-snow,-moderate',
'SHSN:87':'SHSN:87-Snow-showers-or-intermittent-snow,-heavy',
'HAIL:89':'HAIL:89-Hail',
'TS:90':'TS:90-Thunderstorm',
'TS:91':'TS:91-Thunderstorm,-slight-or-moderate,-with-no-precipitation',
'TS:92':'TS:92-Thunderstorm,-slight-or-moderate,-with-rain-showers-and/or-snow-showers',
'TS-HAIL:93':'TS-HAIL:93-Thunderstorm,-slight-or-moderate,-with-hail',  #nancy switched from 'TS HAIL' to avoid space
'TS:94':'TS:94-Thunderstorm,-heavy,-with-no-precipitation',
'TS:95':'TS:95-Thunderstorm,-heavy,-with-rain-showers-and/or-snow',
'TS+HAIL:96':'TS+HAIL:96-Thunderstorm,-heavy,-with-hail',
'+FC:99':'+FC:99-Tornado'
}

'''
#Codes-20-26-are-used-to-report-precip,-fog,-thunderstorm-at-the-stn-during-the-preceding-hr,-but-not-at-the-time-of-obs.)
AW_ISD_dict={
'00':'00-No-significant-weather-observed',
'01':'01-Clouds-generally-dissolving-or-becoming-less-developed',
'02':'02-State-of-sky-on-the-whole-unchanged-during-the-past-hr',
'03':'03-Clouds-generally-forming-or-developing-during-the-past-hr',
'04':'04-Haze,-smoke,-or-dust-in-suspension-in-the-air,-visibility-equal-to-or-greater-than-1km',
'05':'05-Smoke',
'07':'07-Dust-or-sand-raised-by-wind-at-or-near-the-stn-at-the-time-of-obs,-but-no-well-developed-dust-whirls(s)-or-sand-whirl(s),-and-no-duststorm-or-sandstorm-seen-or,-in-the-case-of-ships,-blowing-spray-at-the-stn',
'10':'10-Mist',
'11':'11-Diamond-dust',
'12':'12-Distant-lightning',
'18':'18-Squalls',
'20':'20-Fog',                                                   #see note above
'21':'21-Precip',                                                #see note above
'22':'22-Drizzle-(not-freezing)-or-snow-grains',     #see note above
'23':'23-Rain-(not-freezing)',                               #see note above
'24':'24-Snow',                                                  #see note above
'25':'25-Freezing-drizzle-or-freezing-rain',            #see note above
'26':'26-Thunderstorm-(with-or-without-precip)',   #see note above
'27':'27-Blowing-or-drifting-snow-or-sand',
'28':'28-Blowing-or-drifting-snow-or-sand,-visibility-equal-to-or-greater-than-1-km',
'29':'29-Blowing-or-drifting-snow-or-sand,-visibility-less-than-1-km',
'30':'30-Fog',
'31':'31-Fog-or-ice-fog-in-patches',
'32':'32-Fog-or-ice-fog,-has-become-thinner-during-the-past-hr',
'33':'33-Fog-or-ice-fog,-no-appreciable-change-during-the-past-hr',
'34':'34-Fog-or-ice-fog,-has-begun-or-become-thicker-during-the-past-hr',
'35':'35-Fog,-depositing-rime',
'40':'40-Precip',
'41':'41-Precip,-slight-or-moderate',
'42':'42-Precip,-heavy',
'43':'43-Liquid-precip,-slight-or-moderate',
'44':'44-Liquid-precip,-heavy',
'45':'45-Solid-precip,-slight-or-moderate',
'46':'46-Solid-precip,-heavy',
'47':'47-Freezing-precip,-slight-or-moderate',
'48':'48-Freezing-precip,-heavy',
'50':'50-Drizzle',
'51':'51-Drizzle,-not-freezing,-slight',
'52':'52-Drizzle,-not-freezing,-moderate',
'53':'53-Drizzle,-not-freezing,-heavy',
'54':'54-Drizzle,-freezing,-slight',
'55':'55-Drizzle,-freezing,-moderate',
'56':'56-Drizzle,-freezing,-heavy',
'57':'57-Drizzle-and-rain,-slight',
'58':'58-Drizzle-and-rain,-moderate-or-heavy',
'60':'60-Rain',
'61':'61-Rain,-not-freezing,-slight',
'62':'62-Rain,-not-freezing,-moderate',
'63':'63-Rain,-not-freezing,-heavy',
'64':'64-Rain,-freezing,-slight',
'65':'65-Rain,-freezing,-moderate',
'66':'66-Rain,-freezing,-heavy',
'67':'67-Rain-or-drizzle-and-snow,-slight',
'68':'68-Rain-or-drizzle-and-snow,-moderate-or-heavy',
'70':'70-Snow',
'71':'71-Snow,-slight',
'72':'72-Snow,-moderate',
'73':'73-Snow,-heavy',
'74':'74-Ice-pellets,-slight',
'75':'75-Ice-pellets,-moderate',
'76':'76-Ice-pellets,-heavy',
'77':'77-Snow-grains',
'78':'78-Ice-crystals',
'80':'80-Showers-or-intermittent-precip',
'81':'81-Rain-showers-or-intermittent-rain,-slight',
'82':'82-Rain-showers-or-intermittent-rain,-moderate',
'83':'83-Rain-showers-or-intermittent-rain,-heavy',
'84':'84-Rain-showers-or-intermittent-rain,-violent',
'85':'85-Snow-showers-or-intermittent-snow,-slight',
'86':'86-Snow-showers-or-intermittent-snow,-moderate',
'87':'87-Snow-showers-or-intermittent-snow,-heavy',
'89':'89-Hail',
'90':'90-Thunderstorm',
'91':'91-Thunderstorm,-slight-or-moderate,-with-no-precip',
'92':'92-Thunderstorm,-slight-or-moderate,-with-rain-showers-and/or-snow-showers',
'93':'93-Thunderstorm,-slight-or-moderate,-with-hail',
'94':'94-Thunderstorm,-heavy,-with-no-precip',
'95':'95-Thunderstorm,-heavy,-with-rain-showers-and/or-snow',
'96':'96-Thunderstorm,-heavy,-with-hail',
'99':'99-Tornado'}
'''

#TODO: Nancy: hand edited all of this--made 1 minor change (below) -- need to check
#Codes-20-26-are-used-to-report-precip,-fog,-thunderstorm-at-the-stn-during-the-preceding-hr,-but-not-at-the-time-of-obs.)
AW_LCD_dict={       #from LcdPdfProcessorSupport.java ; the indented ones were added by nancy
#all but top 4 (00-043) are in LCD doc but not LCD code
            '00':'00',
            '01':'01',
            '02':'02',
            '03':'03',
'04':'HZ:04',
'05':'FU:05',
'07':'DU:07',
            '10':'BR:10',   #wasn't in LCD code but is in LCD doc
            '11':'11',
            '12':'12',
'18':'SQ:18',
            '20':'20',
            '21':'21',
            '22':'22',
            '23':'23',
            '24':'24',
            '25':'25',
            '26':'26',
            '27':'27',
            '28':'28',
            '29':'29',
'30':'FG:30',
'31':'FG:31',
'32':'FG:32',
'33':'FG:33',
'34':'FG:34',
'35':'FG:35',
            '40':'40',
            '41':'41',
            '42':'42',
            '43':'43',
            '44':'44',
            '45':'45',
            '46':'46',
            '47':'47',
            '48':'48',
'50':'DZ:50',
'51':'DZ:51',
'52':'DZ:52',
'53':'DZ:53',
'54':'FZDZ:54',
'55':'FZDZ:55',
'56':'FZDZ:56',
'57':'DZ:57',
'58':'DZ:58',
'60':'RA:60',
'61':'RA:61',
'62':'RA:62',
'63':'RA:63',
'64':'FZRA:64',
'65':'FZRA:65',
'66':'FZRA:66',
'67':'RA:67',
'68':'RA:68',
'70':'SN:70',
'71':'SN:71',
'72':'SN:72',
'73':'SN:73',
'74':'PL:74',
'75':'PL:75',
'76':'PL:76',
'77':'SG:77',
'78':'IC:78',
            '80':'80',
'81':'SHRA:81',
'82':'SHRA:82',
'83':'SHRA:83',
'84':'SHRA:84',
'85':'SHSN:85',
'86':'SHSN:86',
'87':'SHSN:87',
'89':'HAIL:89',
'90':'TS:90',
'91':'TS:91',
'92':'TS:92',
'93':'TS-HAIL:93',   #nancy switched from 'TS HAIL' to avoid space
'94':'TS:94',
'95':'TS:95',
'96':'TS+HAIL:96',
'99':'+FC:99'}

'''
#TODO: why arent these codes used as stated in doc?
AW_LCD_doc_code_dict={
'HZ:04':'HZ:04-Haze,-smoke,-or-dust-in-suspension-in-the-air,-visibility-equal-to-or-greater-than-1km',
'FU:05':'FU:05-Smoke',
'DU:07':'DU:07-Dust-or-sand-raised-by-wind-at-or-near-the-station-at-the-time-of-observation,-but-no-well‑developed-dust-whirl(s)-or-sand-whirl(s),-and-no-duststorm-or-sandstorm-seen-or,-in-the-case-of-ships,-blowing-spray-at-the-station',
'BR:10':'BR:10-Mist',
'11':'11-Diamond-dust',
'12':'12-Distant-lightning',
'SQ:18':'SQ:18-Squalls',
'20':'20-Fog-(during-preceding-hour-but-not-at-time-of-observation)',
'21':'21-Precipitation-(during-preceding-hour-but-not-at-time-of-observation)',
'22':'22-Drizzle-(not-freezing)-or-snow-grains-(during-preceding-hour-but-not-at-time-of-observation)',
'23':'23-Rain-(not-freezing)-(during-preceding-hour-but-not-at-time-of-observation)',
'24':'24-Snow-(during-preceding-hour-but-not-at-time-of-observation)',
'25':'25-Freezing-drizzle-or-freezing-rain-(during-preceding-hour-but-not-at-time-of-observation)',
'26':'26-Thunderstorm-(with-or-without-precipitation)-(during-preceding-hour-but-not-at-time-of-observation)(during-preceding-hour-but-not-at-time-of-observation)',
'27':'27-Blowing-or-drifting-snow-or-sand-(during-preceding-hour-but-not-at-time-of-observation)',
'28':'28-Blowing-or-drifting-snow-or-sand,-visibility-equal-to-or-greater-than-1-km-(during-preceding-hour-but-not-at-time-of-observation)',
'29':'29-Blowing-or-drifting-snow-or-sand,-visibility-less-than-1-km-(during-preceding-hour-but-not-at-time-of-observation)',
'FG:30':'FG:30-Fog',
'FG:31':'FG:31-Fog-or-ice-fog-in-patches',
'FG:32':'FG:32-Fog-or-ice-fog,-has-become-thinner-during-the-past-hour',
'FG:33':'FG:33-Fog-or-ice-fog,-no-appreciable-change-during-the-past-hour',
'FG:34':'FG:34-Fog-or-ice-fog,-has-begun-or-become-thicker-during-the-past-hour',
'FG:35':'FG:35-Fog,-depositing-rime',
'40':'40-Precipitation',
'41':'41-Precipitation,-slight-or-moderate',
'42':'42-Precipitation,-heavy',
'43':'43-Liquid-precipitation,-slight-or-moderate',
'44':'44-Liquid-precipitation,-heavy',
'45':'45-Solid-precipitation,-slight-or-moderate',
'46':'46-Solid-precipitation,-heavy',
'47':'47-Freezing-precipitation,-slight-or-moderate',
'48':'48-Freezing-precipitation,-heavy',
'DZ:50':'DZ:50-Drizzle',
'DZ:51':'DZ:51-Drizzle,-not-freezing,-slight',
'DZ:52':'DZ:52-Drizzle,-not-freezing,-moderate',
'DZ:53':'DZ:53-Drizzle,-not-freezing,-heavy',
'FZDZ:54':'FZDZ:54-Drizzle,-freezing,-slight',
'FZDZ:55':'FZDZ:55-Drizzle,-freezing,-moderate',
'FZDZ:56':'FZDZ:56-Drizzle,-freezing,-heavy',
'DZ:57':'DZ:57-Drizzle-and-rain,-slight',
'DZ:58':'DZ:58-Drizzle-and-rain,-moderate-or-heavy',
'RA:60':'RA:60-Rain',
'RA:61':'RA:61-Rain,-not-freezing,-slight',
'RA:62':'RA:62-Rain,-not-freezing,-moderate',
'RA:63':'RA:63-Rain,-not-freezing,-heavy',
'FZRA:64':'FZRA:64-Rain,-freezing,-slight',
'FZRA:65':'FZRA:65-Rain,-freezing,-moderate',
'FZRA:66':'FZRA:66-Rain,-freezing,-heavy',
'RA:67':'RA:67-Rain-or-drizzle-and-snow,-slight',
'RA:68':'RA:68-Rain-or-drizzle-and-snow,-moderate-or-heavy',
'SN:70':'SN:70-Snow',
'SN:71':'SN:71-Snow,-slight',
'SN:72':'SN:72-Snow,-moderate',
'SN:73':'SN:73-Snow,-heavy',
'PL:74':'PL:74-Ice-pellets,-slight',
'PL:75':'PL:75-Ice-pellets,-moderate',
'PL:76':'PL:76-Ice-pellets,-heavy',
'SG:77':'SG:77-Snow-grains',
'IC:78':'IC:78-Ice-crystals',
'80':'80-Showers-or-intermittent-precipitation',
'SHRA:81':'SHRA:81-Rain-showers-or-intermittent-rain,-slight',
'SHRA:82':'SHRA:82-Rain-showers-or-intermittent-rain,-moderate',
'SHRA:83':'SHRA:83-Rain-showers-or-intermittent-rain,-heavy',
'SHRA:84':'SHRA:84-Rain-showers-or-intermittent-rain,-violent',
'SHSN:85':'SHSN:85-Snow-showers-or-intermittent-snow,-slight',
'SHSN:86':'SHSN:86-Snow-showers-or-intermittent-snow,-moderate',
'SHSN:87':'SHSN:87-Snow-showers-or-intermittent-snow,-heavy',
'HAIL:89':'HAIL:89-Hail',
'TS:90':'TS:90-Thunderstorm',
'TS:91':'TS:91-Thunderstorm,-slight-or-moderate,-with-no-precipitation',
'TS:92':'TS:92-Thunderstorm,-slight-or-moderate,-with-rain-showers-and/or-snow-showers',
'TS-HAIL:93':'TS-HAIL:93-Thunderstorm,-slight-or-moderate,-with-hail',      #nancy switched from 'TS HAIL' to avoid space
'TS:94':'TS:94-Thunderstorm,-heavy,-with-no-precipitation',
'TS:95':'TS:95-Thunderstorm,-heavy,-with-rain-showers-and/or-snow',
'TS+HAIL:96':'TS+HAIL:96-Thunderstorm,-heavy,-with-hail',
'+FC:99':'+FC:99-Tornado'
}
'''

#################################################################################################

'''
MW-codes',
'Depending-on-equipment-used-at-the-location,-manually-augmented-stations-report-MW-codes-
either-with-or-instead-of-AU-and-AW-codes.-MW-codes-appear-last,-after-AU-and-AW-codes-
(all-three-types-are-separated-by-a-"|")-when-present.-MW-codes-are-defined-as-follows:',
'''

#https://drive.google.com/file/d/1coT2nn8g7gYBAju7MBgw_JH_i8PIfFU_/view?usp=sharing
#TODO: reconcile all letter codes? AW has TS+HAIL but MW's 99 is simply TS
MW_LCD_dict={       #from LcdPdfProcessorSupport.java ; the indented ones were added by nancy
#all but top 4 (00-03) are in LCD doc but not LCD code
            '00':'00',
            '01':'01',
            '02':'02',
            '03':'03',
'04':'FU:04',
'05':'HZ:05',
'06':'DU:06',
'07':'DU:07',
'08':'DU:08',
'09':'DU:09',
            '10':'BR:10',   #wasn't in LCD code but is in LCD doc
'11':'FG:11',
'12':'FG:12',
            '13':'13',
            '14':'14',
            '15':'15',
            '16':'16',
'17':'TS:17',
'18':'SQ:18',
'19':'FC:19',
            '20':'20',
            '21':'21',
            '22':'22',
            '23':'23',
            '24':'24',
            '25':'25',
            '26':'26',
            '27':'27',
            '28':'28',
            '29':'29',
'30':'DU:30',
'31':'DU:31',
'32':'DU:32',
'33':'DU:33',
'34':'DU:34',
'35':'DU:35',
'36':'DRSN:36',
'37':'DRSN:37',
'38':'BLSN:38',
'39':'BLSN:39',
'40':'FG:40',
'41':'FG:41',
'42':'FG:42',
'43':'FG:43',
'44':'FG:44',
'45':'FG:45',
'46':'FG:46',
'47':'FG:47',
'48':'FG:48',
'49':'FG:49',
'50':'DZ:50',
'51':'DZ:51',
'52':'DZ:52',
'53':'DZ:53',
'54':'DZ:54',
'55':'DZ:55',
'56':'FZDZ:56',
'57':'FZDZ:57',
'58':'DZ:58',
'59':'DZ:59',
'60':'RA:60',
'61':'RA:61',
'62':'RA:62',
'63':'RA:63',
'64':'RA:64',
'65':'RA:65',
'66':'FZRA:66',
'67':'FZRA:67',
'68':'RA:68',
'69':'RA:69',
'70':'SN:70',
'71':'SN:71',
'72':'SN:72',
'73':'SN:73',
'74':'SN:74',
'75':'SN:75',
            '76':'76',
'77':'SG:77',
'78':'SN:78',
'79':'PL:79',
'80':'SHRA:80',
'81':'SHRA:81',
'82':'SHRA:82',
'83':'SHRASN:83',
'84':'SHRASN:84',
'85':'SHSN:85',
'86':'SHSN:86',
'87':'SH:87',
'88':'SH:88',
'89':'SH:89',
'90':'SH:90',
'91':'RA:91',
'92':'RA:92',
            '93':'93',
            '94':'94',
'95':'TS:95',
'96':'TS:96',
'97':'TS:97',
'98':'TS:98',
'99':'TS:99'
 }

MW_LCD_ISD_combined_dict={ # from LCD doc
'00':'00-Cloud development not observed or not observable',
'01':'01-Clouds generally dissolving or becoming less developed',
'02':'02-State of sky on the whole unchanged',
'03':'03-Clouds generally forming or developing',
'FU:04':'FU:04-Visibility-reduced-by-smoke,-e.g.-veldt-or-forest-fires,-industrial-smoke-or-volcanic-ashes',
'HZ:05':'HZ:05-Haze',
'DU:06':'DU:06-Widespread-dust-in-suspension-in-the-air,-not-raised-by-wind-at-or-near-the-station-at-the-time-of-observation',
'DU:07':'DU:07-Dust-or-sand-raised-by-wind-at-or-near-the-station-at-the-time-of-observation-but-no-well-developed-dust-whirl(s)-or-sand-whirl(s),-and-no-duststorm-or-sandstorm-seen-or,-in-the-case-of-ships,-blowing-spray-at-the-station',
'DU:08':'DU:08-Well-developed-dust-whirl(s)-or-sand-whirl(s)-seen-at-or-near-the-station-during-the-preceding-hour-or-at-the-time-of-observation,-but-no-duststorm-or-sandstorm',
'DU:09':'DU:09-Duststorm-or-sandstorm-within-sight-at-the-time-of-observation,-or-at-the-station-during-the-preceding-hour',
'BR:10':'BR:10-Mist',
'FG:11':'FG:11-Patches-of-shallow-fog-or-ice-fog-at-the-station,-whether-on-land-or-sea,-not-deeper-than-about-2-meters-on-land-or-10-meters-at-sea',
'FG:12':'FG:12-More-or-less-continuous-shallow-fog-or-ice-fog-at-the-station,-whether-on-land-or-sea,-not-deeper-than-about-2-meters-on-land-or-10-meters-at-sea',
'13':'13-Lightning-visible,-no-thunder-heard',
'14':'14-Precipitation-within-sight,-not-reaching-the-ground-or-the-surface-of-the-sea',
'15':'15-Precipitation-within-sight,-reaching-the-ground-or-the-surface-of-the-sea,-but-distant,-i.e.,-estimated-to-be-more-than-5-km-from-the-station',
'16':'16-Precipitation-within-sight,-reaching-the-ground-or-the-surface-of-the-sea,-near-to,-but-not-at-the-station',
'TS:17':'TS:17-Thunderstorm,-but-no-precipitation-at-the-time-of-observation',
'SQ:18':'SQ:18-Squalls-at-or-within-sight-of-the-station-during-the-preceding-hour-or-at-the-time-of-observation',
'FC:19':'FC:19-Funnel-cloud(s)-(Tornado-cloud-or-waterspout)-at-or-within-sight-of-the-station-during-the-preceding-hour-or-at-the-time-of-observation',
'20':'20-Drizzle-(not-freezing)-or-snow-grains-not-falling-as-shower(s)-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'21':'21-Rain-(not-freezing)-not-falling-as-shower(s)-(during-the-preceding-hour-but-not-at-the-time-of-observation))',
'22':'22-Snow-not-falling-as-shower(s)-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'23':'23-Rain-and-snow-or-ice-pellets-not-falling-as-shower(s)-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'24':'24-Freezing-drizzle-or-freezing-rain-not-falling-as-shower(s)-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'25':'25-Shower(s)-of-rain-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'26':'26-Shower(s)-of-snow-or-of-rain-and-snow-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'27':'27-Shower(s)-of-hail-(Hail,-small-hail,-snow-pellets),-or-rain-and-hail-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'28':'28-Fog-or-ice-fog-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'29':'29-Thunderstorm-(with-or-without-precipitation)-(during-the-preceding-hour-but-not-at-the-time-of-observation)',
'DU:30':'DU:30-Slight-or-moderate-duststorm-or-sandstorm-has-decreased-during-the-preceding-hour',
'DU:31':'DU:31-Slight-or-moderate-duststorm-or-sandstorm-no-appreciable-change-during-the-preceding-hour',
'DU:32':'DU:32-Slight-or-moderate-duststorm-or-sandstorm-has-begun-or-has-increased-during-the-preceding-hour',
'DU:33':'DU:33-Severe-duststorm-or-sandstorm-has-decreased-during-the-preceding-hour',
'DU:34':'DU:34-Severe-duststorm-or-sandstorm-no-appreciable-change-during-the-preceding-hour',
'DU:35':'DU:35-Severe-duststorm-or-sandstorm-has-begun-or-has-increased-during-the-preceding-hour',
'DRSN:36':'DRSN:36-Slight-or-moderate-drifting-snow-generally-low-(below-eye-level)',
'DRSN:37':'DRSN:37-Heavy-drifting-snow-generally-low-(below-eye-level)',
'BLSN:38':'BLSN:38-Slight-or-moderate-blowing-snow-generally-high-(above-eye-level)',
'BLSN:39':'BLSN:39-Heavy-blowing-snow-generally-high-(above-eye-level)',
'FG:40':'FG:40-Fog-or-ice-fog-at-a-distance-at-the-time-of-observation,-but-not-at-the-station-during-the-preceding-hour,-the-fog-or-ice-fog-extending-to-a-level-above-that-of-the-observer',
'FG:41':'FG:41-Fog-or-ice-fog-in-patches',
'FG:42':'FG:42-Fog-or-ice-fog,-sky-visible,-has-become-thinner-during-the-preceding-hour',
'FG:43':'FG:43-Fog-or-ice-fog,-sky-invisible,-has-become-thinner-during-the-preceding-hour',
'FG:44':'FG:44-Fog-or-ice-fog,-sky-visible,-no-appreciable-change-during-the-preceding-hour',
'FG:45':'FG:45-Fog-or-ice-fog,-sky-invisible,-no-appreciable-change-during-the-preceding-hour',
'FG:46':'FG:46-Fog-or-ice-fog,-sky-visible,-has-begun-or-has-become-thicker-during-the-preceding-hour',
'FG:47':'FG:47-Fog-or-ice-fog,-sky-invisible,-has-begun-or-has-become-thicker-during-the-preceding-hour',
'FG:48':'FG:48-Fog,-depositing-rime,-sky-visible',
'FG:49':'FG:49-Fog,-depositing-rime,-sky-invisible',
'DZ:50':'DZ:50-Drizzle,-not-freezing,-intermittent,-slight-at-time-of-observation',
'DZ:51':'DZ:51-Drizzle,-not-freezing,-continuous,-slight-at-time-of-observation',
'DZ:52':'DZ:52-Drizzle,-not-freezing,-intermittent,-moderate-at-time-of-observation',
'DZ:53':'DZ:53-Drizzle,-not-freezing,-continuous,-moderate-at-time-of-observation',
'DZ:54':'DZ:54-Drizzle,-not-freezing,-intermittent,-heavy-(dense)-at-time-of-observation',
'DZ:55':'DZ:55-Drizzle,-not-freezing,-continuous,-heavy-(dense)-at-time-of-observation',
'FZDZ:56':'FZDZ:56-Drizzle,-freezing,-slight',
'FZDZ:57':'FZDZ:57-Drizzle,-freezing,-moderate-or-heavy-(dense)',
'DZ:58':'DZ:58-Drizzle-and-rain,-slight',
'DZ:59':'DZ:59-Drizzle-and-rain,-moderate-or-heavy',
'RA:60':'RA:60-Rain,-not-freezing,-intermittent,-slight-at-time-of-observation',
'RA:61':'RA:61-Rain,-not-freezing,-continuous,-slight-at-time-of-observation',
'RA:62':'RA:62-Rain,-not-freezing,-intermittent,-moderate-at-time-of-observation',
'RA:63':'RA:63-Rain,-not-freezing,-continuous,-moderate-at-time-of-observation',
'RA:64':'RA:64-Rain,-not-freezing,-intermittent,-heavy-at-time-of-observation',
'RA:65':'RA:65-Rain,-not-freezing,-continuous,-heavy-at-time-of-observation',
'FZRA:66':'FZRA:66-Rain,-freezing,-slight',
'FZRA:67':'FZRA:67-Rain,-freezing,-moderate-or-heavy',
'RA:68':'RA:68-Rain-or-drizzle-and-snow,-slight',
'RA:69':'RA:69-Rain-or-drizzle-and-snow,-moderate-or-heavy',
'SN:70':'SN:70-Intermittent-fall-of-snowflakes,-slight-at-time-of-observation',
'SN:71':'SN:71-Continuous-fall-of-snowflakes,-slight-at-time-of-observation',
'SN:72':'SN:72-Intermittent-fall-of-snowflakes,-moderate-at-time-of-observation',
'SN:73':'SN:73-Continuous-fall-of-snowflakes,-moderate-at-time-of-observation',
'SN:74':'SN:74-Intermittent-fall-of-snowflakes,-heavy-at-time-of-observation',
'SN:75':'SN:75-Continuous-fall-of-snowflakes,-heavy-at-time-of-observation',
'76':'76-Diamond-dust-(with-or-without-fog)',
'SG:77':'SG:77-Snow-grains-(with-or-without-fog)',
'SN:78':'SN:78-Isolated-star-like-snow-crystals-(with-or-without-fog)',
'PL:79':'PL:79-Ice-pellets',
'SHRA:80':'SHRA:80-Rain-shower(s),-slight',
'SHRA:81':'SHRA:81-Rain-shower(s),-moderate-or-heavy',
'SHRA:82':'SHRA:82-Rain-shower(s),-violent',
'SHRASN:83':'SHRASN:83-Shower(s)-of-rain-and-snow-mixed,-slight',
'SHRASN:84':'SHRASN:84-Shower(s)-of-rain-and-snow-mixed,-moderate-or-heavy',
'SHSN:85':'SHSN:85-Show-shower(s),-slight',
'SHSN:86':'SHSN:86-Snow-shower(s),-moderate-or-heavy',
'SH:87':'SH:87-Shower(s)-of-snow-pellets-or-small-hail,-with-or-without-rain-or-rain-and-snow-mixed,-slight',
'SH:88':'SH:88-Shower(s)-of-snow-pellets-or-small-hail,-with-or-without-rain-or-rain-and-snow-mixed,-moderate-or-heavy',
'SH:89':'SH:89-Shower(s)-of-hail-(hail,-small-hail,-snow-pellets),-with-or-without-rain-or-rain-and-snow-mixed,-not-associated-with-thunder,-slight',
'SH:90':'SH:90-Shower(s)-of-hail-(hail,-small-hail,-snow-pellets),-with-or-without-rain-or-rain-and-snow-mixed,-not-associated-with-thunder,-moderate-or-heavy',
'RA:91':'RA:91-Slight-rain-at-time-of-observation,-thunderstorm-during-the-preceding-hour-but-not-at-time-of-observation',
'RA:92':'RA:92-Moderate-or-heavy-rain-at-time-of-observation,-thunderstorm-during-the-preceding-hour-but-not-at-time-of-observation',
'93':'93-Slight-snow,-or-rain-and-snow-mixed-or-hail-(Hail,-small-hail,-snow-pellets),-at-time-of-observation,-thunderstorm-during-the-preceding-hour-but-not-at-time-of-observation',
'94':'94-Moderate-or-heavy-snow,-or-rain-and-snow-mixed-or-hail(Hail,-small-hail,-snow-pellets)-at-time-of-observation,-thunderstorm-during-the-preceding-hour-but-not-at-time-of-observation',
'TS:95':'TS:95-Thunderstorm,-slight-or-moderate,-without-hail-(Hail,-small-hail,-snow-pellets),-but-with-rain-and/or-snow-at-time-of-observation,-thunderstorm-at-time-of-observation',
'TS:96':'TS:96-Thunderstorm,-slight-or-moderate,-with-hail-(hail,-small-hail,-snow-pellets)-at-time-of-observation,-thunderstorm-at-time-of-observation',
'TS:97':'TS:97-Thunderstorm,-heavy,-without-hail-(Hail,-small-hail,-snow-pellets),-but-with-rain-and/or-snow-at-time-of-observation,-thunderstorm-at-time-of-observation',
'TS:98':'TS:98-Thunderstorm-combined-with-duststorm-or-sandstorm-at-time-of-observation,-thunderstorm-at-time-of-observation',
'TS:99':'TS:99-Thunderstorm,-heavy,-with-hail-(Hail,-small-hail,-snow-pellets)-at-time-of-observation,-thunderstorm-at-time-of-observation'
}
