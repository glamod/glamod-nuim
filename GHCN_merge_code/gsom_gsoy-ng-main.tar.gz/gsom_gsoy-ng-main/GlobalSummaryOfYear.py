import polars as pl
import polars.selectors as cs
from typing import Union
import logging
import os
import csv
from datetime import date, datetime
import time

from gsoy import YearlyCalculations
from gsoy.Elements import ElementsDataType
from utils import StationUtils, ArgParserUtil

filePaths = dict()
statusLog = logging.getLogger(__name__)

OUTPUT_EXT = "{}.csv"
LOG_EXT = "status-gsoy_{}.txt"
ERROR_FILE = os.path.join('data','ops','gsom_gsoy_new','status','error-gsoy.txt') # Default path to write error to

elemToSum = set([ 'AWND','EVAP','DP01','DP10','DP1X','DSND','DSNW','DT00','DT32','DX32','DX70','DX90','DYFG','DYHF','DYTS'
                 ,'MN01','MN02','MN03','MN04','MN05','MN06','MN07','MN08','MN09','MNPN','MXPN','MX01','MX02','MX03'
                 ,'MX04','MX05','MX06','MX07','MX08','MX09','PSUN','TAVG','TMAX','TMIN','TSUN','WDMV'])

elemMinMax = set([ 'HN01','HN02','HN03','HN04','HN05','HN06','HN07','HN08','HN09','HX01','HX02','HX03','HX04'
                      ,'HX05','HX06','HX07','HX08','HX09','LN01','LN02','LN03','LN04','LN05','LN06','LN07','LN08'
                      ,'LN09','LX01','LX02','LX03','LX04','LX05','LX06','LX07','LX08','LX09'])

def createYearlyRecords(inputDF: pl.DataFrame, isNorthHem: bool, headers: set) -> Union[dict[str,dict[str,str]], None]:
    elements = set(inputDF.columns)                # Get list of all elements. NOTE: this will contain elements that will not process
    outputDict = dict(dict())                 # 2D dict to store output data

    # Need to go through all years and process each
    years = inputDF['DATE'].dt.year().unique()

    # These elements will process a whole stations data worth at a time
    if 'CLDD' in elements:
        YearlyCalculations.calc_CLDD_HTDD(inputDF, years, 'CLDD', isNorthHem, outputDict, headers)
    if 'HTDD' in elements:
        YearlyCalculations.calc_CLDD_HTDD(inputDF, years, 'HTDD', isNorthHem, outputDict, headers)

    for yr in years:
        yearDF = inputDF.filter(pl.col('DATE').dt.year() == yr)  # Get all columns for a given year
        for element in elements:
            outputData = None
            if element in elemToSum:
                outputData = YearlyCalculations.calcYearTotal(yearDF, element)
            elif element in set(['CDSD','HDSD']):
                outputData = YearlyCalculations.calcSpecificMonth(yearDF, element, isNorthHem)
            elif element in set(['EMNT','EMSD','EMSN','EMXP','EMXT']):
                outputData = YearlyCalculations.calc_EM(yearDF, element)
            elif element in set(['PRCP', 'SNOW']):
                outputData = YearlyCalculations.calcYearTotalWithTrace(yearDF, element)
            elif element in elemMinMax:
                outputData = YearlyCalculations.calc_MinMaxElements(yearDF, element)
            elif element in set(['WSF1','WSF2','WSF5','WSFG','WSFM']):
                outputData = YearlyCalculations.calc_MaxWind(yearDF, element)
                # For adding wind direction element
                if outputData is not None:
                    outputDict.setdefault(str(yr),{})[outputData.directionElement] = outputData.directionValue
                    outputDict.setdefault(str(yr),{})[outputData.directionElement + '_ATTRIBUTES'] = outputData.directionFlag
                    headers.add(outputData.directionElement)
                    headers.add(outputData.directionElement + '_ATTRIBUTES')

            # If valid data, add to storage for writing to output csv
            if outputData is not None:
                outputDict.setdefault(str(yr),{})[element] = outputData.value
                outputDict.setdefault(str(yr),{})[element + '_ATTRIBUTES'] = outputData.flag
                headers.add(element)
                headers.add(element + '_ATTRIBUTES')

    return outputDict

def writeOutputFile(outputDict: dict[str,dict[str,str]], stationID: str, lat, long, elevation, stationName, headers: set):
    with open(filePaths['output'].format(stationID), 'w', newline='') as f:
        completeHeaders = [ 'STATION', 'DATE', 'LATITUDE', 'LONGITUDE', 'ELEVATION', 'NAME' ] + sorted(headers)
        w = csv.DictWriter(f, completeHeaders, restval=None, quoting=csv.QUOTE_NOTNULL)
        w.writeheader()
        for key,val in outputDict.items():
            row = { 'STATION':stationID, 'DATE':key, 'LATITUDE':lat, 'LONGITUDE':long, 'ELEVATION':elevation, 'NAME':stationName }
            row.update(val)
            w.writerow(row)


def readInputFile(stationID: str) -> pl.DataFrame:
    inputDF = pl.read_csv(filePaths['input'].format(stationID), 
                        schema_overrides=ElementsDataType.dataTypeDict)

    inputDF = inputDF.with_columns(pl.col('DATE').str.to_date('%Y-%m'))  # Convert DATE col to date time dtype

    # Fill missing months with null. Using this method so that index # will equal month
    years = inputDF['DATE'].dt.year()
    ymin = years.min()
    ymax = years.max()
    idx = pl.DataFrame({'DATE':pl.date_range(date(ymin,1,1), date(ymax,12,1), interval='1mo', eager=True)})
    inputDF = inputDF.join(idx, on='DATE', how='full', coalesce=True)
    
    # Fill flag columns with empty string '' if no data
    inputDF = inputDF.with_columns(cs.contains('_ATTRIBUTES').fill_null(''))

    return inputDF

def execute():
    # Read in station list
    stationsDF = StationUtils.loadStationsAsDataFrame(filePaths['stations'])
    # Get a list of all the stations (set as index so just grab that)
    strTotalStationCount =  str(stationsDF.height)
    print('Number of stations loaded: ' + strTotalStationCount)
    statusLog.info(f'Number of stations loaded: {strTotalStationCount}')

    # Loop through each station
    for station in range(stationsDF.height):

        stationID = stationsDF.select(pl.col("Station"))[station].item()

        # read in input
        inputDF = readInputFile(stationID)

        # Process data
        headers = set()
        outputDict = createYearlyRecords(inputDF, stationsDF.select(pl.col("isNorthHemisphere"))[station].item(), headers)
        
        # write output to file. skip empty data
        if outputDict:
            writeOutputFile(outputDict, 
                            stationID,
                            stationsDF.select(pl.col("Latitude"))[station].item(),
                            stationsDF.select(pl.col("Longitude"))[station].item(),
                            stationsDF.select(pl.col("Elevation"))[station].item(),
                            stationsDF.select(pl.col("Name"))[station].item(),
                            headers)
        
        #statusLog.info(f'{stationID} ({station+1}/{strTotalStationCount}) finished processing')
        print(f'{stationID} ({station+1}/{strTotalStationCount}) processed')

def validatePath(pathStr):
    if os.path.exists(pathStr):
        return True
    else:
        return False

def parseAndValidateArgs():
    parser = ArgParserUtil.gsoy_parser()  # Set up parser
    global filePaths
    filePaths = vars(parser.parse_args()) # Get dictionary of cmd args
    
    if(len(filePaths) != 4):
        print("Not all required file names provided!")
    
    allPathsValidated = True
    if validatePath(filePaths['log']) is False:
        print("ERROR: Log directory doesn't exist")
        exit()    # No point to continue processing
    else:
        # should start log file
        # Add date/time to file path name
        logPath = LOG_EXT.format(datetime.now().strftime('%d%b%Y_%H%M'))
        filePaths['log'] += logPath
        # Start logging
        logging.basicConfig(filename=filePaths['log'], level=logging.INFO, format='%(asctime)s: %(message)s', datefmt='%m/%d/%Y %H:%M:%S')
        statusLog.info('Log Initialized')
    
    if validatePath(filePaths['stations']) is False:
        print("Station file doesn't exist")
        statusLog.error("ERROR: Station file doesn't exist")
        allPathsValidated = False

    if validatePath(filePaths['input']) is False:
        print("Input directory doesn't exist")
        statusLog.error("ERROR: Input directory doesn't exist")
        allPathsValidated = False

    if validatePath(filePaths['output']) is False:
        print("Output directory doesn't exist")
        statusLog.error("ERROR: Output directory doesn't exist")
        allPathsValidated = False

    if allPathsValidated is False:
        return False

    # Need to go through and attach extention onto some of them
    filePaths['input'] += OUTPUT_EXT
    filePaths['output'] += OUTPUT_EXT

def main():
    # Get path files or exit if not present
    if parseAndValidateArgs() is False:
        statusLog.error("ERROR: GSOY Exiting")
        exit()

    try:
        start = time.perf_counter()
        execute()
        end = time.perf_counter()
        print(round(end-start,3))
        statusLog.info(f'GSOY finished with runtime of {round(end-start,3)}')
    except Exception as e:
        statusLog.exception(e)
        statusLog.error("ERROR: GSOY Exiting")
        raise

if __name__ == '__main__':
    main()