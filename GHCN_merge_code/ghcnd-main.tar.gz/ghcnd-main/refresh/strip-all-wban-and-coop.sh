#./strip_source.exe R mingle-list.txt ghcnd-stations.txt 
./strip_source.exe X mingle-list.txt ghcnd-stations.txt 
./strip_source.exe B mingle-list-no-X.txt ghcnd-stations-no-X.txt 
./strip_source.exe M mingle-list-no-B.txt ghcnd-stations-no-B.txt 
./strip_source.exe A mingle-list-no-M.txt ghcnd-stations-no-M.txt 
./strip_source.exe S mingle-list-no-A.txt ghcnd-stations-no-A.txt 
./strip_source.exe 0 mingle-list-no-S.txt ghcnd-stations-no-S.txt 
./strip_source.exe 6 mingle-list-no-0.txt ghcnd-stations-no-0.txt 
./strip_source.exe 2 mingle-list-no-6.txt ghcnd-stations-no-6.txt 
./strip_source.exe 1 mingle-list-no-2.txt ghcnd-stations-no-2.txt 
./strip_source.exe H mingle-list-no-1.txt ghcnd-stations-no-1.txt 
./strip_source.exe F mingle-list-no-H.txt ghcnd-stations-no-H.txt 
./strip_source.exe N mingle-list-no-F.txt ghcnd-stations-no-F.txt 

