# -*- coding: utf-8 -*-
"""
Created on Wed Apr  9 10:02:22 2025

@author: snoone
"""

import pandas as pd
import os

# Define the path to the .xlsx file
file_path = r'C:\Users\snoone\Dropbox\NEW_DATA_SOURCES_r8_\Yuri_B_New_data_use\All_Giessen_rescue_data\Giessen_new data\China_Years_Nanking_sbdy\China_Years_Nanking\1936\China( Jan 1936).xlsx'

# Define the output folder
output_folder = r'C:\Users\snoone\Dropbox\NEW_DATA_SOURCES_r8_\Yuri_B_New_data_use\All_Giessen_rescue_data\Giessen_new data\China_Years_Nanking_sbdy\China_Years_Nanking\out'

# Ensure the output folder exists
os.makedirs(output_folder, exist_ok=True)

# Read the Excel file
xlsx = pd.ExcelFile(file_path)

# Loop through all the sheet names and save them as CSV
for sheet_name in xlsx.sheet_names:
    # Load the sheet into a DataFrame
    df = pd.read_excel(xlsx, sheet_name=sheet_name)
    
    # Define the output CSV file path with the new folder
    output_csv = os.path.join(output_folder, f'{sheet_name}_1936.csv')
    
    # Save the DataFrame as a CSV file
    df.to_csv(output_csv, index=False)
    print(f'Sheet "{sheet_name}" saved as {output_csv}')
