export PREFIX=/data/
export lib_dir=/data/ops/lib/
echo "Starting qc2.exe" `date`
${lib_dir}qc2.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt M upd

run_status=live
export ftpdatapath="/pub/data/ghcn/daily"

export timestamp=2024010318

echo "Starting qc3.exe" `date`
${lib_dir}qc3.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt upd

echo "Starting post format_check.exe" `date`
${lib_dir}format_check.exe post ${PREFIX}input4sys/ghcnd-stations-update.txt ${PREFIX} ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

echo "Starting append_upd2por.exe" `date`
${lib_dir}append_upd2por.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations-update.txt

echo "Starting to copy updated files from ghcnd_upd to ghcnd_all" `date`
cd ${PREFIX}ghcnd_upd
for i in *
do
  cp -p ${PREFIX}ghcnd_upd/$i ${PREFIX}ghcnd_all
done

echo "Starting make_gsn_hcn.exe" `date`
${lib_dir}make_gsn_hcn.exe $PREFIX upd

por_version=`cat ${PREFIX}input4sys/por-version.txt`
vernum=`cat ${PREFIX}input4sys/version-number.txt`

echo "The current version of GHCN Daily is $vernum-upd-$timestamp (i.e, an update that started at $timestamp [yyyymmddhh] UTC; yyyy=year; mm=month; dd=day; hh=hour)," > ${PREFIX}ghcnd-version.txt
echo "created by appending recently available data updates to the last fully reprocessed version: ${por_version}." >> ${PREFIX}ghcnd-version.txt

echo "Starting ghcnd_ftp.sh" `date`
${lib_dir}ghcnd_ftp.sh upd ${run_status}

echo "Starting ghcnd_archive.sh" `date`
${lib_dir}ghcnd_archive.sh upd ${run_status} /data/backup/latest/

#${lib_dir}monitor-sources.sh /data/ghcnd_all/ /data/ops/lib/

echo "ghcnd_upd.sh finshed at" `date`


