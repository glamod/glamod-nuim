export PREFIX=/data/
export lib_dir=/data/ops/lib/
export timestamp=2020122505
export run_status=sync

echo "Starting post format_check.exe" `date`
${lib_dir}format_check.exe post ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

if [ "$(/usr/bin/du -b format_check_post.log | gawk '{print $1}')" -gt 0 ]
then
echo "WARNING!!! Formatting error detected in post QC mode: Content of log file follows"
cat format_check_post.log
echo "Moving qc1out to qc1outold"
rm -rf ${PREFIX}qc1outold
mv ${PREFIX}qc1out ${PREFIX}qc1outold
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
${lib_dir}ghcnd_archive.sh por no
echo "Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
exit
fi

echo "Starting check_size.sh for this por run" `date`
echo "${PREFIX}qc3out/" "${PREFIX}ghcnd_por/" | ${lib_dir}check_size.sh

if [ -s ${PREFIX}qc3out ]
then
echo "WARNING!!! Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
echo "Starting ghcnd_archive.sh" `date`
${lib_dir}ghcnd_archive.sh por ${run_status} /data/backup/
exit
fi

#echo "Starting make_gsn_hcn.exe" `date`
#${PREFIX}make_gsn_hcn.exe $PREFIX por

echo "Starting ghcndinv.exe" `date`
${lib_dir}ghcndinv.exe ${PREFIX} ${PREFIX}ghcnd_por/ ${PREFIX}input4sys/ghcnd-stations.txt

rm -r ${PREFIX}ghcnd_all
cp -rp ${PREFIX}ghcnd_por ${PREFIX}ghcnd_all

vernum=`cat ${PREFIX}input4sys/version-number.txt`

echo $vernum-por-$timestamp > ${PREFIX}input4sys/por-version.txt
echo "The current version of GHCN Daily is $vernum-por-$timestamp (i.e, a period of record reprocess that started at $timestamp [yyyymmddhh] UTC; yyyy=year; mm=month; dd=day; hh=hour)." > ${PREFIX}ghcnd-version.txt

echo "Starting ghcnd_archive.sh" `date`
${lib_dir}ghcnd_archive.sh por ${run_status} /data/backup/

echo "Starting genclim.exe" `date`
${lib_dir}genclim.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations.txt

if [ "${run_status}" = "sync" ]
then
echo "Starting gen-info2sync-with-upd.sh" `date`
${lib_dir}gen-info2sync-with-upd.sh ${PREFIX} /data/backup/
fi


