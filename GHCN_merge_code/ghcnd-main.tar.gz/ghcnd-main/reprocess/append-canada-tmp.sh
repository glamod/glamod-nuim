PREFIX=$1
#rm -rf ${PREFIX}canada/rawghcnd
#mkdir -p ${PREFIX}canada/rawghcnd
for i in `ls ${PREFIX}canada/archive/por/rawghcnd`
do
gawk 'substr($0,12,6)<202303 {print $0}' ${PREFIX}canada/archive/por/rawghcnd/$i > ${PREFIX}canada/archive/por-new/rawghcnd/$i
done
for i in `ls ${PREFIX}canada/archive/upd-append/rawghcnd`
do
gawk 'substr($0,12,6)>=202303 && substr($0,12,6)<202402  {print $0}' ${PREFIX}canada/archive/upd-append/rawghcnd/$i >> ${PREFIX}canada/archive/por-new/rawghcnd/$i
done
