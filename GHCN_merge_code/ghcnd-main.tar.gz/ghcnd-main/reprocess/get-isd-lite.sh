#Script to download isd-lite hourly data for U.S. stations with data between 1982 and maxyr
#   maxyr is set by ghcnd_por.sh as an environment variable

rm -f ish-history.txt

wget ftp://ftp0.ncdc.noaa.gov/pub/data/noaa/ish-history.txt
gawk 'substr($0,47,2)=="US" {print $0}' ish-history.txt > ish-history-us.txt

if [ -s ${PREFIX}download/isd-lite ] 
then
rm -r ${PREFIX}download/isd-lite
fi

mkdir ${PREFIX}download/isd-lite

for (( year=1982; $year <= $maxyr; year=`expr $year + 1` ))
do
  echo $year
#  echo "open ftp0.ncdc.noaa.gov" > ftpin
#  echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
#  echo "cd pub/data/noaa/isd-lite/$year" >> ftpin
#  echo "lcd ${PREFIX}download/isd-lite" >> ftpin
#  gawk '{print "get "substr($0,1,6)"-"substr($0,8,5)"-"'"$year"'".gz"}' ish-history-us.txt >> ftpin
  gawk '{print "wget -q -P '"${PREFIX}"'download/isd-lite ftp://ftp0.ncdc.noaa.gov/pub/data/noaa/isd-lite/"'"$year"'"/"substr($0,1,6)"-"substr($0,8,5)"-"'"$year"'".gz"}' ish-history-us.txt > ${PREFIX}wget.sh
  chmod u+x ${PREFIX}wget.sh
  ${PREFIX}wget.sh
#  ftp -in < ftpin
done
