#Created by Menne November 2011

PREFIX=$1

#
if [ -s ${PREFIX}download/3207 ]
then
rm -r ${PREFIX}download/3207
fi

mkdir -p ${PREFIX}download/3207

wget -o${PREFIX}download/get-3207.ftp.log -P${PREFIX}download/3207 ftp://ftp0.ncdc.noaa.gov/pub/download/wxcoder3*.dly 

${PREFIX}update-archive2.sh ${PREFIX}download/3207 ${PREFIX}3207/archive 'wxcoder3*.dly'


