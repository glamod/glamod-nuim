# -*- coding: utf-8 -*-
"""
Created on Mon Jul  8 11:22:20 2024

@author: snoone
"""

import zipfile
import csv

# Define the path to the zip file
zip_file_path = r"D:\AEMET_spanish_hist_sub_daily\JLC.zip"

# Open the zip file
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    # List all files in the zip file
    file_list = zip_ref.namelist()

# Define the path to save the CSV file
csv_file_path = r"D:\AEMET_spanish_hist_sub_daily\file_list.csv"

# Write the file list to a CSV file
with open(csv_file_path, 'w', newline='') as csv_file:
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['File Name'])  # Write header
    for file_name in file_list:
        csv_writer.writerow([file_name])

print(f"File list saved to {csv_file_path}")
