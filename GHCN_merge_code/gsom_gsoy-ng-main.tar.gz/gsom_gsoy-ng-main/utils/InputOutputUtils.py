from typing import Dict, Tuple
import polars as pl
import polars.selectors as cs
from gsom.FlagCheck import FlagCheck
from gsom.ElementCalculations import ElementCalculations

    
def fixedWidthInputToDataFrame(file_path: str, col_names_and_widths: Dict[str, int], *, skip_rows: int = 0) -> pl.DataFrame:
    
    # Reads a fixed-width file into a dataframe.
    # Strips all values of leading/trailing whitespaces.

    # Args:
    #   col_names_and_widths: A dictionary where the keys are the column names and the values are the widths of the columns.
    

    df = pl.read_csv(
        file_path,
        has_header=False,
        skip_rows=skip_rows,
        new_columns=["full_str"],
    )

    # transform col_names_and_widths into a Dict[cols name, Tuple[start, width]]
    slices: Dict[str, Tuple[int, int]] = {}
    start = 0
    for col_name, width in col_names_and_widths.items():
        slices[col_name] = (start, width)
        start += width

    df = df.with_columns(
        [
            pl.col("full_str").str.slice(slice_tuple[0], slice_tuple[1]).str.strip_chars().alias(col)
            for col, slice_tuple in slices.items()
        ]
    ).drop(["full_str"])

    return df

def dlyAsDataFrame( DLY:str) -> pl.DataFrame:

    col_list = {
        "Station_ID":11, 
        "Year_Month":6, 
        "Element":4
    }

    # Use a loop to create the daily columns
    for day in range(31):
        col_list[ str(day)] = 5
        col_list[ str(day) + "_measure"] = 1
        col_list[ str(day) + "_quality_control"] = 1
        col_list[ str(day) + "_source"] = 1

    df = fixedWidthInputToDataFrame( DLY, col_list)
    
    data_cols = [str(i) for i in range(31)]
    
    '''
    
    '''
    df = df.with_columns(
        daily_values = pl.concat_list( data_cols ),
        qc_flags = pl.concat_list( cs.matches(".*_quality_control.*") )
    ).drop( 
        data_cols 
    ).drop( 
        cs.matches(".*_quality_control.*") 
    )
     
    df = df.cast( {"daily_values":pl.List(pl.Float32)}, strict=False )
    

    # Remove values if QC values != ""
    # Version 2 - Creates indexes in case we need to know original day of some value 
    fc = FlagCheck()
    df = fc.missing4Consecutive(df)
    df = fc.removeInvalidData(df)
    
    ec = ElementCalculations()
    #df = ec.create_derived_elements(df)
    
    #TODO send filtered values to a when/then tree with all elements
    df = df.with_columns(
        filtered=pl.col.daily_values
    ).drop("daily_values")

    df = ec.process_elements(df)
    
    #print(df)

    # Set empty strings to null
    df = df.with_columns(
        pl.when(pl.col(pl.String).str.len_chars() == 0)
        .then(None)
        .otherwise(pl.col(pl.String))
        .name.keep()
    )
    # Check the measure and source flag columns for non-null values
    # Save if either is found
    df = df.with_columns(
        measure_flag = pl.coalesce(cs.matches(".*_measure.*")),
        source_flag = pl.coalesce(cs.matches(".*_source.*"))
    ).drop( 
        cs.matches(".*_measure.*") 
    ).drop(
        cs.matches(".*_source.*")
    ).drop("qc_flags").drop("filtered").drop("days_of_month")

    df = df.with_columns(
        attributes = pl.concat_str(
            pl.col("measure_flag"), pl.col("source_flag"), separator=","
        ) 
    ).drop("measure_flag", "source_flag")

    #print(df)

    #TODO FINAL - Use alternate filtering method for days to preserve value indexes
    #TODO FINAL - Create vectorized function to check for consecutive missing days
    #TODO Unit Test - Check missing days vs days of month, set missing flag
    #TODO Unit Test - Merge flag columns
    
    
    
    
    #Reduce Year_Month to unique values, turn unique elements into columns
    outputDF = out = df.pivot("Element", index="Year_Month", values=["value", "attributes"])
    
    #Clean Up Column Names
    attributes = outputDF.select(
        cs.matches(".*attributes_.*")
    )

    attributes = attributes.select(
        pl.all().name.map(lambda col_name: col_name.replace("attributes_", ""))
    )

    attributes = attributes.select(
        pl.all().name.map(lambda col_name: col_name + "_ATTRIBUTES")
    )

    values = outputDF.select(
        cs.matches(".*value_.*")
    )

    values = values.select(
        pl.all().name.map(lambda col_name: col_name.replace("value_", ""))
    )

    values = values.with_columns(attributes)

    values = values.select(
        sorted(values.columns)
    )

    outputDF = outputDF.with_columns(
        values
    ).drop(
        cs.matches(".*attributes_.*")
    ).drop(
        cs.matches(".*value_.*")
    )
    
    #print( outputDF )
    
    #print( outputDF )


    
    return outputDF