#!/usr/bin/env python3
# coding: utf-8

"""  June 17, 2020
Derived from code from:
    John Nielsen-Gammon | Regents Professor and Texas State Climatologist
    Department of Atmospheric Sciences | Texas A&M University
    3150 TAMU | College Station, TX 77843-3150
    ph: 979-862-2248 | n-g@tamu.edu
"""

class ISD_ob(object):
    """
    Object that reads ISD data file and returns data one observation at a time.
    
    Iterator returns four-element list.  Only elements flagged with 'Y' are guaranteed to be present.
      
        meta: Dictionary
            'USAF_cat': Y string: 
                FIXED-WEATHER-STATION USAF MASTER STATION CATALOG identifier
            'WBAN':     Y string: 
                FIXED-WEATHER-STATION NCEI WBAN identifier
            'yyyymmdd': Y string: 
                GEOPHYSICAL-POINT-OBSERVATION date #NC added year/month/day
            'hhmm':     Y string: 
                GEOPHYSICAL-POINT-OBSERVATION time #NC added hour/minute
            'source':     string: 
                GEOPHYSICAL-POINT-OBSERVATION data source flag (pp5-6)
            'latitude':    float: 
                GEOPHYSICAL-POINT-OBSERVATION latitude coordinate (deg)
            'longitude':   float: 
                GEOPHYSICAL-POINT-OBSERVATION longitude coordinate (deg)
            'rpt_type':   string: 
                GEOPHYSICAL-REPORT-TYPE code (pp6-7)
            'elev_m':    integer: 
                GEOPHYSICAL-POINT-OBSERVATION elevation dimension (m)
            'call_id':    string: 
                FIXED-WEATHER-STATION call letter identifier
            'qc_proc':  Y string: 
                METEOROLOGICAL-POINT-OBSERVATION quality control process name (p7)

        data: Dictionary of data elements present and non-missing in ob, 
                possibly including the following. () indicate units or location of 
                code table in isd-format-document.  Common lexicon for observables:
                    wind = wind
                    ceiling = ceiling
                    vis = visibility
                    temp = temperature
                    dewpt = dew point temperature
                    mslp = pressure at mean sea level
                    precip = precipitation
                    stnp = station pressure
                    weather = weather
                    hail = hail
                    ice = ice
            'wind_dir'Q:      integer: 
                WIND-OBSERVATION direction angle (deg)
            'wind_type':       string: 
                WIND-OBSERVATION type code (p8)
            'wind_speed_ms'Q:   float: 
                WIND-OBSERVATION speed rate (m/s)
            'ceiling_m'Q:     integer: 
                SKY-CONDITION-OBSERVATION ceiling height dimension (m)
            'how_ceiling':     string: 
                SKY-CONDITION-OBSERVATION ceiling determination code (p9)
            '?CAVOK':          string: 
                SKY-CONDITION-OBSERVATION CAVOK code (p9)
            'vis_km'Q:   float: 
                VISIBILITY-OBSERVATION distance dimension (km)
            'vis_var'Q:        string: 
                VISIBILITY-OBSERVATION variability code (p10)
            'temp_degC'Q:       float: 
                AIR-TEMPERATURE-OBSERVATION air temperature (C)
            'dewpt_degC'Q:      float: 
                AIR-TEMPERATURE-OBSERVATION dew point temperature (C)
            'mslp_hPa'Q:        float: 
                ATMOSPHERIC-PRESSURE-OBSERVATION sea level pressure (hPa=mb)
            ##ADDITIONAL ELEMENTS
            'precip_n'Q where n can be 1-4:
                'precip_n_dur_h':  integer: 
                    LIQUID-PRECIPITATION period quantity in hours
                'precip_n_amt_mm':   float: 
                    LIQUID-PRECIPITATION depth dimension (mm)
                'precip_n_cond':    string: 
                    LIQUID-PRECIPITATION condition code (p13-14)
            'altimeter_hPa'Q:        float:                                                                   ***Nancy added
                    ATMOSPHERIC-PRESSURE-OBSERVATION altimeter setting
            'stnp_hPa'Q:        float:                                                                           ***Nancy added
                    ATMOSPHERIC-PRESSURE-OBSERVATION station pressure rate (hPa=mb)
            'pressure_tendency_code'Q:    string:                                                        ***Nancy added
                    ATMOSPHERIC-PRESSURE-CHANGE tendency code (0-9)
            'pressure_3hr_change_hPa'Q:     float:
                    ATMOSPHERIC-PRESSURE-CHANGE three hour quantity
            'daily_weather_n'Q where n can be 1-8:
                'daily_weather_n_source': string: 
                    DAILY-PRESENT-WEATHER-OBSERVATION source element (p29)
                'daily_weather_n_code':   string: 
                    DAILY-PRESENT-WEATHER-OBSERVATION weather type (p29)
                'daily_weather_n_abbr':   string: 
                    DAILY-PRESENT-WEATHER-OBSERVATION weather type abbreviation (p29)
            'weather_n'Q where n can be 1-9:
                'weather_n_intensity':    string: 
                    PRESENT-WEATHER-OBSERVATION intensity and proximity code (p30)
                'weather_n_descriptor':   string: 
                    PRESENT-WEATHER-OBSERVATION descriptor code (p30)
                'weather_n_precip':       string: 
                    PRESENT-WEATHER-OBSERVATION precipitation code (p30)
                'weather_n_obscuration:   string: 
                    PRESENT-WEATHER-OBSERVATION obscuration code (p31)
                'weather_n_other':        string: 
                    PRESENT-WEATHER-OBSERVATION other weather phenomena code (p31)
                'weather_n_combo':        string: 
                    PRESENT-WEATHER-OBSERVATION combination indicator code (p31)
            'auto_weather_n'Q:   string: 
                PRESENT-WEATHER-OBSERVATION automated atmospheric condition code (p31-33)
            'past_weather_n_code'Q:         string: 
                PAST-WEATHER-OBSERVATION atmospheric condition code (p33)
            'past_weather_n_period_h'Q:    integer: 
                PAST-WEATHER-OBSERVATION period quantity (hours)
            'past_man_weather_n_code'Q:     string: 
                PAST-WEATHER-OBSERVATION manual atmospheric condition code (p34)
            'past_man_weather_n_period_h'Q:integer: 
                PAST-WEATHER-OBSERVATION period quantity (hours
            'rvr_runway_dir':    string: 
                RUNWAY-VISUAL-RANGE-OBSERVATION direction angle (tens of deg)
            'rvr_runway_code':   string: 
                RUNWAY-VISUAL-RANGE-OBSERVATION runway designator code (p58)
            'rvr_vis_km'Q:       string: 
                RUNWAY-VISUAL-RANGE-OBSERVATION visibility dimension (km)
            'sky_cov_layer'Q where n can be 1-6:                                          #nancy added the GA elements (sky cover layer)
                'sky_cov_layer_n_cov_code'Q:  string: 
                    SKY-COVER-LAYER coverage code 
                'sky_cov_layer_n_base_ht'Q:   string: 
                    SKY-COVER-LAYER base height dimension
                'sky_cov_layer_n_cld_type_code'Q:   string: 
                    SKY-COVER-LAYER cloud type code
            'hail_size_cm'Q:     string: 
                HAIL size (cm)
            'x_temp_n' where n can be 1-4:
                'x_temp_n_period_h':  float: 
                    EXTREME-AIR-TEMPERATURE period quantity (hours)
                'x_temp_n_code':     string: 
                    EXTREME-AIR-TEMPERATURE code (p88-89)
                'x_temp_n_C'Q:        float: 
                    EXTREME-AIR-TEMPERATURE temperature
            'x_month_temp_n' where n can be 1-2:
                'x_month_temp_n_code':  string: 
                    EXTREME AIR-TEMPERATURE FOR THE MONTH code (p90)
                'x_month_temp_n_tie':   string: 
                    EXTREME AIR-TEMPERATURE FOR THE MONTH condition code (p90)
                'x_month_temp_n_C'Q:     float: 
                    EXTREME AIR-TEMPERATURE FOR THE MONTH temperature (C)
                'x_month_temp_n_day1':  string: 
                    EXTREME AIR-TEMPERATURE FOR THE MONTH dates of occurrence
                'x_month_temp_n_day2':  string: 
                    EXTREME AIR-TEMPERATURE FOR THE MONTH dates of occurrence
                'x_month_temp_n_day3':  string: 
                    EXTREME AIR-TEMPERATURE FOR THE MONTH dates of occurrence
            'nearby_weather'Q:    string: 
                PRESENT-WEATHER-IN-VICINITY-OBSERVATION atmospheric condition code (p103)
            'SYNOP_weather'Q:     string:
                PRESENT-WEATHER-OBSERVATION manual atmospheric condition code (pp105-107)
            'sup1_wind_n' where n can be 1-3:
                'sup1_wind_n_code':      string: 
                    SUPPLEMENTARY-WIND-OBSERVATION type code (p107)
                'sup1_wind_n_period_h': integer: 
                    SUPPLEMENTARY-WIND-OBSERVATION period quantity (hours)
                'sup1_wind_n_speed_ms'Q:  float: 
                    SUPPLEMENTARY-WIND-OBSERVATION speed rate (m/s)
            'wind_gust_ms'Q:    string: 
                WIND-GUST-OBSERVATION speed rate (m/s)
            'sup2_wind_n' where n can be 1-3:
                'sup2_wind_n_code':      string: 
                    SUPPLEMENTARY-WIND-OBSERVATION type code (p111)
                'sup2_wind_n_period_h': integer: 
                    SUPPLEMENTARY-WIND-OBSERVATION period quantity (hours)
                'sup2_wind_n_speed_ms'Q:  float: 
                    SUPPLEMENTARY-WIND-OBSERVATION speed rate (m/s)
                'sup2_wind_n_dir':      integer: 
                    SUPPLEMENTARY-WIND-OBSERVATION direction quantity (deg)
            'SOD_wind_n'Q where n can be 1-3:
                'SOD_wind_n_code':      string: 
                    SUMMARY-OF-DAY-WIND-OBSERVATION type code (p112)
                'SOD_wind_n_period_h': integer: 
                    SUMMARY-OF-DAY-WIND-OBSERVATION period quantity (hours)
                'SOD_wind_n_speed_ms':   float: 
                    SUMMARY-OF-DAY-WIND-OBSERVATION speed (m/s)
                'SOD_wind_n_dir':      integer: 
                    SUMMARY-OF-DAY-WIND-OBSERVATION direction of wind (deg)
                'SOD_wind_n_Ztme':      string: 
                    SUMMARY-OF-DAY-WIND-OBSERVATION time of occurrence in Z-time (UTC)
            'ice_source':       string:
                PLATFORM-ICE-ACCRETION source code (p120)
            'ice_thickness_cm'Q:  float:
                PLATFORM-ICE-ACCRETION thickness dimension (cm)
            'ice_tendency':     string:
                PLATFORM-ICE-ACCRETION tendency code (p120)
       
        data_qc: Dictionary of quality control flags, with possible keys 
                    noted in data dictionary by 'Q'
        
        orig_ob: Dictionary, possibly including:
            'SYN':    string: Synoptic Remarks (SYNOP report?)
            'AWY':    string: Airways Remarks (Surface Airways Observations SAO?)
            'MET':    string: METAR Remarks
            'SOD':    string: Summary of Day Remarks
            'SOM':    string: Summary of Month Remarks
            'HPD':    string: Hourly Precipitation Data Remarks

"""
    
    def __init__(self,filename):
        self.lines = open(filename, "r")
        #next(self.lines)
    
    def __iter__(self):
        return(self)
        
    def __next__(self):

        VERBOSE = False
        SILENT = True

        try:
            obraw = next(self.lines)
        except:
            if not SILENT: print('No more lines available')
            raise StopIteration
        if len(obraw) < 5:
            if not SILENT: print('Got a length of',len(obraw)) 
            raise StopIteration
        
            
        MANLEN = 105
        MINADD = 5
        oblen = int(obraw[0:4]) + MANLEN
                
        meta={}
        meta['USAF_cat'] = obraw[4:10] 
        meta['WBAN'] = obraw[10:15] 
        meta['ISD_STN_ID'] = obraw[4:15] #NC: this is for STN_ID field in IFF
        meta['yyyymmdd'] = obraw[15:23]
        meta['hhmm'] = obraw[23:27]
        meta['year'] = obraw[15:19]
        meta['month'] = obraw[19:21]
        meta['day'] = obraw[21:23] 
        meta['date'] = obraw[15:23]
        meta['hour'] = obraw[23:25]
        meta['minute'] = obraw[25:27]
        #if obraw[27:28] != '9':      meta['source'] = obraw[27:28] #nancy removed 9-missing; we need to know if it's a 9.
        meta['source'] = obraw[27:28]
        if obraw[28:34] != '+99999': meta['latitude'] = int(obraw[28:34])/1000.
        if obraw[34:41] != '+999999':meta['longitude'] = int(obraw[34:41])/1000.
        if obraw[41:46] != '99999':  meta['rpt_type'] = obraw[41:46]
        #FOR CDMP3851 only: if obraw[46:51] != '+9999' and obraw[46:51] != ', +00':  meta['elev_m'] = int(obraw[46:51]) #Santa Barbara 999999-53153-*
        if obraw[46:51] != '+9999':  meta['elev_m'] = int(obraw[46:51])
        if obraw[51:56] != '99999':  meta['call_id'] = obraw[51:56]
        meta['qc_proc'] = obraw[56:60]
        
        data={}
        data_qc={}
        remark = {}
        #nancy changed from int to string to deal with "VRB" in MAPSO  
        #nancy changed winddir so 999 is allowed b/c this is valid and wind type code
        #orig if obraw[60:63] != '999':    data['wind_dir'] = int(obraw[60:63])
        #orig    if obraw[64:65] != '9':      data['wind_type'] = obraw[64:65]
        data['wind_dir'] = obraw[60:63]
        data_qc['wind_dir'] = obraw[63:64]
        data['wind_type'] = obraw[64:65]
        if obraw[65:69] != '9999' and obraw[65:69].isnumeric():   data['wind_speed_ms'] = int(obraw[65:69])/10.
        data_qc['wind_speed_ms'] = obraw[69:70]
        #if obraw[70:75] != '99999' and obraw[70:75].isnumeric():  data['ceiling_m'] = int(obraw[70:75])
        #data_qc['ceiling_m'] = obraw[75:76]
        #if obraw[76:77] != '9': data['how_ceiling'] = obraw[76:77]
        #if obraw[77:78] != '9': data['?CAVOK'] = obraw[77:78]
        if obraw[78:84] != '999999' and obraw[78:84].isnumeric(): data['vis_km'] = int(obraw[78:84])/1000.
        data_qc['vis_km'] = obraw[84:85]
        #if obraw[85:86] != '9': data['vis_var'] = obraw[85:86]
        data['vis_var'] = obraw[85:86]  #NC change
        data_qc['vis_var'] = obraw[86:87]
        if obraw[87:92] != '+9999': data['temp_degC'] = int(obraw[87:92])/10.
        data_qc['temp_degC'] = obraw[92:93]
        if obraw[93:98] != '+9999': data['dewpt_degC'] = int(obraw[93:98])/10.
        data_qc['dewpt_degC'] = obraw[98:99]
        if obraw[99:104] != '99999' and obraw[99:104].isnumeric(): data['mslp_hPa'] = int(obraw[99:104])/10.
        data_qc['mslp_hPa'] = obraw[104:105]
        
        i = MANLEN
        done = False
        while oblen >= i + 3 and not done:
            if VERBOSE: print('main section ',obraw[i:i+3])
            if obraw[i:i+3] == 'ADD':
                i += 3
                while oblen >= i + MINADD and not done:
                    if VERBOSE: print('subsection ',obraw[i:i+3])
                    if 'AA1' <= obraw[i:i+3] <= 'AA4' :   # Precipitation amount
                        if oblen < i+11: done=True; break
                        n = obraw[i+2:i+3]
                        if obraw[i+3:i+5] != '99' and obraw[i+3:i+5].isnumeric(): 
                            data['precip_'+n+'_dur_h'] = int(obraw[i+3:i+5])
                        if obraw[i+5:i+9] != '9999' and obraw[i+5:i+9].isnumeric(): 
                            data['precip_'+n+'_amt_mm'] = int(obraw[i+5:i+9])/10.
#                        if obraw[i+9:i+10] != '9': 
#                            data['precip_'+n+'_cond'] = obraw[i+9:i+10]
                        data['precip_'+n+'_cond'] = obraw[i+9:i+10]
                        data_qc['precip_'+n] = obraw[i+10:i+11] 
                        i += 11
                    elif obraw[i:i+3] == 'AB1':   # Monthly precipitation
                        i += 10
                    elif obraw[i:i+3] == 'AC1':   # Precipitation duration
                        i += 6
                    elif obraw[i:i+3] == 'AD1':   # Wettest day in month
                        i += 22                   
                    elif obraw[i:i+3] == 'AE1':   # Precipitation threshold counts
                        i += 15
                    elif obraw[i:i+3] == 'AG1':   # Estimated precipitation info
                        i += 7
                    elif 'AH1' <= obraw[i:i+3] <= 'AH6' :  # Max monthly precip < 1h
                        if oblen < i+18: done=True; break
                        n = obraw[i+2:i+3]
                        if obraw[i+3:i+6] != '999' and obraw[i+3:i+6].isnumeric(): 
                            data['max_shdur_precip_AH'+n+'_dur_min'] = int(obraw[i+3:i+6])
                        if obraw[i+6:i+10] != '9999' and obraw[i+6:i+10].isnumeric(): 
                            data['max_shdur_precip_AH'+n+'_amt_mm'] = int(obraw[i+6:i+10])/10.
#                        if obraw[i+10:i+11] != '9':                     #keep condition code even if 9 - like I did for precip
#                            data['max_shdur_precip'+n+'_cond'] = obraw[i+10:i+11]
                        data['max_shdur_precip_AH'+n+'_cond'] = obraw[i+10:i+11]
                        if obraw[i+11:i+17] != '999999' and obraw[i+11:i+17].isnumeric(): 
                            data['max_shdur_precip_AH'+n+'_end_day_time'] = obraw[i+11:i+17]
                        data_qc['max_shdur_precip_AH'+n+'_amt_mm'] = obraw[i+17:i+18]  
                        i += 18
                    elif 'AI1' <= obraw[i:i+3] <= 'AI6' :  # Max monthly precip 1h - 3h
                        if oblen < i+18: done=True; break
                        n = obraw[i+2:i+3]
                        if obraw[i+3:i+6] != '999' and obraw[i+3:i+6].isnumeric(): 
                            data['max_shdur_precip_AI'+n+'_dur_min'] = int(obraw[i+3:i+6])
                        if obraw[i+6:i+10] != '9999' and obraw[i+6:i+10].isnumeric(): 
                            data['max_shdur_precip_AI'+n+'_amt_mm'] = int(obraw[i+6:i+10])/10.
#                        if obraw[i+10:i+11] != '9':                     #keep condition code even if 9 - like I did for precip
#                            data['max_shdur_precip'+n+'_cond'] = obraw[i+10:i+11]
                        data['max_shdur_precip_AI'+n+'_cond'] = obraw[i+10:i+11]
                        if obraw[i+11:i+17] != '999999' and obraw[i+11:i+17].isnumeric(): 
                            data['max_shdur_precip_AI'+n+'_end_day_time'] = obraw[i+11:i+17]
                        data_qc['max_shdur_precip_AI'+n+'_amt_mm'] = obraw[i+17:i+18]  
                        i += 18
                    elif obraw[i:i+3] == 'AJ1':   # Snow depth (no scaling factor) and liquid equivalent (scaling factor of 10)
                        if oblen < i+17: done=True; break
                        if obraw[i+3:i+7] != '9999' and obraw[i+3:i+7].isnumeric(): 
                            data['snow_depth_cm'] = obraw[i+3:i+7]
                        data['snow_depth_cond'] = obraw[i+7:i+8]
                        data_qc['snow_depth_cm'] = obraw[i+8:i+9] 
                        if obraw[i+9:i+15] != '999999' and obraw[i+9:i+15].isnumeric():
                            data['snow_depth_liq_equiv_mm'] = int(obraw[i+9:i+15])/10.
                        data['snow_depth_liq_equiv_cond'] = obraw[i+15:i+16]
                        data_qc['snow_depth_liq_equiv_mm'] = obraw[i+16:i+17]
                        i += 17
                    elif obraw[i:i+3] == 'AK1':   # Greatest snow depth for month
                        i += 15
                    elif 'AL1' <= obraw[i:i+3] <= 'AL4' :  # Snow accumulation (no scaling factor)
                        if oblen < i+10: done=True; break
                        n = obraw[i+2:i+3]
#TODO: #Keeping 99 as valid for snow accum duration - this should be changed if snow accum from USAF is ever changed in the future
                        #if obraw[i+3:i+5] != '99' and obraw[i+3:i+5].isnumeric(): 
                        if obraw[i+3:i+5].isnumeric(): 
                            data['snow_accumulation_'+n+'_dur_h'] = int(obraw[i+3:i+5])       
                        if obraw[i+5:i+8] != '999' and obraw[i+5:i+8].isnumeric(): 
                            data['snow_accumulation_'+n+'_depth_cm'] = int(obraw[i+5:i+8])
                        data['snow_accumulation_'+n+'_cond'] = obraw[i+8:i+9]
                        data_qc['snow_accumulation_'+n+'_depth_cm'] = obraw[i+9:i+10]
                        i += 10
                    elif obraw[i:i+3] == 'AM1':   # Greatest daily snow accumulation in month
                        i += 21
                    elif obraw[i:i+3] == 'AN1':   # Monthly snow accumulation
                        i += 12
                    # AO1 is CRN 5-min precip - most other CRN subhourly values start with a 'C'
                    elif obraw[i:i+3] == 'AO1':   # Precipitation issues
                        i += 11
                    elif 'AP1' <= obraw[i:i+3] <= 'AP4' :  # Intermediate precip 15-min
                        i += 9
                    elif 'AT1' <= obraw[i:i+3] <= 'AT8' :  # Daily present weather
#                        if oblen < i+12: done=True; break
#                        n = obraw[i+2:i+3]
#                        data['daily_weather_'+n+'_source'] = obraw[i+3:i+5]
#                        data['daily_weather_'+n+'_code'] = obraw[i+5:i+7]
#                        data['daily_weather_'+n+'_abbr'] = obraw[i+7:i+11]
#                        data_qc['daily_weather_'+n] = obraw[i+11:i+12] 
                        i += 12
                    elif 'AU1' <= obraw[i:i+3] <= 'AU9' :  # Present weather
                        if oblen < i+11: done=True; break     #nancy corrected to 11 from 12          
                        n = obraw[i+2:i+3]
                        if obraw[i+3:i+4] != '9':
                            data['weather_'+n+'_intensity'] = obraw[i+3:i+4]
                        if obraw[i+4:i+5] != '9':
                            data['weather_'+n+'_descriptor'] = obraw[i+4:i+5]
                        if obraw[i+5:i+7] != '99':
                            data['weather_'+n+'_precip'] = obraw[i+5:i+7]
                        if obraw[i+4:i+5] != '9':
                            data['weather_'+n+'_obscuration'] = obraw[i+7:i+8]
                        if obraw[i+4:i+5] != '9':
                            data['weather_'+n+'_other'] = obraw[i+8:i+9]
                        if obraw[i+4:i+5] != '9':
                            data['weather_'+n+'_combo'] = obraw[i+9:i+10]
                        data_qc['weather_'+n] = obraw[i+10:i+11] 
                        i += 11
                    elif 'AW1' <= obraw[i:i+3] <= 'AW6' :  # Automated present weather        #nancy: ISD format shows only AW1-AW4 - why did he think there were 6?
                        if oblen < i+6: done=True; break
                        n = obraw[i+2:i+3]
                        data['auto_weather_'+n] = obraw[i+3:i+5]
                        data_qc['auto_weather_'+n] = obraw[i+5:i+6] 
                        i += 6
                    elif 'AX1' <= obraw[i:i+3] <= 'AX6' :  # Past weather
#                        if oblen < i+9: done=True; break
#                        n = obraw[i+2:i+3]
#                        if obraw[i+3:i+5] != '99':
#                            data['past_weather_'+n+'_code'] = obraw[i+3:i+5]
#                        data_qc['past_weather_'+n+'_code'] = obraw[i+5:i+6]
#                        if obraw[i+6:i+8] != '99':
#                            data['past_weather_'+n+'_period_h'] = int(obraw[i+6:i+8])
#                        data_qc['past_weather_'+n+'_period_h'] = obraw[i+8:i+9]
                        i += 9
                    elif 'AY1' <= obraw[i:i+3] <= 'AY2' :  # Past weather
#                        if oblen < i+8: done=True; break
#                        n = obraw[i+2:i+3]
#                        if obraw[i+3:i+4] != '9':
#                            data['past_man_weather_'+n+'_code'] = obraw[i+3:i+4]
#                        data_qc['past_man_weather_'+n+'_code'] = obraw[i+4:i+5]
#                        if obraw[i+5:i+7] != '99':
#                            data['past_man_weather_'+n+'_period_h'] = int(obraw[i+5:i+7])
#                        data_qc['past_man_weather_'+n+'_period_h'] = obraw[i+7:i+8]
                        i += 8
                    elif 'CB1' <= obraw[i:i+3] <= 'CX3' :  # Climate Reference Network data (CRN subhourly/5-min data)
                        if not SILENT: print('Bogus CRN group, skipping rest of ob')
                        done = True
                        break
                    elif obraw[i:i+3] == 'ED1':   # Runway visual range
#                        if oblen < i+11: done=True; break
#                        if obraw[i+3:i+5] != '99':
#                            data['rvr_runway_dir'] = obraw[i+3:i+5]
#                        if obraw[i+5:i+6] != '99':
#                            data['rvr_runway_code'] = obraw[i+5:i+6]
#                        if obraw[i+6:i+10] != '9999' and obraw[i+6:i+10].isnumeric(): #nancy added isnumeric but not needed for LCD
#                            data['rvr_vis_km'] = int(obraw[i+6:i+10])/1000.
#                        data_qc['rvr_vis_km'] = obraw[i+10:i+11]
                        i += 11
                    elif 'GA1' <= obraw[i:i+3] <= 'GA6' :  # Sky cover layer  #nancy added
                        if oblen < i+16: done=True; break
                        n = obraw[i+2:i+3]
                        if obraw[i+3:i+5] != '99': 
                            data['sky_cov_layer_'+n+'_cov_code'] = obraw[i+3:i+5]
                        data_qc['sky_cov_layer_'+n+'_cov_code'] = obraw[i+5:i+6]
                        if obraw[i+6:i+12] != '+99999': 
                            data['sky_cov_layer_'+n+'_base_ht'] = obraw[i+6:i+12]
                        data_qc['sky_cov_layer_'+n+'_base_ht'] = obraw[i+12:i+13]
                        if obraw[i+13:i+15] != '99': 
                            data['sky_cov_layer_'+n+'_cld_type'] = obraw[i+13:i+15]
                        data_qc['sky_cov_layer_'+n+'_cld_type_code'] = obraw[i+15:i+16]
                        i += 16
                    elif 'GD1' <= obraw[i:i+3] <= 'GD6' :  # Sky cover summation
                        i += 15
                    elif obraw[i:i+3] == 'GE1':  # Convective cloud info
                        i += 22
                    elif obraw[i:i+3] == 'GF1':  # Total sky cover
                        i += 26
                    elif 'GG1' <= obraw[i:i+3] <= 'GG6' :  # Undercloud
                        i += 18
                    elif obraw[i:i+3] == 'GH1':   # Hourly solar radiation
                        i += 31
                    elif obraw[i:i+3] == 'GJ1':   # Sunshine duration
                        i += 8
                    elif obraw[i:i+3] == 'GK1':   # Sunshine percent
                        i += 7
                    elif obraw[i:i+3] == 'GL1':   # Monthly sunshine
                        i += 9
                    elif obraw[i:i+3] == 'GM1':   # Solar irradiance
                        i += 33
                    elif obraw[i:i+3] == 'GN1':   # Solar radiation
                        i += 31
                    elif obraw[i:i+3] == 'GO1':   # Net radiation
                        i += 22
                    elif obraw[i:i+3] == 'GP1':   # Modeled solar irradiance
                        i += 34
                    elif obraw[i:i+3] == 'GQ1':   # Hourly solar angle
                        i += 17
                    elif obraw[i:i+3] == 'GR1':   # Hourly extraterrestrial radiation (!)
                        i += 17
                    elif obraw[i:i+3] == 'HL1':   # Hail size
#                        if oblen < i+7: done=True; break
#                        if obraw[i+3:i+6] == '999':
#                            data['hail_size_cm'] = int(obraw[i+3:i+6])/10.
#                        data_qc['hail_size_cm'] = obraw[i+6:i+7]
                        i += 7
                    elif obraw[i:i+3] == 'IA1':   # Ground condition
                        i += 6
                    elif obraw[i:i+3] == 'IA2':   # Ground minimum temperature
                        i += 12
                    elif obraw[i:i+3] == 'IB1':   # Hourly ground temperature
                        i += 30
                    elif obraw[i:i+3] == 'IB2':   # Ground temperature sensor
                        i += 16
                    elif obraw[i:i+3] == 'IC1':   # Pan evaporation
                        i += 28
                    elif 'KA1' <= obraw[i:i+3] <= 'KA4' :  # Temperature extremes
#                        if oblen < i+13: done=True; break
#                        n = obraw[i+2:i+3]
#                        if obraw[i+3:i+6] != '999':
#                            data['x_temp'+n+'_period_h'] = int(obraw[i+3:i+6])/10.
#                        if obraw[i+6:i+7] != '9':
#                            data['x_temp_'+n+'_code'] = obraw[i+6:i+7]
#                        if obraw[i+7:i+12] != '+9999':
#                            data['x_temp_'+n+'_C'] = int(obraw[i+7:i+12])/10.
#                        data_qc['x_temp_'+n+'_C'] = obraw[i+12:i+13] 
                        i += 13
                    elif 'KB1' <= obraw[i:i+3] <= 'KB3' :  # Average temperature
                        i += 13
                    elif 'KC1' <= obraw[i:i+3] <= 'KC2' :  # Monthly temperature extremes
#                        if oblen < i+17: done=True; break
#                        n = obraw[i+2:i+3]
#                        if obraw[i+3:i+4] != '9':
#                            data['x_month_temp_'+n+'_code'] = obraw[i+3:i+4]
#                        if obraw[i+4:i+5] != '9':
#                            data['x_month_temp_'+n+'_tie'] = obraw[i+4:i+5]
#                        if obraw[i+5:i+10] != '+9999':
#                            data['x_month_temp_'+n+'_C'] = int(obraw[i+5:i+10])/10.
#                        if obraw[i+10:i+12] != '99':
#                            data['x_month_temp_'+n+'_day1'] = obraw[i+10:i+12]
#                        if obraw[i+12:i+14] != '99':
#                            data['x_month_temp_'+n+'_day2'] = obraw[i+12:i+14]
#                        if obraw[i+14:i+16] != '99':
#                            data['x_month_temp_'+n+'_day3'] = obraw[i+14:i+16]
#                        data_qc['x_month_temp_'+n+'_C'] = obraw[i+16:i+17] 
                        i += 17
                    elif 'KD1' <= obraw[i:i+3] <= 'KD3' :  # Degree days
                        i += 12
                    elif obraw[i:i+3] == 'KE1':   # Monthly temperature thresholds
                        i += 15
                    elif obraw[i:i+3] == 'KF1':   # Calculated temperatures
                        i += 9
                    elif 'KG1' <= obraw[i:i+3] <= 'KG2' :  # Dew point and wet bulb
                        i += 14
                    elif obraw[i:i+3] == 'MA1':   # Air pressure (altimeter + station pressure)
                        if oblen < i+15: done=True; break
                        if obraw[i+3:i+8] != '99999' and obraw[i+3:i+8].isnumeric():
                            data['altimeter_hPa'] = int(obraw[i+3:i+8])/10.
                        data_qc['altimeter_hPa'] = obraw[i+8:i+9]
                        if obraw[i+9:i+14] != '99999' and obraw[i+9:i+14].isnumeric():
                            data['stnp_hPa'] = int(obraw[i+9:i+14])/10.
                        data_qc['stnp_hPa'] = obraw[i+14:i+15]
                        i += 15                        
                    elif obraw[i:i+3] == 'MD1':   # Air pressure tendency + 3-hr change (skipping 24-hr for now)
                        if oblen < i+14: done=True; break
                        if obraw[i+3:i+4] != '9' and obraw[i+3:i+4].isnumeric():
                            data['pressure_tendency_code'] = obraw[i+3:i+4]
                        data_qc['pressure_tendency_code'] = obraw[i+4:i+5]
                        if obraw[i+5:i+8] != '999' and obraw[i+5:i+8].isnumeric():
                            data['pressure_3hr_change_hPa'] = int(obraw[i+5:i+8])/10.
                        data_qc['pressure_3hr_change_hPa'] = obraw[i+8:i+9]         
                        i += 14
                    elif obraw[i:i+3] == 'ME1':   # Geopotential height
                        i += 9
                    elif obraw[i:i+3] == 'MF1':   # Average air pressure
                        i += 15
                    elif obraw[i:i+3] == 'MG1':   # Minimum air pressure
                        i += 15
                    elif obraw[i:i+3] == 'MH1':   # Average monthly air pressure
                        i += 15
                    elif obraw[i:i+3] == 'MK1':   # Extreme monthly air pressure
                        i += 27
                    elif 'MV1' <= obraw[i:i+3] <= 'MV7':   # Nearby weather
#                        if oblen < i+6: done=True; break
#                        n = obraw[i+2:i+3]
#                        if obraw[i+3:i+5] != '99':
#                            data['nearby_weather_'+n] = obraw[i+3:i+5]
#                        data_qc['nearby_weather_'+n] = obraw[i+5:i+6]
                        i += 6
                    elif 'MW1' <= obraw[i:i+3] <= 'MW7':   # Present SYNOP weather
                        if oblen < i+6: done=True; break
                        n = obraw[i+2:i+3]
                        #if obraw[i+3:i+5] != '99':  #nancy commented -- 99 is code for tstorms -- is there an NA code? likely not
                        data['SYNOP_weather_'+n] = obraw[i+3:i+5]
                        data_qc['SYNOP_weather_'+n] = obraw[i+5:i+6]
                        i += 6
                    elif 'OA1' <= obraw[i:i+3] <= 'OA3':   # Supplementary wind 1
#                        if oblen < i+11: done=True; break
#                        n = obraw[i+2:i+3]
#                        if obraw[i+3:i+4] != '9':
#                            data['sup1_wind_'+n+'_code'] = obraw[i+3:i+4]
#                        if obraw[i+4:i+6] != '99':
#                            data['sup1_wind_'+n+'_period_h'] = int(obraw[i+4:i+6])
#                        if obraw[i+6:i+10] != '9999':
#                            data['sup1_wind_'+n+'_speed_ms'] = int(obraw[i+6:i+10])/10.
#                        data_qc['sup1_wind'+n+'_speed_ms'] = obraw[i+10:i+11]
                        i += 11
                    elif 'OB1' <= obraw[i:i+3] <= 'OB2':   # Brief CRN winds
                        i += 31
                    elif obraw[i:i+3] == 'OC1':   # Wind gust
                        if oblen < i+8: done=True; break
                        n = obraw[i+2:i+3]
                        if obraw[i+3:i+7] != '9999' and obraw[i+3:i+7].isnumeric():
                            data['wind_gust_ms'] = float(obraw[i+3:i+7])/10.
                        data_qc['wind_gust_ms'] = obraw[i+7:i+8]
                        i += 8
                    elif 'OD1' <= obraw[i:i+3] <= 'OD3':   # Supplementary wind 2
#                        if oblen < i+14: done=True; break
#                        n = obraw[i+2:i+3]
#                        if obraw[i+3:i+4] != '9':
#                            data['sup2_wind_'+n+'_code'] = obraw[i+3:i+4]
#                        if obraw[i+4:i+6] != '99':
#                            data['sup2_wind_'+n+'_period_h'] = int(obraw[i+4:i+6])
#                        if obraw[i+6:i+10] != '9999':
#                            data['sup2_wind_'+n+'_speed_ms'] = int(obraw[i+6:i+10])/10.
#                        data_qc['sup2_wind'+n+'_speed_ms'] = obraw[i+10:i+11]
#                        if obraw[i+11:i+14] != '999':
#                            data['sup2_wind_'+n+'_dir'] = int(obraw[i+6:i+10])
                        i += 14
                    elif 'OE1' <= obraw[i:i+3] <= 'OE3':   # Summary of Day winds
                    #    if oblen < i+19: done=True; break
                    #    n = obraw[i+2:i+3]
                    #    data['SOD_wind_'+n+'_code'] = obraw[i+3:i+4]
                    #    if obraw[i+4:i+6] != '99':
                    #        data['SOD_wind_'+n+'_period_h'] = int(obraw[i+4:i+6])
                    #    if obraw[i+6:i+11] != '99999' and obraw[i+6:i+11] != '*****':   #nancy added starts to deal with 72258813926 obs at 202006270559
                    #        data['SOD_wind_'+n+'_speed_ms'] = int(obraw[i+6:i+11])/100.
                    #    if obraw[i+11:i+14] != '999':
                    #        data['sup2_wind_'+n+'_dir'] = int(obraw[i+11:i+14])
                    #    if obraw[i+14:i+18] != '9999':
                    #        data['SOD_wind_'+n+'_Ztime'] = obraw[i+14:i+18]
                    #    data_qc['SOD_wind_'+n] = obraw[i+18:i+19]
                        i += 19
                    elif 'RH1' <= obraw[i:i+3] <= 'RH3':   # Relative humidity
                        i += 12
                    elif obraw[i:i+3] == 'SA1':   # Sea surface temperature
                        i += 8
                    elif obraw[i:i+3] == 'ST1':   # Soil temperature
                        i += 20
                    elif obraw[i:i+3] == 'WA1':   # Ice accretion
#                        if oblen < i+9: done=True; break
#                        if obraw[i+3:i+4] != '9':
#                            data['ice_source'] = obraw[i+3:i+4]
#                        if obraw[i+4:i+7] != '999':
#                            data['ice_thickness_cm'] = int(obraw[i+4:i+7])/10.
#                        if obraw[i+7:i+8] != '9':
#                            data['ice_tendency'] = obraw[i+7:i+8]
#                        data_qc['ice_thickness_cm'] = obraw[i+8:i+9]
                        i += 9
                    elif 'UA1' <= obraw[i:i+3] <= 'WJ1' :  # Marine, ice, and water data
                        if not SILENT: print('Unexpected marine, ice, or water group ',obraw[i:i+3],
                                              ' skipping rest of ob')
                        done = True
                        break
                    elif obraw[i:i+3] == 'REM': break
                    elif obraw[i:i+3] == 'EQD': break
                    elif obraw[i:i+3] == 'AWY': break  # The 'REM' group is probably missing
                    elif obraw[i:i+3] == 'QNN': break
                    else:
                        if not SILENT: print('Unknown code ',obraw[i:i+3],' quitting ',
                                             meta['yyyymmdd'],meta['hhmm'])
                        done = True
                        break
            elif obraw[i:i+3] == 'REM':
                if VERBOSE: print(obraw[i:i+3],i)
                if oblen < i+10: done=True; break
                i += 3
                #nancy added check for numeric value due to NOAA-SWO_ISD_QCL1_DFTY_s20050101_e20051231_c20120126T085152.dat  line:
                #0230914080403092005053114518+07333+134483FM-15+0033PTKR V0101005N00315091445MN0241405N5+02795+02455100895ADDMA1100885999999REMMET99B010059                                                                                        0000
                if (obraw[i+3:i+6].isnumeric()):
                    remlen = int(obraw[i+3:i+6])
                else:
                    remlen = 400  #TODO: kludge -- I'm not sure if it will return extra things including the EOL \n (?)
                    #TODO: add a message to the IFF saying there's an issue with REM?
                    #kludge: to deal with incorrect GEOPHYSICAL-POINT-OBSERVATION remark length quantity/bad characters
                    #MIN: 001 MAX: 999
                if obraw[i:i+3] == 'SYN':
#                    remark['SYN'] = obraw[i+6:i+6+remlen]
                    remark['SYN'] = obraw[i:i+6+remlen]
                elif obraw[i:i+3] == 'AWY':
#                    remark['AWY'] = obraw[i+6:i+6+remlen]
                    remark['AWY'] = obraw[i:i+6+remlen]
                elif obraw[i:i+3] == 'MET':
#                    remark['MET'] = obraw[i+6:i+6+remlen]
                    remark['MET'] = obraw[i:i+6+remlen]
                elif obraw[i:i+3] == 'SOD':
                    remark['SOD'] = obraw[i+6:i+6+remlen]
                elif obraw[i:i+3] == 'SOM':
                    remark['SOM'] = obraw[i+6:i+6+remlen]
                elif obraw[i:i+3] == 'HPD':
                    remark['HPD'] = obraw[i+6:i+6+remlen]
                else:
                    if not SILENT: print('Encountered unexpected REM type, quitting: ',
                                          obraw[i:i+3])
                    done = True
                    break
#TODO: ask Matt -- we don't need this stuff, correct?
                '''
                i = i + 6 + remlen
            elif obraw[i:i+3] == 'AWY':    # should not be here
                remlen = int(obraw[i+3:i+6])
                remark ['AWY'] = obraw[i+6:i+6+remlen]
                if not SILENT: print('AWY without REM at ',meta['yyyymmdd'],
                                     meta['hhmm'])
                i = i + 6 + remlen
            elif obraw[i:i+3] == 'EQD':   # Element quality data section
                i += 3
                while oblen >= i+16 and not done: 
                    if 'Q01' <= obraw[i:i+3] <= 'Q99':   # AFAW USAF Surface Hourly and ISD v2
                        i += 16
                    elif 'P01' <= obraw[i:i+3] <= 'P99':   # ISD v2 from hourly precip or surface hourly
                        i += 16
                    elif 'R01' <= obraw[i:i+3] <= 'R99':   # ISD v2&3 from >=2006 NCEI data source
                        i += 16
                    elif 'C01' <= obraw[i:i+3] <= 'C99':   # Table constraint
                        i += 16
                    elif 'D01' <= obraw[i:i+3] <= 'D99':   # Temporary QC replacement
                        i += 16
                    elif 'N01' <= obraw[i:i+3] <= 'N99':   # NCEI surface hourly
                        i += 16
                    elif obraw[i:i+3] == 'QNN': break
                    else:
                        if not SILENT: print('Encountered unexpected EQD type, quitting: ',
                                              obraw[i:i+3])
                        done = True
                        break       
            elif obraw[i:i+3] == 'QNN':   # If no REM, store as original ob
                if remark == {}:
                    remark = obraw[i+3:oblen]
                done = True
            else:
                if not SILENT: print('Encountered unexpected main section, quitting: ',
                                      obraw[i:i+3])
                done = True
            '''
            else:
                done=True
                continue
        return(meta,data,data_qc,remark)
