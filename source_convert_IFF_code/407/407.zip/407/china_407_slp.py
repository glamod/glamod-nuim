# -*- coding: utf-8 -*-
"""
Created on Thu Feb 15 10:01:49 2024

@author: snoone
"""

import os
import glob
import pandas as pd
import re

OUTDIR = "C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/out/combined/IFF/slp"
os.chdir("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/out/combined/error")
extension = '.csv'  # Assuming you want to process CSV files
all_filenames = [i for i in glob.glob('*{}'.format(extension))]

for filename in all_filenames:
   
        df = pd.read_csv(filename)
        # Preprocess the Date column
        df['Date'] = df['Date'].astype(str).str.strip()
        df['Date'] = pd.to_datetime(df['Date'], format='%d/%m/%Y %H:%M', errors='coerce')
        
        # Check for invalid dates
        nat_count = df['Date'].isna().sum()
        if nat_count > 0:
            print(f"Warning: {nat_count} rows have invalid Date values in file {filename}.")
            invalid_dates = df[df['Date'].isna()]
            invalid_dates.to_csv(f"{OUTDIR}/{filename}_invalid_dates.csv", index=False)
        
        # Drop rows with NaT in the Date column
        df = df.dropna(subset=['Date'])

       
        
        df["Source_ID"] = "407"
        df["Alias_station_name"] = ""
        df["Source_QC_flag"] = ""
        df["Original_observed_value_units"] = "mmhg"
        df['Report_type_code'] = ""
        df['Measurement_code_1'] = ""
        df['Measurement_code_2'] = ""
        df['Station_ID'] = df['Source']
        # Remove non-ASCII characters from Station_name
        df['Station_name'] = df["Source"]
        df["Original_observed_value"] = ""        
        df["Observed_value"] =""
        # Convert the 'Date' column to datetime format
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce')

        
        # Extract Year, Month, and Day into separate columns
        df['Year'] = df['Date'].dt.year
        df['Month'] = df['Date'].dt.month
        df['Day'] = df['Date'].dt.day
                
 

        # Load the Stations.csv file into a DataFrame
        stations = pd.read_csv("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/Stations.csv")
        
        # Perform the join based on the 'Station_ID' column
        # Adjust 'how' parameter as needed: 'inner', 'left', 'right', 'outer'
        merged_df = pd.merge(df, stations, on="Station_ID", how="inner")
        # Replace the values in Station_ID with the values from Station_ID_new
        if "Station_ID_New" in merged_df.columns:
            merged_df["Station_ID"] = merged_df["Station_ID_New"]
            merged_df = merged_df.drop(columns=["Station_ID_New"])
        # Preview the merged DataFrame
        print(merged_df.head())

          
        
        df1=merged_df
        #df1=df1.drop(columns =["y", "d", "m","DATE","9p","21p","2 1/2t","9t","21t"])
        df1["Hour"]="9" 
        df1["Minute"]="00"
        df1['Observed_value']=df1["Bar. Pressure 9h"]
        df1["Original_observed_value"]=df1["Observed_value"]
        df1["Observed_value"] = pd.to_numeric(df1["Observed_value"],errors='coerce')
        df1["Observed_value"]=df1["Observed_value"]* 1.3332239 

        df1 = df1[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]
        df2=merged_df
        #df2=df2.drop(columns =["y", "d", "m","DATE","2 1/2p","21p","2 1/2t","9t","21t"])
        df2["Hour"]="14" 
        df2["Minute"] ="00"
        df2['Observed_value']=df2['Bar. Pressure 14h']
        df2["Original_observed_value"]=df2["Observed_value"]
        df2["Observed_value"] = pd.to_numeric(df2["Observed_value"],errors='coerce')
        df2["Observed_value"]=df2["Observed_value"]* 1.3332239 

        df2 = df2[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]

        df3=merged_df
        #df3=df3.drop(columns =["y", "d", "m","DATE","2 1/2p","9p","2 1/2t","9t","21t"])
        df3["Hour"]="21" 
        df3["Minute"] ="00"
        df3['Observed_value']=df3['Bar. Pressure 21h']
        df3["Original_observed_value"]=df3["Observed_value"]
        df3["Observed_value"] = pd.to_numeric(df3["Observed_value"],errors='coerce')
        df3["Observed_value"]=df3["Observed_value"]* 1.3332239 

        df3 = df3[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]

        merged_slp=pd.concat([df1,df2,df3], axis=0)
        merged_slp=merged_slp.dropna(subset = ['Observed_value'])


        # Create the Timestamp column by combining Year, Month, Day, Hour, and Minute
        merged_slp["Timestamp2"] = (
            merged_slp["Year"].map(str) + "-" + 
            merged_slp["Month"].map(str) + "-" + 
            merged_slp["Day"].map(str)
        )
        merged_slp["Timestamp"] = (
            merged_slp["Timestamp2"] + " " + 
            merged_slp["Hour"].map(str) + ":" + 
            merged_slp["Minute"].map(str)
        )
        merged_slp = merged_slp.drop(columns=["Timestamp2"])

        # Convert the Timestamp column to datetime
        merged_slp['Timestamp'] = pd.to_datetime(merged_slp['Timestamp'], format='%Y-%m-%d %H:%M')

        # Localize and convert timezone
        merged_slp['Timestamp'] = merged_slp['Timestamp'].dt.tz_localize('Etc/GMT-8').dt.tz_convert('GMT')

        # Extract datetime components
        merged_slp['Year'] = merged_slp['Timestamp'].dt.year
        merged_slp['Month'] = merged_slp['Timestamp'].dt.month
        merged_slp['Day'] = merged_slp['Timestamp'].dt.day
        merged_slp['Hour'] = merged_slp['Timestamp'].dt.hour
        merged_slp['Minute'] = merged_slp['Timestamp'].dt.minute
        merged_slp['Seconds'] = merged_slp['Timestamp'].dt.second
        merged_slp = merged_slp.sort_values(by='Timestamp')


        merged_slp = merged_slp.drop(columns="Timestamp")
        merged_slp['Minute']='00'
        merged_slp['Observed_value'] = merged_slp['Observed_value'].round(1)
        merged_slp = merged_slp.astype(str)
        merged_slp = merged_slp[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]



        # Generate the file name dynamically based on Station_ID
        station_id = merged_slp['Station_ID'].iloc[0]  # Assuming Station_ID is a column in your DataFrame
        file_name = f"{station_id}_station_level_pressure_358.psv"

        # Full path for the file
        file_path = os.path.join(OUTDIR, file_name)

        # Save the DataFrame to a pipe-delimited file
        merged_slp.to_csv(file_path, sep='|', index=False)

        print(f"File saved successfully to: {file_path}")






