#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'


os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera")

df=pd.read_excel("Faro de la Punta de Caldera(1875).xlsx",skiprows = 3,sheet_name="1875") 
df["Source_ID"]="358"
df["Station_ID"]="358-00002"
df["Alias_station_name"]="Null"
df["Station_name"]="Faro de la Punta de Caldera"
df["Latitude"]= "-27.0512"
df["Longitude"]= "-70.8517"
df["Elevation"]= "25.5"
df['Year'] = df["y"]
df['Month'] = df['m'] 
df['Day'] = df['d']
df["Hour"]="14"
df["Minute"]="30"
df["Source_QC_flag"]=""
df['Original_observed_value_units']="perc"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''

df["Observed_value"]=df["14rh"]
df['Original_observed_value']=df["14rh"]

#df["Observed_value"]=df["BAROMETRO 2 1/2 h."]
#df['Original_observed_value']=df["BAROMETRO 2 1/2 h."]

df.dropna(subset = ["Observed_value"], inplace=True)
df = df.astype({"Year": int})
df = df.astype({"Month": int})
df = df.astype({"Day": int})
#df = df.astype({"Hour": int})
#df = df.astype({"Minute": int})
#df.fillna("NULL",inplace=True)
#df = df.fillna()
##df.drop(df.tail(4).index,inplace=True)
#df['Year'].replace('', np.nan, inplace=True)
#df.dropna(subset=['Year'], inplace=True)

#df = df.astype({"Year": int})
#df = df.astype({"Month": int})
##df = df.astype({"Day": int})
#df = df.astype({"Hour": int})

#remove rows with  o obervaed values

df["Observed_value"] = pd.to_numeric(df["Observed_value"],errors='coerce')
#df = df.astype({"Observed_value": int})
#df['Observed_value'].astype(str).astype(int)
#df["Observed_value"]= df["Observed_value"]-32
#df["Observed_value"]= df["Observed_value"]*5
#df["Observed_value"]= df["Observed_value"]/9
#df['Observed_value']=df["Observed_value"]* 1.3332239 
#df["Observed_value"]= df["Observed_value"].round(1)
df['Observed_value'].replace('', np.nan, inplace=True)
df.dropna(subset=['Observed_value'], inplace=True)

df["Timestamp2"] = df["Year"].map(str) + "-" + df["Month"].map(str)+ "-" + df["Day"].map(str)  
df["Timestamp"] = df["Timestamp2"].map(str)+ " " + df["Hour"].map(str)+":"+df["Minute"].map(str) 


df.drop(columns=["Timestamp2"])
df['Timestamp'] =  pd.to_datetime(df['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df['Timestamp'] = df['Timestamp'].dt.tz_localize('Etc/GMT+3').dt.tz_convert('GMT')
df['Year'] = df['Timestamp'].dt.year 
df['Month'] = df['Timestamp'].dt.month 
df['Day'] = df['Timestamp'].dt.day 
df['Hour'] = df['Timestamp'].dt.hour 
df['Minute'] = df['Timestamp'].dt.minute
df['Seconds'] = df['Timestamp'].dt.second
    

df['Minute'] = df['Minute'].astype('str')
df.Minute[df.Minute == "0"] = "00"
df= df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]


df['Original_observed_value']= round(df['Original_observed_value'],2)
df['Observed_value']= round(df['Observed_value'],1)

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera/sef/rh")

df.to_csv("358-00002_relative_humidity_358_1875_14.csv", index=False, sep=",")


import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'


os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera")

df2=pd.read_excel("Faro de la Punta de Caldera(1875).xlsx",skiprows = 3,sheet_name="1875")
df2["Source_ID"]="358"
df2["Station_ID"]="358-00002"
df2["Alias_station_name"]="Null"
df2["Station_name"]="Faro de la Punta de Caldera"
df2["Latitude"]= "-27.0512"
df2["Longitude"]= "-70.8517"
df2["Elevation"]= "25.5"
df2['Year'] = df2["y"]
df2['Month'] = df2['m'] 
df2['Day'] = df2["d"]
df2["Hour"]="9"
df2["Minute"]="00"
df2["Source_QC_flag"]=""
df2['Original_observed_value_units']="perc"
df2['Measurement_code_1']=''
df2['Measurement_code_2']=''
df2['Report_type_code']=''

df2["Observed_value"]=df2["9rh"]
df2['Original_observed_value']=df2["9rh"]



df2.dropna(subset = ["Observed_value"], inplace=True)
df2 = df2.astype({"Year": int})
df2 = df2.astype({"Month": int})
df2 = df2.astype({"Day": int})
#df = df.astype({"Hour": int})
#df = df.astype({"Minute": int})
#df.fillna("NULL",inplace=True)
#df = df.fillna()
##df.drop(df.tail(4).index,inplace=True)
#df['Year'].replace('', np.nan, inplace=True)
#df.dropna(subset=['Year'], inplace=True)

#df = df.astype({"Year": int})
#df = df.astype({"Month": int})
##df = df.astype({"Day": int})
#df = df.astype({"Hour": int})

#remove rows with  o obervaed values

df2["Observed_value"] = pd.to_numeric(df2["Observed_value"],errors='coerce')
#df = df.astype({"Observed_value": int})
#df['Observed_value'].astype(str).astype(int)
#df["Observed_value"]= df["Observed_value"]-32
#df["Observed_value"]= df["Observed_value"]*5
#df["Observed_value"]= df["Observed_value"]/9
#df2['Observed_value']=df2["Observed_value"]* 1.3332239 
#df2["Observed_value"]= df2["Observed_value"].round(1)
df2['Observed_value'].replace('', np.nan, inplace=True)
df2.dropna(subset=['Observed_value'], inplace=True)

df2["Timestamp2"] = df2["Year"].map(str) + "-" + df2["Month"].map(str)+ "-" + df2["Day"].map(str)  
df2["Timestamp"] = df2["Timestamp2"].map(str)+ " " + df2["Hour"].map(str)+":"+df2["Minute"].map(str) 


df2.drop(columns=["Timestamp2"])
df2['Timestamp'] =  pd.to_datetime(df2['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df2['Timestamp'] = df2['Timestamp'].dt.tz_localize('Etc/GMT+3').dt.tz_convert('GMT')
df2['Year'] = df2['Timestamp'].dt.year 
df2['Month'] = df2['Timestamp'].dt.month 
df2['Day'] = df2['Timestamp'].dt.day 
df2['Hour'] = df2['Timestamp'].dt.hour 
df2['Minute'] = df2['Timestamp'].dt.minute
df2['Seconds'] = df2['Timestamp'].dt.second
    

df2['Minute'] = df2['Minute'].astype('str')
df2.Minute[df2.Minute == "0"] = "00"
df2= df2[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]


df2['Original_observed_value']= round(df2['Original_observed_value'],2)
df2['Observed_value']= round(df2['Observed_value'],1)

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera/sef/rh")

df2.to_csv("358-00002_relative_humidity_358_1875_9.csv", index=False, sep=",")

import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'


os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera")

df3=pd.read_excel("Faro de la Punta de Caldera(1875).xlsx",skiprows = 3,sheet_name="1875")
df3["Source_ID"]="358"
df3["Station_ID"]="358-00002"
df3["Alias_station_name"]="Null"
df3["Station_name"]="Faro de la Punta de Caldera"
df3["Latitude"]= "-27.0512"
df3["Longitude"]= "-70.8517"
df3["Elevation"]= "25.5"
df3['Year'] = df3["y"]
df3['Month'] = df3["m"] 
df3['Day'] = df3['d']
df3["Hour"]="21"
df3["Minute"]="00"
df3["Source_QC_flag"]=""
df3['Original_observed_value_units']="perc"
df3['Measurement_code_1']=''
df3['Measurement_code_2']=''
df3['Report_type_code']=''


df3["Observed_value"]=df3["21rh"]
df3['Original_observed_value']=df3["21rh"]

#df3["Observed_value"]=df3["BAROMETRO 21 h"]
#df3['Original_observed_value']=df3["BAROMETRO 21 h"]

df3.dropna(subset = ["Observed_value"], inplace=True)
df3 = df3.astype({"Year": int})
df3 = df3.astype({"Month": int})
df3 = df3.astype({"Day": int})
#df = df.astype({"Hour": int})
#df = df.astype({"Minute": int})
#df.fillna("NULL",inplace=True)
#df = df.fillna()
##df.drop(df.tail(4).index,inplace=True)
#df['Year'].replace('', np.nan, inplace=True)
#df.dropna(subset=['Year'], inplace=True)

#df = df.astype({"Year": int})
#df = df.astype({"Month": int})
##df = df.astype({"Day": int})
#df = df.astype({"Hour": int})

#remove rows with  o obervaed values

df3["Observed_value"] = pd.to_numeric(df3["Observed_value"],errors='coerce')
#df = df.astype({"Observed_value": int})
#df['Observed_value'].astype(str).astype(int)
#df["Observed_value"]= df["Observed_value"]-32
#df["Observed_value"]= df["Observed_value"]*5
#df["Observed_value"]= df["Observed_value"]/9
#df3['Observed_value']=df3["Observed_value"]* 1.3332239 
#df3["Observed_value"]= df3["Observed_value"].round(1)
df3['Observed_value'].replace('', np.nan, inplace=True)
df3.dropna(subset=['Observed_value'], inplace=True)

df3["Timestamp2"] = df3["Year"].map(str) + "-" + df3["Month"].map(str)+ "-" + df3["Day"].map(str)  
df3["Timestamp"] = df3["Timestamp2"].map(str)+ " " + df3["Hour"].map(str)+":"+df3["Minute"].map(str) 


df3.drop(columns=["Timestamp2"])
df3['Timestamp'] =  pd.to_datetime(df3['Timestamp'], format='%Y-%m-%d' " ""%H:%M:%S")
df3['Timestamp'] = df3['Timestamp'].dt.tz_localize('Etc/GMT+3').dt.tz_convert('GMT')
df3['Year'] = df3['Timestamp'].dt.year 
df3['Month'] = df3['Timestamp'].dt.month 
df3['Day'] = df3['Timestamp'].dt.day 
df3['Hour'] = df3['Timestamp'].dt.hour 
df3['Minute'] = df3['Timestamp'].dt.minute
df3['Seconds'] = df3['Timestamp'].dt.second
    

df3['Minute'] = df3['Minute'].astype('str')
df3.Minute[df3.Minute == "0"] = "00"
df3= df3[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]


df3['Original_observed_value']= round(df3['Original_observed_value'],2)
df3['Observed_value']= round(df3['Observed_value'],1)

os.chdir("D:/All_Giessen_rescue_data/Giessen_new data_inida_sth_america/Chilean_sbdy/Chilean/Faro de la Punta de Caldera/sef/rh")

df3.to_csv("358-00002_relative_humidity_358_1875_21.csv", index=False, sep=",")






