export PREFIX=/data/
export lib_dir=/data/ops/lib/
export timestamp=2020102815
export run_status=sync

if [ "${run_status}" = "sync" ]
then
echo "Starting gen-info2sync-with-upd.sh" `date`
${lib_dir}gen-info2sync-with-upd.sh ${PREFIX} /data/backup/
fi

