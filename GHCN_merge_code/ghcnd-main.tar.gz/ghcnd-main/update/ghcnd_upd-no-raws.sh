#

export PREFIX=$1

run_status=$2

export lib_dir=$3

export minyr4update=`date -d "10 days ago" +%Y`

mmdd10daysago=`date -d "10 days ago" '+%m%d'`

if [ ${mmdd10daysago} = "0101" ]
then
run_checksize="no"
else
run_checksize="yes"
fi

find ${PREFIX}archive -maxdepth 1 -name '*inventory*.txt' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.log' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.flags' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.tar.gz' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.tar.gz.mnf' -mtime +31 -exec rm -f {} \;

export ftpdatapath="/pub/data/ghcn/daily"

export timestamp=`date -u '+%Y%m%d%H'`

sed 's/integer,parameter::iMinYr=1750/integer,parameter::iMinYr='${minyr4update}'/' ${lib_dir}ghcndmod.f95 > ${lib_dir}ghcndmod_update.f95

#echo "Starting compile-ghcnd.sh" `date`
#echo ghcndmod_update.f95 | ${PREFIX}compile-ghcnd.sh
#
echo "Starting get-latest-por-files.sh" `date`
${lib_dir}get-latest-por-files.sh ${PREFIX} /data/backup/

if [ -s ${PREFIX}new-por.txt ]
then
echo "Starting gen-stns2update.sh" `date`
${lib_dir}gen-stns2update.sh
fi

cd $PREFIX

#Get RAWS Data while getting and reformatting other data sources 

if [ -s ${PREFIX}raws/archive/last-date-in-archive.txt ]
then
lastrawsporyr=`cut -c1-4 ${PREFIX}raws/archive/last-date-in-archive.txt`
lastrawspormo=`cut -c5-6 ${PREFIX}raws/archive/last-date-in-archive.txt`
if [ "${lastrawspormo}" = "12" ]
then
firstrawsupdyr=`expr ${lastrawsporyr} + 1`
firstrawsupdmo="01"
else
firstrawsupdyr=${lastrawsporyr}
firstrawsupdmo=`expr ${lastrawspormo} + 1`
fi

firstrawsupdmo=`printf %02i ${firstrawsupdmo}`

#echo "Starting get-raws.sh" `date`
#${lib_dir}get-raws.sh ${PREFIX} ${lib_dir} upd ${firstrawsupdyr}${firstrawsupdmo}01 `echo ${timestamp} | cut -c1-8` &

fi

#Get the Australian data
#echo "Starting get-australia.sh" `date`
#${lib_dir}get-australia.sh ${PREFIX}
#echo "Starting gen-rawdata-australia.sh" `date`
#${lib_dir}gen-rawdata-australia.sh ${PREFIX} upd
#echo "Starting rf_australia2ghcnd.exe" `date`
#${lib_dir}rf_australia2ghcnd.exe ${PREFIX} &

echo "Starting get_hprcc.exe" `date`
${lib_dir}get_hprcc.exe $PREFIX

echo "Starting rf_hprcc2ghcnd.exe" `date`
${lib_dir}rf_hprcc2ghcnd.exe $PREFIX
tar czf ${PREFIX}hprcc/hprcc.archive.tar.gz ${PREFIX}hprcc_archive 
cp -p ${PREFIX}hprcc/hprcc.archive.tar.gz /ncdcftp/7days
cd ${PREFIX}hprcc
tar czf ${PREFIX}hprcc/hprcc-rawghcnd.tar.gz rawghcnd
cp -p ${PREFIX}hprcc/hprcc-rawghcnd.tar.gz /ncdcftp/7days
cd ${PREFIX}

echo "Starting get-cocorahs.exe" `date`
${lib_dir}get-cocorahs.exe ${PREFIX} ${minyr4update}0101 `echo ${timestamp} | cut -c1-8` &

echo "Starting get-snotel-nrcs-rf2ghcnd.exe" `date`
yyyy=`echo ${timestamp} | cut -c1-4`
mm=`echo ${timestamp} | cut -c5-6`
dd=`echo ${timestamp} | cut -c7-8`
${lib_dir}get-snotel-nrcs-rf2ghcnd.exe ${minyr4update}-01-01 ${yyyy}-${mm}-${dd} ${PREFIX}download/snotel/rawdata/ ${PREFIX}download/snotel/rawghcnd/ ${PREFIX}download/snotel/snotel-stations.txt ${PREFIX}download/snotel/snotel-match-list.txt
if [ ${run_checksize} = "yes" ]
then
echo "Starting update-archive-snotel.sh for snotel" `date`
${lib_dir}update-archive-snotel.sh ${PREFIX}download/snotel/rawghcnd ${PREFIX}snotel/rawghcnd '*.dly'
fi

echo "Starting get-isdsod.sh" `date`
${lib_dir}get-isdsod.sh ${PREFIX} ${minyr4update} `echo ${timestamp} | cut -c1-4`

${lib_dir}update-archive2.sh ${PREFIX}download/wsod ${PREFIX}wsod/isdsod/archive 'sod*.isd'

echo "Starting rf-isdsod2ghcnd.exe" `date`
${lib_dir}rf-isdsod2ghcnd.exe ${PREFIX} ${PREFIX}input4sys/wsod-stations-utc-offsets.txt

#Move the updated isdsod data to wsod/rawghcnd.  No need to cat with the maed data as in the por

if [ -s ${PREFIX}wsod/isdsod/rawghcnd ]
then
rm -rf ${PREFIX}wsod/rawghcnd
mv ${PREFIX}wsod/isdsod/rawghcnd ${PREFIX}wsod
fi

echo "Starting ghcn_canada.exe" `date`
${lib_dir}ghcn_canada.exe ${PREFIX}download/canada/ ${PREFIX}download/canada/rawghcnd/
cp -p ${PREFIX}download/canada/DailyClimateData.txt ${PREFIX}canada/archive/DailyClimateData-${timestamp}.txt
#echo "${PREFIX}download/canada/rawghcnd/" "${PREFIX}canada/archive/upd/rawghcnd/" | ${PREFIX}check_size.sh 
${lib_dir}update-archive.sh ${PREFIX}download/canada/rawghcnd ${PREFIX}canada/archive/upd/rawghcnd '*.dly'
echo "Copying ${PREFIX}canada/archive/upd/rawghcnd to ${PREFIX}canada/rawghcnd" `date`
rm -rf ${PREFIX}canada/rawghcnd
cp -rp ${PREFIX}canada/archive/upd/rawghcnd ${PREFIX}canada/rawghcnd

echo "Starting get_gsod.exe" `date`
${lib_dir}get_gsod.exe ${PREFIX}download/
echo "Starting check_size.sh for gsod" `date`
echo "${PREFIX}download/gsod/rawdata/" "${PREFIX}gsod/rawdata/" | ${lib_dir}check_size.sh
ls ${PREFIX}/gsod/rawdata > ${PREFIX}gsod.inv
echo "Starting rf_gsod2ghcnd.exe" `date`
${lib_dir}rf_gsod2ghcnd.exe $PREFIX

#Get the CRN data
echo "Starting get_crn.exe" `date`
${lib_dir}get_crn.exe ${PREFIX}download/
echo "Starting check_size.sh for crn" `date`
echo "${PREFIX}download/crn/rawdata/" "${PREFIX}crn/rawdata/" | ${lib_dir}check_size.sh 
echo "Starting rf_crn2ghcnd.exe" `date`
${lib_dir}rf_crn2ghcnd.exe $PREFIX

#Get the CF6 data
echo "Starting get-cf6.sh" `date`
${lib_dir}get-cf6.sh ${PREFIX} ${lib_dir}
echo "Starting rf-cf62ghcnd.exe" `date`
${lib_dir}rf-cf62ghcnd.exe ${PREFIX}
cd ${PREFIX}cf6
tar cvzf ${PREFIX}cf6/cf6.archive.tar.gz archive
cp -p  ${PREFIX}cf6/cf6.archive.tar.gz /ncdcftp/7days

#Create the CF6 data archive for transfer to reprocessing server
${lib_dir}transfer-cf6-archive.sh ${PREFIX}

#Wait until get-raws.sh and get-cocorahs.exe and rf_australia have finished before doing anything else
wait

#transfer new reformatted Australian data
${lib_dir}update-archive.sh ${PREFIX}download/australia/rawghcnd ${PREFIX}australia/rawghcnd '*.dly'

#Reformat RAWS data
#echo "Starting gen-rawdata-raws.sh" `date`
#${lib_dir}gen-rawdata-raws.sh

echo "Starting rf-raws2ghcnd.exe" `date`
${lib_dir}rf-raws2ghcnd.exe ${PREFIX}

echo "Starting rf-cocorahs2ghcnd.exe" `date`
${lib_dir}rf-cocorahs2ghcnd.exe ${PREFIX} 

#Mingle the data

echo "starting mingle.exe" `date`
${lib_dir}mingle.exe $PREFIX ${PREFIX}input4sys/mingle-list-update.txt

# PRE-FORMAT CHECK

echo "Starting pre format_check.exe" `date`
${lib_dir}format_check.exe pre ${PREFIX}input4sys/ghcnd-stations-update.txt ${PREFIX} ${PREFIX}mingled/ ${PREFIX}rawghcnd/ ${PREFIX}format_check_pre.log

# QC1, QC2 and QC3, etc.

echo "Starting qc1.exe" `date`
${lib_dir}qc1.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt M upd

echo "Starting rf_stn2time.exe" `date`
${lib_dir}rf_stn2time.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt

echo "Starting qc2.exe" `date`
${lib_dir}qc2.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt M upd

echo "Starting qc3.exe" `date`
${lib_dir}qc3.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt upd

echo "Starting post format_check.exe" `date`
${lib_dir}format_check.exe post ${PREFIX}input4sys/ghcnd-stations-update.txt ${PREFIX} ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

echo "Starting append_upd2por.exe" `date`
${lib_dir}append_upd2por.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations-update.txt 

echo "Starting to copy updated files from ghcnd_upd to ghcnd_all" `date`
cd ${PREFIX}ghcnd_upd
for i in *
do
  cp -p ${PREFIX}ghcnd_upd/$i ${PREFIX}ghcnd_all
done

echo "Starting make_gsn_hcn.exe" `date`
${lib_dir}make_gsn_hcn.exe $PREFIX upd

por_version=`cat ${PREFIX}input4sys/por-version.txt`
vernum=`cat ${PREFIX}input4sys/version-number.txt`

echo "The current version of GHCN Daily is $vernum-upd-$timestamp (i.e, an update that started at $timestamp [yyyymmddhh] UTC; yyyy=year; mm=month; dd=day; hh=hour)," > ${PREFIX}ghcnd-version.txt
echo "created by appending recently available data updates to the last fully reprocessed version: ${por_version}." >> ${PREFIX}ghcnd-version.txt

echo "Starting ghcnd_ftp.sh" `date`
${lib_dir}ghcnd_ftp.sh upd ${run_status}

echo "Starting ghcnd_archive.sh" `date`
${lib_dir}ghcnd_archive.sh upd ${run_status} /data/backup/latest/

#${lib_dir}monitor-sources.sh /data/ghcnd_all/ /data/ops/lib/

echo "ghcnd_upd.sh finshed at" `date`

