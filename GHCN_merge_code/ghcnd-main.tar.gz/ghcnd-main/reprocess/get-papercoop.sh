#Created by Menne/Durre summer 2011

PREFIX=$1

#
if [ -s ${PREFIX}download/papercoop ]
then
rm -r ${PREFIX}download/papercoop
fi

mkdir -p ${PREFIX}download/papercoop/tmp 

wget -o${PREFIX}download/get-papercoop.ftp.log -P${PREFIX}download/papercoop/tmp ftp://ncdcftp.ncdc.noaa.gov/pub/upload/7days/keyed_daily.*.*.ghcnd.tar.gz 

${PREFIX}update-archive.sh ${PREFIX}download/papercoop/tmp ${PREFIX}papercoop/archive 'keyed_daily.*.*.ghcnd.tar.gz'

rm -rf ${PREFIX}papercoop/rawdata
mkdir -p ${PREFIX}papercoop/rawdata

for i in `ls ${PREFIX}papercoop/archive/keyed_daily.*.*.ghcnd.tar.gz`
  
do

tar xzf $i -C ${PREFIX}papercoop/rawdata

done 

ls -1 ${PREFIX}papercoop/rawdata/* | grep dly | sort -u > ${PREFIX}papercoop-rawdata.inv

