# lambda_function.py
# This file acts as the single entry point for the container.
# It imports the handlers from the other scripts so we can specify them
# in the Lambda function configuration.

from producer import lambda_handler as producer_handler
from sqs_trigger import lambda_handler as sqs_trigger_handler
from start_job import lambda_handler as start_job_handler
from process_chunk import lambda_handler as process_chunk_handler
from consolidate import lambda_handler as consolidate_handler