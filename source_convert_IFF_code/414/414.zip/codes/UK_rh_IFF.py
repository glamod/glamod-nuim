#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Relative humidity IFF code for ALL stations
One output file per station
"""

import pandas as pd
import os
import re
import glob

SOURCE_ID = "414"

STATIONDATA_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/midas_uk-hourly-weather-obs_v202507_FLAT/midas_uk-hourly-weather-obs_v202507/stationdata"

OUTDIR = os.path.join(STATIONDATA_DIR, "IFF_relative_humidity_ALL_STATIONS")
os.makedirs(OUTDIR, exist_ok=True)

# clear old outputs
for f in glob.glob(os.path.join(OUTDIR, "*.psv")):
    os.remove(f)

POSSIBLE_RH_COLS = [
    "rltv_hum", "relative_humidity", "rh", "rel_hum", "humidity"
]

DATE_COLS = ["ob_time", "ob_end_time", "time", "date", "Date"]

UNIT = "%"


# ---------- HELPERS ----------

def get_csv_cell(line, idx):
    return line.split(",")[idx].strip()


def get_station_name(filename, station_id):
    base = os.path.basename(filename).replace(".csv", "")
    match = re.search(rf"_{station_id}_(.*?)_qcv", base)
    return match.group(1).replace("_", "-").title() if match else station_id


def find_column(cols, possible_cols):
    cols = [str(c).strip() for c in cols]
    for col in possible_cols:
        if col in cols:
            return col
    return None


def parse_datetime(series):
    return pd.to_datetime(series, errors="coerce", dayfirst=True)


def clean_numeric(series):
    s = series.astype(str).str.strip()

    s = s.replace(["", "NA", "N/A", "NaN", "nan", "NULL", "null", "--", "-", ".", "-.", "*"], pd.NA)
    s = s.str.replace(r"[^0-9.\-]", "", regex=True)

    out = pd.to_numeric(s, errors="coerce")
    out = out.mask(out.isin([-9999, -999, -99]))

    return out


# ---------- MAIN ----------

station_folders = sorted([
    f for f in glob.glob(os.path.join(STATIONDATA_DIR, "*"))
    if os.path.isdir(f) and os.path.basename(f).isdigit()
])

print(f"Total stations: {len(station_folders)}")

saved = 0

for station_folder in station_folders:

    station_id = os.path.basename(station_folder)
    csv_files = glob.glob(os.path.join(station_folder, "*.csv"))

    station_data = []

    for FILE in csv_files:

        try:
            meta = pd.read_csv(FILE, nrows=20, header=None)
            lat = pd.to_numeric(meta.iloc[16, 2], errors="coerce")
            lon = pd.to_numeric(meta.iloc[16, 3], errors="coerce")
            elev = pd.to_numeric(meta.iloc[17, 2], errors="coerce")
        except:
            continue

        station_name = get_station_name(FILE, station_id)

        try:
            header = pd.read_csv(FILE, skiprows=283, nrows=0).columns
            header = [str(c).strip() for c in header]
        except:
            continue

        rh_col = find_column(header, POSSIBLE_RH_COLS)
        date_col = find_column(header, DATE_COLS)

        if not rh_col or not date_col:
            continue

        try:
            df = pd.read_csv(FILE, skiprows=283, usecols=[date_col, rh_col])
        except:
            continue

        df["Date"] = parse_datetime(df[date_col])
        df["Observed_value"] = clean_numeric(df[rh_col]).round(0)

        df = df.dropna(subset=["Date", "Observed_value"])

        if df.empty:
            continue

        df["Observed_value"] = df["Observed_value"].astype("Int64")
        df["Original_observed_value"] = df["Observed_value"]
        df["Original_observed_value_units"] = UNIT

        df["Source_ID"] = SOURCE_ID
        df["Station_ID"] = station_id
        df["Station_name"] = station_name
        df["Alias_station_name"] = ""

        df["Year"] = df["Date"].dt.year
        df["Month"] = df["Date"].dt.month
        df["Day"] = df["Date"].dt.day
        df["Hour"] = df["Date"].dt.hour.fillna(0)
        df["Minute"] = df["Date"].dt.minute.fillna(0)

        df["Latitude"] = lat
        df["Longitude"] = lon
        df["Elevation"] = elev

        df["Source_QC_flag"] = ""
        df["Report_type_code"] = ""
        df["Measurement_code_1"] = ""
        df["Measurement_code_2"] = ""

        df = df[[
            "Source_ID","Station_ID","Station_name","Alias_station_name",
            "Year","Month","Day","Hour","Minute",
            "Latitude","Longitude","Elevation",
            "Observed_value","Source_QC_flag",
            "Original_observed_value","Original_observed_value_units",
            "Report_type_code","Measurement_code_1","Measurement_code_2"
        ]]

        station_data.append(df)

    if not station_data:
        continue

    station_df = pd.concat(station_data)

    station_df = station_df.sort_values(["Year","Month","Day","Hour","Minute"])

    outname = f"{station_id}_relative_humidity_{SOURCE_ID}.psv"
    station_df.to_csv(os.path.join(OUTDIR, outname), sep="|", index=False)

    saved += 1
    print(f"Saved: {outname}")

print("\nDONE")
print(f"Stations saved: {saved}")