#

export PREFIX=$1

export timestamp=`date -u '+%Y%m%d%H'`

echo "Starting compile-ghcnd.sh" `date`
echo ghcndmod.f95 | ${PREFIX}compile-ghcnd.sh

# FORMAT CHECK

# QC1, QC2 and QC3

echo "Starting qc1.exe" `date`
${PREFIX}qc1.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations.txt M por

echo "Starting post format_check.exe" `date`
${PREFIX}format_check.exe post ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}qc1out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

echo "ghcnd_por.sh finished at" `date`
