run_status="sync"
export timestamp="2014091913"
export PREFIX="/home/mmenne/ghcnd2/"

vernum=`cat ${PREFIX}input4sys/version-number.txt`

#echo $vernum-por-$timestamp > ${PREFIX}input4sys/por-version.txt
echo "The current version of GHCN Daily is $vernum-por-$timestamp (i.e, a period of record reprocess that started at $timestamp [yyyymmddhh] UTC; yyyy=year; mm=month; dd=day; hh=hour)." > ${PREFIX}ghcnd-version.txt

echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh por ${run_status} /home/mmenne/backup/ghcnd2/

echo "Starting genclim.exe" `date`
${PREFIX}genclim.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations.txt

if [ "${run_status}" = "sync" ]
then
echo "Starting gen-info2sync-with-upd.sh" `date`
${PREFIX}gen-info2sync-with-upd.sh ${PREFIX} /home/mmenne/backup/ghcnd2/
fi

echo "ghcnd_por.sh finished at" `date`
