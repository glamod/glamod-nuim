refresh_dir=$1

mod_dir=/home/mmenne/ghcnd/

lf95path=/usr/local/lf6480/bin/

${lf95path}lf95 ${mod_dir}ghcndmod.f95 ${refresh_dir}gen-wmo-stninfo.f95 -o ${refresh_dir}gen-wmo-stninfo.exe
${lf95path}lf95 ${mod_dir}ghcndmod.f95 ${refresh_dir}pre_screen.f95 -o ${refresh_dir}pre_screen.exe --ap
${lf95path}lf95 ${mod_dir}ghcndmod.f95 ${refresh_dir}intrasource_dupchk.f95 -o ${refresh_dir}intrasource_dupchk.exe --ap
${lf95path}lf95 ${mod_dir}ghcndmod.f95 ${refresh_dir}strip_source.f95 -o ${refresh_dir}strip_source.exe 
${lf95path}lf95 ${mod_dir}ghcndmod.f95 ${refresh_dir}gen-wmo-xref.f95 -o ${refresh_dir}gen-wmo-xref.exe 
${lf95path}lf95 ${mod_dir}ghcndmod.f95 ${refresh_dir}genDataXref.f95 -o ${refresh_dir}genDataXref.exe --ap
${lf95path}lf95 ${mod_dir}ghcndmod.f95 ${refresh_dir}add_stns.f95 -o ${refresh_dir}add_stns.exe 



