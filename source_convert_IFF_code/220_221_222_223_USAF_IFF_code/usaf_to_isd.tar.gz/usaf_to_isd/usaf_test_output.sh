#!/bin/bash
# This is a convenience script for comparing USAF ISD output to expected output.
# It could be used for other formats too but is speficially engineered for the 
# purpose of USAF->ISD formatting code due to the need to ignore characters 8-15
# in the comparisons. We intentionally do not convert our ID strings in the same
# way as the original code and therefore must remove those characters before 
# comparing. To use this script:
#
# ./usaf_test_compare.sh path/to/expected_output_filename path/to/generated_output_filename
#
# Optional 'vimdiff' argument can be used to use the visual display vimdiff in
# additionto creating a standard diff output file.

# Usage statement output if both arguments are not given
display_usage(){
        echo This script requires two input parameters, the locations of the two files to be compared.
        echo A third optional parameter of \'vimdiff\' will cause the visual display vimdiff to be used 
        echo in addition to creating a standard diff output file.
        echo
        echo USAGE: ./usaf_test_compare.sh path/to/filename1 path/to/filename2
        echo '      ./usaf_test_compare.sh path/to/filename1 path/to/filename2 vimdiff '
}

# Check that two filename arguments are supplied and display usage and exit if not.
if [  $# -le 1 ] 
	then 
		display_usage
		exit 1
	else
		echo Comparing files $1 and $2 while disregarding characters 8-15 which are expected to differ.
fi 

# Copying file to this directory for comparison
cp $1 prod_output.compare
cp $2 dev_output.compare

dos2unix -n prod_output.compare prod_output.compare.convert
dos2unix -n dev_output.compare dev_output.compare.convert

# Sorting lines to better match output lines
sort prod_output.compare.convert > prod_output_sorted.compare
sort dev_output.compare.convert > dev_output_sorted.compare

# Removing characters 8-15 which are known to use different ID strings
cut -c8-15 --complement prod_output_sorted.compare > prod_output_sorted_altered.compare
cut -c8-15 --complement dev_output_sorted.compare > dev_output_sorted_altered.compare
#cp prod_output_sorted.compare prod_output_sorted_altered.compare
#cp dev_output_sorted.compare dev_output_sorted_altered.compare

# Diff the altered output files
diff --suppress-common-lines prod_output_sorted_altered.compare dev_output_sorted_altered.compare > compare_diff.out

# Add 3rd command line argument "vimdiff" for visual diff output.
if [ $3 == "vimdiff" ]
	then
		vimdiff prod_output_sorted_altered.compare dev_output_sorted_altered.compare
fi

# Delete all the .compare files created for this script
echo Cleaning up temporary comparison files....
rm *.compare*

# Process complete
echo "DIFF COMPLETE"

