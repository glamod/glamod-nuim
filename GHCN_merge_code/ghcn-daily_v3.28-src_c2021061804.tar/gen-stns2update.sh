rm -f ${PREFIX}input4sys/ghcnd-stations-update.txt
rm -f ${PREFIX}input4sys/mingle-list-update.txt

for i in `gawk '$6>="'${minyr4update}'" {print $1}' ${PREFIX}ghcnd-inventory.txt | sort -u`

do
  grep "^$i" ${PREFIX}input4sys/ghcnd-stations.txt >> ${PREFIX}input4sys/ghcnd-stations-update.txt
  grep "^$i" ${PREFIX}input4sys/mingle-list.txt >> ${PREFIX}input4sys/mingle-list-update.txt
done


  
