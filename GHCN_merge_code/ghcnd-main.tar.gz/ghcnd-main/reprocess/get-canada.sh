#

if [ -s ${PREFIX}download/canada ]
then
rm -r ${PREFIX}download/canada
fi

mkdir ${PREFIX}download/canada

wget -o${PREFIX}download/get_canada.ftp.log -P${PREFIX}download/canada ftp://ncdcftp.ncdc.noaa.gov/pub/upload/7days/ca.ghcnd.tar.gz 

mkdir ${PREFIX}download/canada/rawghcnd

tar xzf ${PREFIX}download/canada/ca.ghcnd.tar.gz -C ${PREFIX}download/canada/rawghcnd 

if [ ! -s ${PREFIX}canada ]
then
mkdir ${PREFIX}canada
fi

echo "${PREFIX}download/canada/rawghcnd/" "${PREFIX}canada/archive/upd/rawghcnd/" | ${PREFIX}check_size.sh 



