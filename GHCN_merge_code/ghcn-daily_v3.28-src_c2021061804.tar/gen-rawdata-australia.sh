PREFIX=$1
mode=$2

yr=`date "+%Y"`

rm -rf ${PREFIX}australia/rawdatarain
rm -rf ${PREFIX}australia/rawdatatemps

if [ "${mode}" = "por" ]
then

mkdir -p ${PREFIX}australia/rawdatarain/183201
mkdir -p ${PREFIX}australia/rawdatatemps/183201

for i in ${PREFIX}australia/cd_archive/*ain*; do unzip -q -d${PREFIX}australia/rawdatarain/183201 "$i"; done
for i in ${PREFIX}australia/cd_archive/*emp*; do unzip -q -d${PREFIX}australia/rawdatatemps/183201 "$i"; done

for i in ${PREFIX}australia/patch_archive/*ain*; do unzip -q -d${PREFIX}australia/rawdatarain/200701 "$i"; done
for i in ${PREFIX}australia/patch_archive/*emp*; do unzip -q -d${PREFIX}australia/rawdatatemps/200701 "$i"; done

ls ${PREFIX}australia/update_archive > ${PREFIX}australia.zip.upd.archive.inv

for i in `grep emp ${PREFIX}australia.zip.upd.archive.inv`
do
yrmo=`echo $i | cut -c11-16`
mkdir -p ${PREFIX}australia/rawdatatemps/$yrmo
unzip -q -d${PREFIX}australia/rawdatatemps/$yrmo ${PREFIX}australia/update_archive/$i
done

for i in `grep ain ${PREFIX}australia.zip.upd.archive.inv`
do
yrmo=`echo $i | cut -c11-16`
mkdir -p ${PREFIX}australia/rawdatarain/$yrmo
unzip -q -d${PREFIX}australia/rawdatarain/$yrmo ${PREFIX}australia/update_archive/$i
done

mkdir -p ${PREFIX}australia/rawdatarain/daily
mkdir -p ${PREFIX}australia/rawdatatemps/daily

for i in ${PREFIX}australia/daily_update_archive/*rain*; do unzip -q -d${PREFIX}australia/rawdatarain/daily/ "$i"; done
for i in ${PREFIX}australia/daily_update_archive/*mmt*; do unzip -q -d${PREFIX}australia/rawdatatemps/daily/ "$i"; done

rm -f ${PREFIX}australia/rain-files.inv
rm -f ${PREFIX}australia/temps-files.inv

for i in `ls ${PREFIX}australia/rawdatarain`
do 
ls ${PREFIX}australia/rawdatarain/$i >> ${PREFIX}australia/rain-files.inv
done
grep -v Notes ${PREFIX}australia/rain-files.inv | grep -v StnDet | cut -c12-17 | sort -u > ${PREFIX}australia.rain.archive.inv

for i in `ls ${PREFIX}australia/rawdatatemps`
do 
ls ${PREFIX}australia/rawdatatemps/$i >> ${PREFIX}australia/temps-files.inv
done
grep -v Notes ${PREFIX}australia/temps-files.inv | grep -v StnDet | cut -c12-17 | sort -u > ${PREFIX}australia.temps.archive.inv

elif [ "${mode}" = "upd" ]
then

mkdir -p ${PREFIX}australia/rawdatarain/daily
mkdir -p ${PREFIX}australia/rawdatatemps/daily

rm -f ${PREFIX}australia/rain-files.inv
rm -f ${PREFIX}australia/temps-files.inv

for i in ${PREFIX}australia/daily_update_archive/*rain*; do unzip -q -d${PREFIX}australia/rawdatarain/daily/ "$i"; done
for i in ${PREFIX}australia/daily_update_archive/*mmt*; do unzip -q -d${PREFIX}australia/rawdatatemps/daily/ "$i"; done

for i in `ls ${PREFIX}australia/rawdatarain`
do 
ls ${PREFIX}australia/rawdatarain/$i >> ${PREFIX}australia/rain-files.inv
done
grep -v Notes ${PREFIX}australia/rain-files.inv | grep -v StnDet | cut -c12-17 | sort -u > ${PREFIX}australia.rain.archive.inv

for i in `ls ${PREFIX}australia/rawdatatemps`
do 
ls ${PREFIX}australia/rawdatatemps/$i >> ${PREFIX}australia/temps-files.inv
done
grep -v Notes ${PREFIX}australia/temps-files.inv | grep -v StnDet | cut -c12-17 | sort -u > ${PREFIX}australia.temps.archive.inv

fi
