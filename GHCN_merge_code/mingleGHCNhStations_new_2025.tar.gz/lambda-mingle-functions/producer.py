# producer.py
import json
import boto3
import os
import logging
import time # Import the time module

logger = logging.getLogger()
logger.setLevel(logging.INFO)

SQS_QUEUE_URL = os.environ.get("SQS_QUEUE_URL")
STATION_FILE = "stations_to_process.txt"

sqs = boto3.client("sqs")

def lambda_handler(event, context):
    station_count = 0
    
    # A good submission rate to start with is 5-10 messages per second.
    # 0.2 seconds = 5 messages per second.
    # 0.1 seconds = 10 messages per second.
    SUBMISSION_DELAY_SECONDS = 0.2 

    script_dir = os.environ.get("LAMBDA_TASK_ROOT", ".")
    station_file_path = os.path.join(script_dir, STATION_FILE)
    logger.info(f"Reading stations from: {station_file_path}")

    with open(station_file_path, "r") as f:
        for station_id in f:
            station_id = station_id.strip()
            if not station_id:
                continue

            message_body = {"station_id": station_id}

            sqs.send_message(
                QueueUrl=SQS_QUEUE_URL,
                MessageBody=json.dumps(message_body)
            )
            station_count += 1
            
            # THE FIX: Add a small delay after sending each message
            time.sleep(SUBMISSION_DELAY_SECONDS)

    logger.info(f"Successfully submitted {station_count} station jobs to the queue.")
    return {"status": "success", "stations_submitted": station_count}