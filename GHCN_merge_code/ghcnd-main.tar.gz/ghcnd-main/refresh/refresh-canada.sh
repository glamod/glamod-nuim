# Written by Menne/Durre Sept. 2013
ghcnd_list_dir=$1 # directory from which GHCN-Daily and mingle lists should be taken
module=$2
dsi=canada # 1-to-15 character data set identifier used in subdirectory and station list names
src_code=C # one-character code used as source flag in GHCN-Daily files
refresh_dir=${HOME}/ghcnd/makelist/

echo "Untarring rawghcnd source directories on " `date`
${refresh_dir}untar-sources-rawghcnd.sh ${refresh_dir}source-list.txt /home/mmenne/backup/ghcnd2/ ${refresh_dir}

echo "Getting earliest year of data for source ${dsi}" `date`
cut -c12-15 ${refresh_dir}${dsi}/rawghcnd/* | sort -u > ${refresh_dir}${dsi}-years.txt 
firstyear=`head -1 ${refresh_dir}${dsi}-years.txt`
sed 's/integer,parameter::iMinYr=1750/integer,parameter::iMinYr='${firstyear}'/' ${refresh_dir}ghcndmod.f95 > ${refresh_dir}ghcndmod4refresh.f95
#${refresh_dir}compile-refresh-canada.sh ${refresh_dir} ${refresh_dir}ghcndmod4refresh.f95

if [ ! -s ${refresh_dir}canada/archive/por/get_canada_por.log ] 
then
echo "${refresh_dir}canada/archive/por/get_canada_por.log does not exist...stopping"
exit
fi
if [ ! -s ${refresh_dir}canada/archive/por/ca.por.ghcnd ] 
then
echo "${refresh_dir}canada/archive/por/ca.por.ghcnd does not exist...stopping"
exit
fi

${refresh_dir}rf-canada-log.exe ${refresh_dir}canada/archive/por/get_canada_por.log ${refresh}canada/canada-md.txt

if [ ! -s ${refresh_dir}canada/canada-md.txt ] 
then
echo "${refresh_dir}canada/canada-md.txt does not exist...stopping"
exit
fi

rm -rf ${refresh_dir}canada/rawghcnd
mkdir -p ${refresh_dir}canada/rawghcnd

for i in `cat ${refresh_dir}canada/archive/por/ca.por.ghcnd ${refresh_dir}canada/canada-md.txt | cut -c1-11 | sort -u` 
do 
grep "^$i" ${refresh_dir}canada/archive/por/ca.por.ghcnd > ${refresh_dir}canada/tmp.dly
grep "^$i" ${refresh_dir}canada/canada-md.txt >> ${refresh_dir}canada/tmp.dly
sort -n -k1.12,1.15 -n -k1.16,1.17 -k 1.18,1.21 ${refresh_dir}canada/tmp.dly > ${refresh_dir}canada/rawghcnd/$i.dly 
done

#Keep a copy of last ${dsi} list of stations with data
cp -p ${refresh_dir}${dsi}.inv ${refresh_dir}${dsi}.inv.old
ls ${refresh_dir}${dsi}/rawghcnd | cut -c1-11 > ${refresh_dir}${dsi}.inv

#wget the Canadian station catalogue
cp -p ${refresh_dir}station_data_catalogue.txt ${refresh_dir}station_data_catalogue.old
wget -N -P${refresh_dir} ftp://arcdm20.tor.ec.gc.ca/pub/doc/station_catalogue/station_data_catalogue.txt   

mv -f ${refresh_dir}${dsi}-stations.txt ${refresh_dir}${dsi}-stations.old

echo "Starting gen-canada-stninfo.exe on " `date`
${refresh_dir}gen-canada-stninfo.exe ${dsi} ${refresh_dir} 
if [ ! -s ${refresh_dir}${dsi}-stations.txt ]
then
echo "${dsi}-stations.txt was not created...exiting script" `date`
exit
fi
echo "Starting pre_screen.exe for ${dsi} on" `date`
${refresh_dir}pre_screen.exe ${refresh_dir}${dsi}/ ${refresh_dir}${dsi}-stations.txt ${dsi}
echo "Starting intrasource_dupchk.exe on" `date`
${refresh_dir}intrasource_dupchk.exe ${refresh_dir}${dsi}/ ${refresh_dir}${dsi}-stations-prescreened.txt ${dsi}

echo "Starting strip_source.exe on" `date`
${refresh_dir}strip_source.exe ${src_code} ${refresh_dir}mingle-list.txt ${refresh_dir}ghcnd-stations.txt 

echo "Starting mingle.exe to create version of GHCN-Daily without ${dsi} on " `date`
${refresh_dir}mingle.exe ${refresh_dir} ${refresh_dir}mingle-list-no-${src_code}.txt 

echo "Creating input for gen-data-xref " `date`
rm -f ${refresh_dir}${dsi}.*xref 
touch -a ${refresh_dir}${dsi}.id.xref 
gawk 'substr($0,12,1)==" " {print substr($0,1,11)}' ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt > ${refresh_dir}${dsi}.id.noxref

#First subset ghcnd-stations.txt list to limit data matching to the geography covered by Canadian data
gawk '$2>40 && $3>-150 && $3<15 {print $0}' ${refresh_dir}ghcnd-stations-no-C.txt > ${refresh_dir}ghcnd-stations-4canadadataxref.txt

echo "Starting gen-data-xref.exe on" `date`
#${refresh_dir}gen-data-xref.exe ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${src_code} ${operational_dir}ghcnd_por/ ${data_base_dir}${dsi}/rawghcnd/ ${refresh_dir}${dsi}.id.noxref ${refresh_dir}datamatchinfo/ ${refresh_dir}${dsi}.data.xref
${refresh_dir}gen-data-xref.exe ${refresh_dir}ghcnd-stations-4canadadataxref.txt ${src_code} ${refresh_dir}mingled/ ${refresh_dir}${dsi}/rawghcnd/ ${refresh_dir}${dsi}.id.noxref ${refresh_dir}datamatchinfo/ ${refresh_dir}${dsi}.data.xref ${refresh_dir}${dsi}.data.noxref

echo "catting ${dsi}.id.xref and ${dsi}.data.xref" `date`
cat ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.data.xref > ${refresh_dir}${dsi}.xref

echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${src_code} ${refresh_dir}${dsi}.xref ${refresh_dir}input4refresh/mingle-list-custom.txt
echo "Number of stations in ghcnd-stations" `wc ${refresh_dir}ghcnd-stations.txt | cut -c1-7`

echo "Setting GSN and HCN fields on " `date`
mv ${refresh_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.4gsn

echo "Starting setGSNfield.exe on" `date`
${refresh_dir}setGSNfield.exe ${refresh_dir}gsn-ids.txt ${refresh_dir}ghcnd-stations.4gsn ${refresh_dir}ghcnd-stations.4hcn
echo "Starting setHCNfield.exe on" `date`
${refresh_dir}setHCNfield.exe ${refresh_dir}ushcn-ids.txt ${refresh_dir}ghcnd-stations.4hcn ${refresh_dir}ghcnd-stations.txt

echo "Removing temporary directories on " `date`
${refresh_dir}remove-sources-rawghcnd.sh ${refresh_dir}source-list.txt ${refresh_dir}
rm -r ${refresh_dir}${dsi}
