#Script for generating a list of station/year/months that have problems with
# the timing of daily maximum or minimum temperatures

export PREFIX=$1

export maxyr=`date +%Y`

echo 'starting get-mshr.sh at' `date`
${PREFIX}get-mshr.sh ${PREFIX}input4sys/

#First download isd-lite for U.S. stations
echo "Starting get-isd-lite.sh" `date`
${PREFIX}get-isd-lite.sh

echo "Starting rf_isd2day.exe" `date`
${PREFIX}rf_isd2day.exe ${PREFIX}

echo "Starting check4timing.exe" `date`
${PREFIX}check4timing.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX}input4sys/MASTER-STN-HIST.TXT ${PREFIX}ish-history-us-data.txt

if [ -s ${PREFIX}check4timing.flags ]
then
find ${PREFIX} -name "check4timing.flags.new" -newer ${PREFIX}"check4timing.flags" \! -empty -exec mv {} ${PREFIX}"check4timing.flags" \;
else
mv ${PREFIX}check4timing.flags.new ${PREFIX}check4timing.flags
fi
