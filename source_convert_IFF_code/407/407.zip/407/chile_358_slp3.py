#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'

OUTDIR = ("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Chilean_sbdy_/Chilean/Constitucion_merge/IFF/slp")
os.chdir("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Chilean_sbdy_/Chilean/Constitucion_merge")

df=pd.read_csv("const_master.csv",skiprows = 0) 
df["Source_ID"]="407"
df["Station_ID"]="407-00001"
df["Alias_station_name"]=""
df["Station_name"]="Constitucion"
df["Latitude"]= "-35.4"
df["Longitude"]= "-72.4"
df["Elevation"]= "14"
df['Year'] = df["a"]
df['Month'] = df['b'] 
df['Day'] = df['c']
df = df.dropna(subset=["d"])  # Drop rows with NaN in column 'd'
df = df[df["d"] != float('inf')]  # Drop rows with 'inf' values in column 'd'
df = df[df["d"] != -float('inf')]  # Drop rows with '-inf' values in column 'd'
df["Hour"] = df["d"].astype(int)

df["Minute"]=""
df["Source_QC_flag"]=""
df['Original_observed_value_units']="inhg"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''
df['Original_observed_value']=''
df['Observed_value']=df['p']
df["Original_observed_value"]=df["Observed_value"]
df["Observed_value"] = pd.to_numeric(df["Observed_value"],errors='coerce')
#df["Observed_value"]=df["Observed_value"]* 1.3332239 
df["Observed_value"] = df["Observed_value"] * 33.8639

df = df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]



df=df.dropna(subset = ['Observed_value'])
df["Minute"] ="00"

# Create the Timestamp column by combining Year, Month, Day, Hour, and Minute
df["Timestamp2"] = (
 df["Year"].map(str) + "-" + 
 df["Month"].map(str) + "-" + 
 df["Day"].map(str)
)
df["Timestamp"] = (
 df["Timestamp2"] + " " + 
 df["Hour"].map(str) + ":" + 
 df["Minute"].map(str)
)
df =df.drop(columns=["Timestamp2"])

# Convert the Timestamp column to datetime
df['Timestamp'] = pd.to_datetime(df['Timestamp'], format='%Y-%m-%d %H:%M')

# Localize and convert timezone
df['Timestamp'] =df['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')

# Extract datetime components
df['Year'] =df['Timestamp'].dt.year
df['Month'] =df['Timestamp'].dt.month
df['Day'] =df['Timestamp'].dt.day
df['Hour'] =df['Timestamp'].dt.hour
df['Minute'] =df['Timestamp'].dt.minute
df['Seconds'] =df['Timestamp'].dt.second
df =df.sort_values(by='Timestamp')


df =df.drop(columns="Timestamp")
df['Minute']='00'
df['Observed_value'] =df['Observed_value'].round(1)
df =df.astype(str)
df =df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]



# Generate the file name dynamically based on Station_ID
station_id =df['Station_ID'].iloc[0]  # Assuming Station_ID is a column in your DataFrame
file_name = f"{station_id}_station_level_pressure_a_407.psv"

# Full path for the file
file_path = os.path.join(OUTDIR, file_name)

# Save the DataFrame to a pipe-delimited file
df.to_csv(file_path, sep='|', index=False)

print(f"File saved successfully to: {file_path}")








