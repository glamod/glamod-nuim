#modified by Menne 01/29/2014 to ensure that RAWS stations are included in stations to update
#even when end year in the inventory does not yest include minyr4update.  Essentially, the 
#por process will 35 days behind the update process for RAWS data, which causes a delay in
#getting RAWS at the start of a new year

PREFIX=/data/

minyr4updatelist=`date -d "865 days ago" +%Y`

rm -f ${PREFIX}input4sys/ghcnd-stations-update.tmp
rm -f ${PREFIX}input4sys/mingle-list-update.tmp

rm -f ${PREFIX}input4sys/ghcnd-stations-update.txt
rm -f ${PREFIX}input4sys/mingle-list-update.txt

for i in `gawk '$6>="'${minyr4updatelist}'" {print $1}' ${PREFIX}ghcnd-inventory.txt | sort -u`

do
  grep "^$i" ${PREFIX}input4sys/ghcnd-stations.txt >> ${PREFIX}input4sys/ghcnd-stations-update.tmp
  grep "^$i" ${PREFIX}input4sys/mingle-list.txt >> ${PREFIX}input4sys/mingle-list-update.tmp
done

#for i in `grep "^USR" ${PREFIX}input4sys/ghcnd-stations.txt | cut -c1-11`

#do
#  grep "^$i" ${PREFIX}input4sys/ghcnd-stations.txt >> ${PREFIX}input4sys/ghcnd-stations-update.tmp
#  grep "^$i" ${PREFIX}input4sys/mingle-list.txt >> ${PREFIX}input4sys/mingle-list-update.tmp
#done

sort -u ${PREFIX}input4sys/ghcnd-stations-update.tmp > ${PREFIX}input4sys/ghcnd-stations-update.txt
sort -u ${PREFIX}input4sys/mingle-list-update.tmp > ${PREFIX}input4sys/mingle-list-update.txt 


  
