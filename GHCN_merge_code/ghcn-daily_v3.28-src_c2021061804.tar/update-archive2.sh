#!/bin/sh
# Update the archive directory of a data source with files from the corresponding download directory that 
# (1) are not yet in the archive directory or 
# (2) have been updated, and 
# (3) have a larger file size than the file with the same name in the archive

# Interpret arguments
download=$1  # directory where newly downloaded files are temporarily stored 
archive=$2  # directory where downloaded files are archived
findstring=$3  # portion of file names to consider copying; may include wildcards

# Check whether the specified download and archive directories exist.
 if [ ! -s ${download} ] 
 then 
 echo "${download} must exist. Terminating 
 update-archive.sh..." 
 exit 
fi

if [ ! -s ${archive} ] 
 then 
 echo "${archive} did not exist yet."
echo "Update-archive2.sh copied all of ${download}." 
 mv ${download} ${archive} 
 exit 
fi

# Identify the most recently modified file in the archive directory.
newest=`ls -r -t ${archive}/${findstring} | xargs -n1 basename | tail -1`
#count=`ls -r -t ${archive} | wc | cut -c1-7`
#echo "The most recently modified of the ${count} files in the archive was ${newest}."

cwd=`pwd`
cd ${download}
numnewer="$(find . -maxdepth 1 -name "${findstring}" -type f -newer ${archive}/${newest} \! -empty | wc | gawk '{print $1}')"

if [ $numnewer = 0 ]
then
echo "Update-archive2.sh moved no files from ${download}."
else

# Find all downloaded files whose modification date is later than the latest
# modification date in the archive directory and that are not empty and move
# them to the archive directory.

num_moved=0
for file in `find . -maxdepth 1 -name "${findstring}"  -type f -newer ${archive}/${newest} \! -empty | xargs -n1 basename`
do
#get size of old file (if it exists)
oldsize=0
if [ -s $archive/${file} ]
then
oldsize="$(/usr/bin/du -b ${archive}/${file} | gawk '{print $1}')"
fi
#get size of file we are looking to move
newsize=0
if [ -s ${download}/${file} ]
then
newsize="$(/usr/bin/du -b ${download}/${file} | gawk '{print $1}')"
fi

sizediff=`expr $oldsize - $newsize`
if [ $sizediff -gt 10000 ] 
then
echo "WARNING from update-archive2.sh!!! ${download}/${file} is smaller than ${archive}/${file}...keeping ${archive}/${file}"
else
mv ${download}/${file} ${archive}/${file}
#echo "update-archive2.sh moved ${download}/${file} to ${archive}"
num_moved=$[num_moved + 1]
fi

done
echo "update-archive2.sh evaluated $numnewer files in ${download} and moved ${num_moved} to ${archive}." 
fi
cd $cwd

# Print out final message from the script.
newest2=`ls -l -r -t ${archive}/${findstring} | tail -1`
count1=`ls -r -t ${archive} | wc | gawk '{print $1}'`
count2=`ls -r -t ${archive}/${findstring} | wc | gawk '{print $1}'`
echo "The directory ${archive} now contains ${count1} files and ${count2} match the string ${findstring}"  
echo "The most recently modified of the archive file(s) that match ${findstring} is: ${newest2}"
