# download ECA data for GHCN-Daily.
# created 16 November 2010 by Imke Durre

PREFIX=$1

# if the ECA download directory exists, remove it.
if [ -s ${PREFIX}download/eca ]
then
rm -rf ${PREFIX}download/eca
fi

# re-create the directory.
mkdir -p ${PREFIX}download/eca

# download the desired files:

# get daily precipitation:
wget -o${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_rr.zip https://knmi-ecad-assets-prd.s3.amazonaws.com/download/ECA_nonblend_rr.zip
#wget -o${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_rr.zip http://eca.knmi.nl/utils/downloadfile.php?file=download/ECA_nonblend_rr.zip
# get daily snow depth:
wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_sd.zip https://knmi-ecad-assets-prd.s3.amazonaws.com/download/ECA_nonblend_sd.zip
#wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_sd.zip http://eca.knmi.nl/utils/downloadfile.php?file=download/ECA_nonblend_sd.zip
# get daily minimum temperature:
wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_tn.zip https://knmi-ecad-assets-prd.s3.amazonaws.com/download/ECA_nonblend_tn.zip
#wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_tn.zip http://eca.knmi.nl/utils/downloadfile.php?file=download/ECA_nonblend_tn.zip
# get daily maximum temperature:
wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_tx.zip https://knmi-ecad-assets-prd.s3.amazonaws.com/download/ECA_nonblend_tx.zip
#wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_tx.zip http://eca.knmi.nl/utils/downloadfile.php?file=download/ECA_nonblend_tx.zip
# get Station list:
wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_info_all.txt  https://knmi-ecad-assets-prd.s3.amazonaws.com/download/ECA_nonblend_info_all.txt  
#wget -a${PREFIX}download/get-eca.log -O ${PREFIX}download/eca/ECA_nonblend_info_all.txt  http://eca.knmi.nl/utils/downloadfile.php?file=download/ECA_nonblend_info_all.txt  

# check if each zip file downloaded correctly and re-download if not.

for i in `ls ${PREFIX}download/eca | grep "\.zip"`
do
unzip -l ${PREFIX}download/eca/$i > ${PREFIX}zipped-files.list
listsize="$(/usr/bin/du -b ${PREFIX}zipped-files.list | gawk '{print $1}')"
echo "Zipped file list size for $i: "${listsize}
while [ ${listsize} == 0 ]
do
#rm old version of zip file
rm -f ${PREFIX}download/eca/$i
#get $i again, download seems incomplete
wget -o${PREFIX}download/get_eca.ftp.log -O ${PREFIX}download/eca/$i http://eca.knmi.nl/utils/downloadfile.php?file=download/$i
done
done

numfiles=`ls ${PREFIX}download/eca | wc | cut -c1-7`

echo "Downloaded ${numfiles} files from ECA Website"


