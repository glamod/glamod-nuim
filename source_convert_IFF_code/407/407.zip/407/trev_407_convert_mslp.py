# -*- coding: utf-8 -*-
"""
Created on Wed Apr  9 08:46:27 2025

@author: snoone
"""

import pandas as pd
from datetime import datetime, timedelta

# Conversion factor from inches of mercury to hectopascals
INCHES_TO_HPA = 33.8639

# Load the data (update 'input_file' with the actual path to your file)
input_file = "C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Other stations_bdy/Other stations/trevandrum_master.csv"
output_file = "C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Other stations_bdy/Other stations/trevandrum_master_reformatted.psv"


# Load the dataset
data = pd.read_csv(input_file)

# Reshape the data to have 'Hour', 'Original_observed_value', and 'Observed_value' columns
melted_data = data.melt(id_vars=["Year", "Month", "Day"], 
                        value_vars=[str(i) for i in range(1, 25)],
                        var_name="Hour", 
                        value_name="Original_observed_value")

# Convert the Hour column to integers
melted_data['Hour'] = melted_data['Hour'].astype(int)

# Add a column for converted values in hectopascals
melted_data['Observed_value'] = melted_data['Original_observed_value'] * INCHES_TO_HPA

# Remove rows where Observed_value has no value
melted_data = melted_data.dropna(subset=["Observed_value"])

# Add a datetime column and adjust to UTC
melted_data['Local_datetime'] = pd.to_datetime(melted_data[['Year', 'Month', 'Day']]) + pd.to_timedelta(melted_data['Hour'] - 1, unit='h')
# Assuming local time is already in UTC+5:30 (Indian Standard Time)
melted_data['UTC_datetime'] = melted_data['Local_datetime'] - timedelta(hours=5, minutes=30)

# Sort the data by UTC datetime
melted_data = melted_data.sort_values(by=["UTC_datetime"])

melted_data["Source_ID"] = "407"
melted_data["Station_ID"]="383-00011"
melted_data["Station_name"]="Tevandrum"
melted_data["Alias_station_name"]=""
melted_data["Latitude"]="8.4855"
melted_data["Longitude"]="76.94924"
melted_data["Elevation"]="30"
melted_data["Source_QC_flag"]=""
melted_data['Original_observed_value_units']="inhg"
melted_data['Report_type_code']=''
melted_data['Measurement_code_1']=''
melted_data['Measurement_code_2']='' 

melted_data = melted_data[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]

# Save the reformatted data to a PSV file
melted_data.to_csv(output_file, index=False, sep='|')