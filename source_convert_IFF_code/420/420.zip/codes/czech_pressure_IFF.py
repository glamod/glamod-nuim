#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu May 21 17:49:25 2026

@author: sangethaedathil
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CHMI air pressure files → IFF row-by-row format

Input:
CHMI_daily_data/air_pressure

Metadata:
CHMI_daily_data/station_metadata/meta1.csv

Metadata mapping:
STATION in data file  → WSI in meta1.csv
FULL_NAME             → Station_name
GEOGR2                → Latitude
GEOGR1                → Longitude

Output:
CHMI_daily_data/IFF/air_pressure

Source_ID:
420
"""

import os
import glob
import pandas as pd
import unicodedata


# ============================================================
# SETTINGS
# ============================================================

SOURCE_ID = "420"
VARIABLE_NAME = "air_pressure"

INPUT_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/air_pressure"

META_FILE = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/station_metadata/meta1.csv"

OUTPUT_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/IFF/air_pressure"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# IFF COLUMNS
# ============================================================

IFF_COLUMNS = [
    "Source_ID",
    "Station_ID",
    "Station_name",
    "Alias_station_name",
    "Year",
    "Month",
    "Day",
    "Hour",
    "Minute",
    "Latitude",
    "Longitude",
    "Elevation",
    "Observed_value",
    "Source_QC_flag",
    "Original_observed_value",
    "Original_observed_value_units",
    "Report_type_code",
    "Measurement_code_1",
    "Measurement_code_2"
]


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def clean_station_name(name):
    """
    Convert Czech characters to plain ASCII.

    Examples:
    Bílá Voda -> Bila Voda
    České Budějovice -> Ceske Budejovice
    """

    name = clean_text(name)

    # Remove accents/diacritics
    name = unicodedata.normalize('NFKD', name)
    name = name.encode('ASCII', 'ignore').decode('ASCII')

    return name
def read_csv_safely(path):
    """
    Read CSV safely with common separators.
    """
    for sep in [",", ";", "\t"]:
        try:
            df = pd.read_csv(path, dtype=str, sep=sep)
            if df.shape[1] > 1:
                return df
        except Exception:
            continue

    return pd.read_csv(path, dtype=str)


def normalise_columns(df):
    """
    Clean column names.
    """
    df.columns = [str(col).strip().upper() for col in df.columns]
    return df


def clean_text(value):
    """
    Clean text safely.
    """
    if pd.isna(value):
        return ""

    value = str(value).strip()

    if value.lower() in ["nan", "none", "na", "nat"]:
        return ""

    return value


def clean_number(value):
    """
    Remove unnecessary .0 from numbers.

    Examples:
    1015.0 -> 1015
    1015.6 -> 1015.6
    """
    if pd.isna(value):
        return ""

    try:
        num = float(value)

        if num.is_integer():
            return str(int(num))

        return str(num).rstrip("0").rstrip(".")

    except Exception:
        return clean_text(value)


def is_pressure_file(filepath):
    """
    Keep air pressure CSV files.

    This keeps all CSV files in the air_pressure folder.
    If later you want only a specific element suffix, we can tighten this.
    """
    filename = os.path.basename(filepath)
    return filename.endswith(".csv")


def load_station_metadata():
    """
    Load CHMI station metadata.

    Required columns:
    WSI
    FULL_NAME
    GEOGR1
    GEOGR2
    """

    meta = read_csv_safely(META_FILE)
    meta = normalise_columns(meta)

    required_cols = ["WSI", "FULL_NAME", "GEOGR1", "GEOGR2"]

    missing = [col for col in required_cols if col not in meta.columns]

    if missing:
        raise ValueError(
            f"Metadata file missing required columns: {missing}\n"
            f"Available columns: {list(meta.columns)}"
        )

    meta["WSI"] = meta["WSI"].apply(clean_text)
    meta["Station_name"] = meta["FULL_NAME"].apply(clean_text)

    # GEOGR2 = latitude
    # GEOGR1 = longitude
    meta["Latitude"] = meta["GEOGR2"].apply(clean_text)
    meta["Longitude"] = meta["GEOGR1"].apply(clean_text)

    # Elevation column, if available
    possible_elevation_cols = [
        "ELEVATION",
        "ALTITUDE",
        "ALT",
        "ELEV",
        "VYSKA",
        "HEIGHT",
        "H"
    ]

    elevation_col = None

    for col in possible_elevation_cols:
        if col in meta.columns:
            elevation_col = col
            break

    if elevation_col:
        meta["Elevation"] = meta[elevation_col].apply(clean_number)
    else:
        meta["Elevation"] = ""

    meta_lookup = meta[
        [
            "WSI",
            "Station_name",
            "Latitude",
            "Longitude",
            "Elevation"
        ]
    ].drop_duplicates(subset=["WSI"])

    return meta_lookup


# ============================================================
# MAIN CONVERSION FUNCTION
# ============================================================

def create_iff_from_pressure_file(input_file, meta_lookup):
    """
    Convert one CHMI air pressure CSV file to IFF row-by-row format.
    """

    filename = os.path.basename(input_file)
    print(f"Processing: {filename}")

    df = read_csv_safely(input_file)
    df = normalise_columns(df)

    required_cols = ["STATION", "ELEMENT", "DT", "VALUE"]

    missing = [col for col in required_cols if col not in df.columns]

    if missing:
        print(f"  Skipped. Missing columns: {missing}")
        return None

    # Clean station and element
    df["STATION"] = df["STATION"].apply(clean_text)
    df["ELEMENT"] = df["ELEMENT"].apply(clean_text)

    # Keep pressure rows.
    # Most CHMI air pressure files should already contain only pressure.
    # This removes any accidental blank ELEMENT rows.
    df = df[df["ELEMENT"] != ""].copy()

    if df.empty:
        print("  Skipped. No valid ELEMENT rows.")
        return None

    # Parse datetime
    dt = pd.to_datetime(df["DT"], errors="coerce", utc=True)

    df["Year"] = dt.dt.year
    df["Month"] = dt.dt.month
    df["Day"] = dt.dt.day
    df["Hour"] = dt.dt.hour
    df["Minute"] = dt.dt.minute

    df = df.dropna(subset=["Year", "Month", "Day", "Hour", "Minute"]).copy()

    if df.empty:
        print("  Skipped. Date parsing failed.")
        return None

    
    # Remove rows where TIMEFUNC == AVG
    if "TIMEFUNC" in df.columns:
        df["TIMEFUNC"] = df["TIMEFUNC"].apply(clean_text)
    
        df = df[df["TIMEFUNC"] != "AVG"].copy()
    
    # Keep only:
    # 06:00, 13:00, 20:00
    
    df = df[
        (df["Minute"] == 0) &
        (df["Hour"].isin([6, 13, 20]))
    ].copy()
    
    if df.empty:
        print("  Skipped. No valid 06:00, 13:00, or 20:00 observations.")
        return None

    # Clean values
    df["VALUE"] = df["VALUE"].apply(clean_text)
    df = df[df["VALUE"] != ""].copy()

    df["VALUE_NUM"] = pd.to_numeric(df["VALUE"], errors="coerce")
    df = df.dropna(subset=["VALUE_NUM"]).copy()

    if df.empty:
        print("  Skipped. No valid numeric values.")
        return None

    df["VALUE_CLEAN"] = df["VALUE_NUM"].apply(clean_number)

    # Merge metadata:
    # STATION in data file = WSI in meta1.csv
    df = df.merge(
        meta_lookup,
        left_on="STATION",
        right_on="WSI",
        how="left"
    )

    df["Station_name"] = df["Station_name"].apply(clean_text)
    df["Latitude"] = df["Latitude"].apply(clean_text)
    df["Longitude"] = df["Longitude"].apply(clean_text)
    df["Elevation"] = df["Elevation"].apply(clean_text)

    missing_name_count = (df["Station_name"] == "").sum()

    if missing_name_count > 0:
        print(f"  Warning: Station name missing for {missing_name_count} rows")

    # Sort rows
    df = df.sort_values(
        by=["STATION", "Year", "Month", "Day", "Hour", "Minute"]
    ).copy()

    # ========================================================
    # BUILD IFF
    # ========================================================

    iff = pd.DataFrame(index=df.index)

    # Source_ID must be filled with 420 in every row
    iff["Source_ID"] = "420"

    # Station_ID comes from STATION column
    iff["Station_ID"] = df["STATION"].apply(clean_text)

    # Station_name comes from FULL_NAME in meta1.csv
    iff["Station_name"] = df["Station_name"].apply(clean_station_name)

    iff["Alias_station_name"] = ""

    iff["Year"] = df["Year"].astype(int)
    iff["Month"] = df["Month"].astype(int)
    iff["Day"] = df["Day"].astype(int)
    iff["Hour"] = df["Hour"].astype(int)
    iff["Minute"] = df["Minute"].astype(int)

    iff["Latitude"] = df["Latitude"].apply(clean_text)
    iff["Longitude"] = df["Longitude"].apply(clean_text)
    iff["Elevation"] = df["Elevation"].apply(clean_text)

    iff["Observed_value"] = df["VALUE_CLEAN"]

    # Keep QC blank
    iff["Source_QC_flag"] = ""

    iff["Original_observed_value"] = df["VALUE_CLEAN"]

    # Pressure unit
    iff["Original_observed_value_units"] = "hPa"

    iff["Report_type_code"] = ""

    # Keep measurement codes blank
    iff["Measurement_code_1"] = ""
    iff["Measurement_code_2"] = ""

    # Reorder exactly
    iff = iff[IFF_COLUMNS]

    # Final safety check
    iff["Source_ID"] = "420"

    station_id = clean_text(iff["Station_ID"].iloc[0])

    output_filename = f"{station_id}_pressure_{SOURCE_ID}.psv"
    output_path = os.path.join(OUTPUT_DIR, output_filename)

    iff.to_csv(output_path, sep="|", index=False)

    print(f"  Saved: {output_path}")
    print(f"  Rows: {len(iff)}")

    return output_path


# ============================================================
# MAIN
# ============================================================

def main():

    print("======================================")
    print("CHMI air pressure → IFF row-by-row")
    print("======================================")

    print("Loading metadata...")
    meta_lookup = load_station_metadata()
    print(f"Metadata stations loaded: {len(meta_lookup)}")

    all_csv_files = glob.glob(os.path.join(INPUT_DIR, "*.csv"))

    pressure_files = [
        file for file in all_csv_files
        if is_pressure_file(file)
    ]

    print(f"Input folder: {INPUT_DIR}")
    print(f"Output folder: {OUTPUT_DIR}")
    print(f"Total CSV files found: {len(all_csv_files)}")
    print(f"Pressure CSV files found: {len(pressure_files)}")
    print("======================================")

    if not pressure_files:
        print("No pressure CSV files were found.")
        return

    created_files = []
    failed_files = []

    for file in sorted(pressure_files):
        try:
            output = create_iff_from_pressure_file(file, meta_lookup)

            if output:
                created_files.append(output)

        except Exception as e:
            print(f"FAILED: {os.path.basename(file)}")
            print(f"Reason: {e}")

            failed_files.append({
                "file": file,
                "error": str(e)
            })

    if failed_files:
        failed_log = os.path.join(
            OUTPUT_DIR,
            "failed_CHMI_pressure_files.csv"
        )

        pd.DataFrame(failed_files).to_csv(failed_log, index=False)

        print(f"Failed file log saved to: {failed_log}")

    print("======================================")
    print("DONE")
    print(f"IFF files created: {len(created_files)}")
    print(f"Failed files: {len(failed_files)}")
    print("======================================")


if __name__ == "__main__":
    main()