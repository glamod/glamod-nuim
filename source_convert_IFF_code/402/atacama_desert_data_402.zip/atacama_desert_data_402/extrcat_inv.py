# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 12:20:32 2024

@author: snoone
"""

import pandas as pd
import os

# Define directory and output CSV file
directory = r'E:\NEW_DATA_SOURCES_r8_\atacama_desert_chile_data\CDM_lite\wind_speed'
output_file = 'E:/NEW_DATA_SOURCES_r8_/atacama_desert_chile_data/CDM_lite/inventory/ws_inv.csv'

# Initialize a list to hold the extracted data from all files
consolidated_data = []

# Loop through all .psv files in the directory
for filename in os.listdir(directory):
    if filename.endswith('.psv'):
        file_path = os.path.join(directory, filename)
        
        # Read the .psv file
        df = pd.read_csv(file_path, sep='|')
        
        # Extract the first row's values for the selected columns
        first_row = df.iloc[0][['station_name', 'primary_station_id', 'latitude', 'longitude', "height_of_station_above_sea_level",'report_timestamp']]
        
        # Get the start and end date from the 'report_timestamp' column
        start_date = df['report_timestamp'].min()
        end_date = df['report_timestamp'].max()
        
        # Append the extracted information to the consolidated data
        consolidated_data.append({
            'station_name': first_row['station_name'],
            'primary_station_id': first_row['primary_station_id'],
            'latitude': first_row['latitude'],
            'longitude': first_row['longitude'],
            "height_of_station_above_sea_level":first_row["height_of_station_above_sea_level"],
            'start_date': start_date,
            'end_date': end_date
        })

# Convert the consolidated data to a DataFrame
consolidated_df = pd.DataFrame(consolidated_data)

# Save the consolidated data to a CSV file
consolidated_df.to_csv(output_file, index=False)

print(f'Consolidated data saved to {output_file}')
