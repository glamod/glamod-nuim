# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 12:17:19 2023

@author: snoone
"""

import os 
import glob
import pandas as pd
import csv
import calendar

OUTDIR = "C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/IFF/rr/out"
os.chdir("C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/completed_forms/all_A/")

extension = 'xlsx'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

 
for filename in all_filenames:
    try:
   
                # Extract year and month from the filename

        
        base_name = os.path.basename(filename)  # Get the file name without the path
        file_parts = base_name.split('_')  # Split the filename by underscores
        
        # Extract year and month as integers
        year = int(file_parts[0])  # First part is the year
        month = int(file_parts[1])  # Second part is the month
        
        print(f"Year: {year}, Month: {month}")

        


# Read the first 37 rows, skipping the first 5 rows, with no headers initially
        df = pd.read_excel(filename, skiprows=5, header=None, nrows=31,usecols=range(46))
        df.columns = ["Day","slp_7","temp_7","dbt_7","wtb_7","wd_7","wf_7","cf_7","ca_7","we_7","rain_7",
                      "na1","slp_14","temp_14","dbt_14","wtb_14","wd_14","wf_14","cf_14","ca_14","we_14",
                      "na2","slp_21","temp_21","dbt_21","wtb_21","wd_21","wf_21","cf_21","ca_21","we_21",
                      "tmax_21","tmin_21","sun_21","na3","earth_t1m_7","earth_t4m_7","na4","wmile_7","wmile_14",
                      "wmile_21","na5","tr_radiation_them_7","solar_rad_12","solar_rad_bright","1"]
    
        # Drop unnecessary columns
        df = df.drop(columns=["1", "na1", "na2", "na3", "na4", "na5"])
        
                # Add the Year and Month columns to the DataFrame
        df['Year'] = year
        df['Month'] = month
            # Add the Year and Month columns to the DataFrame
        df["Source_ID"] = "405"
        df["Station_ID"]="405-00001"
        df["Station_name"]="ENTEBBE"
        df["Alias_station_name"]=""
        df["Latitude"]="0.067"
        df["Longitude"]="32.45"
        df["Elevation"]="1153"
        df["Source_QC_flag"]=""
        df["Original_observed_value"]=""
        df['Original_observed_value_units']="inch"
        df['Report_type_code']=''
        df['Measurement_code_1']=''
        df['Measurement_code_2']='' 
        df["Minute"]="00" 
        
            
 
   
        df_a=df
        
        df_a["Hour"]="07" 
        df_a= df_a.rename(columns=({"rain_7":'Observed_value'}))
        # Replace the word "Trace" with 0 in the 'Observed_value' column
        df_a['Observed_value'] = df_a['Observed_value'].replace('Trace', 0)
        df_a['Observed_value'] = df_a['Observed_value'].replace('Traces', 0)
        df_a['Observed_value'] = df_a['Observed_value'].replace('trace', 0)
        df_a["Original_observed_value"]=df_a["Observed_value"]
        df_a['Original_observed_value'] = df_a['Original_observed_value'].fillna(0)
        
        #if need to add decimal places
        df_a["Observed_value"]=df_a["Observed_value"]*25.4
        df_a["Observed_value"] = pd.to_numeric(df_a["Observed_value"],errors='coerce')
        #df_a["Observed_value"] = (df_a["Observed_value"] - 32) * 5 / 9

        
        df_a = df_a[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1","Measurement_code_2"]]
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="N",value="0")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="NNE",value="22.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="NE",value="45")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="ENE",value="67.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="E",value="90")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="ESE",value="112")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="SE",value="135")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="SSE",value="157.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="S",value="180")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="SSW",value="202.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="SW",value="225")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="Sw",value="225")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="WSW",value="247.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="W",value="270")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="WNW",value="292.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="NW",value="315")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="NNW",value="337.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="Calme",value="")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="cal",value="")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="east",value="90")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="E ",value="90")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="WNW",value="90")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="n",value="0")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="nne",value="22.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="ne",value="45")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="ene",value="67.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="e",value="90")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="ese",value="112")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="se",value="135")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="sse",value="157.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="s",value="180")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="ssw",value="202.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="sw",value="225")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="wsw",value="247.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="w",value="270")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="wnw",value="292.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="nw",value="315")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="nnw",value="337.5")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="calme",value="")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="cal",value="")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="east",value="90")
        df_a ["Observed_value"]=df_a["Observed_value"].replace(to_replace="Ee ",value="90")
        
        
        def get_days_in_month(year, month):
            """Returns the number of days in a month considering leap years."""
            return calendar.monthrange(year, month)[1]

        # Apply this filter to remove invalid rows
        valid_rows = []
    
        for _, row in df_a.iterrows():
            year = row['Year']
            month = row['Month']
            day = row['Day']
            
            # Get the valid number of days for the month and year
            valid_days_in_month = get_days_in_month(year, month)
            
            # Only include rows where the Day is valid for that month
            if 1 <= day <= valid_days_in_month:
                valid_rows.append(row)
        
        # Create a new DataFrame with only valid rows
        df_a_valid = pd.DataFrame(valid_rows)
        # Replace NaN values in the 'Observed_value' column with 0
        df_a_valid['Observed_value'] = df_a_valid['Observed_value'].fillna(0)
        
         # Round the 'Observed_value' column to 1 decimal place
        df_a_valid['Observed_value'] = df_a_valid['Observed_value'].round(1)



    
       
        merged=pd.concat([df_a_valid], axis=0)
        


    #change time zones
        merged["Timestamp2"] = merged["Year"].map(str) + "-" + merged["Month"].map(str) + "-" + merged["Day"].map(str)
        merged["Timestamp"] = merged["Timestamp2"].map(str) + " " + merged["Hour"].map(str) + ":" + merged["Minute"].map(str)
        merged = merged.drop(columns=["Timestamp2"])
        
        # Handle mixed date formats by letting pandas infer the format
        merged['Timestamp'] = pd.to_datetime(merged['Timestamp'], errors='coerce')
        
        # Localize and convert to GMT
        merged['Timestamp'] = merged['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')
        
        # Sort by Timestamp
        merged = merged.sort_values(by='Timestamp')
        
        # Extract year, month, day, hour, minute, second
        merged['Year'] = merged['Timestamp'].dt.year
        merged['Month'] = merged['Timestamp'].dt.month
        merged['Day'] = merged['Timestamp'].dt.day
        merged['Hour'] = merged['Timestamp'].dt.hour
        merged['Minute'] = merged['Timestamp'].dt.minute
        merged['Seconds'] = merged['Timestamp'].dt.second
        
        # Drop the original Timestamp column
        merged = merged.drop(columns="Timestamp")
        # Drop the original Timestamp column
        merged = merged.drop(columns="Seconds")
        
        # Round relevant numeric columns and ensure no decimals
        merged["Year"] = merged["Year"].astype(int)
        merged["Month"] = merged["Month"].astype(int)
        merged["Day"] = merged["Day"].astype(int)
        merged["Hour"] = merged["Hour"].astype(int)
        merged["Minute"] = merged["Minute"].astype(int)

     
       
    
        # Save output file
         # Ensure year is converted to an integer and then to a string
        year = str(int(merged.iloc[1]["Year"]))
        
        # Ensure month is converted to an integer, zero-padded, and then to a string
        month = str(int(merged.iloc[1]["Month"])).zfill(2)
        
        # Format date as "YYYY_MM"
        date = f"{year}_{month}"
        
        # Ensure source ID is a string
        source_id = str(merged.iloc[1]["Source_ID"])
        
        # Construct file type string
        cdm_type = f"{date}_precipitation_{source_id}"
        
        print(cdm_type)

        
        # Ensure output directory exists
        os.makedirs(OUTDIR, exist_ok=True)
        
        # Construct output file name
        outname = os.path.join(OUTDIR, cdm_type)
                # Convert relevant columns to integers

                
        # Save to CSV with pipe separator
        merged.to_csv(outname + ".psv", index=False, sep="|")
    except:
        continue


    
    
    
