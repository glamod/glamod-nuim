#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import glob
import pandas as pd
import os
import numpy as np  
# Define the directory where the files are located
OUTDIR1 = "D:/BOM_new_data/CDM_lite/precipitation_1hour"
OUTDIR = "D:/BOM_new_data/IFF/precipitation_1hour"
os.chdir("D:/BOM_new_data/data")

# Collect all files matching the pattern in the directory
extension = '*'  
all_filenames = [i for i in glob.glob(f'*{extension}')]

# Define column widths based on the fixed-width file structure
colspecs = [(0, 6),   # Station_ID
            (8, 13),  # wmo_id
            (14, 57), # Station_name
            (57, 64), # Latitude
            (65, 72), # Longitude
            (73, 79), # Elevation
            (80, 92),# Date
            (141, 148),# Observed_value
            (168, 170), # Source_QC_flag
            (148,153)] # Measurement_code_2
# Define column names for the fixed-width columns
col_names = ["Station_ID", "wmo_id", "Station_name", "Latitude", 
             "Longitude", "Elevation", "Date", "Observed_value", 
             "Source_QC_flag","Measurement_code_2"]

# Loop through each file and read the selected columns
for filename in all_filenames:
    # Read the fixed-width formatted file
    df = pd.read_fwf(filename, colspecs=colspecs, header=None, names=col_names)
    
        # Split the 'Date' column into Year, Month, Day, Hour, Minute
    df['Year'] = df['Date'].astype(str).str[0:4]     # YYYY
    df['Month'] = df['Date'].astype(str).str[4:6]    # MM
    df['Day'] = df['Date'].astype(str).str[6:8]      # DD
    df['Hour'] = df['Date'].astype(str).str[8:10]    # HH
    df['Minute'] = df['Date'].astype(str).str[10:12] # MM
    
    #set up extra cioluns
    df["Source_ID"] = 401
    df["Alias_station_name"]=""
    df["Original_observed_value"]=df["Observed_value"]
    df['Original_observed_value_units']="mm"
    df['Report_type_code']=''
    df['Measurement_code_1']=''
    # Replace -999.0 with NaN, then drop rows with NaN values
    df.replace(-999.0, np.nan, inplace=True)
    df.dropna(inplace=True)
    

    try:
        # Drop the original 'Date' column if you no longer need it
        df.drop('Date', axis=1, inplace=True)
        
        # only keep rows with 3 hour obs
        df = df[df["Measurement_code_2"] == 1]
    
        # Reorder columns
        df = df[["Source_ID",'Station_ID',"Station_name","Alias_station_name","Year","Month","Day",
                         "Hour","Minute","Latitude","Longitude","Elevation",
                         "Observed_value","Source_QC_flag","Original_observed_value",
                         "Original_observed_value_units",                                
                         "Report_type_code","Measurement_code_1","Measurement_code_2"]]
        
        # Convert station_id to string before using it in the file name
        station_id = str(df['Station_ID'].iloc[0])  # Extract Station_ID for output file name
        outname = os.path.join(OUTDIR, station_id + "_precipitation_1hour_401.psv")
        
        # Save the dataframe to a PSV (pipe-separated values) file
        df.to_csv(outname, index=False, sep="|")
        
        
    #set up cdm_lite file
        df2=df
        df2["report_type"] = "0"
        df2["date_time_meaning"] = "1"
        df2["platform_type"] = "0"
        df2["station_type"] = "1"
        df2["observation_id"] = ""
        df2["data_policy_licence"] = "2"
        df2["primary_station_id"] = df["Station_ID"]
        df2["quality_flag"] = df["Source_QC_flag"].astype(str)
        df2["observed_variable"] = "44"
        #df2['Observed_value'] = (df2['Observed_value']+ 273.15)
        #df2["Observed_value"]= df2["Observed_value"].round(2)
        df2["observation_value"] = df["Observed_value"]
        df2["station_name"] = df["Station_name"]
        df2["units"] = "710"
        df2["value_significance"] = "13"
        df2["observation_duration"] = "9"
        df2["source_id"] = "401"
        df2["record_number"] = "1"
        
        ##add timestamp to df and create report id
        df2["Timestamp2"] = df2["Year"].map(str) + "-" + df2["Month"].map(str)+ "-" + df2["Day"].map(str)
        df2["Seconds"] = "00"  # Modify this line
        #df2["offset"] = "+00"
        df2["date_time"] = df2["Timestamp2"].map(str) + " " + df2["Hour"].map(str) + ":" + df2["Minute"].map(str) + ":" + df2["Seconds"].map(str)
        #df2.date_time = df2.date_time + '+00'
        df2["report_id1"] = df2["date_time"]
    
        
        #rename df2 columns to cdm-core and create report_id
        df2["height_of_station_above_sea_level"]=df2["Elevation"]
        df2["report_timestamp"]= df2["date_time"]+ '+00'
        df2["report_meaning_of_time_stamp"]= df2["date_time_meaning"]
        df2["report_duration"]= df2["observation_duration"]
        df2["latitude"]= df2["Latitude"]
        df2["longitude"]= df2["Longitude"]
        df2["station_name"]= df2["Station_name"]
        
               
       ##add observation id to datafrme
        df2["dates"] = ""
        df2["dates"] = df2["report_id1"].str[:-3]
        df2['observation_id'] = df2['primary_station_id'].astype(str) + '-' + df2['record_number'].astype(str) + '-' + df2['dates'].astype(str)
        df2['observation_id'] = df2['observation_id'].str.replace(r' ', '-')
        df2["observation_id"] = df2["observation_id"] + '-'+ df2['observed_variable'] + '-' + df2['value_significance']
        # Function to extract substring before the second last '-'
        def extract_report_id(obs_id):
            parts = obs_id.split('-')
            report_id = '-'.join(parts[:-2])
            return report_id
        
        # Apply the function to create the new column report_id
        df2['report_id'] = df2['observation_id'].apply(extract_report_id)
        
        #set up final columns
        df2 = df2[["station_name","primary_station_id","report_id","observation_id",
                                     "longitude","latitude","height_of_station_above_sea_level","report_timestamp",
                                     "report_meaning_of_time_stamp","report_duration","observed_variable",
                                     "units","observation_value","quality_flag","source_id","data_policy_licence",
                                     "report_type","value_significance"]]
        
        # Convert station_id to string before using it in the file name
        station_id = str(df2['primary_station_id'].iloc[0])  # Extract Station_ID for output file name
        outname = os.path.join(OUTDIR1, station_id + "_precipitation_1hour_401.psv")
        
        # Save the dataframe to a PSV (pipe-separated values) file
        df2.to_csv(outname, index=False, sep="|")
    except:
        continue

