import os
import glob
import pandas as pd

OUTDIR = "C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/out/combined/IFF/tt"
os.chdir("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/out/combined/error/")
extension = '.csv'
all_filenames = [i for i in glob.glob(f'*{extension}')]

error_files = []

for filename in all_filenames:
    try:
        df = pd.read_csv(filename)

        # Preprocess the Date column
        df['Date'] = df['Date'].astype(str).str.strip()
        df['Date'] = pd.to_datetime(df['Date'], format='%d/%m/%Y %H:%M', errors='coerce')

        # Check for invalid dates
        nat_count = df['Date'].isna().sum()
        if nat_count > 0:
            print(f"Warning: {nat_count} rows have invalid Date values in file {filename}.")
            invalid_dates = df[df['Date'].isna()]
            invalid_dates.to_csv(f"{OUTDIR}/{filename}_invalid_dates.csv", index=False)

        # Drop rows with NaT in the Date column
        df = df.dropna(subset=['Date'])

        # Add additional columns
        df["Source_ID"] = "407"
        df["Alias_station_name"] = ""
        df["Source_QC_flag"] = ""
        df["Original_observed_value_units"] = "C"
        df['Report_type_code'] = ""
        df['Measurement_code_1'] = ""
        df['Measurement_code_2'] = ""
        df['Station_ID'] = df['Source']
        df['Station_name'] = df["Source"]
        df["Original_observed_value"] = ""        
        df["Observed_value"] = ""

        # Extract Year, Month, and Day
        df['Year'] = df['Date'].dt.year
        df['Month'] = df['Date'].dt.month
        df['Day'] = df['Date'].dt.day

        # Load the Stations.csv file
        stations = pd.read_csv("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/Stations.csv")

        # Perform the join and replace Station_ID
        merged_df = pd.merge(df, stations, on="Station_ID", how="inner")
        if "Station_ID_New" in merged_df.columns:
            merged_df["Station_ID"] = merged_df["Station_ID_New"]
            merged_df = merged_df.drop(columns=["Station_ID_New"])

        # Process hour data dynamically with fallback
        def process_hour_data(primary_col, hour_value):
            if primary_col not in merged_df.columns:
                return None  # Skip if column is not present
            df_temp = merged_df.copy()
            df_temp["Hour"] = hour_value
            df_temp["Minute"] = "00"
            df_temp["Observed_value"] = pd.to_numeric(df_temp[primary_col], errors="coerce") 
            df_temp["Original_observed_value"] = df_temp["Observed_value"]
            return df_temp[[
                "Source_ID", 'Station_ID', "Station_name", "Alias_station_name",
                "Year", "Month", "Day", "Hour", "Minute",
                "Latitude", "Longitude", "Elevation", "Observed_value",
                "Source_QC_flag", "Original_observed_value",
                "Original_observed_value_units",
                "Report_type_code", "Measurement_code_1", "Measurement_code_2"
            ]]

        # Process primary and fallback hours
        df6h = process_hour_data("Air Temp. 6h", "6")
        df9h = process_hour_data("Air Temp. 9h", "9")
        df10h = process_hour_data("Air Temp. 10h", "10")
        df14h = process_hour_data("Air Temp. 14h", "14")
        df15h = process_hour_data("Air Temp. 15h", "15")
        df21h = process_hour_data("Air Temp. 21h", "21")
        df18h = process_hour_data("Air Temp. 18h", "18")
        df22h = process_hour_data("Air Temp. 22h", "22")

        # Combine available data
        dfs = [df for df in [df6h, df9h,df10h, df14h, df15h, df21h, df18h,df22h] if df is not None]
        if not dfs:
            print(f"Warning: No valid pressure columns found in file {filename}. Skipping.")
            error_files.append(filename)
            continue

        merged_slp = pd.concat(dfs, axis=0).dropna(subset=['Observed_value'])

        # Create Timestamp and adjust timezone
        merged_slp["Timestamp2"] = (
            merged_slp["Year"].map(str) + "-" +
            merged_slp["Month"].map(str) + "-" +
            merged_slp["Day"].map(str)
        )
        merged_slp["Timestamp"] = (
            merged_slp["Timestamp2"] + " " +
            merged_slp["Hour"].map(str) + ":" +
            merged_slp["Minute"].map(str)
        )
        merged_slp['Timestamp'] = pd.to_datetime(merged_slp['Timestamp'], format='%Y-%m-%d %H:%M')
        merged_slp['Timestamp'] = merged_slp['Timestamp'].dt.tz_localize('Etc/GMT-8').dt.tz_convert('GMT')
        
        # Sort by Timestamp
        merged_slp = merged_slp.sort_values(by='Timestamp')
        
        # Finalize the data
        merged_slp['Year'] = merged_slp['Timestamp'].dt.year
        merged_slp['Month'] = merged_slp['Timestamp'].dt.month
        merged_slp['Day'] = merged_slp['Timestamp'].dt.day
        merged_slp['Hour'] = merged_slp['Timestamp'].dt.hour
        merged_slp['Minute'] = '00'

        merged_slp['Observed_value'] = merged_slp['Observed_value'].round(1)
        merged_slp['Original_observed_value'] = merged_slp['Original_observed_value'].round(2)

        # Drop unnecessary columns and save
        merged_slp = merged_slp.drop(columns=["Timestamp", "Timestamp2"])
        station_id = merged_slp['Station_ID'].iloc[0]
        file_name = f"{station_id}_temperature_407.psv"
        file_path = os.path.join(OUTDIR, file_name)
        merged_slp.to_csv(file_path, sep='|', index=False)
        print(f"File saved successfully to: {file_path}")

    except Exception as e:
        print(f"Error processing file {filename}: {e}")
        error_files.append(filename)

if error_files:
    print("\nThe following files could not be processed:")
    for error_file in error_files:
        print(error_file)
else:
    print("\nAll files processed successfully.")
