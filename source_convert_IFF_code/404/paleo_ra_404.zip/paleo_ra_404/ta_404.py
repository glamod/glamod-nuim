
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import glob
import pandas as pd
import csv


OUTDIR = "E:/Yuri_B_New_data/paleo_RA_new/paleo_data_yuri/PALAEO-RA/sef_data/hourly/ta/IFF"
os.chdir("E:/Yuri_B_New_data/paleo_RA_new/paleo_data_yuri/PALAEO-RA/sef_data/hourly/ta/")
extension = 'tsv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]


for filename in all_filenames:
    df = pd.read_csv(filename, sep='\t', skiprows=12, encoding='unicode_escape')
    # Read the first 11 rows of the file
    df1 = pd.read_csv(filename, sep='\t', nrows=11, encoding='unicode_escape')
    # Extract the first two columns
    df2 = df1.iloc[:, 0:2]
    # Save these columns to a CSV file
    df2.to_csv("header.csv", index=False)
    # Read the "header.csv" file, set 'SEF' as index (ensure 'SEF' exists in the columns of "header.csv")
    df3 = pd.read_csv("header.csv", index_col='SEF')
    # If you need `df3` to be squeezed into a Series, do it explicitly
    df3 = df3.squeeze("columns")  # Converts to Series if possible
    station_id=df3.ID
    station_name=df3.Name
    lat=df3.Lat
    lon=df3.Lon
    Elev=df3.Alt
    #Alias=df3.Meta
    df["Source_ID"] = 404
    df["Station_ID"]=station_id
    df["Station_name"]=station_id
    df["Alias_station_name"]=""
    df["Latitude"]=lat
    df["Longitude"]=lon
    df["Elevation"]=Elev
    df = df.rename(columns=({'Value':'Observed_value'}))
    df["Source_QC_flag"]=""
    df["Original_observed_value"]=""
    df['Original_observed_value_units']="c"
    df['Report_type_code']=''
    df['Measurement_code_1']=''
    df['Measurement_code_2']=''
    df["Observed_value2"]=df["Observed_value"]
    del df["Observed_value"]
    df = df.rename(columns=({'Observed_value2':'Observed_value'}))
            #reorder headings
    df = df[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                                 "Year","Month","Day","Hour","Minute",
                                "Latitude","Longitude","Elevation","Observed_value",
                                "Source_QC_flag","Original_observed_value",
                                "Original_observed_value_units",                                
                                "Report_type_code","Measurement_code_1",
                                "Measurement_code_2"]]
# Remove rows where "Hour" has the string "NA"
# Remove rows where "Hour" has NaN values
    df = df.dropna(subset=['Hour'])
    df = df.dropna(subset=['Observed_value'])
    df.Minute ="00"  
    df.Day = df.Day.apply(int)
    df.Hour = df.Hour.apply(int)
  
  
    outname = os.path.join(OUTDIR, filename)
    #with open(filename, "w") as outfile:
    df.to_csv(outname, index=False, sep="|")



##combine and rename files by station id
import os
import glob
import pandas as pd
import csv

##import all psv files in current dir
os.chdir("E:/Yuri_B_New_data/paleo_RA_new/paleo_data_yuri/PALAEO-RA/sef_data/hourly/ta/IFF")
extension = 'tsv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
#combine all files in the list
df = pd.concat([pd.read_csv(f,delimiter='|') for f in all_filenames])
#dewpointtemp df['Observed_value']= round(df['Observed_value'],1)
df.to_csv("combined.csv",index=False)

with open('combined.csv') as fin:    
    csvin = csv.DictReader(fin)
    #csvin.columns = [x.replace(' ', '_') for x in csvin.columns]  
    # Category -> open file lookup
    outputs = {}
    for row in csvin:
        cat = row['Station_ID']
        # Open a new file and write the header
        if cat not in outputs:
            fout = open ('{}_temperature_404.psv'.format(cat), "w", newline = "")
            dw = csv.DictWriter(fout, fieldnames=csvin.fieldnames,delimiter='|')
            dw.writeheader()
            outputs[cat] = fout, dw
        # Always write the row
        outputs[cat][1].writerow(row)
        
    # Close all the files
    for fout, _ in outputs.values():
        fout.close()
