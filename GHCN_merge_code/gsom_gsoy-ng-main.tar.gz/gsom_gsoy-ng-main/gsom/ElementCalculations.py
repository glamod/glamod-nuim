import polars as pl
from gsom.Elements import Elements

class ElementCalculations():        
    

    
    def create_derived_elements(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Create rows for GSOM output elements not in the original DLY.
        Only adds derived elements if their source elements are present.
        If multiple source elements are required for a derived element,
        a "daily_values_2" column will be added to the  input df to
        retain both source element's daily_values. 

        Parameters
        ----------
        df : pl.DataFrame
            A Polars DataFrame read from a DLY.

        Returns
        -------
        pl.DataFrame
            A Polars DataFrame with rows of derived elements added.
        """
        unique_elements = df["Element"].unique()

        # Edge case
        if len(unique_elements) == 0:
            return df
        
        # Set up which derived element columns will copy their source's values and which columns will be null
        columns_to_keep = ['Station_ID', 'Year_Month', 'Element', 'daily_values', 'qc_flags', 'days_of_month']
        null_columns = [pl.lit(None).alias(col) for col in df.columns if col not in columns_to_keep]
        
        derived_element_dfs = []

        # Define the rules for derived elements where the LHS is source element(s) \
        # (i.e. from the DLY) as a list and the RHS is a list of the derived element(s)
        derived_element_source_rules = [
            (["SNWD"], ["EMSD", "DYSD"]),
            (["SNOW"], ["DSNW", "DYSN", "EMSN"]),
            (["SNOW", "SNWD"], ["DSND"]), # TODO: SNWD only required if SNOW flag has -9999 value?
            (["PRCP"], ["DP01", "DP10", "DP1X", "DYXP", "EMXP"]),
            (["TMIN"], ["CDSD", "CLDD", "DT32", "DYNT", "EMNT", "HDSD", "TAVG"]), # TODO: TAVG requires TMIN and TMAX?
            (["TMIN", "TMAX"], ["DT00", "DX32", "DX70", "DX90", "DYXT", "EMXT", "HTDD"]),
        ]

        # If the required source(s) are present in the DLY (i.e. is a subset), \
        # filter the input df to capture the source element(s)
        for required_sources, derived_elements_list in derived_element_source_rules:
            if set(required_sources).issubset(unique_elements):
                filtered_source_df = df.filter(
                    pl.col("Element").is_in(required_sources)
                )

                # Check for multiple required sources
                if len(required_sources) > 1:
                    # Combine the source elements present in each Year_Month
                    # For example: {"Year_Month": ["200001", "200001", "200002"],
                    #               "Element": ["TMAX", "TMIN", "TMIN"]}
                    # would result in... {"Year_Month": ["200001", "200002"],
                    #                     "elements_list": [["TMAX", "TMIN"], ["TMIN"]]}
                    source_elements_by_year = filtered_source_df.group_by("Year_Month").agg(
                        pl.col("Element").alias("elements_list")
                    )

                    # Filter on the original and reversed required_sources lists
                    # (This is necessary to include the reversed list since depending \
                    # on the order of the input df source elements, the order may be
                    # the same as the required_sources in the derived_element_source_rules \
                    # or it may be revered (as seen in the example above on line 59))
                    reversed_required_sources = required_sources[::-1]
                    valid_year_months = source_elements_by_year.filter(
                            ((pl.col("elements_list") == required_sources) |
                             (pl.col("elements_list") == reversed_required_sources))
                        )["Year_Month"]

                    # Filter on Year_Months where required source elements are present
                    filtered_source_df = filtered_source_df.filter(
                        pl.col("Year_Month").is_in(valid_year_months)
                    )

                    # Create a df filtered on the first required source
                    filtered_source_0_df = filtered_source_df.filter(
                        pl.col("Element") == required_sources[0]
                    )

                    # Create a df filtered on the second required source
                    filtered_source_1_df = filtered_source_df.filter(
                        pl.col("Element") == required_sources[1]
                    )

                    # Add the second required source's daily_values to a new "daily_values_2" column
                    filtered_source_df = filtered_source_0_df.with_columns(
                        filtered_source_1_df["daily_values"].alias("daily_values_2")
                    )

                # Rename the values in the "Element" column for each derived element, \
                # unpack the null columns, and append the renamed, filtered df
                for derived_element in derived_elements_list:
                    derived_element_df = filtered_source_df.with_columns(
                        [pl.lit(derived_element).alias("Element"), *null_columns]
                    )
                    derived_element_dfs.append(derived_element_df)

        # Filter input df to capture source elements SN<XX> and <SN<XX>
        # Ensures <XX> are digits of length 2
        # (total length of 4 - prefix length of 2 = 2 remaining chars for <XX>)
        filtered_source_df = df.filter(
            (pl.col("Element").str.starts_with("SN") |
             pl.col("Element").str.starts_with("SX")) &
            (pl.col("Element").str.extract(r"(\d{2})$", 1).is_not_null()) &
            (pl.col("Element").str.len_chars() == 4)
        )

        # Replace the first char in the filtered df's "Element" column. For example, \
        # SN<XX> will result in 3 dfs with "Element" columns HN<XX>, LN<XX>, MN<XX>
        for derived_element_prefix in ["H", "L", "M"]:
            derived_element_df = filtered_source_df.with_columns(
                [pl.col("Element").str.replace(r"^.", derived_element_prefix), *null_columns]
            )
            derived_element_dfs.append(derived_element_df)

        # Concat derived element dfs to input df diagonally so 
        # rows without a "daily_values_2" column, becomes null
        df = pl.concat([df] + derived_element_dfs, how="diagonal")

        # Only keep the first unique "Element" for a "Year_Month"
        # The derived dfs will come after the original source elements \
        # resulting in the duplicate derived element(s) in the same \
        # "Year_Month" as the source being removed. 
        # This needs to occur if "TMIN" and "TAVG" are both DLY sources \
        # in the same "Year_Month" for example.
        df = df.unique(subset=["Year_Month", "Element"], keep="first")

        return df
    
    def process_elements(self, df: pl.DataFrame) -> pl.DataFrame:
        
        means = ["ADPT", "ASLP", "ASTP", "AWBT", "AWND", 
                "MNPN", "MXPN", "RHAV", "RHMN", "RHMX", 
                "TAVG", "TMAX", "TMIN", "TSUN"
                ]

        df = df.with_columns(
            pl.when(#Elements summed and multiplied by .10
                pl.col("Element").is_in( means ) 
            ).then(
                pl.col.filtered.list.mean()*.1    
            ).alias(
                "value"
            )
        )
        
        #round
        df = df.with_columns(
            pl.when(#Elements rounded to 2 decimal places
                pl.col("Element").is_in(["TMAX", "TMIN", "TSUN"])
            ).then(
                pl.col.value.round(2)
            )
        )      
        
        return df
        