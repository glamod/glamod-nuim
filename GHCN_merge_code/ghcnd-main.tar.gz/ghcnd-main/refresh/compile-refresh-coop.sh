refresh_dir=$1
mod_file=$2

ulimit -s unlimited

lf95path=/usr/local/lf6481/bin/

${lf95path}lf95 ${mod_file} ${refresh_dir}gen-coop-stninfo.f95 -o ${refresh_dir}gen-coop-stninfo.exe
${lf95path}lf95 ${mod_file} ${refresh_dir}pre_screen.f95 -o ${refresh_dir}pre_screen.exe --ap
${lf95path}lf95 ${mod_file} ${refresh_dir}intrasource_dupchk.f95 -o ${refresh_dir}intrasource_dupchk.exe --ap
${lf95path}lf95 ${mod_file} ${refresh_dir}strip_source.f95 -o ${refresh_dir}strip_source.exe 
${lf95path}lf95 ${mod_file} ${refresh_dir}mingle.f95 -o ${refresh_dir}mingle.exe 
${lf95path}lf95 ${mod_file} ${refresh_dir}gen-coop-xref.f95 -o ${refresh_dir}gen-coop-xref.exe 
${lf95path}lf95 ${mod_file} ${refresh_dir}gen-data-xref.f95 -o ${refresh_dir}gen-data-xref.exe --ap
${lf95path}lf95 ${mod_file} ${refresh_dir}add_stns.f95 -o ${refresh_dir}add_stns.exe 
${lf95path}lf95 ${mod_file} ${refresh_dir}setGSNfield.f95 -o ${refresh_dir}setGSNfield.exe 
${lf95path}lf95 ${mod_file} ${refresh_dir}setHCNfield.f95 -o ${refresh_dir}setHCNfield.exe 
${lf95path}lf95 ${mod_file} ${refresh_dir}setCRNfield.f95 -o ${refresh_dir}setCRNfield.exe 



