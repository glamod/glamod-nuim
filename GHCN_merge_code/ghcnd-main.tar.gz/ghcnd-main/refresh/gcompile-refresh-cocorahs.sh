refresh_dir=$1
mod_file=$2 

ulimit -s unlimited

lf95path=/usr/local/lf6481/bin/

gfortran ${mod_file} ${refresh_dir}gen-cocorahs-stninfo.f95 -o ${refresh_dir}gen-cocorahs-stninfo.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}pre_screen.f95 -o ${refresh_dir}pre_screen.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}intrasource_dupchk.f95 -o ${refresh_dir}intrasource_dupchk.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}strip_source.f95 -o ${refresh_dir}strip_source.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}mingle.f95 -o ${refresh_dir}mingle.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}gen-data-xref.f95 -o ${refresh_dir}gen-data-xref.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}add_stns.f95 -o ${refresh_dir}add_stns.exe -ffree-line-length-none
