import polars as pl
from typing import Union
import logging
import os
import csv
from datetime import date
import time
import tarfile

from gsom import MonthlySummary
from utils import ArgParserUtil, StationUtils
from utils import InputOutputUtils as ioU
from gsom import SOM_Processing as som_processing

filePaths = dict()
statusLog = logging.getLogger(__name__)

INPUT_EXT = "{}.dly"
OUTPUT_EXT = "{}.csv"
LOG_EXT = "ghcnm-err.dat"
ERROR_FILE = os.path.join('data','ops','gsom_gsoy_new','status','error-gsoy.txt') # Default path to write error to

def writeOutputFile(stationID: str, outputDF: pl.DataFrame):
    #print( outputDF)
    outputDF.write_csv(filePaths['output'].format(stationID),
                       separator=",")

def execute():
    
    #Read in station list
    #stored in DataFrame with their metadata
    stationList = StationUtils.loadStationsAsDataFrame(filePaths['stations'])
    
    # Open asos som .tar.gz. Calling here so only do it once instead of each station.
    tar = None
    try:
        tar = tarfile.open(filePaths['som'])
        # Need to get a list of all paths in archive
        som_csv_paths = tar.getnames()
    except Exception as e:
        print('Error in opening asos som')
        # TODO add to log

    #Loop through the stations and process the DLYs
    for station in range(stationList.height):
    #for station in range(1):    
        stationID = stationList.select( pl.col("Station") )[station].item()
        print(stationID)
        #Pull the corresp onding DLY and turn it into a DataFrame
        #print( filePaths['input'].format(stationID) )
        inputDF = ioU.dlyAsDataFrame( filePaths['input'].format(stationID) )
        
        #TODO Move prototype code out of ioU into Monthly Summary 
        #Send the inputDF to the Monthly Calculator
        #outputDF = MonthlySummary.summarizeMonths(inputDF, True)
        #TODO Remove this once MonthlySummary is updated
        outputDF = inputDF
        
        #Join ASOS SOM (Summary of the Month) elements
        if tar is not None:
            outputDF = som_processing.somToDataFrame(tar, som_csv_paths, outputDF, stationID)
        #Output the GSOM CSV
        writeOutputFile(stationID, outputDF)
        #print(outputDF)
        #TODO Send outputDF to GSOY
    if tar is not None:
        tar.close()

def parse_arguments():
    parser = ArgParserUtil.gsom_parser()  # Set up parser
    global filePaths
    filePaths = vars(parser.parse_args()) # Get dictionary of cmd args
    
    # Need to go through and attach extention onto some of them
    filePaths['input'] += INPUT_EXT 
    filePaths['output'] += OUTPUT_EXT
    filePaths['log'] += LOG_EXT

def main():
    #print('Hello World')
    # Get path files or exit if not present
    parse_arguments()

    # Start logging
    logging.basicConfig(filename=filePaths['log'], level=logging.INFO)
    statusLog.info('Log Started')

    start = time.perf_counter()
    execute()
    end = time.perf_counter()
    print(round(end-start,3))

if __name__ == '__main__':
    main()