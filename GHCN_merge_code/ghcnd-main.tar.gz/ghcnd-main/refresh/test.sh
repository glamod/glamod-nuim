# Set Internal variables.
dsi=eca # 1-to-15 character data set identifier used in subdirectory and station list names
src_code=E # one-character code used as source flag in GHCN-Daily files
refresh_dir=${HOME}/ghcnd/makelist/

for element in `cat ${refresh_dir}elements.txt`

do

for (( iter=1; ${iter} <= 2; iter=`expr ${iter} + 1` ))

do

gawk 'substr($0,12,1)==" " {print $1}' eca-${element}-stations-prescreened-dupchecked-${iter}.txt > tmp.txt
cat tmp.txt eca-${element}-${iter}.data.xref | cut -c1-11 | sort | uniq -u > eca-${element}-${iter}.data.noxref

# Creates subset of ECA stations not matched based on data
echo "Creating list of ECA stations not cross-referenced based on data for ${element} on " `date`
rm -f ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt
for i in `cat ${refresh_dir}${dsi}-${element}-${iter}.data.noxref | cut -c1-11`
do
grep "${i}" ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-${iter}.txt >> ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt 
done

# Match ECA stations with GHCN-Daily stations based on latitude/longitude
echo "Starting gen-coord-xref.exe for ${element}-${iter} on" `date`
${refresh_dir}gen-coord-xref.exe ${refresh_dir}ghcnd-stations.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt  ${refresh_dir}${dsi}-${element}-${iter}.coord.xref ${refresh_dir}${dsi}-${element}-${iter}.coord.noxref  

# Creates subset of ECA stations not matched based on data or coordinates
echo "Creating list of ECA stations not cross-referenced based on data or coordinates for ${element} on " `date`
rm -f ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nocoordxref-${iter}.txt
for i in `cat ${refresh_dir}${dsi}-${element}-${iter}.coord.noxref | cut -c1-11`
do
grep "${i}" ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-${iter}.txt >> ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nocoordxref-${iter}.txt 
done

echo "Starting gen-meta-xref.exe for ${element} on" `date`
${refresh_dir}gen-meta-xref.exe ${refresh_dir}ghcnd-stations.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nocoordxref-${iter}.txt ${refresh_dir}${dsi}-${element}-${iter}.meta.xref ${refresh_dir}${dsi}-${element}-${iter}.meta.noxref

# Combine all of the cross-reference results.
cat ${refresh_dir}${dsi}-${element}-${iter}.coord.xref ${refresh_dir}${dsi}-${element}-${iter}.meta.xref > ${refresh_dir}${dsi}-${element}-${iter}.xref

# integrate the matched stations into the corresponding GHCN-Daily 
# station list and mingle list records and add any unmatched stations as new station records.
echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list.txt ${refresh_dir}ghcnd-stations.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt ${src_code} ${refresh_dir}${dsi}-${element}-${iter}.xref

# Move the log files to element-specific names:
mv ${refresh_dir}gen-coord-xref.log ${refresh_dir}gen-coord-xref.${dsi}-${element}-${iter}.log  
mv ${refresh_dir}gen-meta-xref.log ${refresh_dir}gen-meta-xref.${dsi}-${element}-${iter}.log  
mv ${refresh_dir}add_stns.log ${refresh_dir}add_stns.${dsi}-${element}-${iter}.log 

done
done

# Reset the GSN designation in the GHCN-Daily station list.
mv ${refresh_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.4gsn
echo "Starting setGSNfield.exe on" `date`
${refresh_dir}setGSNfield.exe ${refresh_dir}gsn-ids20090101.txt ${refresh_dir}ghcnd-stations.4gsn ${refresh_dir}ghcnd-stations.txt
echo "Number of GSN stations now in ghcnd-stations" `gawk 'substr($0,73,3)=="GSN" {print $0}' ${refresh_dir}ghcnd-stations.txt | wc | cut -c1-7`
