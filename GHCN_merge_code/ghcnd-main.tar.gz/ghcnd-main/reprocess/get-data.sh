#

export PREFIX=$1

run_status=$2
#"sync" or "test"

export lib_dir=$3
export timestamp=`date -u '+%Y%m%d%H'`

yr35daysago=`date -d "35 days ago" +%Y`
mo35daysago=`date -d "35 days ago" +%m`
lastrawsday=`cal ${mo35daysago} ${yr35daysago} | grep -v '[A-Za-z]' | wc -w`

echo "Starting compile-ghcnd.sh" `date`
echo ghcndmod.f95 | ${PREFIX}compile-ghcnd.sh

cd $PREFIX
if [ ! -s download ]
then
mkdir download
fi

find ${PREFIX}archive -maxdepth 1 -name '*inventory*.txt' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.log' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.flags' -mtime +31 -exec rm -f {} \;
find ${PREFIX}archive -maxdepth 1 -name '*.tar.gz' -mtime +31 -exec rm -f {} \;

#GET THE INTERNATIONAL DATA SOURCES

#Get the Australian data
echo "Starting get-australia.sh" `date`
${lib_dir}get-australia.sh ${PREFIX}
echo "Starting gen-rawdata-australia.sh" `date`
${lib_dir}gen-rawdata-australia.sh ${PREFIX} por
echo "Starting rf_australia2ghcnd.exe" `date`
${lib_dir}rf_australia2ghcnd.exe ${PREFIX}

#Get the Canadian Data and append big por download with latest update
echo "Starting ghcn_canada.exe" `date`
${lib_dir}ghcn_canada.exe ${PREFIX}download/canada/ ${PREFIX}download/canada/rawghcnd/
cp -p ${PREFIX}download/canada/DailyClimateData.txt ${PREFIX}canada/archive/DailyClimateData-${timestamp}.txt
#echo "${PREFIX}download/canada/rawghcnd/" "${PREFIX}canada/archive/upd/rawghcnd/" | ${PREFIX}check_size.sh 
${lib_dir}update-archive.sh ${PREFIX}download/canada/rawghcnd ${PREFIX}canada/archive/upd/rawghcnd '*.dly'
echo "Copying ${PREFIX}canada/archive/upd/rawghcnd to ${PREFIX}canada/rawghcnd" `date`
rm -rf ${PREFIX}canada/rawghcnd
cp -rp ${PREFIX}canada/archive/upd/rawghcnd ${PREFIX}canada/rawghcnd

#Get the ECA Data
echo "Starting get-eca.sh" `date`
${lib_dir}get-eca.sh ${PREFIX}
echo "Starting check_size.sh for eca" `date`
echo "${PREFIX}download/eca/" "${PREFIX}eca/archive/" | ${lib_dir}check_size.sh
echo "Starting gen-rawdata-eca.sh" `date`
${lib_dir}gen-rawdata-eca.sh ${PREFIX}
echo "Starting rf-eca2ghcnd.exe" `date`
${lib_dir}rf-eca2ghcnd.exe ${PREFIX}

#Get the GCOS Database
echo "Starting getgcos_rf2ghcnd.exe" `date`
${PREFIX}getgcos_rf2ghcnd.exe ${PREFIX}download/
echo "Starting check_size.sh for gcos" `date`
echo "${PREFIX}download/gcos/rawghcnd/" "${PREFIX}gcos/rawghcnd/" | ${PREFIX}check_size.sh
echo "Creating gcos raw ghcnd inventory" `date`
ls ${PREFIX}gcos/rawghcnd | cut -c6-10 > ${PREFIX}gcos.inv

#Get the GSOD and RAWS data
echo "Starting get_gsod.exe" `date`
${lib_dir}get_gsod.exe ${PREFIX}download/ &
echo "Starting get-raws.sh" `date`
${lib_dir}get-raws.sh ${PREFIX} por ${yr35daysago}0101 ${yr35daysago}${mo35daysago}${lastrawsday}
echo "get-raws.sh finished at " `date`
wait

#Reformat GSOD
echo "Starting check_size.sh for gsod" `date`
echo "${PREFIX}download/gsod/rawdata/" "${PREFIX}gsod/rawdata/" | ${lib_dir}check_size.sh
ls ${PREFIX}/gsod/rawdata > ${PREFIX}gsod.inv
echo "Starting rf_gsod2ghcnd.exe" `date`
${lib_dir}rf_gsod2ghcnd.exe $PREFIX

#Reformat RAWS
echo "Starting gen-rawdata-raws.sh" `date`
${lib_dir}gen-rawdata-raws.sh
cut -c2-3,8-11 ${PREFIX}raws/rawdata/* | gawk '{print substr($0,3,4)substr($0,1,2)}' | sort -u | tail -1 > ${PREFIX}raws/archive/last-date-in-archive.txt
echo "Starting rf-raws2ghcnd.exe" `date`
${lib_dir}rf-raws2ghcnd.exe ${PREFIX}

#GET THE REALTIME SOURCES FOR THE USA

#Get the HPRCC (SHEF) data
echo "Starting get_hprcc.exe" `date`
${lib_dir}get_hprcc.exe ${PREFIX}
echo "Starting rf_hprcc2ghcnd.exe" `date`
${lib_dir}rf_hprcc2ghcnd.exe ${PREFIX}

#Get the CoCoRaHS data
echo "Starting get-cocorahs.exe" `date`
${lib_dir}get-cocorahs.exe ${PREFIX} 20070101 `echo ${timestamp} | cut -c1-8`
echo "Starting rf-cocorahs2ghcnd.exe" `date`
${lib_dir}rf-cocorahs2ghcnd.exe ${PREFIX}

#Get the Snotel data
#echo "Starting get-snotel.exe" `date`
#${PREFIX}get-snotel.exe ${PREFIX}download/ ${PREFIX}input4sys/snotel-inv.txt 
#rm -rf ${PREFIX}snotel/rawdataold 
#rm -rf ${PREFIX}snotel/rawghcndnew 
#rm -rf ${PREFIX}snotel/rawghcndold
#mv ${PREFIX}snotel/rawdata ${PREFIX}snotel/rawdataold
#mv ${PREFIX}snotel/rawghcnd ${PREFIX}snotel/rawghcndold
#mv ${PREFIX}download/snotel/rawdata ${PREFIX}snotel
#echo "Starting rf-snotel2ghcnd.exe " `date`
#${PREFIX}rf-snotel2ghcnd.exe ${PREFIX}
#mv ${PREFIX}snotel/rawghcnd ${PREFIX}snotel/rawghcndnew 
#mv ${PREFIX}snotel/rawghcndold ${PREFIX}snotel/rawghcnd 
#echo "Starting check_size.sh for snotel" `date`
#echo "${PREFIX}snotel/rawghcndnew/" "${PREFIX}snotel/rawghcnd/" | ${PREFIX}check_size.sh

echo "Starting get-snotel-nrcs-rf2ghcnd.exe" `date`
yyyy=`echo ${timestamp} | cut -c1-4`
mm=`echo ${timestamp} | cut -c5-6`
dd=`echo ${timestamp} | cut -c7-8`
${lib_dir}get-snotel-nrcs-rf2ghcnd.exe 1960-01-01 ${yyyy}-${mm}-${dd} ${PREFIX}download/snotel/rawdata/ ${PREFIX}download/snotel/rawghcnd/ ${PREFIX}download/snotel/snotel-stations.txt ${PREFIX}download/snotel/snotel-match-list.txt
${lib_dir}update-archive-snotel.sh ${PREFIX}download/snotel/rawghcnd ${PREFIX}snotel/rawghcnd '*.dly'

#Get the CRN data
echo "Starting get_crn.exe" `date`
${lib_dir}get_crn.exe ${PREFIX}download/
echo "Starting check_size.sh for crn" `date`
echo "${PREFIX}download/crn/rawdata/" "${PREFIX}crn_archive/rawdata/" | ${lib_dir}check_size.sh
echo "Moving raw data from /crn_arhive/ to /crn/" `date`
rm -rf ${PREFIX}crn/rawdata
mv ${PREFIX}crn_archive/rawdata ${PREFIX}crn/rawdata
echo "Starting rf_crn2ghcnd.exe" `date`
${lib_dir}rf_crn2ghcnd.exe $PREFIX
echo "Moving /crn/rawdata back to /crn_archive/"
mv ${PREFIX}crn/rawdata ${PREFIX}crn_archive/rawdata

#Get the keyed paper coop data
#This is no longer a dynamic process (as of circa 2015)
#echo "Starting get-papercoop.sh" `date`
#${PREFIX}get-papercoop.sh ${PREFIX}
#echo "Starting rf-papercoop2ghcnd.exe" `date`
#${PREFIX}rf-papercoop2ghcnd.exe ${PREFIX}

#Get the wxcoder data
echo "Starting get-3207.sh" `date`
${lib_dir}get-3207.sh ${PREFIX}
#Parse the monthly wxcoder data into por station files
echo "Starting gen-rawghcnd-3207.sh" `date`
${lib_dir}gen-rawghcnd-3207.sh ${PREFIX}

#get and reformat the cf6 data
cp -p /ncdcftp/7days/cf6.archive.tar.gz ${PREFIX}cf6
tar xfz ${PREFIX}cf6/cf6.archive.tar.gz
echo "Starting get-cf6.sh" `date`
${lib_dir}get-cf6.sh ${PREFIX} ${lib_dir}
echo "Starting rf-cf62ghcnd.exe" `date`
${lib_dir}rf-cf62ghcnd.exe ${PREFIX}


#GET AND REFORMAT THE ARCHIVED SOURCES FOR THE USA

echo "Starting get-isdsod.sh" `date`
${lib_dir}get-isdsod.sh ${PREFIX} 2006 `echo ${timestamp} | cut -c1-4` &

echo "Starting get_32xx.exe" `date`
${PREFIX}get_32xx.exe ${PREFIX}download/
echo "Starting check_size.sh for 3200" `date`
echo "${PREFIX}download/3200/rawdata/" "${PREFIX}3200/rawdata/" | ${PREFIX}check_size.sh
echo "Starting rf320x_to_ghcnd.exe for 3200" `date`
${PREFIX}rf320x_to_ghcnd.exe $PREFIX M 3200
echo "Starting check_size.sh for 3206" `date`
echo "${PREFIX}download/3206/rawdata/" "${PREFIX}3206/rawdata/" | ${PREFIX}check_size.sh
echo "Starting rf320x_to_ghcnd.exe for 3206" `date`
${PREFIX}rf320x_to_ghcnd.exe $PREFIX M 3206
echo "Starting check_size.sh for 3210" `date`
echo "${PREFIX}download/3210/rawdata/" "${PREFIX}3210/rawdata/" | ${PREFIX}check_size.sh
echo "Starting rf3210or3211_to_ghcnd.exe for 3210" `date`
${PREFIX}rf3210or3211_to_ghcnd.exe $PREFIX M 3210
echo "Starting check_size.sh for 3211" `date`
echo "${PREFIX}download/3211/rawdata/" "${PREFIX}3211/rawdata/" | ${PREFIX}check_size.sh
echo "Starting rf3210or3211_to_ghcnd.exe for 3211" `date`
${PREFIX}rf3210or3211_to_ghcnd.exe $PREFIX M 3211
wait

${lib_dir}update-archive2.sh ${PREFIX}download/wsod ${PREFIX}wsod/isdsod/archive 'sod*.isd'

echo "Starting rf-isdsod2ghcnd.exe" `date`
${lib_dir}rf-isdsod2ghcnd.exe ${PREFIX} ${PREFIX}input4sys/wsod-stations-utc-offsets.txt

echo "Starting cat-isdsod-maed.sh" `date`
${lib_dir}cat-isdsod-maed.sh ${PREFIX}

#Reformat the latest 3210 edits for Datzilla
echo "Starting rf-3210edits4datzilla.exe" `date`
${lib_dir}rf-3210edits4datzilla.exe $PREFIX M 3210

#GET THE LATEST DATZILLA TICKETS
echo "Starting get-datzilla.sh" `date`
${PREFIX}get-datzilla.sh ${PREFIX}
${PREFIX}update-archive2.sh ${PREFIX}download/datzilla ${PREFIX}datzilla/archive '*Corr.txt'
echo "Starting gen-datzilla-rawdata.sh" `date`
${lib_dir}gen-datzilla-rawdata.sh ${PREFIX}

