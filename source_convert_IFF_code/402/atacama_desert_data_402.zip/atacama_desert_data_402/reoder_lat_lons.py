# -*- coding: utf-8 -*-
"""
Created on Thu Oct 24 10:55:50 2024

@author: snoone
"""

import os
import pandas as pd

# Directory containing the pipe-delimited files
directory = "C:/Users/snoone/Dropbox/atacama_desert_chile_data/CDM_lite/wind_speed"

# Loop through each file in the directory
for filename in os.listdir(directory):
    if filename.endswith(".psv") or filename.endswith(".psv"):  # Assuming the files are either .txt or .csv
        file_path = os.path.join(directory, filename)
        
        # Read the file as a DataFrame
        df = pd.read_csv(file_path, delimiter='|')
        
        # Rename 'latitude' to 'longitude' and 'longitude' to 'latitude'
        df = df.rename(columns={'latitude': 'temp_longitude', 'longitude': 'temp_latitude'})
        df = df.rename(columns={'temp_longitude': 'longitude', 'temp_latitude': 'latitude'})
        
        # Assuming you have a fixed number of columns, reorder the columns
        # Adjust based on the actual structure of your file
        cols = df.columns.tolist()  # Get list of current columns
        cols.insert(4, cols.pop(cols.index('longitude')))  # Move 'longitude' to 5th position
        cols.insert(5, cols.pop(cols.index('latitude')))  # Move 'latitude' to 6th position
        
        df = df[cols]  # Reorder columns
        
        # Save the file with the same name back to the directory
        df.to_csv(file_path, sep='|', index=False)

print("Processing complete!")
