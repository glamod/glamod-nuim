echo "Starting get-raws.sh" `date`
${lib_dir}get-raws.sh ${PREFIX} por 20240101 20240208 
echo "get-raws.sh finished at " `date`
echo "Starting gen-rawdata-raws.sh" `date`
${lib_dir}gen-rawdata-raws.sh
cut -c2-3,8-11 ${PREFIX}raws/rawdata/* | gawk '{print substr($0,3,4)substr($0,1,2)}' | sort -u | tail -1 > ${PREFIX}raws/archive/last-date-in-archive.txt
echo "Starting rf-raws2ghcnd.exe" `date`
${lib_dir}rf-raws2ghcnd.exe ${PREFIX}
