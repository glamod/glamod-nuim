#Use gawk, tr, sed etc to extract state,id,name,lat,lon and elev from csv station metadata file
#System call also changes all characters to upper case and removes the "'" and "FT" from elevations
#and sorts by id, year and month and gets rid of header line
gawk 'BEGIN {FS=","} {printf "%2s %6.6i %7s %30s %9.5f %9.5f %8s\n", substr($1,1,2),$2,$4,$5,$7,$8,$10}' DSI-3297CDMP19thCenturyStations.dat | tr -s / | tr 'a-z' 'A-Z' | sed s/' FT'/'   '/g | sed s/\'/' '/g | sort -k 1.4,1.9 -k 1.14,1.17 -n -k 1.12,1.13 | grep -v "STATION NAME" > forts-list-reformatted.txt
