from typing import Dict, Tuple
import polars as pl

from utils import InputOutputUtils as ioU

def loadStationsAsDataFrame(stationPath:str) -> pl.DataFrame:
    
	col_list = {
		"Station":12, 
		"Latitude":9, 
		"Longitude":9, 
		"Elevation":7, 
		"State":3, 
		"Name":31, 
		"Network":8, 
		"WMO":5
	}

	df = ioU.fixedWidthInputToDataFrame(stationPath, col_list )
	#changing dType of Latitude so that we can compare to 0.0
	df = df.cast( { "Latitude":pl.Float64, "Longitude":pl.Float64, "Elevation":pl.Float64 }, strict=False )
	df = df.with_columns( (pl.col("Latitude") >= 0.0).alias("isNorthHemisphere") )
	return df