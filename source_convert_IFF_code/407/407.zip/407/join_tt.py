# -*- coding: utf-8 -*-
"""
Created on Tue Apr  8 11:28:56 2025

@author: snoone
"""
import os
import pandas as pd

# Define the directory containing the .psv files
input_dir = r"C:\Users\snoone\Dropbox\NEW_DATA_SOURCES_r8_\Yuri_B_New_data_use\All_Giessen_rescue_data\Giessen_new data\Chilean_sbdy_\Chilean\Constitucion_merge\IFF\tt"

# Define the output directory
output_dir = r"C:\Users\snoone\Dropbox\NEW_DATA_SOURCES_r8_\Yuri_B_New_data_use\All_Giessen_rescue_data\Giessen_new data\Chilean_sbdy_\Chilean\Constitucion_merge\IFF"

# Ensure the output directory exists
os.makedirs(output_dir, exist_ok=True)

# Get a list of all .psv files in the directory
file_list = [f for f in os.listdir(input_dir) if f.endswith('.psv')]

# Initialize an empty DataFrame
combined_df = pd.DataFrame()

# Iterate through each file, read, and append it to the DataFrame
for file in file_list:
    file_path = os.path.join(input_dir, file)
    df = pd.read_csv(file_path, sep='|')  # Use the appropriate separator for .psv files
    combined_df = pd.concat([combined_df, df], ignore_index=True)

# Ensure the 'Station_ID' column exists
if 'Station_ID' in combined_df.columns:
    # Sort the DataFrame by Year, Month, Day, and Hour
    sort_columns = ['Year', 'Month', 'Day', 'Hour']
    if all(col in combined_df.columns for col in sort_columns):
        combined_df = combined_df.sort_values(by=sort_columns)
    else:
        print(f"Warning: One or more sorting columns {sort_columns} are missing in the data.")

    # Use the first unique Station_ID for the output file name
    station_id = combined_df['Station_ID'].iloc[0]
    output_file = os.path.join(output_dir, f"{station_id}_temperature_407.psv")
    
    # Save the combined DataFrame to the output file, keeping only one header
    combined_df.to_csv(output_file, sep='|', index=False)
    
    print(f"Combined and sorted file saved as: {output_file}")
else:
    print("Error: 'Station_ID' column not found in the data.")
