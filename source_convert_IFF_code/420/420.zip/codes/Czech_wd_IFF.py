#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 22 15:17:01 2026

@author: sangethaedathil
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CHMI wind direction D10 files → IFF row-by-row format

ONLY processes:
-D10.csv

Example:
dly-0-203-0-11639-D10.csv

RULES:
- Remove AVG observations
- Keep only 06, 13, 20 observations
- Remove invalid 0 direction values
- Convert observed values:
    10 -> 100 degrees
    20 -> 200 degrees
- Original_observed_value stays unchanged
- Clean Czech station names
- Remove double spaces
- Fix spacing around hyphens

Example:
Hradec Kralove - Ulrichovo namesti
→ Hradec Kralove-Ulrichovo namesti

Output:
CHMI_daily_data/IFF/wind_direction

Source_ID:
420
"""

import os
import glob
import pandas as pd
import unicodedata
import re


# ============================================================
# SETTINGS
# ============================================================

SOURCE_ID = "420"
VARIABLE_NAME = "wind_direction"

INPUT_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/wind"

META_FILE = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/station_metadata/meta1.csv"

OUTPUT_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/IFF/wind_direction"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# IFF COLUMNS
# ============================================================

IFF_COLUMNS = [
    "Source_ID",
    "Station_ID",
    "Station_name",
    "Alias_station_name",
    "Year",
    "Month",
    "Day",
    "Hour",
    "Minute",
    "Latitude",
    "Longitude",
    "Elevation",
    "Observed_value",
    "Source_QC_flag",
    "Original_observed_value",
    "Original_observed_value_units",
    "Report_type_code",
    "Measurement_code_1",
    "Measurement_code_2"
]


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def clean_text(value):

    if pd.isna(value):
        return ""

    value = str(value).strip()

    if value.lower() in ["nan", "none", "na", "nat"]:
        return ""

    return value


def clean_station_name(name):
    """
    Clean Czech station names.
    """

    name = clean_text(name)

    # Remove Czech accents
    name = unicodedata.normalize('NFKD', name)
    name = name.encode('ASCII', 'ignore').decode('ASCII')

    # Remove multiple spaces
    name = re.sub(r"\s+", " ", name)

    # Remove spaces around hyphen
    name = re.sub(r"\s*-\s*", "-", name)

    return name.strip()


def clean_number(value):
    """
    Remove unnecessary .0
    """

    if pd.isna(value):
        return ""

    try:

        num = float(value)

        if num.is_integer():
            return str(int(num))

        return str(num).rstrip("0").rstrip(".")

    except Exception:
        return clean_text(value)


def read_csv_safely(path):

    for sep in [",", ";", "\t"]:

        try:

            df = pd.read_csv(
                path,
                dtype=str,
                sep=sep
            )

            if df.shape[1] > 1:
                return df

        except Exception:
            continue

    return pd.read_csv(path, dtype=str)


def normalise_columns(df):

    df.columns = [
        str(col).strip().upper()
        for col in df.columns
    ]

    return df


def is_true_D10_file(filepath):

    filename = os.path.basename(filepath)

    return filename.endswith("-D10.csv")


def load_station_metadata():

    meta = read_csv_safely(META_FILE)

    meta = normalise_columns(meta)

    required_cols = [
        "WSI",
        "FULL_NAME",
        "GEOGR1",
        "GEOGR2"
    ]

    missing = [
        col for col in required_cols
        if col not in meta.columns
    ]

    if missing:

        raise ValueError(
            f"Metadata file missing required columns: {missing}\n"
            f"Available columns: {list(meta.columns)}"
        )

    meta["WSI"] = meta["WSI"].apply(clean_text)

    meta["Station_name"] = (
        meta["FULL_NAME"]
        .apply(clean_station_name)
    )

    # GEOGR2 = latitude
    meta["Latitude"] = meta["GEOGR2"].apply(clean_text)

    # GEOGR1 = longitude
    meta["Longitude"] = meta["GEOGR1"].apply(clean_text)

    possible_elevation_cols = [
        "ELEVATION",
        "ALTITUDE",
        "ALT",
        "ELEV",
        "VYSKA",
        "HEIGHT",
        "H"
    ]

    elevation_col = None

    for col in possible_elevation_cols:

        if col in meta.columns:
            elevation_col = col
            break

    if elevation_col:

        meta["Elevation"] = (
            meta[elevation_col]
            .apply(clean_number)
        )

    else:
        meta["Elevation"] = ""

    meta_lookup = meta[
        [
            "WSI",
            "Station_name",
            "Latitude",
            "Longitude",
            "Elevation"
        ]
    ].drop_duplicates(subset=["WSI"])

    return meta_lookup


# ============================================================
# MAIN CONVERSION
# ============================================================

def create_iff_from_direction_file(input_file, meta_lookup):

    filename = os.path.basename(input_file)

    print(f"Processing: {filename}")

    df = read_csv_safely(input_file)

    df = normalise_columns(df)

    required_cols = [
        "STATION",
        "ELEMENT",
        "DT",
        "VALUE"
    ]

    missing = [
        col for col in required_cols
        if col not in df.columns
    ]

    if missing:

        print(f"  Skipped. Missing columns: {missing}")

        return None

    # ========================================================
    # KEEP ONLY TRUE D10 ELEMENT
    # ========================================================

    df["ELEMENT"] = df["ELEMENT"].apply(clean_text)

    df = df[df["ELEMENT"] == "D10"].copy()

    if df.empty:

        print("  Skipped. No ELEMENT == D10 rows.")

        return None

    # ========================================================
    # STATION ID
    # ========================================================

    df["STATION"] = df["STATION"].apply(clean_text)

    # ========================================================
    # PARSE DATETIME
    # ========================================================

    dt = pd.to_datetime(
        df["DT"],
        errors="coerce",
        utc=True
    )

    df["Year"] = dt.dt.year
    df["Month"] = dt.dt.month
    df["Day"] = dt.dt.day
    df["Hour"] = dt.dt.hour
    df["Minute"] = dt.dt.minute

    df = df.dropna(
        subset=[
            "Year",
            "Month",
            "Day",
            "Hour",
            "Minute"
        ]
    ).copy()

    if df.empty:

        print("  Skipped. Date parsing failed.")

        return None

    # ========================================================
    # REMOVE AVG OBSERVATIONS
    # KEEP ONLY 06, 13, 20
    # ========================================================

    if "TIMEFUNC" in df.columns:

        df["TIMEFUNC"] = (
            df["TIMEFUNC"]
            .apply(clean_text)
        )

        df = df[df["TIMEFUNC"] != "AVG"].copy()

    df = df[
        (df["Minute"] == 0) &
        (df["Hour"].isin([6, 13, 20]))
    ].copy()

    if df.empty:

        print("  Skipped. No valid 06, 13, 20 observations.")

        return None

    # ========================================================
    # CLEAN VALUES
    # ========================================================

    df["VALUE"] = df["VALUE"].apply(clean_text)

    df = df[df["VALUE"] != ""].copy()

    df["VALUE_NUM"] = pd.to_numeric(
        df["VALUE"],
        errors="coerce"
    )

    df = df.dropna(subset=["VALUE_NUM"]).copy()

    if df.empty:

        print("  Skipped. No valid numeric values.")

        return None

    # ========================================================
    # REMOVE INVALID 0 VALUES
    # ========================================================

    df = df[df["VALUE_NUM"] != 0].copy()

    if df.empty:

        print("  Skipped. All values were 0.")

        return None

    # ========================================================
    # CONVERT TO TRUE WIND DIRECTION
    # 10 -> 100
    # 20 -> 200
    # ========================================================

    df["Observed_direction"] = df["VALUE_NUM"] * 10

    df["Observed_value_clean"] = (
        df["Observed_direction"]
        .apply(clean_number)
    )

    # Original values stay unchanged
    df["Original_value_clean"] = (
        df["VALUE_NUM"]
        .apply(clean_number)
    )

    # ========================================================
    # MERGE METADATA
    # ========================================================

    df = df.merge(
        meta_lookup,
        left_on="STATION",
        right_on="WSI",
        how="left"
    )

    df["Station_name"] = (
        df["Station_name"]
        .apply(clean_station_name)
    )

    df["Latitude"] = (
        df["Latitude"]
        .apply(clean_text)
    )

    df["Longitude"] = (
        df["Longitude"]
        .apply(clean_text)
    )

    df["Elevation"] = (
        df["Elevation"]
        .apply(clean_text)
    )

    # ========================================================
    # SORT
    # ========================================================

    df = df.sort_values(
        by=[
            "STATION",
            "Year",
            "Month",
            "Day",
            "Hour",
            "Minute"
        ]
    ).copy()

    # ========================================================
    # BUILD IFF
    # ========================================================

    iff = pd.DataFrame(index=df.index)

    iff["Source_ID"] = "420"

    iff["Station_ID"] = (
        df["STATION"]
        .apply(clean_text)
    )

    iff["Station_name"] = (
        df["Station_name"]
        .apply(clean_station_name)
    )

    iff["Alias_station_name"] = ""

    iff["Year"] = df["Year"].astype(int)

    iff["Month"] = df["Month"].astype(int)

    iff["Day"] = df["Day"].astype(int)

    iff["Hour"] = df["Hour"].astype(int)

    iff["Minute"] = df["Minute"].astype(int)

    iff["Latitude"] = (
        df["Latitude"]
        .apply(clean_text)
    )

    iff["Longitude"] = (
        df["Longitude"]
        .apply(clean_text)
    )

    iff["Elevation"] = (
        df["Elevation"]
        .apply(clean_text)
    )

    # Converted direction
    iff["Observed_value"] = df["Observed_value_clean"]

    # Blank QC
    iff["Source_QC_flag"] = ""

    # Original values unchanged
    iff["Original_observed_value"] = (
        df["Original_value_clean"]
    )

    # Degrees
    iff["Original_observed_value_units"] = "degrees"

    iff["Report_type_code"] = ""

    # Blank measurement codes
    iff["Measurement_code_1"] = ""

    iff["Measurement_code_2"] = ""

    # Final order
    iff = iff[IFF_COLUMNS]

    # Final safety
    iff["Source_ID"] = "420"

    station_id = clean_text(
        iff["Station_ID"].iloc[0]
    )

    output_filename = (
        f"{station_id}_{VARIABLE_NAME}_{SOURCE_ID}.psv"
    )

    output_path = os.path.join(
        OUTPUT_DIR,
        output_filename
    )

    iff.to_csv(
        output_path,
        sep="|",
        index=False
    )

    print(f"  Saved: {output_path}")

    print(f"  Rows: {len(iff)}")

    return output_path


# ============================================================
# MAIN
# ============================================================

def main():

    print("======================================")
    print("CHMI wind direction D10 → IFF")
    print("======================================")

    print("Loading metadata...")

    meta_lookup = load_station_metadata()

    print(f"Metadata stations loaded: {len(meta_lookup)}")

    all_csv_files = glob.glob(
        os.path.join(INPUT_DIR, "*.csv")
    )

    d10_files = [
        file for file in all_csv_files
        if is_true_D10_file(file)
    ]

    print(f"Input folder: {INPUT_DIR}")

    print(f"Output folder: {OUTPUT_DIR}")

    print(f"Total CSV files found: {len(all_csv_files)}")

    print(f"True -D10.csv files found: {len(d10_files)}")

    print("======================================")

    if not d10_files:

        print("No files ending with '-D10.csv' were found.")

        return

    created_files = []

    failed_files = []

    for file in sorted(d10_files):

        try:

            output = create_iff_from_direction_file(
                file,
                meta_lookup
            )

            if output:
                created_files.append(output)

        except Exception as e:

            print(f"FAILED: {os.path.basename(file)}")

            print(f"Reason: {e}")

            failed_files.append({
                "file": file,
                "error": str(e)
            })

    if failed_files:

        failed_log = os.path.join(
            OUTPUT_DIR,
            "failed_CHMI_wind_direction_D10_files.csv"
        )

        pd.DataFrame(failed_files).to_csv(
            failed_log,
            index=False
        )

        print(f"Failed file log saved to: {failed_log}")

    print("======================================")

    print("DONE")

    print(f"IFF files created: {len(created_files)}")

    print(f"Failed files: {len(failed_files)}")

    print("======================================")


if __name__ == "__main__":
    main()#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
CHMI wind direction D10 files → IFF row-by-row format

ONLY processes:
-D10.csv

Example:
dly-0-203-0-11639-D10.csv

RULES:
- Remove AVG observations
- Keep only 06, 13, 20 observations
- Remove invalid 0 direction values
- Convert observed values:
    10 -> 100 degrees
    20 -> 200 degrees
- Original_observed_value stays unchanged
- Clean Czech station names
- Remove double spaces
- Fix spacing around hyphens

Example:
Hradec Kralove - Ulrichovo namesti
→ Hradec Kralove-Ulrichovo namesti

Output:
CHMI_daily_data/IFF/wind_direction

Source_ID:
420
"""

import os
import glob
import pandas as pd
import unicodedata
import re


# ============================================================
# SETTINGS
# ============================================================

SOURCE_ID = "420"
VARIABLE_NAME = "wind_direction"

INPUT_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/wind"

META_FILE = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/station_metadata/meta1.csv"

OUTPUT_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/CHMI_daily_data/IFF/wind_direction"

os.makedirs(OUTPUT_DIR, exist_ok=True)


# ============================================================
# IFF COLUMNS
# ============================================================

IFF_COLUMNS = [
    "Source_ID",
    "Station_ID",
    "Station_name",
    "Alias_station_name",
    "Year",
    "Month",
    "Day",
    "Hour",
    "Minute",
    "Latitude",
    "Longitude",
    "Elevation",
    "Observed_value",
    "Source_QC_flag",
    "Original_observed_value",
    "Original_observed_value_units",
    "Report_type_code",
    "Measurement_code_1",
    "Measurement_code_2"
]


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def clean_text(value):

    if pd.isna(value):
        return ""

    value = str(value).strip()

    if value.lower() in ["nan", "none", "na", "nat"]:
        return ""

    return value


def clean_station_name(name):
    """
    Clean Czech station names.
    """

    name = clean_text(name)

    # Remove Czech accents
    name = unicodedata.normalize('NFKD', name)
    name = name.encode('ASCII', 'ignore').decode('ASCII')

    # Remove multiple spaces
    name = re.sub(r"\s+", " ", name)

    # Remove spaces around hyphen
    name = re.sub(r"\s*-\s*", "-", name)

    return name.strip()


def clean_number(value):
    """
    Remove unnecessary .0
    """

    if pd.isna(value):
        return ""

    try:

        num = float(value)

        if num.is_integer():
            return str(int(num))

        return str(num).rstrip("0").rstrip(".")

    except Exception:
        return clean_text(value)


def read_csv_safely(path):

    for sep in [",", ";", "\t"]:

        try:

            df = pd.read_csv(
                path,
                dtype=str,
                sep=sep
            )

            if df.shape[1] > 1:
                return df

        except Exception:
            continue

    return pd.read_csv(path, dtype=str)


def normalise_columns(df):

    df.columns = [
        str(col).strip().upper()
        for col in df.columns
    ]

    return df


def is_true_D10_file(filepath):

    filename = os.path.basename(filepath)

    return filename.endswith("-D10.csv")


def load_station_metadata():

    meta = read_csv_safely(META_FILE)

    meta = normalise_columns(meta)

    required_cols = [
        "WSI",
        "FULL_NAME",
        "GEOGR1",
        "GEOGR2"
    ]

    missing = [
        col for col in required_cols
        if col not in meta.columns
    ]

    if missing:

        raise ValueError(
            f"Metadata file missing required columns: {missing}\n"
            f"Available columns: {list(meta.columns)}"
        )

    meta["WSI"] = meta["WSI"].apply(clean_text)

    meta["Station_name"] = (
        meta["FULL_NAME"]
        .apply(clean_station_name)
    )

    # GEOGR2 = latitude
    meta["Latitude"] = meta["GEOGR2"].apply(clean_text)

    # GEOGR1 = longitude
    meta["Longitude"] = meta["GEOGR1"].apply(clean_text)

    possible_elevation_cols = [
        "ELEVATION",
        "ALTITUDE",
        "ALT",
        "ELEV",
        "VYSKA",
        "HEIGHT",
        "H"
    ]

    elevation_col = None

    for col in possible_elevation_cols:

        if col in meta.columns:
            elevation_col = col
            break

    if elevation_col:

        meta["Elevation"] = (
            meta[elevation_col]
            .apply(clean_number)
        )

    else:
        meta["Elevation"] = ""

    meta_lookup = meta[
        [
            "WSI",
            "Station_name",
            "Latitude",
            "Longitude",
            "Elevation"
        ]
    ].drop_duplicates(subset=["WSI"])

    return meta_lookup


# ============================================================
# MAIN CONVERSION
# ============================================================

def create_iff_from_direction_file(input_file, meta_lookup):

    filename = os.path.basename(input_file)

    print(f"Processing: {filename}")

    df = read_csv_safely(input_file)

    df = normalise_columns(df)

    required_cols = [
        "STATION",
        "ELEMENT",
        "DT",
        "VALUE"
    ]

    missing = [
        col for col in required_cols
        if col not in df.columns
    ]

    if missing:

        print(f"  Skipped. Missing columns: {missing}")

        return None

    # ========================================================
    # KEEP ONLY TRUE D10 ELEMENT
    # ========================================================

    df["ELEMENT"] = df["ELEMENT"].apply(clean_text)

    df = df[df["ELEMENT"] == "D10"].copy()

    if df.empty:

        print("  Skipped. No ELEMENT == D10 rows.")

        return None

    # ========================================================
    # STATION ID
    # ========================================================

    df["STATION"] = df["STATION"].apply(clean_text)

    # ========================================================
    # PARSE DATETIME
    # ========================================================

    dt = pd.to_datetime(
        df["DT"],
        errors="coerce",
        utc=True
    )

    df["Year"] = dt.dt.year
    df["Month"] = dt.dt.month
    df["Day"] = dt.dt.day
    df["Hour"] = dt.dt.hour
    df["Minute"] = dt.dt.minute

    df = df.dropna(
        subset=[
            "Year",
            "Month",
            "Day",
            "Hour",
            "Minute"
        ]
    ).copy()

    if df.empty:

        print("  Skipped. Date parsing failed.")

        return None

    # ========================================================
    # REMOVE AVG OBSERVATIONS
    # KEEP ONLY 06, 13, 20
    # ========================================================

    if "TIMEFUNC" in df.columns:

        df["TIMEFUNC"] = (
            df["TIMEFUNC"]
            .apply(clean_text)
        )

        df = df[df["TIMEFUNC"] != "AVG"].copy()

    df = df[
        (df["Minute"] == 0) &
        (df["Hour"].isin([6, 13, 20]))
    ].copy()

    if df.empty:

        print("  Skipped. No valid 06, 13, 20 observations.")

        return None

    # ========================================================
    # CLEAN VALUES
    # ========================================================

    df["VALUE"] = df["VALUE"].apply(clean_text)

    df = df[df["VALUE"] != ""].copy()

    df["VALUE_NUM"] = pd.to_numeric(
        df["VALUE"],
        errors="coerce"
    )

    df = df.dropna(subset=["VALUE_NUM"]).copy()

    if df.empty:

        print("  Skipped. No valid numeric values.")

        return None

    # ========================================================
    # REMOVE INVALID 0 VALUES
    # ========================================================

    df = df[df["VALUE_NUM"] != 0].copy()

    if df.empty:

        print("  Skipped. All values were 0.")

        return None

    # ========================================================
    # CONVERT TO TRUE WIND DIRECTION
    # 10 -> 100
    # 20 -> 200
    # ========================================================

    df["Observed_direction"] = df["VALUE_NUM"] * 10

    df["Observed_value_clean"] = (
        df["Observed_direction"]
        .apply(clean_number)
    )

    # Original values stay unchanged
    df["Original_value_clean"] = (
        df["VALUE_NUM"]
        .apply(clean_number)
    )

    # ========================================================
    # MERGE METADATA
    # ========================================================

    df = df.merge(
        meta_lookup,
        left_on="STATION",
        right_on="WSI",
        how="left"
    )

    df["Station_name"] = (
        df["Station_name"]
        .apply(clean_station_name)
    )

    df["Latitude"] = (
        df["Latitude"]
        .apply(clean_text)
    )

    df["Longitude"] = (
        df["Longitude"]
        .apply(clean_text)
    )

    df["Elevation"] = (
        df["Elevation"]
        .apply(clean_text)
    )

    # ========================================================
    # SORT
    # ========================================================

    df = df.sort_values(
        by=[
            "STATION",
            "Year",
            "Month",
            "Day",
            "Hour",
            "Minute"
        ]
    ).copy()

    # ========================================================
    # BUILD IFF
    # ========================================================

    iff = pd.DataFrame(index=df.index)

    iff["Source_ID"] = "420"

    iff["Station_ID"] = (
        df["STATION"]
        .apply(clean_text)
    )

    iff["Station_name"] = (
        df["Station_name"]
        .apply(clean_station_name)
    )

    iff["Alias_station_name"] = ""

    iff["Year"] = df["Year"].astype(int)

    iff["Month"] = df["Month"].astype(int)

    iff["Day"] = df["Day"].astype(int)

    iff["Hour"] = df["Hour"].astype(int)

    iff["Minute"] = df["Minute"].astype(int)

    iff["Latitude"] = (
        df["Latitude"]
        .apply(clean_text)
    )

    iff["Longitude"] = (
        df["Longitude"]
        .apply(clean_text)
    )

    iff["Elevation"] = (
        df["Elevation"]
        .apply(clean_text)
    )

    # Converted direction
    iff["Observed_value"] = df["Observed_value_clean"]

    # Blank QC
    iff["Source_QC_flag"] = ""

    # Original values unchanged
    iff["Original_observed_value"] = (
        df["Original_value_clean"]
    )

    # Degrees
    iff["Original_observed_value_units"] = "degrees"

    iff["Report_type_code"] = ""

    # Blank measurement codes
    iff["Measurement_code_1"] = ""

    iff["Measurement_code_2"] = ""

    # Final order
    iff = iff[IFF_COLUMNS]

    # Final safety
    iff["Source_ID"] = "420"

    station_id = clean_text(
        iff["Station_ID"].iloc[0]
    )

    output_filename = (
        f"{station_id}_{VARIABLE_NAME}_{SOURCE_ID}.psv"
    )

    output_path = os.path.join(
        OUTPUT_DIR,
        output_filename
    )

    iff.to_csv(
        output_path,
        sep="|",
        index=False
    )

    print(f"  Saved: {output_path}")

    print(f"  Rows: {len(iff)}")

    return output_path


# ============================================================
# MAIN
# ============================================================

def main():

    print("======================================")
    print("CHMI wind direction D10 → IFF")
    print("======================================")

    print("Loading metadata...")

    meta_lookup = load_station_metadata()

    print(f"Metadata stations loaded: {len(meta_lookup)}")

    all_csv_files = glob.glob(
        os.path.join(INPUT_DIR, "*.csv")
    )

    d10_files = [
        file for file in all_csv_files
        if is_true_D10_file(file)
    ]

    print(f"Input folder: {INPUT_DIR}")

    print(f"Output folder: {OUTPUT_DIR}")

    print(f"Total CSV files found: {len(all_csv_files)}")

    print(f"True -D10.csv files found: {len(d10_files)}")

    print("======================================")

    if not d10_files:

        print("No files ending with '-D10.csv' were found.")

        return

    created_files = []

    failed_files = []

    for file in sorted(d10_files):

        try:

            output = create_iff_from_direction_file(
                file,
                meta_lookup
            )

            if output:
                created_files.append(output)

        except Exception as e:

            print(f"FAILED: {os.path.basename(file)}")

            print(f"Reason: {e}")

            failed_files.append({
                "file": file,
                "error": str(e)
            })

    if failed_files:

        failed_log = os.path.join(
            OUTPUT_DIR,
            "failed_CHMI_wind_direction_D10_files.csv"
        )

        pd.DataFrame(failed_files).to_csv(
            failed_log,
            index=False
        )

        print(f"Failed file log saved to: {failed_log}")

    print("======================================")

    print("DONE")

    print(f"IFF files created: {len(created_files)}")

    print(f"Failed files: {len(failed_files)}")

    print("======================================")


if __name__ == "__main__":
    main()