refresh_dir=/data/makelist/
cd ${refresh_dir}
#cp -p /ghcn-daily/ghcnd-stations.txt /data/input4sys
#cp -p /ghcn-daily/mingle-list.txt /data/input4sys
#lf95path=/usr/local/lf6481/bin/
gfortran ${refresh_dir}ghcndmod.f95 ${refresh_dir}strip_source.f95 -o ${refresh_dir}strip_source.exe -ffree-line-length-none
echo "Starting strip_source.exe for 3207" `date`
${refresh_dir}strip_source.exe 7 /data/input4sys/mingle-list.txt /data/input4sys/ghcnd-stations.txt 
echo "Starting strip_source.exe for HPRCC" `date`
${refresh_dir}strip_source.exe H ${refresh_dir}mingle-list-no-7.txt ${refresh_dir}ghcnd-stations-no-7.txt 
echo "Starting strip_source.exe for CoCoRaHS" `date`
${refresh_dir}strip_source.exe N ${refresh_dir}mingle-list-no-H.txt ${refresh_dir}ghcnd-stations-no-H.txt 
mv ${refresh_dir}mingle-list-no-N.txt ${refresh_dir}mingle-list-no-7-no-H-no-N.txt
mv ${refresh_dir}ghcnd-stations-no-N.txt ${refresh_dir}ghcnd-stations-no-7-no-H-no-N.txt
cp -p ${refresh_dir}mingle-list-no-7-no-H-no-N.txt ${refresh_dir}mingle-list.txt
cp -p ${refresh_dir}ghcnd-stations-no-7-no-H-no-N.txt ${refresh_dir}ghcnd-stations.txt
${refresh_dir}refresh-coop.sh 3207 7 ${refresh_dir}
mv ${refresh_dir}gen-data-xref.log ${refresh_dir}gen-data-xref.3207.log
${refresh_dir}refresh-coop.sh hprcc H ${refresh_dir}
mv ${refresh_dir}gen-data-xref.log ${refresh_dir}gen-data-xref.hprcc.log
#${refresh_dir}refresh-cocorahs.sh ${refresh_dir}
#mv ${refresh_dir}gen-data-xref.log ${refresh_dir}gen-data-xref.cocorahs.log
${refresh_dir}refresh-wban.sh crn R ${refresh_dir}
mv ${refresh_dir}gen-data-xref.log ${refresh_dir}gen-data-xref.crn.log
