backup_dir=$1
if [ ${backup_dir} = "" ] 
then
exit
fi
cd $PREFIX
tar czf ${backup_dir}gsod-rawghcnd.tar.gz gsod/rawghcnd
tar czf ${backup_dir}hprcc-archive.tar.gz hprcc_archive
tar czf ${backup_dir}hprcc-rawghcnd.tar.gz hprcc/rawghcnd
tar czf ${backup_dir}raws-rawghcnd.tar.gz raws/rawghcnd
tar czf ${backup_dir}raws-archive.tar.gz raws/archive
tar czf ${backup_dir}snotel-rawghcnd.tar.gz snotel/rawghcnd
tar czf ${backup_dir}cocorahs-archive.tar.gz cocorahs/archive cocorahs/cocorahs-stations.xml
tar czf ${backup_dir}cocorahs-rawghcnd.tar.gz cocorahs/rawghcnd 
tar czf ${backup_dir}asos-archive.tar.gz asos_archive
tar czf ${backup_dir}asos-rawghcnd.tar.gz asos/rawghcnd
tar czf ${backup_dir}intl-rawghcnd.tar.gz intl/rawghcnd
tar czf ${backup_dir}unquarantined-archive.tar.gz unquarantined/rawdata unquarantined/*.*
tar czf ${backup_dir}unquarantined-rawghcnd.tar.gz unquarantined/rawghcnd
tar czf ${backup_dir}canada-rawghcnd.tar.gz canada/rawghcnd
tar czf ${backup_dir}canada-archive.tar.gz canada/archive
tar czf ${backup_dir}gcos-rawghcnd.tar.gz gcos/rawghcnd
tar czf ${backup_dir}australia-archive.tar.gz australia/*_archive
tar czf ${backup_dir}australia-rawghcnd.tar.gz australia/rawghcnd
tar czf ${backup_dir}china-rawghcnd.tar.gz china/rawghcnd
tar czf ${backup_dir}mexico-rawghcnd.tar.gz mexico/rawghcnd
tar czf ${backup_dir}belarus-archive.tar.gz belarus/*.*
tar czf ${backup_dir}belarus-rawghcnd.tar.gz belarus/rawghcnd
tar czf ${backup_dir}ukraine-archive.tar.gz ukraine/*.*
tar czf ${backup_dir}ukraine-rawghcnd.tar.gz ukraine/rawghcnd
tar czf ${backup_dir}uzbekistan-archive.tar.gz uzbekistan/*.*
tar czf ${backup_dir}uzbekistan-rawghcnd.tar.gz uzbekistan/rawghcnd
tar czf ${backup_dir}eca-archive.tar.gz eca/archive
tar czf ${backup_dir}eca-rawghcnd.tar.gz eca/rawghcnd
tar czf ${backup_dir}russia-archive.tar.gz russia/archive
tar czf ${backup_dir}russia-rawghcnd.tar.gz russia/rawghcnd
tar czf ${backup_dir}mae-rawghcnd.tar.gz mae/rawghcnd
tar czf ${backup_dir}3211-rawghcnd.tar.gz 3211/rawghcnd
tar czf ${backup_dir}forts-archive.tar.gz forts/rawdata forts/*.* 
tar czf ${backup_dir}forts-rawghcnd.tar.gz forts/rawghcnd
tar czf ${backup_dir}3207-archive.tar.gz 3207/archive
tar czf ${backup_dir}3207-rawghcnd.tar.gz 3207/rawghcnd
tar czf ${backup_dir}papercoop-archive.tar.gz papercoop/archive
tar czf ${backup_dir}papercoop-rawghcnd.tar.gz papercoop/rawghcnd
tar czf ${backup_dir}wsod-rawghcnd.tar.gz wsod/rawghcnd
tar czf ${backup_dir}3210-rawghcnd.tar.gz 3210/rawghcnd
tar czf ${backup_dir}3206-rawghcnd.tar.gz 3206/rawghcnd
tar czf ${backup_dir}3200-rawghcnd.tar.gz 3200/rawghcnd
tar czf ${backup_dir}crn-rawghcnd.tar.gz crn/rawghcnd
tar czf ${backup_dir}datzilla-archive.tar.gz datzilla/archive
tar czf ${backup_dir}clim.tar.gz clim
tar czf ${backup_dir}input4sys.tar.gz input4sys
tar czf ${backup_dir}until.tar.gz archive/*until*
tar czf ${backup_dir}source-code.tar.gz ${lib_dir}*.f95 ${lib_dir}*.sh 
tar czf ${backup_dir}ghcnd-por.tar.gz ghcnd_por ghcnd-inventory.txt
