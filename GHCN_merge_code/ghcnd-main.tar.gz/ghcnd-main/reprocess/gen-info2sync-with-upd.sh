basedir=$1
backupdir=$2

cd ${backupdir}
tar cf ${basedir}ghcnd-backup.tar *.tar.gz

cd ${basedir}

cp -p ghcnd-backup.tar /ncdcftp/7days
#rm -f ftpin

#echo "open ncdcftp.ncdc.noaa.gov" > ftpin
#echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
#echo "cd /pub/upload/7days" >> ftpin
#echo "dele ghcnd-backup.tar" >> ftpin
#echo "put ghcnd-backup.tar" >> ftpin
#echo "quit" >> ftpin
#ftp -in < ftpin
#rm ftpin
