#!/bin/sh
# compile programs required by a refresh-wmo-with-list.sh.

compile_dir=$1 # directory where source code is located and executables will be placed
mod_file=$2 # path and name of module to use

lf95path=/usr/local/lf6480/bin/

${lf95path}lf95 ${mod_file} ${compile_dir}pre_screen.f95 -o ${compile_dir}pre_screen.exe --ap
${lf95path}lf95 ${mod_file} ${compile_dir}intrasource_dupchk.f95 -o ${compile_dir}intrasource_dupchk.exe --ap
${lf95path}lf95 ${mod_file} ${compile_dir}strip_source.f95 -o ${compile_dir}strip_source.exe 
${lf95path}lf95 ${mod_file} ${compile_dir}gen-wmo-xref.f95 -o ${compile_dir}gen-wmo-xref.exe 
${lf95path}lf95 ${mod_file} ${compile_dir}gen-data-xref.f95 -o ${compile_dir}gen-data-xref.exe --ap
${lf95path}lf95 ${mod_file} ${compile_dir}add_stns.f95 -o ${compile_dir}add_stns.exe 
${lf95path}lf95 ${mod_file} ${compile_dir}setGSNfield.f95 -o ${compile_dir}setGSNfield.exe
