#

export PREFIX=$1

run_status=$2

export minyr4update=`date -d "10 days ago" +%Y`

mmdd10daysago=`date -d "10 days ago" '+%m%d'`

if [ ${mmdd10daysago} = "0101" ]
then
run_checksize="no"
else
run_checksize="yes"
fi

export ftpdatapath="/pub/data/ghcn/daily"

export timestamp=`date -u '+%Y%m%d%H'`

sed 's/integer,parameter::iMinYr=1750/integer,parameter::iMinYr='${minyr4update}'/' ${PREFIX}ghcndmod.f95 > ${PREFIX}ghcndmod_update.f95

echo "Starting compile-ghcnd.sh" `date`
echo ghcndmod_update.f95 | ${PREFIX}compile-ghcnd.sh

echo "Starting get-latest-por-files.sh" `date`
${PREFIX}get-latest-por-files.sh ${PREFIX} /home/mmenne/backup/ghcnd2/

echo "Starting gen-stns2update.sh" `date`
${PREFIX}gen-stns2update.sh

cd $PREFIX

#Get RAWS Data while getting and reformatting other data sources 

if [ -s ${PREFIX}raws/archive/last-date-in-archive.txt ]
then
lastrawsporyr=`cut -c1-4 ${PREFIX}raws/archive/last-date-in-archive.txt`
lastrawspormo=`cut -c5-6 ${PREFIX}raws/archive/last-date-in-archive.txt`
if [ "${lastrawspormo}" = "12" ]
then
firstrawsupdyr=`expr ${lastrawsporyr} + 1`
firstrawsupdmo="01"
else
firstrawsupdyr=${lastrawsporyr}
firstrawsupdmo=`expr ${lastrawspormo} + 1`
fi

firstrawsupdmo=`printf %02i ${firstrawsupdmo}`

echo "Starting get-raws.sh" `date`
${PREFIX}get-raws.sh ${PREFIX} upd ${firstrawsupdyr}${firstrawsupdmo}01 `echo ${timestamp} | cut -c1-8` &

fi

echo "Starting get_hprcc.exe" `date`
${PREFIX}get_hprcc.exe $PREFIX
echo "Starting rf_hprcc2ghcnd.exe" `date`
${PREFIX}rf_hprcc2ghcnd.exe $PREFIX
echo "Starting get-cocorahs.exe" `date`
${PREFIX}get-cocorahs.exe ${PREFIX} ${minyr4update}0101 `echo ${timestamp} | cut -c1-8`
echo "Starting rf-cocorahs2ghcnd.exe" `date`
${PREFIX}rf-cocorahs2ghcnd.exe ${PREFIX} 
echo "Starting get-snotel.exe" `date`
${PREFIX}get-snotel.exe ${PREFIX}download/ ${PREFIX}input4sys/snotel-inv.txt ${minyr4update}0101 `echo ${timestamp} | cut -c1-8`
rm -rf ${PREFIX}snotel/rawdataold 
rm -rf ${PREFIX}snotel/rawghcndnew 
rm -rf ${PREFIX}snotel/rawghcndold
mv ${PREFIX}snotel/rawdata ${PREFIX}snotel/rawdataold
mv ${PREFIX}snotel/rawghcnd ${PREFIX}snotel/rawghcndold
mv ${PREFIX}download/snotel/rawdata ${PREFIX}snotel
echo "Starting rf-snotel2ghcnd.exe " `date`
${PREFIX}rf-snotel2ghcnd.exe ${PREFIX}
if [ ${run_checksize} = "yes" ]
then
mv ${PREFIX}snotel/rawghcnd ${PREFIX}snotel/rawghcndnew 
mv ${PREFIX}snotel/rawghcndold ${PREFIX}snotel/rawghcnd 
echo "Starting check_size.sh for snotel" `date`
echo "${PREFIX}snotel/rawghcndnew/" "${PREFIX}snotel/rawghcnd/" | ${PREFIX}check_size.sh
fi
echo "Starting get-isdsod.sh" `date`
${PREFIX}get-isdsod.sh ${PREFIX} ${minyr4update} `echo ${timestamp} | cut -c1-4`

${PREFIX}update-archive2.sh ${PREFIX}download/wsod ${PREFIX}wsod/isdsod/archive 'sod*.isd'

echo "Starting rf-isdsod2ghcnd.exe" `date`
${PREFIX}rf-isdsod2ghcnd.exe ${PREFIX} ${PREFIX}input4sys/wsod-stations-utc-offsets.txt

#Move the updated isdsod data to wsod/rawghcnd.  No need to cat with the maed data as in the por

if [ -s ${PREFIX}wsod/isdsod/rawghcnd ]
then
rm -rf ${PREFIX}wsod/rawghcnd
mv ${PREFIX}wsod/isdsod/rawghcnd ${PREFIX}wsod
fi

echo "Starting get-canada.sh" `date`
${PREFIX}get-canada.sh
echo "Copying ${PREFIX}canada/archive/upd/rawghcnd to ${PREFIX}canada/rawghcnd" `date`
rm -rf ${PREFIX}canada/rawghcnd
cp -rp ${PREFIX}canada/archive/upd/rawghcnd ${PREFIX}canada/rawghcnd
echo "Starting get_gsod.exe" `date`
${PREFIX}get_gsod.exe $PREFIX
ls ${PREFIX}/gsod/rawdata > ${PREFIX}gsod.inv
echo "Starting rf_gsod2ghcnd.exe" `date`
${PREFIX}rf_gsod2ghcnd.exe $PREFIX
echo "Starting get_crn.exe" `date`
${PREFIX}get_crn.exe $PREFIX
echo "Starting rf_crn2ghcnd.exe" `date`
${PREFIX}rf_crn2ghcnd.exe $PREFIX

#Wait until get-raws.sh has finished before doing anything else
wait

#Reformat RAWS data
echo "Starting gen-rawdata-raws.sh" `date`
${PREFIX}gen-rawdata-raws.sh

echo "Starting rf-raws2ghcnd.exe" `date`
${PREFIX}rf-raws2ghcnd.exe ${PREFIX}


#Mingle the data

echo "starting mingle.exe" `date`
${PREFIX}mingle.exe $PREFIX ${PREFIX}input4sys/mingle-list-update.txt

# PRE-FORMAT CHECK

echo "Starting pre format_check.exe" `date`
${PREFIX}format_check.exe pre ${PREFIX}input4sys/ghcnd-stations-update.txt ${PREFIX} ${PREFIX}mingled/ ${PREFIX}rawghcnd/ ${PREFIX}format_check_pre.log

# QC1, QC2 and QC3, etc.

echo "Starting qc1.exe" `date`
${PREFIX}qc1.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt M upd

echo "Starting rf_stn2time.exe" `date`
${PREFIX}rf_stn2time.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt

echo "Starting qc2.exe" `date`
${PREFIX}qc2.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt M upd

echo "Starting qc3.exe" `date`
${PREFIX}qc3.exe $PREFIX ${PREFIX}input4sys/ghcnd-stations-update.txt upd

echo "Starting post format_check.exe" `date`
${PREFIX}format_check.exe post ${PREFIX}input4sys/ghcnd-stations-update.txt ${PREFIX} ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log

echo "Starting append_upd2por.exe" `date`
${PREFIX}append_upd2por.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations-update.txt 

echo "Starting to copy updated files from ghcnd_upd to ghcnd_all" `date`
cd ${PREFIX}ghcnd_upd
for i in *
do
  cp -p ${PREFIX}ghcnd_upd/$i ${PREFIX}ghcnd_all
done

echo "Starting make_gsn_hcn.exe" `date`
${PREFIX}make_gsn_hcn.exe $PREFIX upd

por_version=`cat ${PREFIX}input4sys/por-version.txt`
vernum=`cat ${PREFIX}input4sys/version-number.txt`

echo "The current version of GHCN Daily is $vernum-upd-$timestamp (i.e, an update that started at $timestamp [yyyymmddhh] UTC; yyyy=year; mm=month; dd=day; hh=hour)," > ${PREFIX}ghcnd-version.txt
echo "created by appending recently available data updates to the last fully reprocessed version: ${por_version}." >> ${PREFIX}ghcnd-version.txt

echo "Starting ghcnd_ftp.sh" `date`
${PREFIX}ghcnd_ftp.sh upd ${run_status}

echo "Starting ghcnd_archive.sh" `date`
${PREFIX}ghcnd_archive.sh upd ${run_status} /home/mmenne/backup/ghcnd2/

echo "ghcnd_upd.sh finshed at" `date`

