# -*- coding: utf-8 -*-
"""
Created on Fri Feb 14 11:57:53 2025

@author: snoone
"""

import os
import glob
import pandas as pd
import matplotlib.pyplot as plt
import csv
import numpy as np

# Set directories
OUTDIR = "C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/IFF/rr"
os.chdir("C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/IFF/rr/out")

# File extension
extension = 'psv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

# Combine all files in the list
df = pd.concat([pd.read_csv(f, delimiter='|') for f in all_filenames])

# Clean and prepare the data
df["Observed_value"] = pd.to_numeric(df["Observed_value"], errors='coerce')
df["Observed_value"] = df["Observed_value"].round(1)
df["Original_observed_value"] = pd.to_numeric(df["Original_observed_value"], errors='coerce')
df["Original_observed_value"] = df["Original_observed_value"].round(2)

# Combine 'Year', 'Month', and 'Day' into a single column 'date_column'
df['date_column'] = df['Year'].astype(str) + '-' + df['Month'].astype(str).str.zfill(2) + '-' + df['Day'].astype(str).str.zfill(2) + '-' + df['Hour'].astype(str).str.zfill(2)
df = df.sort_values(by='date_column')
df = df.drop(columns=['date_column'])  # Drop the auxiliary 'date_column' after sorting

os.chdir("C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/IFF/rr")
cats = sorted(df['Station_ID'].unique())
for cat in cats:
    outfilename = cat + "_precipitation_405.psv"
    print(outfilename)
    df[df["Station_ID"] == cat].to_csv(outfilename, sep='|', index=False)
    os.chdir("C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/UGANDA/chosen_forms_uganda/admin/IFF/rr/out")

# Combine 'Year', 'Month', and 'Day' into a single datetime column
df['date'] = pd.to_datetime(df['Year'].astype(str) + '-' + df['Month'].astype(str).str.zfill(2) + '-' + df['Day'].astype(str).str.zfill(2))

# Group by date to calculate daily average
daily_avg = df.groupby('date')['Observed_value'].mean().reset_index()

# Plot the daily average pressure
plt.figure(figsize=(12, 6))
plt.plot(daily_avg['date'], daily_avg['Observed_value'], label='Daily Average precipitation', color='blue', linewidth=1.5)
plt.title('Daily Average precipitation', fontsize=16)
plt.xlabel('Date', fontsize=14)
plt.ylabel("(MM)", fontsize=14)
plt.grid(visible=True, linestyle='--', alpha=0.6)
plt.legend(fontsize=12)

# Save the plot as a high-quality JPEG
output_path = os.path.join(OUTDIR, 'precipitation.jpeg')
plt.savefig(output_path, format='jpeg', dpi=300)
plt.close()

print(f"Plot saved as {output_path}")
