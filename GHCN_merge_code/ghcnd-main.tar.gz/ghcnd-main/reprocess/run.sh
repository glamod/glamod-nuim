for (( unum=0 ; $unum <= 1; unum=`expr $unum + 0` ))
 do
   echo " "
 done

