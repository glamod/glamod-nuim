#!/bin/sh

### Create combined data set
cd ${PREFIX}raws
rm -rf ${PREFIX}raws/rawdata
mkdir ${PREFIX}raws/rawdata
find archive/data/* -type f -print | sort > raws-archive.inv
while read fnin
do
 fnout="rawdata/${fnin:18:8}"
 tail -n+8 $fnin | head -n-6 >> ${fnout}
done < raws-archive.inv
exit 0
