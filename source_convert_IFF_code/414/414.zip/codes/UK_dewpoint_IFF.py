#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import pandas as pd
import os
import re
import glob
from concurrent.futures import ThreadPoolExecutor

SOURCE_ID = "414"

STATIONDATA_DIR = "C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/midas_uk-hourly-weather-obs_v202507_FLAT/midas_uk-hourly-weather-obs_v202507/stationdata"
OUTDIR = os.path.join(STATIONDATA_DIR, "IFF_dewpoint_temperature_sn")
os.makedirs(OUTDIR, exist_ok=True)

POSSIBLE_DEWPOINT_COLS = [
    "dewpoint", "dew_point", "dewpoint_temperature", "dew_point_temperature"
]

DATE_COLS = ["ob_time", "ob_end_time", "time", "date", "Date"]

UNIT = "C"


# ------------------ Helpers ------------------

def get_station_name(filename, station_id):
    base = os.path.basename(filename).replace(".csv", "")
    m = re.search(rf"_{station_id}_(.*?)_qcv", base)
    return m.group(1).replace("_", "-").title() if m else station_id


def find_column(cols, possible_cols):
    cols = [str(c).strip() for c in cols]
    for col in possible_cols:
        if col in cols:
            return col
    return None


def parse_datetime(series):
    s = series.astype(str)

    # Fast ISO path (your main format)
    dt = pd.to_datetime(
        s,
        format="%Y-%m-%d %H:%M:%S",
        errors="coerce"
    )

    # fallback ONLY for weird formats (no dayfirst!)
    if dt.isna().any():
        dt_fallback = pd.to_datetime(s, errors="coerce")
        dt = dt.fillna(dt_fallback)

    return dt


def clean_numeric(series):
    s = pd.to_numeric(series, errors="coerce")
    return s.mask(s.isin([-9999, -999, -99]))


def read_metadata(file):
    try:
        with open(file, "r", encoding="utf-8", errors="ignore") as f:
            lines = [next(f, "") for _ in range(283)]

        def cell(line, idx):
            parts = line.split(",")
            return parts[idx].strip() if idx < len(parts) else ""

        lat = pd.to_numeric(cell(lines[16], 2), errors="coerce")
        lon = pd.to_numeric(cell(lines[16], 3), errors="coerce")
        elev = pd.to_numeric(cell(lines[17], 2), errors="coerce")

        return lat, lon, elev
    except:
        return None, None, None


# ------------------ Core ------------------

def process_station(station_folder):
    station_id = os.path.basename(station_folder)
    csv_files = glob.glob(os.path.join(station_folder, "*.csv"))

    if not csv_files:
        return None, [[station_id, "", "No CSV files"]]

    station_data = []
    failed = []

    for FILE in csv_files:

        lat, lon, elev = read_metadata(FILE)
        station_name = get_station_name(FILE, station_id)

        try:
            df = pd.read_csv(FILE, skiprows=283, low_memory=False)
        except:
            failed.append([station_id, FILE, "CSV read failed"])
            continue

        df.columns = df.columns.astype(str).str.strip()

        dew_col = find_column(df.columns, POSSIBLE_DEWPOINT_COLS)
        date_col = find_column(df.columns, DATE_COLS)

        if not dew_col or not date_col:
            failed.append([station_id, FILE, "Missing required column"])
            continue

        df = df[[date_col, dew_col]]

        df["Date"] = parse_datetime(df[date_col])
        df["Observed_value"] = clean_numeric(df[dew_col]).round(1)

        df = df.dropna(subset=["Date", "Observed_value"])

        if df.empty:
            continue

        # Metadata
        df["Source_ID"] = SOURCE_ID
        df["Station_ID"] = station_id
        df["Station_name"] = station_name
        df["Alias_station_name"] = ""

        df["Year"] = df["Date"].dt.year
        df["Month"] = df["Date"].dt.month
        df["Day"] = df["Date"].dt.day
        df["Hour"] = df["Date"].dt.hour.fillna(0)
        df["Minute"] = df["Date"].dt.minute.fillna(0)

        df["Latitude"] = round(lat, 3) if pd.notna(lat) else ""
        df["Longitude"] = round(lon, 3) if pd.notna(lon) else ""
        df["Elevation"] = int(elev) if pd.notna(elev) else ""

        df["Source_QC_flag"] = ""
        df["Report_type_code"] = ""
        df["Measurement_code_1"] = ""
        df["Measurement_code_2"] = ""

        df["Original_observed_value"] = df["Observed_value"]
        df["Original_observed_value_units"] = UNIT

        df = df[[
            "Source_ID", "Station_ID", "Station_name", "Alias_station_name",
            "Year", "Month", "Day", "Hour", "Minute",
            "Latitude", "Longitude", "Elevation",
            "Observed_value", "Source_QC_flag",
            "Original_observed_value", "Original_observed_value_units",
            "Report_type_code", "Measurement_code_1", "Measurement_code_2"
        ]]

        station_data.append(df)

    if not station_data:
        return None, failed

    station_df = pd.concat(station_data, ignore_index=True)

    station_df = station_df.sort_values(
        by=["Year", "Month", "Day", "Hour", "Minute"]
    ).fillna("")

    outname = f"{station_id}_dew_point_temperature_{SOURCE_ID}.psv"
    outpath = os.path.join(OUTDIR, outname)

    station_df.to_csv(outpath, sep="|", index=False)

    return outname, failed


# ------------------ Main ------------------

def main():
    station_folders = [
        f for f in glob.glob(os.path.join(STATIONDATA_DIR, "*"))
        if os.path.isdir(f) and os.path.basename(f).isdigit()
    ]

    print(f"Stations found: {len(station_folders)}")

    all_failed = []
    saved = 0

    # Threading (safe in Spyder)
    with ThreadPoolExecutor(max_workers=8) as executor:
        results = list(executor.map(process_station, station_folders))

    for outname, failed in results:
        if outname:
            saved += 1
            print(f"Saved: {outname}")
        all_failed.extend(failed)

    if all_failed:
        failed_log = os.path.join(OUTDIR, "failed_log.csv")
        pd.DataFrame(all_failed, columns=["Station_ID", "File", "Reason"]).to_csv(failed_log, index=False)
        print(f"\nFailed log saved: {failed_log}")

    print("\nDONE")
    print(f"Stations processed: {len(station_folders)}")
    print(f"Stations saved: {saved}")
    print(f"Output folder: {OUTDIR}")


if __name__ == "__main__":
    main()