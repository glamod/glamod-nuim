#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'

OUTDIR = ("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Chilean_sbdy_/Chilean/Santiago/IFF/tt")
os.chdir("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Chilean_sbdy_/Chilean/Santiago")

df=pd.read_csv("Santiago_master.csv") 
df["Source_ID"]="407"
df["Station_ID"]="358-00008"
df["Alias_station_name"]=""
df["Station_name"]="Santiago"
df["Latitude"]= "-33.447487"
df["Longitude"]= "-70.673676"
df["Elevation"]= "520"
df['Year'] = df["a"]
df['Month'] = df['b'] 
df['Day'] = df['c']
df["Hour"] = ""
df["Minute"]=""
df["Source_QC_flag"]=""
df['Original_observed_value_units']="c"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''
df['Original_observed_value']=''
df['Observed_value']=''


df1=df
#df1=df1.drop(columns =["a", "b", "c","Date","Pressure 4","Pressure 9","Pressure 10","Temperature 4","Temperature 10"])
df1["Hour"]="10" 
df1["Minute"]="00"
df1['Observed_value']=df1["Temp10"]
df1["Original_observed_value"]=df1["Observed_value"]
df1["Observed_value"] = pd.to_numeric(df1["Observed_value"],errors='coerce')
#df1["Observed_value"]=df1["Observed_value"]* 1.3332239 

df1 = df1[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]
df2=df
#df2=df2.drop(columns=["a", "b", "c","Date","Pressure 4","Pressure 9","Pressure 10","Temperature 9","Temperature 10"])
df2["Hour"]="16" 
df2["Minute"] ="00"
df2['Observed_value']=df2["Temp4"]
df2["Original_observed_value"]=df2["Observed_value"]
df2["Observed_value"] = pd.to_numeric(df2["Observed_value"],errors='coerce')
#df2["Observed_value"]=df2["Observed_value"]* 1.3332239 

df2 = df2[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]



merged_slp=pd.concat([df1,df2], axis=0)
merged_slp=merged_slp.dropna(subset = ['Observed_value'])


# Create the Timestamp column by combining Year, Month, Day, Hour, and Minute
merged_slp["Timestamp2"] = (
    merged_slp["Year"].map(str) + "-" + 
    merged_slp["Month"].map(str) + "-" + 
    merged_slp["Day"].map(str)
)
merged_slp["Timestamp"] = (
    merged_slp["Timestamp2"] + " " + 
    merged_slp["Hour"].map(str) + ":" + 
    merged_slp["Minute"].map(str)
)
merged_slp = merged_slp.drop(columns=["Timestamp2"])

# Convert the Timestamp column to datetime
merged_slp['Timestamp'] = pd.to_datetime(merged_slp['Timestamp'], format='%Y-%m-%d %H:%M')

# Localize and convert timezone
merged_slp['Timestamp'] = merged_slp['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')

# Extract datetime components
merged_slp['Year'] = merged_slp['Timestamp'].dt.year
merged_slp['Month'] = merged_slp['Timestamp'].dt.month
merged_slp['Day'] = merged_slp['Timestamp'].dt.day
merged_slp['Hour'] = merged_slp['Timestamp'].dt.hour
merged_slp['Minute'] = merged_slp['Timestamp'].dt.minute
merged_slp['Seconds'] = merged_slp['Timestamp'].dt.second
merged_slp = merged_slp.sort_values(by='Timestamp')


merged_slp = merged_slp.drop(columns="Timestamp")
merged_slp['Minute']='00'
merged_slp['Observed_value'] = merged_slp['Observed_value'].round(1)
merged_slp = merged_slp.astype(str)
merged_slp = merged_slp[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]



# Generate the file name dynamically based on Station_ID
station_id = merged_slp['Station_ID'].iloc[0]  # Assuming Station_ID is a column in your DataFrame
file_name = f"{station_id}_temperature_407.psv"

# Full path for the file
file_path = os.path.join(OUTDIR, file_name)

# Save the DataFrame to a pipe-delimited file
merged_slp.to_csv(file_path, sep='|', index=False)

print(f"File saved successfully to: {file_path}")







