PREFIX=$1

if [ -s ${PREFIX}download/flags ]
then
rm -r ${PREFIX}download/flags
fi

mkdir ${PREFIX}download/flags

wget -o${PREFIX}download/get-ghcnd-flags.ftp.log -P${PREFIX}download/flags ftp://ncdcftp.ncdc.noaa.gov/upload/2days/ghcnd-qc-flags.txt


