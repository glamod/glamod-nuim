PREFIX=$1

cat ${PREFIX}*.flags > ${PREFIX}nws-flags/ghcnd-qc-flags.txt

cd ${PREFIX}nws-flags

for i in `cut -c13-15 ghcnd-stations-with-wfo.txt | sort -u`; do grep $i ghcnd-stations-with-wfo.txt | cut -c1-11 > $i.stations; done

rm *.flags

for i in `cat wfo-list.txt`; do for j in `cat $i.stations`; do grep $j ghcnd-qc-flags.txt | gawk '{printf "%s,%i,%2.2i,%2.2i,%s,%i,%s,%s,%s\n", substr($0,1,11), substr($0,13,4), substr($0,18,2), substr($0,21,2),substr($0,24,4),substr($0,29,5),substr($0,35,1),substr($0,37,1),substr($0,39,1)}' >> $i.flags; done; done

for WFO in `cat wfo-list.txt`; do rm -r ${WFO}; mkdir ${WFO}; for i in `cut -c13-16,18-19 ${WFO}.flags | sort -u`; do grep "${i:0:4},${i:4:2}" ${WFO}.flags  | sort >> ${WFO}/$i.csv; done; done
