#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import os
import pandas as pd
import numpy as np

pd.options.mode.chained_assignment = None  # default='warn'

OUTDIR = ("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Chilean_sbdy_/Chilean/Faro de la Punta de Coquimbo/IFF/tt")
os.chdir("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/Chilean_sbdy_/Chilean/Faro de la Punta de Coquimbo")

df=pd.read_csv("Faro_de_la_Punta_de_Coquimbo_master.csv",skiprows = 3) 
df["Source_ID"]="358"
df["Station_ID"]="358-00004"
df["Alias_station_name"]=""
df["Station_name"]="Faro de la Punta de Coquimbo"
df["Latitude"]= "-29.9358"
df["Longitude"]= "-71.3411"
df["Elevation"]= "2"
df['Year'] = df["y"]
df['Month'] = df['m'] 
df['Day'] = df['d']
df["Hour"]=""
df["Minute"]=""
df["Source_QC_flag"]=""
df['Original_observed_value_units']="c"
df['Measurement_code_1']=''
df['Measurement_code_2']=''
df['Report_type_code']=''
df['Original_observed_value']=''
df['Observed_value']=''

df1=df
df1=df1.drop(columns =["y", "d", "m","DATE","2 1/2 h","9 h","21 h","9p","21p","14p","9t","21t"])
df1["Hour"]="14" 
df1['Observed_value']=df1['14t']
df1["Original_observed_value"]=df1["Observed_value"]
df1["Observed_value"] = pd.to_numeric(df1["Observed_value"],errors='coerce')
#df1["Observed_value"]=df1["Observed_value"]* 1.3332239 

df1 = df1[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]
df2=df
df2=df2.drop(columns =["y", "d", "m","DATE","2 1/2 h","9 h","21 h","14p","21p","14t","9p","21t"])
df2["Hour"]="9" 
df2['Observed_value']=df2['9t']
df2["Original_observed_value"]=df2["Observed_value"]
df2["Observed_value"] = pd.to_numeric(df2["Observed_value"],errors='coerce')
#df2["Observed_value"]=df2["Observed_value"]* 1.3332239 

df2 = df2[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]

df3=df
df3=df3.drop(columns =["y", "d", "m","DATE","2 1/2 h","9 h","21 h","14p","9p","14t","9t","21p"])
df3["Hour"]="21" 
df3['Observed_value']=df3['21t']
df3["Original_observed_value"]=df3["Observed_value"]
df3["Observed_value"] = pd.to_numeric(df3["Observed_value"],errors='coerce')
#df3["Observed_value"]=df3["Observed_value"]* 1.3332239 

df3 = df3[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]

merged_tt=pd.concat([df1,df2,df3], axis=0)
merged_tt=merged_tt.dropna(subset = ['Observed_value'])
merged_tt["Minute"] ="00"

# Create the Timestamp column by combining Year, Month, Day, Hour, and Minute
merged_tt["Timestamp2"] = (
  merged_tt["Year"].map(str) + "-" + 
  merged_tt["Month"].map(str) + "-" + 
  merged_tt["Day"].map(str)
)
merged_tt["Timestamp"] = (
  merged_tt["Timestamp2"] + " " + 
  merged_tt["Hour"].map(str) + ":" + 
  merged_tt["Minute"].map(str)
)
merged_tt =merged_tt.drop(columns=["Timestamp2"])

# Convert the Timestamp column to datetime
merged_tt['Timestamp'] = pd.to_datetime(merged_tt['Timestamp'], format='%Y-%m-%d %H:%M')

# Localize and convert timezone
merged_tt['Timestamp'] =merged_tt['Timestamp'].dt.tz_localize('Etc/GMT-3').dt.tz_convert('GMT')

# Extract datetime components
merged_tt['Year'] =merged_tt['Timestamp'].dt.year
merged_tt['Month'] =merged_tt['Timestamp'].dt.month
merged_tt['Day'] =merged_tt['Timestamp'].dt.day
merged_tt['Hour'] =merged_tt['Timestamp'].dt.hour
merged_tt['Minute'] =merged_tt['Timestamp'].dt.minute
merged_tt['Seconds'] =merged_tt['Timestamp'].dt.second
merged_tt =merged_tt.sort_values(by='Timestamp')


merged_tt =merged_tt.drop(columns="Timestamp")
merged_tt['Minute']='00'
merged_tt['Observed_value'] =merged_tt['Observed_value'].round(1)
merged_tt =merged_tt.astype(str)
merged_tt =merged_tt[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                         "Year","Month","Day","Hour","Minute",
                        "Latitude","Longitude","Elevation","Observed_value",
                        "Source_QC_flag","Original_observed_value",
                        "Original_observed_value_units",                                
                        "Report_type_code","Measurement_code_1",
                        "Measurement_code_2"]]



# Generate the file name dynamically based on Station_ID
station_id =merged_tt['Station_ID'].iloc[0]  # Assuming Station_ID is a column in your DataFrame
file_name = f"{station_id}_temperature_358.psv"

# Full path for the file
file_path = os.path.join(OUTDIR, file_name)

# Save the DataFrame to a pipe-delimited file
merged_tt.to_csv(file_path, sep='|', index=False)

print(f"File saved successfully to: {file_path}")








