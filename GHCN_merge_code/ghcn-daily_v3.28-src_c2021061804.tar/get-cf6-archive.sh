#!/bin/sh
# This script downloads the CF6 daily archive files from the GHCNd update server, which downloads 
# CF6 daily summaries each day from the High Plains Regional Climate Center and places them in an archive directory
# Written March 2019 by Matt Menne

PREFIX=$1

if [ -s ${PREFIX}download/cf6 ]
then
rm -r ${PREFIX}download/cf6
fi

mkdir ${PREFIX}download/cf6

wget -o${PREFIX}download/get_cf6.ftp.log -P${PREFIX}download/cf6 ftp://ncdcftp.ncdc.noaa.gov/upload/2days/cf6.archive.tar.gz

${PREFIX}update-archive2.sh ${PREFIX}download/cf6 ${PREFIX}cf6/ 'cf6.archive.tar.gz'

rm -r ${PREFIX}cf6/archive

cd ${PREFIX}cf6

tar xvzf cf6.archive.tar.gz

ls ${PREFIX}cf6/archive > ${PREFIX}cf6/cf6.inv

date +%Y%m%d -d "45 days ago" > ${PREFIX}cf6/date-45-days-ago.txt
date45daysago=`date +%Y%m%d -d "45 days ago"` 

rm -f ${PREFIX}cf6/cf6.tmp

for cf6file in `cat ${PREFIX}cf6/cf6.inv`
do
if [ ${cf6file:9:8} -gt ${date45daysago} ]
then
cat  ${PREFIX}cf6/archive/${cf6file} >> ${PREFIX}cf6/cf6.tmp
fi
#sort -u ${PREFIX}cf6/cf6.tmp > ${PREFIX}cf6/cf6.dat
done
sort -u ${PREFIX}cf6/cf6.tmp > ${PREFIX}cf6/cf6.dat
