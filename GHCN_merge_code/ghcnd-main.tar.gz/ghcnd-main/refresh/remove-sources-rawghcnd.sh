source_list=$1
remove_dir=$2
for source in `cat ${source_list}`
do
rm -r ${remove_dir}${source}/rawghcnd
done

