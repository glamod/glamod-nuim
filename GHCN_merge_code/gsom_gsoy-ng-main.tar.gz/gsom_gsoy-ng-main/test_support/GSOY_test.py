import subprocess as sp
import pandas as pd


def runGSOY():
    sp.run(["java", "-cp", "target/gsom-gsoy-ng.jar", "ncei.GSOY.GlobalSummaryOfYear",
            "MONTHLY=/NCEI_Data/GSOY/test-input/%s.csv",
            "STATIONS=/NCEI_Data/testData/test-stations.txt",
            "GSOY_OUTPUT=/NCEI_Data/GSOY/test-output/%s.csv",
            "LOGS_PATH=/NCEI_Data/GSOY/logs/status-yr.txt"])
    
def runDiff():
    # Read in station files.
    headerNames = ['STATION', 'LAT', 'LONG', 'DESCRIP']
    stations = pd.read_fwf('c:/NCEI_DATA/testData/test-stations.txt', names=headerNames, usecols=headerNames)
    
    print("Starting diff")
    df = pd.read_csv('c:/NCEI_Data/GSOY/data-output/AE000041196.csv')

    # df.loc[df['DATE'] == 1955, 'CDSD']  # This will get a value using year and element
    # (df.CDSD.fillna(0) == other_df.CDSD.fillna(0)).all()
    # for d in df.DATE.unique():

    # df =df.set_index(df.DATE)   
    # (df.DATE == other_df.DATE).all()


def main():

    runGSOY()
    runDiff()

if __name__ == '__main__':
    main()