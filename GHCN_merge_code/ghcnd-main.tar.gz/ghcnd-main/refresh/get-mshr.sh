path=$1
echo $path
#if [ ${path}==" " ] 
#then
#echo "No path providing for where to put the mshr...stopping"
#exit
#fi
cp -p ${path}MASTER-STN-HIST.TXT ${path}MASTER-STN-HIST.TXT.OLD
wget -N -P${path} ftp://ftp.ncdc.noaa.gov/pub/data/inventories/MASTER-STN-HIST.TXT 
year=`grep "created on" ${path}MASTER-STN-HIST.TXT | cut -c34-37`
month=`grep "created on" ${path}MASTER-STN-HIST.TXT | cut -c28-29`
day=`grep "created on" ${path}MASTER-STN-HIST.TXT | cut -c31-32`
echo "Using MASTER-STN-HIST.TXT that was created on ${year}/${month}/${day}"
cp -p ${path}MASTER-STN-HIST.TXT ${path}MASTER-STN-HIST.TMP
iconv -f utf-8 -t ascii//translit ${path}MASTER-STN-HIST.TMP > ${path}MASTER-STN-HIST.TXT
