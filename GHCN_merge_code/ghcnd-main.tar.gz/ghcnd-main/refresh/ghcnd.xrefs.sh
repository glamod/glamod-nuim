#!/bin/sh

rm ghcnd.xrefs

for i in `cut -c1-11 mingle-list.txt`
do
  grep $i ../ghcnd2ish >> ghcnd.xrefs
done
