import polars as pl

ELEMENT_NAMES = {
    'month_greatest_precip':'MOGP',
    'month_total_precip':'MOTP',
    'month_greatest_snowdepth':'MGSD',
    'month_greatest_snowfall':'MGSF',
    'month_total_snowfall':'MTSF',
    'month_max_slp':'MXSP',
    'month_min_slp':'MNSP'
}
FLAG_STR = '_ATTRIBUTES'
DATE_COL_NAME = 'Year_Month' # This will change to 'DATE'

class Pxxx_mapping:
    renameElements = {
        'AH1_Depth_mm':'P005',
        'AH2_Depth_mm':'P010',
        'AH3_Depth_mm':'P015',
        'AH4_Depth_mm':'P020',
        'AH5_Depth_mm':'P030',
        'AH6_Depth_mm':'P045',
        'AI1_Depth_mm':'P060',
        'AI2_Depth_mm':'P080',
        'AI3_Depth_mm':'P100',
        'AI4_Depth_mm':'P120',
        'AI5_Depth_mm':'P150',
        'AI6_Depth_mm':'P180'
    }
    prefixToElementName = {
        'AH1':'P005',
        'AH2':'P010',
        'AH3':'P015',
        'AH4':'P020',
        'AH5':'P030',
        'AH6':'P045',
        'AI1':'P060',
        'AI2':'P080',
        'AI3':'P100',
        'AI4':'P120',
        'AI5':'P150',
        'AI6':'P180'
    }
    indexToPrefix = {
        1:'AH1',
        2:'AH2',
        3:'AH3',
        4:'AH4',
        5:'AH5',
        6:'AH6',
        7:'AI1',
        8:'AI2',
        9:'AI3',
        10:'AI4',
        11:'AI5',
        12:'AI6'
    }

class SOM_ElementsDataType:
    max_short_dur_precip = {
        'Year':pl.String,
        'Month':pl.String,
        'AH1_Depth_mm':pl.Float64,
        'AH1_Source_QC_flag':pl.String,
        'AH1_Measurement_code_1':pl.String,
        'AH1_Ending-day-time':pl.String,

        'AH2_Depth_mm':pl.Float64,
        'AH2_Source_QC_flag':pl.String,
        'AH2_Measurement_code_1':pl.String,
        'AH2_Ending-day-time':pl.String,

        'AH3_Depth_mm':pl.Float64,
        'AH3_Source_QC_flag':pl.String,
        'AH3_Measurement_code_1':pl.String,
        'AH3_Ending-day-time':pl.String,

        'AH4_Depth_mm':pl.Float64,
        'AH4_Source_QC_flag':pl.String,
        'AH4_Measurement_code_1':pl.String,
        'AH4_Ending-day-time':pl.String,

        'AH5_Depth_mm':pl.Float64,
        'AH5_Source_QC_flag':pl.String,
        'AH5_Measurement_code_1':pl.String,
        'AH5_Ending-day-time':pl.String,

        'AH6_Depth_mm':pl.Float64,
        'AH6_Source_QC_flag':pl.String,
        'AH6_Measurement_code_1':pl.String,
        'AH6_Ending-day-time':pl.String,

        'AI1_Depth_mm':pl.Float64,
        'AI1_Source_QC_flag':pl.String,
        'AI1_Measurement_code_1':pl.String,
        'AI1_Ending-day-time':pl.String,

        'AI2_Depth_mm':pl.Float64,
        'AI2_Source_QC_flag':pl.String,
        'AI2_Measurement_code_1':pl.String,
        'AI2_Ending-day-time':pl.String,

        'AI3_Depth_mm':pl.Float64,
        'AI3_Source_QC_flag':pl.String,
        'AI3_Measurement_code_1':pl.String,
        'AI3_Ending-day-time':pl.String,

        'AI4_Depth_mm':pl.Float64,
        'AI4_Source_QC_flag':pl.String,
        'AI4_Measurement_code_1':pl.String,
        'AI4_Ending-day-time':pl.String,

        'AI5_Depth_mm':pl.Float64,
        'AI5_Source_QC_flag':pl.String,
        'AI5_Measurement_code_1':pl.String,
        'AI5_Ending-day-time':pl.String,

        'AI6_Depth_mm':pl.Float64,
        'AI6_Source_QC_flag':pl.String,
        'AI6_Measurement_code_1':pl.String,
        'AI6_Ending-day-time':pl.String,
    }

    month_greatest_precip = {
        'Year':pl.String,
        'Month':pl.String,
        'Element_data_value':pl.Float64,
        'Measurement_code':pl.String,
        'Source_QC_flag':pl.String,
        'Day_1_2_3':pl.String
    }

    month_total_precip = {
        'Year':pl.String,
        'Month':pl.String,
        'Element_data_value':pl.Float64,
        'Measurement_code':pl.String,
        'Source_QC_flag':pl.String,
    }

    month_greatest_snowdepth = {
        'Year':pl.String,
        'Month':pl.String,
        'Element_data_value':pl.Float64,
        'Measurement_code':pl.String,
        'Source_QC_flag':pl.String,
        'Day_1_2_3':pl.String
    }

    month_greatest_snowfall = {
        'Year':pl.String,
        'Month':pl.String,
        'Element_data_value':pl.Float64,
        'Measurement_code':pl.String,
        'Source_QC_flag':pl.String,
        'Day_1_2_3':pl.String
    }

    month_total_snowfall = {
        'Year':pl.String,
        'Month':pl.String,
        'Element_data_value':pl.Float64,
        'Measurement_code':pl.String,
        'Source_QC_flag':pl.String,
    }

    month_max_slp = {
        'Year':pl.String,
        'Month':pl.String,
        'SLP_hPa':pl.Float64,
        'Source_QC_flag':pl.String,
        'Day_of_month':pl.String,
        'Time_of_day':pl.String
    }

    month_min_slp = {
        'Year':pl.String,
        'Month':pl.String,
        'SLP_hPa':pl.Float64,
        'Source_QC_flag':pl.String,
        'Day_of_month':pl.String,
        'Time_of_day':pl.String
    }