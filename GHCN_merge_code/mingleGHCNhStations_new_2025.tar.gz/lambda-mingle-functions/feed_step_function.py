# feed_step_function.py
import boto3
import json
import logging
from botocore.exceptions import ClientError

# --- Configuration ---

# 1. The ARN of your Step Function
STATE_MACHINE_ARN = "arn:aws:states:us-east-1:659949029828:stateMachine:MingleGHCNhStations"

# 2. The AWS Region your Step Function is in
AWS_REGION = "us-east-1"

# 3. List of station IDs to process
STATION_IDS = [
"USW00003014"
# Add more station IDs here for your tests
]

# --- Main ---

# Set up logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger()

def start_executions():
    """Starts a Step Function execution for each station ID in the list."""
    # --- THIS IS THE FIXED LINE ---
    sfn_client = boto3.client('stepfunctions', region_name=AWS_REGION)
    
    logger.info(f"Starting executions for {len(STATION_IDS)} stations...")

    for station_id in STATION_IDS:
        try:
            # The input for your Step Function is a simple JSON object
            # with the station_id.
            input_payload = {
                "station_id": station_id
            }

            logger.info(f"Submitting job for station: {station_id}")
            
            response = sfn_client.start_execution(
                stateMachineArn=STATE_MACHINE_ARN,
                input=json.dumps(input_payload),
            )
            
            logger.info(
                f"Successfully started execution for {station_id}. "
                f"Execution ARN: {response['executionArn']}"
            )

        except ClientError as e:
            logger.error(
                f"Failed to start execution for station {station_id}: {e}"
            )
        except Exception as e:
            logger.error(f"An unexpected error occurred for {station_id}: {e}")

    logger.info("All jobs submitted.")

if __name__ == "__main__":
    start_executions()
