#constants and dictionaries
IFF_HEADER='Source_ID|Station_ID|Station_name|Alias_station_name|Year|Month|Day|Hour|Minute|Latitude|Longitude|Elevation|Observed_value|Source_QC_flag|Original_observed_value|Original_observed_value_units|Report_type_code|Measurement_code_1|Measurement_code_2|'

data_source_ISD_dict={
'6':'ASOS/AWOS',
'8':'MAPSO',
'I':'USCRN',
'K':'SURFRAD'
}

source_id_dict={
'WMO':'220',
'AFWA':'221',
'CMANS':'222',
'ICAO':'223',
'FAA':'347',
'CANA':'348',
'ASOS/AWOS':'343',
'MAPSO':'344',
'USCRN':'345',
'SURFRAD':'346',
'3280':'335',
'mexico':'322',
'CDMP_3850':'313',
'CDMP_3851':'314',
'CDMP_3853':'315'
#TODO: fix CDMP logic for opening files
#dataset='CDMP' ; cdmp_id='3850' ; srcID='313'
#dataset='CDMP' ; cdmp_id='3851' ; srcID='314'
#dataset='CDMP' ; cdmp_id='3853' ; srcID='315'
#None:'xxx'
}

src_code_dict={
'1':'1-USAF-not-merged-w-NCEI-failed-element-cross-checks',
'2':'2-NCEI-sfc-hrly-not-merged-w-USAF-failed-element-cross-checks',
'3':'3-USAF-sfc-hrly-NCEI-sfc-hrly-merged',
'4':'4-USAF-sfc-hrly',
'5':'5-NCEI-sfc-hrly',
'6':'6-ASOS-AWOS-from-NCEI',
'7':'7-ASOS-AWOS-merged-w-USAF',
'8':'8-MAPSO-NCEI',
'A':'A-USAF-sfc-hrly-NCEI-hrly-precip-candidate-not-merged-w-NCEI-sfc-hrly-failed-element-cross-checks',
'B':'B-NCEI-sfc-hrly-NCEI-hrly-precip-candidate-not-merged-w-USAF-sfc-hrly-failed-element-cross-checks',
'C':'C-USAF-sfc-hrly-NCEI-sfc-hrly-NCEI-hrly-precip-merged',
'D':'D-USAF-sfc-hrly-NCEI-hrly-precip-merged',
'E':'E-NCEI-sfc-hrly-NCEI-hrly-precip-merged',
'F':'F-Form-OMR-1001-Wx-Bur-city-office-keyed',
'G':'G-SAO-pre-1949-keyed',
'H':'H-SAO-1965-1981-format-period-keyed',
'I':'I-CRN',
'J':'J-COOP',
'K':'K-Rad-net',
'L':'L-CDMP',
'M':'M-NREL',
'N':'N-NCAR-NCEI-coop-effort-var-ntl-datasets',
'O':'O-Summary-obs-created-by-NCEI-using-hrly-obs-that-may-not-share-same-data-source-flag',
'9':'9-Missing'}
 
rpt_type_dict= {
'AERO':'AERO-Aerological',
'AUST':'AUST-Australia',
'AUTO':'AUTO',
'BOGUS':'BOGUS',
'BRAZ':'BRAZ-Brazil',
'COOPD':'COOPD-USCOOP-SOD',
'COOPS':'COOPS-USCOOP-soiltemp',
'CRB':'CRB-Clim-Ref-Book-from-CDMP',
'CRN05':'CRN05-CRN5min',
'CRN15':'CRN15-CRN15min',
'FM-12':'FM12-SYNOP-fixed-land-stn',
'FM-13':'FM13-SHIP-sea-stn',
'FM-14':'FM14-SYNOP-MOBIL-mobile-land-stn',
'FM-15':'FM15-METAR-Aviation-routine-wx',
'FM-16':'FM16-SPECI-Aviation-selected-special-wx',
'FM-18':'FM18-BUOY',
'GREEN':'GREEN-Greenland',
'MESOH':'MESOH-Hydro-MESONET-civ-govt',
'MESOS':'MESOS-MESONET-civ-govt',
'MESOW':'MESOW-Snow-MESONET-civ-govt',
'MEXIC':'MEXIC-Mexico',
'NSRDB':'NSRDB-Natl-Sol-Rad-Data-Base',
'PCP15':'PCP15-US-15-min-precip-network',
'PCP60':'PCP60-US-60-min-precip-network',
'S-S-A':'SAA-Synoptic-airways-auto-merged',
'SA-AU':'SA-AU-Airways-auto-merged',
'SAO':'SAO-Airways-incl-record-specials',
'SAOSP':'SAOSP-Airways-special-excl-record-specials',
'SHEF':'SHEF-Std-Hydro-Exch-Frmt',
'SMARS':'SMARS-Supp-airways-stn',
'SOD':'SOD-ASOS-AWOS',
'SOM':'SOM-ASOS-AWOS',
'SURF':'SURF-Surf-Rad-Net',
'SY-AE':'SYAE-Synop-and-aero-merged',
'SY-AU':'SYAU-Synop-and-auto-merged',
'SY-MT':'SYMT-Synop-and-METAR-merged',
'SY-SA':'SYSA-Synop-and-airways-merged',
'WBO':'WBO',
'WNO':'WNO-WashNavObs',
'99999':'999999-Missing'}

qc_ISD_dict={
'0' : '0-Pass-gross-limits',
'1' : '1-Pass-allQC',
'2' : '2-Suspect',
'3' :  '3-Erroneous',
'4' : '4-Pass-gross-NCEI-src',
'5' : '5-Pass-allQC-NCEI-src',
'6' : '6-Suspect-NCEI-src',
'7' : '7-Erroneous-NCEI-src',
'9' : '9-Pass-gross-limits-check-if-present',
'A' : 'A-Flagged-suspect-accepted-good',
'U' : 'U-Replaced-with-edited',
'P' : 'P-Not-flagged-suspect-replaced-by-validator',
'I' : 'I-Not-originally-in-data-inserted-by-validator',
'M' : 'M-Manual-change-made-info-from-NWS-or-FAA',
'C' : 'C-Ta-Td-from-AWOS-whole-degC-autoflagged-but-valid',
'R' : 'R-Replaced-with-computed-value-NCEI'}

qc_USAF_dict={
'0':'0-Not-Checked',
'1':'1-Good',
'2':'2-Suspect',
'3':'3-Erroneous',
'4':'4-Calculated',
'5':'5-Removed',
'9':'9-Missing'
}

#for wdir/wspd only
#ISD format doc:  If a value of 9 appears with a wind speed of 0000, this indicates calm winds
#ISD format doc:  If wind type code = V, then 999 indicates variable wind direction
wind_code_dict={
'A':'A-Abr-Beauf',
'B':'B-Beaufort',
'C':'C-Calm',
'H':'H-5min-avg-spd',
'N':'N-Normal',
'R':'R-60min-avg-spd',
'Q':'Q-Squall',
'T':'T-180min-avg-spd',
'V':'V-Variable',
'9':'9-Missing'}
#NOTE: USAF uses WINDCONDITIONS "character" of wind obs -- also has a QC code associated with it
#doesn't explicitly use 9 -- ISD puts in a 9 when code is missing
#USAF:  C Calm N Normal Q Squall V Variable

atm_pres_tend_code_dict={
'0':'0-Incr-then-decr;-atm-pres-same-or-higher-than-3-hrs-ago',
'1':'1-Incr-then-steady;-or-incr.-then-incr-more-slowly;-atm-pres-now-higher-than-3-hrs-ago',
'2':'2-Incr-(steadily-or-unsteadily);-atm-pres-now-higher-than-3-hrs-ago',
'3':'3-Decr-or-steady,-then-incr;-or-incr,-then-incr-more-rapidly;-atm-pres-now-higher-than-3-hrs-ago',
'4':'4-Steady;-atm-pres-the-same-as-3-hrs-ago',
'5':'5-Decr,-then-incr;-atm-pres-the-same-or-lower-than-3-hrs-ago',
'6':'6-Decr,-then-steady;-or-decr,-then-decr-more-slowly;-atm-pres-now-lower-than-3-hrs-ago',
'7':'7-Decr-(steadily-or-unsteadily);-atm-pres-now-lower-than-3-hrs-ago',
'8':'8-Steady-or-incr,-then-decr;-or-decr,-then-decr-more-rapidly;-atm-pres-now-lower-than-3-hrs-ago',
'9':'9-Missing' }

vis_var_type_USAF_dict={
'A':'A-Aircraft-horiz-vis',
'L':'L-Aircraft-slant-rng-vis',
'M':'M-Max',
'N':'N-Min',
'P':'P-Prevailing',
'S':'S-Sector',
'9':'9-Missing' }

#The code that denotes whether or not the reported visibility is variable
vis_var_type_ISD_dict={
'N':'N-Not-variable',
'V':'V-Variable',
'9':'9-Missing'}

precip_code_USAF_dict={
'0':'0-None',
'1':'1-Measurement-impossible-or-inaccurate',
'2':'2-Trace',
'3':'3-Measurable',
'9':'9-Missing'}
    
precip_code_ISD_dict={
'1':'1-Measurement-impossible-or-inaccurate',
'2':'2-Trace',
'3':'3-Begin-accumulated-period-(precipitation-amount-missing-until-end-of-accumulated-period)',
'4':'4-End-accumulated-period',
'5':'5-Begin-deleted-period-(precipitation-amount-missing-due-to-data-problem)',
'6':'6-End-deleted-period',
'7':'7-Begin-missing-period',
'8':'8-End-missing-period',
'E':'E-Estimated-data-value-(eg-from-nearby-station)',
'I':'I-Incomplete-precipitation-amount,-excludes-one-or-more-missing-reports,-such-as-one-or-more-15-minute-reports-not-included-in-the-1-hour-precipitation-total',
'J':'J-Incomplete-precipitation-amount,-excludes-one-or-more-erroneous-reports,-such-as-one-or-more-1-hour-precipitation-amounts-excluded-from-the-24-hour-total',
'9':'9-Missing' }

snow_depth_code_USAF_dict={
'0':'0-None',
'1':'1-Unmeasurable',
'2':'2-Snow-cover-not-continuous',
'3':'3-Measurable',
'9':'9-Missing' }

snow_accum_code_USAF_dict={
'0':'0-None',
'1':'1-Unmeasurable',
'2':'2-Trace',
'3':'3-Measurable',
'9':'9-Missing' }

snow_code_ISD_dict={
'1':'1-Measurement-impossible-or-inaccurate',
'2':'2-Snow-cover-not-continuous',
'3':'3-Trace',
'4':'4-End-accumulated-period-(data-include-more-than-one-day)',
'5':'5-End-deleted-period-(data-eliminated-due-to-quality-problems)',
'6':'6-End-missing-period',
'E':'E-Estimated-data-value-(eg,-from-nearby-station)',
'9':'9-Missing' }

snow_depth_liq_equiv_code_USAF_dict={
'1':'1-Measurable',
'2':'2-Trace',
'9':'9-Missing' }

snow_depth_liq_equiv_code_ISD_dict={
'1':'1-Measurement-impossible-or-inaccurate',
'2':'2-Trace',
'9':'9-Missing-(no-special-code-to-report)' }

#The code that denotes the fraction of the total celestial dome covered by a SKY-COVER-LAYER.
#Note: This is for a discrete cloud layer, as opposed to the cloud later summation data in the GD1-GD6 section.
#ISD is same as USAF except for 9 in USAF definition specifies: Sky obscured by fog and/or other meteorological phenomena
sky_cover_long_dict={
'00':'00-None,SKC-or-CLR',
'01':'01-One-okta-1/10-or-less-but-not-zero',
'02':'02-Two-oktas-2/10-3/10-or-FEW',
'03':'03-Three-oktas-4/10',
'04':'04-Four-oktas-5/10,-or-SCT',
'05':'05-Five-oktas-6/10',
'06':'06-Six-oktas-7/10-8/10',
'07':'07-Seven-oktas-9/10-or-more-but-not-10/10,-or-BKN',
'08':'08-Eight-oktas-10/10,-or-OVC',
'09':'09-Sky-obscured,-or-cloud-amount-cannot-be-estimated',
'10':'10-Partial-obscuration',
'99':'99-Missing'}

sky_cover_LCD_dict={
'00':'CLR:00',
'01':'FEW:01',
'02':'FEW:02',
'03':'SCT:03',
'04':'SCT:04',
'05':'BKN:05',
'06':'BKN:06',
'07':'BKN:07',
'08':'OVC:08',
'09':'VV:09',
'10':'X'}