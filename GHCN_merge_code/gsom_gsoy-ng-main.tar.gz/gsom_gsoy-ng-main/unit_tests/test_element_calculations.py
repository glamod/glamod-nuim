"""
Test cases for ElementCalculations.py.

Expects df to have ['Year_Month'] and ['Element'] columns.
"""


import polars as pl
from polars.testing import assert_frame_equal
import pytest
from gsom.ElementCalculations import ElementCalculations


@pytest.fixture
def ec():
    return ElementCalculations()


def test_empty_dataframe(ec):
    """Test behavior when the input DataFrame is empty (edge case)."""
    input_df = pl.DataFrame({"Station_ID": [], "Year_Month": [], "Element": []})
    expected_df = input_df # Should return the same empty DataFrame
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_empty_element(ec):
    """Test behavior when the input DataFrame has an empty 'Element'."""
    with pytest.raises(pl.exceptions.ColumnNotFoundError, match='"Element" not found'):
        input_df = pl.DataFrame({"Station_ID": ["RQC00663532"], "Year_Month": ["202407"]})
        ec.create_derived_elements(input_df)

    
def test_empty_year_month(ec):
    """Test behavior when the input DataFrame has an empty 'Year_Month'."""
    with pytest.raises(pl.exceptions.ColumnNotFoundError, match='"Year_Month" not found'):
        input_df = pl.DataFrame({"Station_ID": ["RQC00663532"], "Element": ["SNWD"]})
        ec.create_derived_elements(input_df)


def test_multiple_station_ids_no_derived(ec):
    """Test behavior when the input DataFrame has multiple unique 'Station_ID's with
      no elements to derive. Input df is returned."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "SWE00138464", "SWE00138464"],
        "Year_Month": ["202407", "202407", "202408"],
        "Element": ["ADPT", "ASLP", "AWBT"]
    })
    expected_df = input_df
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_multiple_station_ids(ec):
    """Test behavior when the input DataFrame has multiple unique 'Station_ID's. \
        Derived rows have a null 'Station_ID' while original rows remain unaffected."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "SWE00138464", "SWE00138464", "SWE00138465"],
        "Year_Month": ["202407", "202407", "202407", "202408"],
        "Element": ["ADPT", "ASLP", "AWBT", "SX01"]
    })
    expected_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "SWE00138464", "SWE00138464", "SWE00138465", "SWE00138465", "SWE00138465", "SWE00138465"],
        "Year_Month": ["202407", "202407", "202407", "202408", "202408", "202408", "202408"],
        "Element": ["ADPT", "ASLP", "AWBT", "HX01", "LX01", "MX01", "SX01"]
    })
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_single_station_id(ec):
    """Test behavior when the input DataFrame has one unique 'Station_ID' with elements \
        to derive."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407"],
        "Element": ["ADPT", "SNOW", "AWBT"]
    })
    expected_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407", "202407", "202407", "202407"],
        "Element": ["ADPT", "AWBT", "DSNW", "DYSN", "EMSN", "SNOW"]
    })
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_invalid_elements(ec):
    """Test with invalid or unknown elements."""
    input_df = pl.DataFrame({"Station_ID": ["RQC00663532"], "Year_Month": ["202407"], "Element": ["UNKNOWN"]})
    expected_df = input_df
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_multiple_required_source_elements(ec):
    """Test behavior when the input DataFrame satisfies multiple source elements such as {"SNOW", "SNWD"} for ["DSND"]."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407"],
        "Element": ["SN55", "SNOW", "SNWD"],
        "daily_values": [[72.0], [74.0, -28.0], [110.0]],
        "qc_flags": [[""], None, [""]],
        "days_of_month": [[1, 2, 3], [5, 6, 7], [2, 3, 4, 5, 6]],
    })
    expected_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532",
                       "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532",
                       "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407", "202407", "202407", "202407",
                       "202407", "202407", "202407", "202407", "202407", "202407"],
        "Element": ["DSND", "DSNW", "DYSD", "DYSN", "EMSD", "EMSN",
                    "HN55", "LN55", "MN55", "SN55", "SNOW", "SNWD"],
        "daily_values": [[74.0, -28.0], [74.0, -28.0], [110.0], [74.0, -28.0],
                         [110.0], [74.0, -28.0], [72.0], [72.0], [72.0],
                         [72.0], [74.0, -28.0], [110.0]],
        "qc_flags": [None, None, [""], None, [""], None,
                     [""], [""], [""], [""], None, [""]],
        "days_of_month": [[5, 6, 7], [5, 6, 7], [2, 3, 4, 5, 6], [5, 6, 7],
                          [2, 3, 4, 5, 6], [5, 6, 7], [1, 2, 3], [1, 2, 3],
                          [1, 2, 3], [1, 2, 3], [5, 6, 7], [2, 3, 4, 5, 6]],
        "daily_values_2": [[110.0], None, None, None, None, None,
                           None, None, None, None, None, None],
    })
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_derived_element_present_in_DLY(ec):
    """Test behavior when the input DataFrame has a derived element in the DLY. \
        Ensures data is not overwritten in existing rows."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202408"],
        "Element": ["SNWD", "ADPT", "SNWD"],
        "daily_values": [[1,2,3], [4,5,6], [1,2,2]]
    })
    expected_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407", "202407", "202408", "202408", "202408"],
        "Element": ["ADPT", "DYSD", "EMSD", "SNWD", "DYSD", "EMSD", "SNWD",],
        "daily_values": [[4,5,6], [1,2,3], [1,2,3], [1,2,3], [1,2,2], [1,2,2], [1,2,2]]
    })
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_non_core_columns_are_null(ec):
    """
    Test behavior when the input DataFrame has columns not in:
    ['Station_ID', 'Year_Month', 'Element', 'daily_values', 'qc_flags', 'days_of_month'].
    
    Source elements from DLY keep not relevant column information while
    derived elements will not (only keep core 6 columns).
    """
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407"],
        "Element": ["ADPT", "AWBT", "SNWD"],
        "not_relevant": [True, False, True],
        "not_relevant2": ["test1", "test2", "test3"],
        "daily_values": [[72.0, 3.0, 3.0 , 92.0, 50.0], [12.0, 110.0, 112.0, 40.0], [78.0, 72.0]],
        "qc_flags": [["", "", ""], ["",""], ["",""]],
        "days_of_month": [[1, 2, 3, 4, 5], [3, 4, 5, 6], [28, 29]],
    })
    expected_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407", "202407", "202407"],
        "Element": ["ADPT", "AWBT", "DYSD", "EMSD", "SNWD"],
        "not_relevant": pl.Series([True, False, None, None, True], dtype=bool),
        "not_relevant2": pl.Series(["test1", "test2", None, None, "test3"], dtype=str),
        "daily_values": [[72.0, 3.0, 3.0 , 92.0, 50.0], [12.0, 110.0, 112.0, 40.0], [78.0, 72.0], [78.0, 72.0], [78.0, 72.0]],
        "qc_flags": [["", "", ""], ["",""], ["",""], ["",""], ["",""]],
        "days_of_month": [[1, 2, 3, 4, 5], [3, 4, 5, 6], [28, 29], [28, 29], [28, 29]],
    })
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_non_digit_SN_SX(ec):
    """Test behavior when the input DataFrame has a SN and SX non digit elements."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407"],
        "Element": ["SN1A", "SXA1"]
    })
    expected_df = input_df
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_too_many_digits_SN_SX(ec):
    """Test behavior when the input DataFrame has a SN and SX with too many digit elements."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407"],
        "Element": ["SN123", "SX9999"]
    })
    expected_df = input_df
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_too_many_digits_SN_SX(ec):
    """Test behavior when the input DataFrame has a SN and SX with too few digit elements."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407"],
        "Element": ["SN1", "SX8"]
    })
    expected_df = input_df
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)


def test_SN_SX_sources_together(ec):
    """Test behavior when the input DataFrame has both SN and SX source elements."""
    input_df = pl.DataFrame({
        "Station_ID": ["RQC00663532","RQC00663532", "RQC00663532"],
        "Year_Month": ["202407", "202407", "202407"],
        "Element": ["SN11", "SX23", "SX05"]
    })
    expected_df  = pl.DataFrame({
        "Station_ID": [
            "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532",
            "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532",
            "RQC00663532", "RQC00663532", "RQC00663532", "RQC00663532",
        ],
        "Year_Month": [
            "202407", "202407", "202407", "202407", 
            "202407", "202407", "202407", "202407",
            "202407", "202407", "202407", "202407",
        ],
        "Element": [
            "HN11", "HX05", "HX23", 
            "LN11", "LX05", "LX23",
            "MN11", "MX05", "MX23",
            "SN11", "SX05", "SX23",
        ]
    })
    result_df = ec.create_derived_elements(input_df).sort(["Year_Month", "Element"])
    assert_frame_equal(expected_df, result_df)