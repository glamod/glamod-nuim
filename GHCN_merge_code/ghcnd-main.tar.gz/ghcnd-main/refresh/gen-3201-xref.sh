./genCoopXref.exe mshr20080505.txt 3201.station.list.dupchecked mingle-list-no-2.txt 3201A.id.xref 3201A.id.noxref
./genDataXref.exe /home/mmenne/ghcnd/ ghcnd-stations-no-2.txt 2 /home/mmenne/ghcnd/ghcnd_all/ 3201A.id.noxref 3201A.data.xref
cat 3201A.id.xref 3201A.data.xref > 3201A.xref
./add_stns.exe mingle-list-no-2.txt ghcnd-stations-no-2.txt 3201.station.list.dupchecked 2 3201A.xref
