# sqs_trigger.py
import json
import boto3
import os
import logging

# --- LOGGING ---
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# --- AWS CLIENTS ---
sfn = boto3.client("stepfunctions")

# --- CONFIGURATION ---
# Get the State Machine ARN from an environment variable
STATE_MACHINE_ARN = os.environ.get("STATE_MACHINE_ARN")

def lambda_handler(event, context):
    """
    This function is triggered by SQS messages. For each message,
    it starts an execution of the Step Functions state machine.
    """
    if not STATE_MACHINE_ARN:
        logger.error("FATAL: STATE_MACHINE_ARN environment variable is not set.")
        return {"status": "error", "reason": "Configuration error"}

    for record in event['Records']:
        try:
            # The message body from SQS is a string, so we parse it as JSON
            payload_str = record['body']
            payload_json = json.loads(payload_str)
            
            station_id = payload_json.get("station_id")
            if not station_id:
                logger.warning(f"Skipping record with no station_id: {record}")
                continue

            # Start a Step Function execution for each station
            # The input to the Step Function is the payload from the SQS message
            sfn.start_execution(
                stateMachineArn=STATE_MACHINE_ARN,
                input=json.dumps(payload_json)
            )
            logger.info(f"Started Step Function execution for station: {station_id}")

        except Exception as e:
            logger.error(f"Failed to process record: {record}")
            logger.error(f"Error: {e}", exc_info=True)
            # You might want to raise the exception to have SQS retry the batch
            raise e
            
    return {"status": "success"}