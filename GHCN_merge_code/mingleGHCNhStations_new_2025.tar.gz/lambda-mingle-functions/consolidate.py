import logging
import boto3
import awswrangler as wr
import duckdb
from typing import List

# --- STATIC CONFIG ---
OUTPUT_BUCKET = "ghcnh-mingled"
VARIABLES = ["temperature", "dew_point_temperature", "station_level_pressure", "sea_level_pressure", "wind_direction", "wind_speed", "wind_gust", "precipitation", "relative_humidity", "wet_bulb_temperature", "pres_wx_MW1", "pres_wx_MW2", "pres_wx_MW3", "pres_wx_AU1", "pres_wx_AU2", "pres_wx_AU3", "pres_wx_AW1", "pres_wx_AW2", "pres_wx_AW3", "snow_depth", "visibility", "altimeter", "pressure_3hr_change", "sky_condition", "sky_condition_baseht", "ceiling_height", "sky_cover_layer_1", "sky_cover_layer_2", "sky_cover_layer_3", "sky_cover_layer_4", "sky_cover_layer_baseht_1", "sky_cover_layer_baseht_2", "sky_cover_layer_baseht_3", "sky_cover_layer_baseht_4", "sky_cover_summation_1", "sky_cover_summation_2", "sky_cover_summation_3", "sky_cover_summation_4", "sky_cover_summation_baseht_1", "sky_cover_summation_baseht_2", "sky_cover_summation_baseht_3", "sky_cover_summation_baseht_4", "precipitation_5_minute", "precipitation_15_minute", "precipitation_3_hour", "precipitation_6_hour", "precipitation_9_hour", "precipitation_12_hour", "precipitation_15_hour", "precipitation_18_hour", "precipitation_21_hour", "precipitation_24_hour", "REM"]

# --- LOGGING ---
logger = logging.getLogger()
logger.setLevel(logging.INFO)


# --- HELPER FUNCTIONS ---
def setup_duckdb_s3():
    con = duckdb.connect(database=":memory:")
    con.execute("SET home_directory='/tmp'")
    # --- FIX: Set a writable temporary directory for large operations ---
    con.execute("SET temp_directory='/tmp'")
    con.execute("INSTALL httpfs; LOAD httpfs;")
    sess = boto3.Session()
    creds = sess.get_credentials().get_frozen_credentials()
    con.execute(f"SET s3_region='{sess.region_name}';")
    con.execute(f"SET s3_access_key_id='{creds.access_key}';")
    con.execute(f"SET s3_secret_access_key='{creds.secret_key}';")
    if creds.token:
        con.execute(f"SET s3_session_token='{creds.token}';")
    return con

def consolidate_chunks(temp_s3_path: str, final_parquet_path: str, final_psv_path: str):
    con = setup_duckdb_s3()
    try:
        temp_files = wr.s3.list_objects(temp_s3_path)
        if not temp_files:
            logger.warning("No temporary chunk files were found to consolidate. No output will be created.")
            return

        read_query = f"SELECT * FROM read_parquet('{temp_s3_path}', union_by_name=True)"
        
        logger.info(f"Reading all chunks from {temp_s3_path} and writing to {final_parquet_path}")
        con.execute(f"COPY ({read_query}) TO '{final_parquet_path}' (FORMAT PARQUET, COMPRESSION SNAPPY, OVERWRITE)")
        logger.info("Consolidation to Parquet successful.")
        
        logger.info(f"Writing formatted PSV version to {final_psv_path}")
        select_cols = [
            "STATION", "Station_name", "DATE", "Year",
            "printf('%02d', CAST(Month AS BIGINT)) AS Month",
            "printf('%02d', CAST(Day AS BIGINT)) AS Day",
            "printf('%02d', CAST(Hour AS BIGINT)) AS Hour",
            "printf('%02d', CAST(Minute AS BIGINT)) AS Minute",
            "LATITUDE", "LONGITUDE", "ELEVATION"
        ]
        for var in VARIABLES:
            select_cols.extend([
                f'"{var}"', f'"{var}_Measurement_Code"', f'"{var}_Quality_Code"',
                f'"{var}_Report_Type"', f'"{var}_Source_Code"', f'"{var}_Source_Station_ID"'
            ])
        
        select_query_psv = f"SELECT {', '.join(select_cols)} FROM read_parquet('{temp_s3_path}', union_by_name=True)"
        con.execute(f"COPY ({select_query_psv}) TO '{final_psv_path}' (FORMAT CSV, HEADER 1, DELIMITER '|')")
        logger.info("PSV file creation successful.")

    except Exception as e:
        logger.error(f"An error occurred during consolidation: {e}", exc_info=True)
        raise
    finally:
        con.close()

# --- LAMBDA HANDLER ---
def lambda_handler(event, context):
    station_id = event['station_id']
    min_year = event['min_year']
    max_year = event['max_year']
    # --- FIX: Extract the UUID string from the job_id object ---
    job_id = event['job_id']['UUID']
    
    logger.info(f"--- Consolidating all chunks for station {station_id} ---")
    
    # --- FIX: Read from the unique, isolated path for this job run ---
    temp_read_path = f"s3://{OUTPUT_BUCKET}/_temp/{job_id}/{station_id}*.parquet"
    
    base_filename = f"{station_id}-mingled-{min_year}-{max_year}"
    final_parquet_path = f"s3://{OUTPUT_BUCKET}/parquet/{base_filename}.parquet"
    final_psv_path = f"s3://{OUTPUT_BUCKET}/psv/{station_id}.psv"
    
    consolidate_chunks(temp_read_path, final_parquet_path, final_psv_path)
    
    # --- FIX: Delete the entire temporary folder for this job run ---
    temp_delete_path = f"s3://{OUTPUT_BUCKET}/_temp/{job_id}/"
    logger.info(f"--- Cleaning up temporary files at {temp_delete_path} ---")
    wr.s3.delete_objects(temp_delete_path)
    
    return {
        "status": "complete",
        "final_parquet_path": final_parquet_path,
        "final_psv_path": final_psv_path
    }