#!/bin/sh

PREFIX=$1

${PREFIX}nws-flags/get-ghcnd-flags.sh ${PREFIX}

cd ${PREFIX}nws-flags

${PREFIX}nws-flags/gen-nws-flags.sh

${PREFIX}nws-flags/ftp-nws-flags.sh
