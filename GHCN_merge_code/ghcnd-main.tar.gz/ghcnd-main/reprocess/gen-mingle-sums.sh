PREFIX=$1
lib_dir=$2
mv ${PREFIX}src-counts.new ${PREFIX}src-counts.old
grep -v unknown  ${PREFIX}mingle.log | grep -v Station | grep -v Mismatch > ${PREFIX}mingle.sums
echo "source code, difference (today's total minus total from last run), today's total, last run's total" > ${PREFIX}src-counts.txt
for (( src=2; $src <= 100; src=`expr $src + 2` ))
do
count=`expr $src + 1`
source_code=`gawk '{print $'"$src"'}' ${PREFIX}mingle.sums | sort -u`
#echo $source_code
sum=`gawk '{print $'"$count"'}' ${PREFIX}mingle.sums | awk -f ${lib_dir}avg.awk | gawk '{print $3}'`
if [ "$source_code" = "" ]
then
join ${PREFIX}src-counts.new ${PREFIX}src-counts.old | gawk '($2>"0" || $3>"0") {printf "%s,%10i,%10i,%10i\n", $1,$2-$3,$2,$3}' >> ${PREFIX}src-counts.txt
cat ${PREFIX}src-counts.txt
exit
fi
echo "$source_code $sum" >> ${PREFIX}src-counts.new
done


