#!/bin/sh
# refreshes the GHCN-Daily station and mingle list entries for a data 
# source whose station list has already been reformatted into GHCN-Daily 
# format and whose stations should be cross-referenced with GHCN-Daily 
# Assuming that the last five digits of the source station IDs are WMO numbers.

echo "Starting refresh-wmo-with-list.sh for ${dsi} on " `date`

# Interpret arguments.
ghcnd_list_dir=$1 # directory from which GHCN-Daily and mingle lists should be taken
dsi=$2 # 1-to-15 character data set identifier used in subdirectory and station list names
src_code=$3 # one-character code used as source flag in GHCN-Daily files
src_list=$4 # path and name of the GHCN-Daily formatted source station list
begyear=$5

# set Internal Directory variables.
refresh_dir=${HOME}/ghcnd/makelist/
data_dir=${HOME}/ghcnd/${dsi}/
operational_dir=/home/mmenne/ghcnd2/

# set module file to use when compiling
mod_file=${Refresh_dir}ghcndmod4${dsi}.f95
# Set iMinYr In the module to the first year in $dsi.
#sed 's/integer,parameter::iMinYr=1801/integer,parameter::iMinYr='${begyear}'/' ${operational_dir}ghcndmod.f95 > ${refresh_dir}${mod_file}
sed 's/integer,parameter::iMinYr=1750/integer,parameter::iMinYr='${begyear}'/' /home/mmenne/ghcnd/ghcndmod.f95 > ${refresh_dir}${mod_file}

# change into the directory where to run all programs.
cd ${refresh_dir}

# Compile all programs.
${refresh_dir}compile-refresh-wmo-with-list.sh ${refresh_dir} ${mod_file}

# Make backups of the GHCND station and mingle lists.
cp -p ${ghcnd_list_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.txt.old
cp -p ${ghcnd_list_dir}mingle-list.txt ${refresh_dir}mingle-list.txt.old

# Also make sure that the GHCN-Daily station and mingle lists barware the programs expect them to be in ${refresh_dir}.
cp -p ${refresh_dir}ghcnd-stations.txt.old ${refresh_dir}ghcnd-stations.txt
cp -p ${refresh_dir}mingle-list.txt.old ${refresh_dir}mingle-list.txt

# Keep a copy of the previous GHCN-Daily formatted source Station list.
cp -p ${refresh_dir}${dsi}-stations.txt  ${refresh_dir}${dsi}-stations.txt.old
# Copy The latest version of the GHCN-Daily formatted source station list.
cp -p ${src_list} ${refresh_dir}${dsi}-stations.txt

if [ ! -s ${refresh_dir}${dsi}-stations.txt ]
then
echo "${dsi}-stations.txt was not created...exiting script" `date`
exit
fi

# screen out all stations with fewer than 100 values 
# for each element as well as those where more than 50% of one temperature element's 
# values are equal to zero.
echo "Starting pre_screen.exe on" `date`
${refresh_dir}pre_screen.exe ${data_dir} ${refresh_dir}${dsi}-stations.txt ${dsi}

# make a list of all unique years to process with the intra-source duplicate check.
cut -c12-15 ${data_dir}rawghcnd/* | sort -u > ${refresh_dir}${dsi}-years.txt
# identify and remove interstation duplicates within the source to be refreshed.
echo "Starting intrasource_dupchk.exe on" `date`
${refresh_dir}intrasource_dupchk.exe ${data_dir} ${refresh_dir}${dsi}-stations-prescreened.txt ${dsi}

# strip the source from the GHCN-Daily station and mingle lists 
# if it is already present. I.e., entries applicable to the source 
# are removed from mingle list, and records for stations that only 
# originate from the source are removed entirely from both the station and mingle lists.
echo "Starting strip_source.exe on" `date`
${refresh_dir}strip_source.exe ${src_code} ${refresh_dir}mingle-list.txt ${refresh_dir}ghcnd-stations.txt 

# cross-reference the WMO station IDs for the source with GHCN-Daily.
echo "Starting gen-wmo-xref.exe on" `date`
${refresh_dir}gen-wmo-xref.exe ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.id.noxref

# for stations not match with the GHCN-Daily station based on 
# ID cross-referencing, try to find a match based on data comparison with all GHCN-Daily stations.
echo "Starting gen-data-xref.exe on" `date`
${refresh_dir}gen-data-xref.exe ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${src_code} ${operational_dir}ghcnd_por/ ${data_dir}rawghcnd/ ${refresh_dir}${dsi}.id.noxref ${refresh_dir}datamatchinfo/ ${refresh_dir}${dsi}.data.xref ${refresh_dir}${dsi}.data.noxref 

# Combine the files of matches found with the ID and data cross-referencing programs.
echo "catting ${dsi}.id.xref and ${dsi}.data.xref" `date`
cat ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.data.xref > ${refresh_dir}${dsi}.xref

# integrate the matched stations into the corresponding GHCN-Daily 
# station list and mingle list records and add any unmatched stations as new station records.
echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${src_code} ${refresh_dir}${dsi}.xref ${refresh_dir}input4refresh/mingle-list-custom.txt

# count number of stations in the newly produced GHCN-Daily station list as a sanity check.
echo "Number of stations in ghcnd-stations" `wc ${refresh_dir}ghcnd-stations.txt | cut -c1-7`

# Reset the GSN designation in the GHCN-Daily station list.
mv ${refresh_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.4gsn
echo "Starting setGSNfield.exe on" `date`
${refresh_dir}setGSNfield.exe ${refresh_dir}gsn-ids.txt ${refresh_dir}ghcnd-stations.4gsn ${refresh_dir}ghcnd-stations.txt
echo "Number of GSN stations now in ghcnd-stations" `gawk 'substr($0,73,3)=="GSN" {print $0}' ${refresh_dir}ghcnd-stations.txt | wc | cut -c1-7`

echo "Finished refresh-wmo-with-list.sh for ${dsi} on " `date`

