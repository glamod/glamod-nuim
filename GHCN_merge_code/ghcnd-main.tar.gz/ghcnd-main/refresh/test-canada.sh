dsi=canada # 1-to-15 character data set identifier used in subdirectory and station list names
src_code=C # one-character code used as source flag in GHCN-Daily files
refresh_dir=${HOME}/ghcnd/makelist/

echo "Starting mingle.exe to create version of GHCN-Daily without ${dsi} on " `date`
${refresh_dir}mingle.exe ${refresh_dir} ${refresh_dir}mingle-list-no-${src_code}.txt 

echo "Creating input for gen-data-xref " `date`
rm -f ${refresh_dir}${dsi}.*xref 
touch -a ${refresh_dir}${dsi}.id.xref 
gawk 'substr($0,12,1)==" " {print substr($0,1,11)}' ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt > ${refresh_dir}${dsi}.id.noxref

echo "Starting gen-data-xref.exe on" `date`
#${refresh_dir}gen-data-xref.exe ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${src_code} ${operational_dir}ghcnd_por/ ${data_base_dir}${dsi}/rawghcnd/ ${refresh_dir}${dsi}.id.noxref ${refresh_dir}datamatchinfo/ ${refresh_dir}${dsi}.data.xref
${refresh_dir}gen-data-xref.exe ${refresh_dir}ghcnd-stations-4canadadataxref.txt ${src_code} ${refresh_dir}mingled/ ${refresh_dir}${dsi}/rawghcnd/ ${refresh_dir}${dsi}.id.noxref ${refresh_dir}datamatchinfo/ ${refresh_dir}${dsi}.data.xref ${refresh_dir}${dsi}.data.noxref

echo "catting ${dsi}.id.xref and ${dsi}.data.xref" `date`
cat ${refresh_dir}${dsi}.id.xref ${refresh_dir}${dsi}.data.xref > ${refresh_dir}${dsi}.xref

echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list-no-${src_code}.txt ${refresh_dir}ghcnd-stations-no-${src_code}.txt ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt ${src_code} ${refresh_dir}${dsi}.xref ${refresh_dir}input4refresh/mingle-list-custom.txt
echo "Number of stations in ghcnd-stations" `wc ${refresh_dir}ghcnd-stations.txt | cut -c1-7`

echo "Setting GSN and HCN fields on " `date`
mv ${refresh_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.4gsn

echo "Starting setGSNfield.exe on" `date`
${refresh_dir}setGSNfield.exe ${refresh_dir}gsn-ids.txt ${refresh_dir}ghcnd-stations.4gsn ${refresh_dir}ghcnd-stations.4hcn
echo "Starting setHCNfield.exe on" `date`
${refresh_dir}setHCNfield.exe ${refresh_dir}ushcn-ids.txt ${refresh_dir}ghcnd-stations.4hcn ${refresh_dir}ghcnd-stations.txt
