#!/bin/sh
# This script downloads CF6 daily summaries from the High Plains Regional Climate Center and places them in an archive directory
# Written March 2018 by Matt Menne
# Updated 01/07/2021 to make use of HPRCC push of files to pub/access

PREFIX=$1
lib_dir=$2

if [ -s ${PREFIX}download/cf6 ]
then
rm -r ${PREFIX}download/cf6
fi

mkdir ${PREFIX}download/cf6

hr=`date +%H`

if [ ${hr} -lt 15 ]
then
date=`date +%Y%m%d -d "yesterday"`
else
date=`date +%Y%m%d`
fi

cd /pub-access

cp -p HPRCC_cli*.txt ${PREFIX}download/cf6

echo ${date} > ${PREFIX}cf6/date-latest.txt

i#wget -o${PREFIX}download/get_cf6.ftp.log -P${PREFIX}download/cf6 http://hprcc7.unl.edu/ncdc/cli/HPRCC_cli${date}.txt

${lib_dir}update-archive2.sh ${PREFIX}download/cf6 ${PREFIX}cf6/archive 'HPRCC_cli*.txt'

ls ${PREFIX}cf6/archive > ${PREFIX}cf6/cf6.inv

date +%Y%m%d -d "45 days ago" > ${PREFIX}cf6/date-45-days-ago.txt
date45daysago=`date +%Y%m%d -d "45 days ago"` 

rm -f ${PREFIX}cf6/cf6.tmp

for cf6file in `cat ${PREFIX}cf6/cf6.inv`
do
if [ ${cf6file:9:8} -gt ${date45daysago} ]
then
cat  ${PREFIX}cf6/archive/${cf6file} >> ${PREFIX}cf6/cf6.tmp
fi
done
sort -u ${PREFIX}cf6/cf6.tmp > ${PREFIX}cf6/cf6.dat

