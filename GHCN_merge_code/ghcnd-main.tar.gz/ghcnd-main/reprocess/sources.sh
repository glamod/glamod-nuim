#!/bin/sh

y=$1 #  Year
m=$2 #  Month
d=$3 #  Day
path=$4 #  Path where data files are located

#  Extract desired data from GHCN-Daily
offset=`expr ${d} \* 8`
c2=`expr 21 + ${offset}`
c1=${c2}
if [ ! -s extracted${y}-${m}.txt ]
then
for i in ${path}*.dly 
do
grep -h "${y}${m}" $i | gawk 'substr($0,12,6)=="'${y}${m}'" {print $0}' >> extracted${y}-${m}.txt
done
fi

echo "Station counts by source for major elements on ${y}-${m}-${d} as of `date`" > sources${y}-${m}-${d}.txt
echo " " >> sources${y}-${m}-${d}.txt
for e in `cat sources-elements.txt`
do
echo "${e}:" >> sources${y}-${m}-${d}.txt
grep "${e}" extracted${y}-${m}.txt | cut -c${c1}-${c2} | gawk '$0!=" " {print $0}' | sort | uniq -c | gawk '{printf("%1s %5i\n", $2, $1)}' >> sources${y}-${m}-${d}.txt
echo " " >> sources${y}-${m}-${d}.txt
done
