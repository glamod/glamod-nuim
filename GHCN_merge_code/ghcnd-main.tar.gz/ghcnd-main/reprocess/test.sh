PREFIX=/home/mmenne/ghcnd2/
echo "Starting post format_check.exe" `date`
${PREFIX}format_check.exe post ${PREFIX}input4sys/ghcnd-stations.txt ${PREFIX} ${PREFIX}qc3out/ ${PREFIX}empty/ ${PREFIX}format_check_post.log
echo "Starting check_size.sh for this por run" `date`
echo "${PREFIX}qc3out/" "${PREFIX}ghcnd_por/" | ${PREFIX}check_size.sh 
if [ -s ${PREFIX}qc3out ]
then
echo "WARNING!!! Terminating ghcnd_por.sh ... retaining previous ghcnd_por directory" 
echo "Moving qc3out to qc3outold"
rm -rf ${PREFIX}qc3outold
mv ${PREFIX}qc3out ${PREFIX}qc3outold
exit
fi
echo "Starting genclim.exe" `date`
${PREFIX}genclim.exe ${PREFIX} ${PREFIX}input4sys/ghcnd-stations.txt
