# -*- coding: utf-8 -*-
"""
Created on Thu Jan 26 12:17:19 2023

@author: snoone
"""

# -*- coding: utf-8 -*-
"""
Created on Tue Apr  9 15:32:19 2024

@author: snoone
"""

import os
import glob
import pandas as pd
import re

OUTDIR = "D:/AEMET_spanish_hist_sub_daily/extracted_files/Presion/JLC/Presion/data/out/slp"

os.chdir("D:/AEMET_spanish_hist_sub_daily/extracted_files/Presion/JLC/Presion/data/")
extension = '.csv'



all_filenames = [i for i in glob.glob('*{}'.format(extension))]
def remove_non_utf8_chars(text):
    return re.sub(r'[^\x00-\x7F]+', '', text)
for filename in all_filenames:
    df = pd.read_csv(filename, sep=';',skiprows=1, header=None, encoding='latin-1')  # Reading CSV with ';' separator and no header
  
        # Selecting and renaming specified columns
    df = df.iloc[:, :13]  # Selecting first 13 columns
    df.columns = ["Station_ID", "Year", "Month", "Day", "Station_name", "Elevation", "Province",
                  "Longitude", "Latitude", "00", "7", "13", "18"]  # Renaming columns
        # Remove non-UTF characters from Station_name column using regex
    df['Station_name'] = df['Station_name'].apply(remove_non_utf8_chars)
        # Replace commas with dots in Latitude and Longitude columns
    df['Latitude'] = df['Latitude'].str.replace(',', '.')
    df['Longitude'] = df['Longitude'].str.replace(',', '.')
    # Adding additional columns with empty values
    df['Report_type_code'] = ''
    df['Measurement_code_1'] = ''
    df['Measurement_code_2'] = ''
    df["Minute"] = "00"
    df["Alias_station_name"] = ""
    df["Source_QC_flag"] = ""
    df['Source_ID'] = '400'
  
        
     
    
##extract presssure @00 am 
    df_pressure00=df
    df_pressure00 =df_pressure00[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","00",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_pressure00["Hour"]="00" 
    df_pressure00= df_pressure00.rename(columns=({'00':'Observed_value'}))
    df_pressure00["Original_observed_value"]=df_pressure00["Observed_value"]
    df_pressure00["Original_observed_value_units"]="Hpa"
    df_pressure00["Observed_value"] = pd.to_numeric(df_pressure00["Observed_value"],errors='coerce')
    df_pressure00["Observed_value"]=df_pressure00["Observed_value"]/10
    
    df_pressure00 = df_pressure00[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
  ##extract presssure @7  
    df_pressure7=df
    df_pressure7 =df_pressure7[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","7",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_pressure7["Hour"]="7" 
    df_pressure7= df_pressure7.rename(columns=({'7':'Observed_value'}))
    df_pressure7["Original_observed_value"]=df_pressure7["Observed_value"]
    df_pressure7["Original_observed_value_units"]="Hpa"
    df_pressure7["Observed_value"] = pd.to_numeric(df_pressure7["Observed_value"],errors='coerce')
    df_pressure7["Observed_value"]=df_pressure7["Observed_value"]/10
    
    df_pressure7= df_pressure7[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
 
  ##extract presssure @13  
    df_pressure13=df
    df_pressure13 =df_pressure13[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","13",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_pressure13["Hour"]="13" 
    df_pressure13= df_pressure13.rename(columns=({'13':'Observed_value'}))
    df_pressure13["Original_observed_value"]=df_pressure13["Observed_value"]
    df_pressure13["Original_observed_value_units"]="Hpa"
    df_pressure13["Observed_value"] = pd.to_numeric(df_pressure13["Observed_value"],errors='coerce')
    df_pressure13["Observed_value"]=df_pressure13["Observed_value"]/10
    
    df_pressure13= df_pressure13[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]       
 
  ##extract presssure @18  
    df_pressure18=df
    df_pressure18 =df_pressure18[["Alias_station_name","Year","Month","Day","Minute","Source_ID","Station_ID","Station_name","Latitude","Longitude","Elevation","18",
            "Source_QC_flag","Report_type_code","Measurement_code_1","Measurement_code_2" ]]
    df_pressure18["Hour"]="18" 
    df_pressure18= df_pressure18.rename(columns=({'18':'Observed_value'}))
    df_pressure18["Original_observed_value"]=df_pressure18["Observed_value"]
    df_pressure18["Original_observed_value_units"]="Hpa"
    df_pressure18["Observed_value"] = pd.to_numeric(df_pressure18["Observed_value"],errors='coerce')
    df_pressure18["Observed_value"]=df_pressure18["Observed_value"]/10
    
    df_pressure18= df_pressure18[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]          
        
        
        

    merged_pressure=pd.concat([df_pressure00,df_pressure7,df_pressure13,df_pressure18], axis=0)
    merged_pressure=merged_pressure.dropna(subset = ['Observed_value'])
    
       
    merged_pressure = merged_pressure[["Source_ID",'Station_ID',"Station_name","Alias_station_name",  
                             "Year","Month","Day","Hour","Minute",
                            "Latitude","Longitude","Elevation","Observed_value",
                            "Source_QC_flag","Original_observed_value",
                            "Original_observed_value_units",                                
                            "Report_type_code","Measurement_code_1",
                            "Measurement_code_2"]]
    merged_pressure = merged_pressure.astype(str)
    # Combine 'Year', 'Month', and 'Day' into a single column 'date_column'
    merged_pressure['date_column'] = merged_pressure['Year']+ '-' + merged_pressure['Month'].astype(str).str.zfill(2)  + '-' + merged_pressure['Day'].astype(str).str.zfill(2)
    merged_pressure = merged_pressure.sort_values(by='date_column')
    merged_pressure = merged_pressure.drop(columns=['date_column'])  # Drop the auxiliary 'date_column' after sorting
        
    
    #save output file   
    cdm_type=("_station_level_pressure_"+filename)
     
    a = merged_pressure['Station_ID'].unique()
    print (a)
    outname = os.path.join(OUTDIR,cdm_type)
      #with open(filename, "w") as outfile:
    merged_pressure.to_csv(outname+".csv", index=False, sep=",")

   
    
   


