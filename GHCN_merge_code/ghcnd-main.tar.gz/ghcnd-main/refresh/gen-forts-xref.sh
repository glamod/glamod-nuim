./genFortsStnInfo.exe
./pre_screen.exe /home/mmenne/ghcnd/ forts.station.list forts
./intrasource_dupchk.exe /home/mmenne/ghcnd/  forts.station.list.presreened forts
./genCoopXref.exe mshr20080505.txt forts.station.list.prescreened.dupchecked mingle-list.txt forts.id.xref forts.id.noxref
./genDataXref.exe /home/mmenne/ghcnd/ ghcnd-stations.txt F /home/mmenne/ghcnd2/ghcnd_all/ forts.id.noxref forts.data.xref
cat forts.id.xref forts.data.xref > forts.xref
./add_stns.exe mingle-list-no-F.txt ghcnd-stations-no-F.txt forts.station.list.prescreened.dupchecked F forts.xref
