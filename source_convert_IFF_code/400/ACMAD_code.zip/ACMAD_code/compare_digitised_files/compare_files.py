import os
import pandas as pd

def list_excel_files(directory):
    """List all Excel files in a given directory."""
    return [f for f in os.listdir(directory) if f.endswith('.xlsx')]

def read_excel_files(directory, filenames):
    """Read Excel files and store them in a dictionary."""
    dataframes = {}
    for filename in filenames:
        filepath = os.path.join(directory, filename)
        dataframes[filename] = pd.read_excel(filepath)
    return dataframes

def compare_dataframes(df1, df2):
    """Compare two DataFrames and return differences."""
    # Align the dataframes to ensure they have the same labels
    df1, df2 = df1.align(df2, join='outer', axis=0, fill_value='NaN')
    df1, df2 = df1.align(df2, join='outer', axis=1, fill_value='NaN')
    
    if df1.equals(df2):
        return None
    else:
        # Find differences
        differences = df1.compare(df2)
        return differences

def main(directory1, directory2, output_file):
    # Step 1: List all Excel files in both directories
    files1 = list_excel_files(directory1)
    files2 = list_excel_files(directory2)

    print(f"Files in directory 1 ({directory1}): {files1}")
    print(f"Files in directory 2 ({directory2}): {files2}")

    # Ensure both directories have the same files
    common_files = set(files1).intersection(set(files2))
    if len(common_files) == 0:
        print("No common Excel files found in both directories.")
        return

    print(f"Common files: {common_files}")

    # Step 2: Read each Excel file from both directories
    dataframes1 = read_excel_files(directory1, common_files)
    dataframes2 = read_excel_files(directory2, common_files)

    # Step 3: Compare the contents of the matching files
    mismatched_files = []
    for filename in common_files:
        df1 = dataframes1[filename]
        df2 = dataframes2[filename]

        # Step 4: Identify and report any differences
        differences = compare_dataframes(df1, df2)
        if differences is not None:
            mismatched_files.append(filename)

    # Save the mismatched filenames to an output text file
    with open(output_file, 'w') as f:
        for filename in mismatched_files:
            f.write(f"{filename}\n")

    print(f"Mismatched files list saved to {output_file}")


# Example usage:
directory1 = 'C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/test_compare/a'
directory2 = 'C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/test_compare/b'
output_file = 'C:/Users/snoone/Dropbox/OLD_BELGIAN_AFRICAN_DARE_INVENTORY/data_for_transcribing_2023/test_compare/mismatched_files.txt'
main(directory1, directory2, output_file)
