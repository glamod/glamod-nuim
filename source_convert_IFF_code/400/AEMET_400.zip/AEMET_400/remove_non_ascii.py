# -*- coding: utf-8 -*-
"""
Created on Fri Sep  4 14:00:30 2020

@author: snoone
"""

import os
import glob
import pandas as pd
import csv

#OUTDIR = "/gws/nopw/j04/c3s311a_lot2/data/level1/land/level1a_sub_daily_data/dew_point_temperature/245_fix"
#os.chdir("/gws/nopw/j04/c3s311a_lot2/data/level1/land/level1a_sub_daily_data/dew_point_temperature/245")

def remove_non_ascii(text): 
        return ''.join(i for i in text if ord(i)<128)
 ##D:/dwd_hourly_2020/dwd_3hour_2020/sea_level_pressure/opendata.dwd.de/climate_environment/CDC/observations_germany/climate/subdaily/pressure/historical/out/par   
OUTDIR = "D:/AEMET_spanish_hist_sub_daily/inv"
os.chdir("D:/AEMET_spanish_hist_sub_daily/inv/inv")

extension = 'csv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
for filename in all_filenames:
    df = pd.read_csv(filename, sep=',', encoding= 'unicode_escape')
    df['Station_name'] = df['Station_name'].astype(str)
    df['Station_name'] = df['Station_name'].apply(remove_non_ascii)
    df["Latitude"]= df["Latitude"].round(3)
    df["Longitude"]= df["Longitude"].round(3)
    #df["height_of_station_above_sea_level"]= df["height_of_station_above_sea_level"].round(3)
        #df= df[['Station_ID',"Station_name",  
                                # "Year",]]
        
    outname = os.path.join(OUTDIR, filename)
    #with open(filename, "w") as outfile:
    df.to_csv(outname, index=False, sep=",",encoding='utf-8')
    df.dtypes