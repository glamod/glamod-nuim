#!/bin/sh
# refreshes the GHCN-Daily station and mingle list entries for European climate assessment data.

# Created  17 August 2011 by Imke Durre
# Modified Sept-Nov. 2011 by Menne/Durre
# Modified July 2013 by Menne/Durre

# Interpret arguments.
ghcnd_list_dir=$1 # directory from which GHCN-Daily and mingle lists should be taken
module=$2

echo "Starting refresh-eca.sh on " `date`

# Set Internal variables.
dsi=eca # 1-to-15 character data set identifier used in subdirectory and station list names
src_code=E # one-character code used as source flag in GHCN-Daily files
data_dir=${HOME}/ghcnd/${dsi}/
refresh_dir=${HOME}/ghcnd/makelist/
operational_dir=/home/mmenne/ghcnd/

# Create file of ECA elements to refresh, listed in the order 
# in which they are to be added to GHCN-Daily.
echo "RR" > ${refresh_dir}elements.txt
echo "TX" >> ${refresh_dir}elements.txt
echo "TN" >> ${refresh_dir}elements.txt
echo "SD" >> ${refresh_dir}elements.txt


#Get first years and compile programs

cut -c12-15 ${data_dir}rawghcnd/* | sort -u > ${refresh_dir}${dsi}-years.txt 
firstyear=`head -1 ${refresh_dir}${dsi}-years.txt`
echo "Earliest year for ${dsi} is "${firstyear}
sed 's/integer,parameter::iMinYr=1750/integer,parameter::iMinYr='${firstyear}'/' ${module} > ${refresh_dir}ghcndmod4refresh.f95

${refresh_dir}compile-refresh-eca.sh ${refresh_dir} ${refresh_dir}ghcndmod4refresh.f95

# Change into the directory where to run all programs.
cd ${refresh_dir}

# Making backups:

# Make backups of the GHCND station and mingle lists.
cp -p ${ghcnd_list_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.txt.old
cp -p ${ghcnd_list_dir}mingle-list.txt ${refresh_dir}mingle-list.txt.old

# Also make sure that the GHCN-Daily station and mingle lists barware the programs expect them to be in ${refresh_dir}.
cp -p ${refresh_dir}ghcnd-stations.txt.old ${refresh_dir}ghcnd-stations.txt
cp -p ${refresh_dir}mingle-list.txt.old ${refresh_dir}mingle-list.txt

# Keep a copy of the previous GHCN-Daily formatted source Station list.
cp -p ${refresh_dir}${dsi}-stations.txt ${refresh_dir}${dsi}-stations.txt.old

#... and of last ${dsi} list of stations with ${element} data
cp -p ${refresh_dir}${dsi}.inv ${refresh_dir}${dsi}.inv.old

# Strip the source from the GHCN-Daily station and mingle lists 
# if it is already present. I.e., entries applicable to the source 
# are removed from mingle list, and records for stations that only 
# originate from the source are removed entirely from both the station and mingle lists.
echo "Starting strip_source.exe on" `date`
${refresh_dir}strip_source.exe ${src_code} ${refresh_dir}mingle-list.txt ${refresh_dir}ghcnd-stations.txt

#copying stripped source versions lists back to original file names for use in loops below

cp -p ${refresh_dir}mingle-list-no-E.txt ${refresh_dir}mingle-list.txt 
cp -p ${refresh_dir}ghcnd-stations-no-E.txt ${refresh_dir}ghcnd-stations.txt

echo "Untarring rawghcnd source directories on " `date`
${refresh_dir}untar-sources-rawghcnd.sh ${refresh_dir}source-list.txt /home/mmenne/backup/ghcnd2/ ${refresh_dir}

#echo "Starting mingle.exe to create version of GHCN-Daily without ${dsi} on " `date`
#${refresh_dir}mingle.exe ${refresh_dir} ${refresh_dir}mingle-list-no-${src_code}.txt 


# Enclose all fields in the country code translation table in quotes.
tr '\r' '"\r' < ${refresh_dir}country-codes.csv | sed 's/^/"/g' | sed 's/,/","/g' > ${refresh_dir}country-codes-quoted.csv 

rm -f ${refresh_dir}ECA_nonblend_GHCND_info_all.txt 

for element in `echo "rr tx tn sd"`

do

tail -n+25 ${data_dir}archive/ECA_nonblend_GHCND_info_${element}.txt >> ${refresh_dir}ECA_nonblend_GHCND_info_all.txt

done

# Enclose all fields in the ECA info file in quotes.
#tr '\r' '"\r' < ${data_dir}archive/ECA_nonblend_info_all.txt | sed 's/^/"/g' | sed 's/,/","/g' > ${refresh_dir}eca-info-all.txt 
tr '\r' '"\r' < ${refresh_dir}ECA_nonblend_GHCND_info_all.txt | sed 's/^/"/g' | sed 's/,/","/g' > ${refresh_dir}eca-info-all.txt 

# Make a new ${dsi} list of stations with reformatted data
ls ${data_dir}rawghcnd > ${refresh_dir}${dsi}.inv

echo "Starting gen-eca-stninfo.exe on " `date`
${refresh_dir}gen-eca-stninfo.exe ${refresh_dir} ${refresh_dir}country-codes-quoted.csv ${refresh_dir}eca-info-all.txt ${refresh_dir}${dsi}.inv

if [ ! -s ${refresh_dir}${dsi}-stations.txt ]
then
echo "${dsi}-stations.txt was not created...exiting script" `date`
exit
fi

# screen out all stations with fewer than 100 values 
# for each element as well as those where more than 50% of one temperature element's 
# values are equal to zero.
echo "Starting pre_screen.exe on" `date`
${refresh_dir}pre_screen.exe ${data_dir} ${refresh_dir}${dsi}-stations.txt ${dsi} ${refresh_dir}${dsi}-ids2skip.txt

# identify and remove interstation duplicates within the source to be refreshed.
echo "Starting intrasource_dupchk.exe on" `date`
${refresh_dir}intrasource_dupchk.exe ${data_dir} ${refresh_dir}${dsi}-stations-prescreened.txt ${dsi}

#First subset ghcnd-stations.txt list to limit data matching to the greater European sector

gawk '$2>22 && ($3>-55 || $3<-165) {print $0}' ${refresh_dir}ghcnd-stations-no-E.txt > ${refresh_dir}ghcnd-stations-4ecadataxref.txt

for element in `cat ${refresh_dir}elements.txt`

do

echo "Creating list of station metadata for ECA element ${element}"
gawk 'substr($0,4,2)=="'${element}'" && substr($0,12,1)==" " {print $0}' ${refresh_dir}${dsi}-stations-prescreened-dupchecked.txt > ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked.txt 

echo "Creating two station lists to separate stations with identical coordinates " `date`
sort -u -k1.13,1.30 ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked.txt > ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-1.txt
cat ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-1.txt | sort | uniq -u > ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-2.txt

for (( iter=1; ${iter} <= 2; iter=`expr ${iter} + 1` ))

do

echo "Starting gen-data-xref.exe for ${element} and iteration ${iter} on" `date`
cut -c1-11 ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-${iter}.txt > ${refresh_dir}${dsi}-${element}-$iter.id.noxref
${refresh_dir}gen-data-xref.exe ${refresh_dir}ghcnd-stations-4ecadataxref.txt ${src_code} ${refresh_dir}mingled/ ${data_dir}rawghcnd/ ${refresh_dir}${dsi}-${element}-${iter}.id.noxref ${refresh_dir}datamatchinfo/ ${refresh_dir}${dsi}-${element}-${iter}.data.xref ${refresh_dir}${dsi}-${element}-${iter}.data.noxref
mv ${refresh_dir}/gen-data-xref.log ${refresh_dir}/gen-data-xref.${dsi}-${element}-${iter}.log

# Creates subset of ECA stations matched based on data
echo "Creating list of ECA stations cross-referenced based on data for ${element} on " `date`
rm -f ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-dataxref-${iter}.txt
for i in `cat ${refresh_dir}${dsi}-${element}-${iter}.data.xref | cut -c1-11`
do
grep "${i}" ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-${iter}.txt >> ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-dataxref-${iter}.txt 
done

echo "Starting add_stns.exe for add stations with data matches for ${element}, ${iter} on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list.txt ${refresh_dir}ghcnd-stations.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-dataxref-${iter}.txt ${src_code} ${refresh_dir}${dsi}-${element}-${iter}.data.xref ${refresh_dir}input4refresh/mingle-list-custom.txt

mv ${refresh_dir}add_stns-${src_code}.log ${refresh_dir}add_stns-${dsi}-data-${element}-${iter}.log

done #end iter loop for data xref'ing
done #end element for loop for data xref'ing

for element in `cat ${refresh_dir}elements.txt`

do

for (( iter=1; ${iter} <= 2; iter=`expr ${iter} + 1` ))

do

#gawk 'substr($0,12,1)==" " {print $1}' ${dsi}-${element}-stations-prescreened-dupchecked-${iter}.txt > tmp.txt
#cat tmp.txt ${dsi}-${element}-${iter}.data.xref | cut -c1-11 | sort | uniq -u > eca-${element}-${iter}.data.noxref

# Creates subset of ECA stations not matched based on data
echo "Creating list of ECA stations not cross-referenced based on data for ${element} on " `date`
rm -f ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt
for i in `cat ${refresh_dir}${dsi}-${element}-${iter}.data.noxref | cut -c1-11`
do
grep "${i}" ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-${iter}.txt >> ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt 
done

# Match ECA stations with GHCN-Daily stations based on latitude/longitude
echo "Starting gen-coord-xref.exe for ${element}-${iter} on" `date`
${refresh_dir}gen-coord-xref.exe ${refresh_dir}ghcnd-stations.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt  ${refresh_dir}${dsi}-${element}-${iter}.coord.xref ${refresh_dir}${dsi}-${element}-${iter}.coord.noxref  

# Creates subset of ECA stations not matched based on data or coordinates
echo "Creating list of ECA stations not cross-referenced based on data or coordinates for ${element} on " `date`
rm -f ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nocoordxref-${iter}.txt
for i in `cat ${refresh_dir}${dsi}-${element}-${iter}.coord.noxref | cut -c1-11`
do
grep "${i}" ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-${iter}.txt >> ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nocoordxref-${iter}.txt 
done

echo "0Starting gen-meta-xref.exe for ${element} on" `date`
${refresh_dir}gen-meta-xref.exe ${refresh_dir}ghcnd-stations.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nocoordxref-${iter}.txt ${refresh_dir}${dsi}-${element}-${iter}.meta.xref ${refresh_dir}${dsi}-${element}-${iter}.meta.noxref

# Combine coord and meta of the cross-reference results
cat ${refresh_dir}${dsi}-${element}-${iter}.coord.xref ${refresh_dir}${dsi}-${element}-${iter}.meta.xref > ${refresh_dir}${dsi}-${element}-${iter}.xref

# integrate the matched stations into the corresponding GHCN-Daily 
# station list and mingle list records and add any unmatched stations as new station records.
echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list.txt ${refresh_dir}ghcnd-stations.txt ${refresh_dir}${dsi}-${element}-stations-prescreened-dupchecked-nodataxref-${iter}.txt ${src_code} ${refresh_dir}${dsi}-${element}-${iter}.xref ${refresh_dir}input4refresh/mingle-list-custom.txt

# count number of stations in the newly produced GHCN-Daily station list as a sanity check.
echo "Number of stations in ghcnd-stations for ${elem} and iteration ${iter}" `wc ${refresh_dir}ghcnd-stations.txt | cut -c1-7`

# Move the log files to element-specific names:
mv ${refresh_dir}gen-coord-xref.log ${refresh_dir}gen-coord-xref.${dsi}-${element}-${iter}.log  
mv ${refresh_dir}gen-meta-xref.log ${refresh_dir}gen-meta-xref.${dsi}-${element}-${iter}.log  
mv ${refresh_dir}add_stns-${src_code}.log ${refresh_dir}add_stns-${dsi}-${element}-${iter}.log 

done  #end iter loop
done  #end element for loop 

# Reset the GSN designation in the GHCN-Daily station list.
mv ${refresh_dir}ghcnd-stations.txt ${refresh_dir}ghcnd-stations.4gsn
echo "Starting setGSNfield.exe on" `date`
${refresh_dir}setGSNfield.exe ${refresh_dir}gsn-ids20090101.txt ${refresh_dir}ghcnd-stations.4gsn ${refresh_dir}ghcnd-stations.txt
echo "Number of GSN stations now in ghcnd-stations" `gawk 'substr($0,73,3)=="GSN" {print $0}' ${refresh_dir}ghcnd-stations.txt | wc | cut -c1-7`

${refresh_dir}remove-sources-rawghcnd.sh ${refresh_dir}source-list.txt ${refresh_dir}

echo "Finished refresh-eca.sh on " `date`

