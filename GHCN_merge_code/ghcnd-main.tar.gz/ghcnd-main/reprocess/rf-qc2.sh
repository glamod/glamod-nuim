/home/mmenne/ghcnd2/rf_stn2time.exe /home/mmenne/ghcnd2/ /home/mmenne/ghcnd2/input4sys/ghcnd-stations.txt
/home/mmenne/ghcnd2/qc2.exe /home/mmenne/ghcnd2/ /home/mmenne/ghcnd2/input4sys/ghcnd-stations.txt M por
