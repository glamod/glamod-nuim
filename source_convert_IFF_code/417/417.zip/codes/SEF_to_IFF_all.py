#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import glob
import re
import pandas as pd

# =====================================================
# PATHS
# =====================================================
BASE_DIR = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/sangetha_new_data/DerrickMuheki_converted/DRC_daily_and_subdaily_temperature_data/sef_data"
OUTPUT_BASE = "/Users/sangethaedathil/Library/CloudStorage/Dropbox/NEW_DATA_SOURCES_r8_/sangetha_new_data/DerrickMuheki_converted/DRC_daily_and_subdaily_temperature_data/sef_data/IFF_output"

os.makedirs(OUTPUT_BASE, exist_ok=True)

# =====================================================
# CLASSIFY FILES
# =====================================================
def classify_file(filename):
    name = os.path.basename(filename).lower()

    if "dry_bulb_temp" in name:
        return "dry_bulb_temperature"
    elif "wet_bulb_temp" in name:
        return "wet_bulb_temperature"
    elif "avg_temperature" in name:
        return "mean_temperature"
    elif "max_temperature" in name:
        return "maximum_temperature"
    elif "min_temperature" in name:
        return "minimum_temperature"
    return None

# =====================================================
# HELPERS
# =====================================================
def read_sef_header(filepath):
    header = pd.read_csv(filepath, sep="\t", nrows=12, header=None)
    header = header.iloc[:, 0:2]
    header.columns = ["SEF", "Value"]
    return dict(zip(header["SEF"], header["Value"]))

def parse_decimal(x):
    if pd.isna(x):
        return pd.NA
    return pd.to_numeric(str(x).replace(",", "."), errors="coerce")

def extract_orig(meta_value):
    if pd.isna(meta_value):
        return ""
    text = str(meta_value)
    m = re.search(r'orig=([^|]+)', text)
    if not m:
        return ""
    return m.group(1).strip()

def safe_name(x):
    x = str(x).strip()
    x = re.sub(r"\s+", "_", x)
    x = re.sub(r"[^A-Za-z0-9_\-]", "", x)
    return x

def extract_time_from_filename(filename):
    name = os.path.basename(filename)
    m = re.search(r'_(\d{2})h(\d{2})', name, flags=re.IGNORECASE)
    if m:
        return int(m.group(1)), int(m.group(2))
    return 0, 0

# =====================================================
# FIND ALL TSV FILES IN ALL STATION FOLDERS
# =====================================================
station_dirs = sorted([
    os.path.join(BASE_DIR, d)
    for d in os.listdir(BASE_DIR)
    if os.path.isdir(os.path.join(BASE_DIR, d))
])

all_files = []
for station_dir in station_dirs:
    all_files.extend(sorted(glob.glob(os.path.join(station_dir, "*.tsv"))))

print(f"Found {len(all_files)} TSV files across {len(station_dirs)} station folders")

grouped_frames = {}

# =====================================================
# MAIN
# =====================================================
for filepath in all_files:
    variable_label = classify_file(filepath)
    if variable_label is None:
        print(f"Skipped (not classified): {os.path.basename(filepath)}")
        continue

    try:
        meta = read_sef_header(filepath)

        station_id = str(meta.get("ID", "")).strip()
        station_name = str(meta.get("Name", "")).strip()
        lat = parse_decimal(meta.get("Lat", ""))
        lon = parse_decimal(meta.get("Lon", ""))
        elev = parse_decimal(meta.get("Alt", ""))

        df = pd.read_csv(filepath, sep="\t", skiprows=12)

        if "Value" not in df.columns:
            print(f"Skipped {os.path.basename(filepath)} - no Value column")
            continue

        # Clean observed value
        df["Observed_value"] = df["Value"].replace(["NA", "NaN", "nan", ""], pd.NA)
        df["Observed_value"] = pd.to_numeric(df["Observed_value"], errors="coerce")

        # Keep original value from Meta if present
        if "Meta" in df.columns:
            df["Original_observed_value"] = df["Meta"].apply(extract_orig)
        else:
            df["Original_observed_value"] = ""

        # Fixed fields
        df["Source_ID"] = "417"
        df["Station_ID"] = station_id
        df["Station_name"] = station_name
        df["Alias_station_name"] = ""
        df["Latitude"] = lat
        df["Longitude"] = lon
        df["Elevation"] = elev
        df["Original_observed_value_units"] = "c"
        df["Source_QC_flag"] = ""
        df["Report_type_code"] = ""
        df["Measurement_code_1"] = ""
        df["Measurement_code_2"] = ""

        # Date fields
        if "Year" not in df.columns or "Month" not in df.columns or "Day" not in df.columns:
            print(f"Skipped {os.path.basename(filepath)} - missing Year/Month/Day")
            continue

        df["Year"] = pd.to_numeric(df["Year"], errors="coerce")
        df["Month"] = pd.to_numeric(df["Month"], errors="coerce")
        df["Day"] = pd.to_numeric(df["Day"], errors="coerce")

        if "Hour" in df.columns:
            df["Hour"] = pd.to_numeric(df["Hour"], errors="coerce")
        else:
            hh, mm = extract_time_from_filename(filepath)
            df["Hour"] = hh

        if "Minute" in df.columns:
            df["Minute"] = pd.to_numeric(df["Minute"], errors="coerce")
        else:
            hh, mm = extract_time_from_filename(filepath)
            df["Minute"] = mm

        df["Hour"] = df["Hour"].fillna(0)
        df["Minute"] = df["Minute"].fillna(0)

        # Keep only rows with valid numeric values
        before = len(df)
        df = df.dropna(subset=["Year", "Month", "Day", "Observed_value"])
        after = len(df)

        print(f"{os.path.basename(filepath)} | rows before: {before} | rows kept: {after}")

        if after == 0:
            continue

        df = df[[
            "Source_ID", "Station_ID", "Station_name", "Alias_station_name",
            "Year", "Month", "Day", "Hour", "Minute",
            "Latitude", "Longitude", "Elevation",
            "Observed_value", "Source_QC_flag",
            "Original_observed_value", "Original_observed_value_units",
            "Report_type_code", "Measurement_code_1", "Measurement_code_2"
        ]]

        grouped_frames.setdefault(variable_label, []).append(df)

    except Exception as e:
        print(f"FAILED: {os.path.basename(filepath)} | {e}")

# =====================================================
# SAVE OUTPUTS
# =====================================================
for variable_label, frames in grouped_frames.items():
    outdir = os.path.join(OUTPUT_BASE, variable_label)
    os.makedirs(outdir, exist_ok=True)

    combined = pd.concat(frames, ignore_index=True)

    combined["Timestamp"] = pd.to_datetime(
        dict(
            year=pd.to_numeric(combined["Year"], errors="coerce"),
            month=pd.to_numeric(combined["Month"], errors="coerce"),
            day=pd.to_numeric(combined["Day"], errors="coerce"),
            hour=pd.to_numeric(combined["Hour"], errors="coerce"),
            minute=pd.to_numeric(combined["Minute"], errors="coerce")
        ),
        errors="coerce"
    )

    combined = combined.dropna(subset=["Timestamp"])
    combined = combined.sort_values(["Station_ID", "Timestamp"]).drop(columns=["Timestamp"])

    for station_id, group in combined.groupby("Station_ID"):
        station_name = safe_name(group["Station_name"].iloc[0])
        outname = f"{station_id}_{variable_label}_{417}.psv"
        outpath = os.path.join(outdir, outname)
        group.to_csv(outpath, sep="|", index=False)
        print("Saved:", outpath)

print("Done.")