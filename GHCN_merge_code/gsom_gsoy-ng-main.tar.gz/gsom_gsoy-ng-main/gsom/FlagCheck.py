import polars as pl
import polars.selectors as cs


class FlagCheck:
    
    days = ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15",
			"16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"]
    
    daysInMonth = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ]


    def __init__(self):
        pass

    def removeInvalidData(self, df):
        #Creates a list of indexes of daily values without QC flags
        df = df.with_columns(
            pl.col.qc_flags.list.eval((pl.element() == "").arg_true())
            .alias("days_of_month")
        )
        #Filters out all values where corresponding QC flag isn't empty
        df = df.with_columns(
            pl.col.daily_values.list.gather(
                pl.col.qc_flags.list.eval((pl.element() == "").arg_true())
            )
        )
        #Removes days_of_month values where corresponding daily_values is -9999
        df = df.with_columns(
            pl.col.days_of_month.list.gather(
                
                pl.col.daily_values.list.eval((pl.element() != -9999).arg_true())
            )
        )
        #Filters out all daily_values equal to -9999
        df = df.with_columns(
            pl.col.daily_values.list.gather(
                
                pl.col.daily_values.list.eval((pl.element() != -9999).arg_true())
            )
        )
        #TODO is there a more efficient way to do this? Am I using way too much code? BV

        return df

    def missing4Consecutive(self, df):
        """
        NOTE: Function relies on (-9999.0) value in 'daily_values' and 'qc_flags' columns to work correctly.

        Function will make new column 'missing_4_consecutive'. if there are >= 4 days missing for a month --> Will set True.
                                                                                                              False otherwise.
        
        Function assumes the lists in 'daily_values' and 'qc_flags' columns are of the same length.
        The above assumption has been tested on 54 sample input files without issue. 
        """
        # Evaluate each element in each list for "daily_values"
        # and set any occurrences found to equal -9999.0 to true.
        daily_missing = df["daily_values"].list.eval(pl.element() == -9999.0)
        # Evaluate each element in each list for "qc_flags" and set
        # any occurrences found to not equal an empty string to true.
        qc_missing = df["qc_flags"].list.eval(pl.element() != "")

        # Explode both series to become compatible with zip_with().
        daily_missing_exploded = daily_missing.list.explode()
        qc_missing_exploded = qc_missing.list.explode()

        # Replace false daily_missing_exploded values with qc_missing_exploded's respective value.
        # This results in an OR operation (essentially mimicking the "|" operator). 
        # combined_or has all true values from both daily_missing_exploded and qc_missing_exploded.
        combined_or = daily_missing_exploded.zip_with(daily_missing_exploded, qc_missing_exploded)

        # Restore the shape to match the original "daily_values" and "qc_flags" columns.
        # Cast to pl.List(pl.UInt32) to become compatible with rolling_sum().
        combined_or = combined_or.reshape((daily_missing.shape[0],-1)).cast(pl.List(pl.UInt32))

        # Evaluate each element in each list for the combined_or series to see if the rolling_sum of window size 4
        # is gte 4 (the maximum number of allowed consecutive misses.) 
        # 
        # Since the boolean type has been cast to a 32-bit unsigned integer type, true is 1 and false is 0.
        # This results in a rolling_sum >= 4 being equivalent to 4 consecutive missing values.
        # 
        # any() reduces the list to a single true or false since only a single true is needed to determine if
        # a row in the df is missing 4 consecutive (missing_4_consecutive) or not.
        #
        # list.first() changes the dtype to be boolean from list[bool] (goes from [true] to true).
        missing_4_consecutive = combined_or.list.eval((pl.element().rolling_sum(window_size=4) >= 4).any()).list.first()

        df = df.with_columns(missing_4_consecutive=missing_4_consecutive)

        return df


    def missing_days(self, row):
        #Version 1
        #Create a list of values and QC flags
        #loop through QCs first, check for non-empty strings
        #If there's no flag, check the value != -9999
        #If fails either test, then index of day added to bad_days
        #Throw a flag if 4 consecutive bad days
        # 
        # TODO Test if using Polars functions speeds this up
        # https://stackoverflow.com/questions/76443773/implementing-a-streak-counter-in-polars 
        bad_days=[]
        good_day_count=0
        #Collect all QC Flags into an array
        QCs = row.select( cs.matches(".*_QC.*") ).melt().get_column("value").to_list()
        #Next grab the values
        values = row.select( cs.by_dtype(pl.Float32) ).melt().get_column("value").to_list()
        consecutive_counter = 0
        four_consecutive = False
        for day in range( len(QCs) ):
            
            if QCs[day]!="":
                bad_days.append(day)
                consecutive_counter += 1
                
                if consecutive_counter >=4:
                    four_consecutive = True
            
            else:
                
                if values[day] !=-9999:
                    consecutive_counter = 0
                    good_day_count += 1
                
                else:
                    
                    bad_days.append(day)
                    consecutive_counter += 1
                    
                    if consecutive_counter >=4:
                        four_consecutive = True
        
        #get the missing flag

        return {
            "missed_flag":"M",
            "good_day_count":good_day_count,
            "bad_days":bad_days,
            "four_consecutive":four_consecutive
        }
