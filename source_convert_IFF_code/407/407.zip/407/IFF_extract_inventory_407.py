# -*- coding: utf-8 -*-
"""
Created on Wed Aug 14 09:23:45 2019

@author: snoone
"""

import os
import glob
import pandas as pd
import csv

os.chdir("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/out/combined/IFF/tmax")
##import all psv files in current dir
os.chdir(os.curdir)
extension = 'psv'

all_filenames = [i for i in glob.glob('*.{}'.format(extension))]

for filename in all_filenames:
    df = pd.read_csv(filename ,delimiter='|')
    # Combine Year, Month, Day, Hour columns into a new Timestamp column
    df['Timestamp'] = pd.to_datetime(df[['Year', 'Month', 'Day', 'Hour']])

    # Sort the DataFrame by the Timestamp column
    df = df.sort_values(by='Timestamp')

    # Drop the Timestamp column
    df = df.drop(columns=['Timestamp'])
    
    df2= df.iloc[[0],[0,1,2,4,9,10,11]]
    df3= df.iloc[[-1],[4]]
    df3['Year'].values
    df2['End_Year'] = df3["Year"].values
    df2 = df2[["Source_ID",'Station_ID',"Station_name","Latitude","Longitude",
             "Elevation","Year","End_Year"]]
    df2.to_csv("combined.csv",index=False,sep = ',')
    
    #open combined csv and separate and rename files as per by station_id 
    with open('combined.csv') as fin:    
        csvin = csv.DictReader(fin)
        #csvin.columns = [x.replace(' ', '_') for x in csvin.columns]  
        # Category -> open file lookup
        outputs = {}
        for row in csvin:
            cat = row['Station_ID']
            # Open a new file and write the header
            if cat not in outputs:
                fout = open ('{}_inventory.csv'.format(cat), "w", newline = "")
                dw = csv.DictWriter(fout, fieldnames=csvin.fieldnames,delimiter=',')
                dw.writeheader()
                outputs[cat] = fout, dw
            # Always write the row
            outputs[cat][1].writerow(row)        # Close all the files
        for fout, _ in outputs.values():
            fout.close()
        
os.remove('combined.csv')
#os.remove('_inventory.csv')            
os.chdir(os.curdir)
extension = 'csv'
all_filenames = [i for i in glob.glob('*.{}'.format(extension))]
#combine all files in the list
df = pd.concat([pd.read_csv(f,delimiter=',') for f in all_filenames])
dir_name = "C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/out/combined/IFF/tmax"
test = os.listdir(dir_name)
##remove unwanted .csv files
for item in test:
    if item.endswith(".csv"):
        os.remove(os.path.join(dir_name, item))
## save concatanated inventory file 
#os.chdir("/gws/nopw/j04/c3s311a_lot2/data/incoming/")
df.to_csv("C:/Users/snoone/Dropbox/NEW_DATA_SOURCES_r8_/Yuri_B_New_data_use/All_Giessen_rescue_data/Giessen_new data/China_Years_Nanking_sbdy/China_Years_Nanking/tmax_inventory_407.csv",index=False)