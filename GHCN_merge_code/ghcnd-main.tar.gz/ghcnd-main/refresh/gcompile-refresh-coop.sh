refresh_dir=$1
mod_file=$2

gfortran ${mod_file} ${refresh_dir}gen-coop-stninfo.f95 -o ${refresh_dir}gen-coop-stninfo.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}pre_screen.f95 -o ${refresh_dir}pre_screen.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}intrasource_dupchk.f95 -o ${refresh_dir}intrasource_dupchk.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}strip_source.f95 -o ${refresh_dir}strip_source.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}mingle.f95 -o ${refresh_dir}mingle.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}gen-coop-xref.f95 -o ${refresh_dir}gen-coop-xref.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}gen-data-xref.f95 -o ${refresh_dir}gen-data-xref.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}add_stns.f95 -o ${refresh_dir}add_stns.exe -ffree-line-length-none
gfortran ${refresh_dir}setGSNfield.f95 -o ${refresh_dir}setGSNfield.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}setHCNfield.f95 -o ${refresh_dir}setHCNfield.exe -ffree-line-length-none
gfortran ${mod_file} ${refresh_dir}setCRNfield.f95 -o ${refresh_dir}setCRNfield.exe -ffree-line-length-none



