# -*- coding: utf-8 -*-
"""
Created on Tue Oct 22 13:13:52 2024

@author: snoone
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jul 17 14:22:41 2019

@author: snoone
"""
import numpy as np
import glob
import pandas as pd
import os
import re

# Define the directory where the files are located
OUTDIR1 = "E:/NEW_DATA_SOURCES_r8_/atacama_desert_chile_data/CDM_lite/relative_humidity"
OUTDIR = "E:/NEW_DATA_SOURCES_r8_/atacama_desert_chile_data/IFF/relative_humidity"
os.chdir("E:/NEW_DATA_SOURCES_r8_/atacama_desert_chile_data/data/not_proc/1")

# Read the stations.csv file with the correct encoding and ensure proper data types
stations_df = pd.read_csv("E:/NEW_DATA_SOURCES_r8_/atacama_desert_chile_data/stations.csv", encoding='ISO-8859-1')

# Ensure 'Station_ID' in the stations DataFrame is a string
stations_df['Station_ID'] = stations_df['Station_ID'].astype(str).str.strip()

# Collect all files matching the pattern in the directory
extension = '.txt'
all_filenames = [i for i in glob.glob(f'*{extension}')]

# Loop through each file and read the selected columns
for filename in all_filenames:
    try:
        # Read the file, assuming the first row contains headers
       # df = pd.read_csv(filename, header=0)
        df = pd.read_csv(filename, header=0, on_bad_lines='skip')

        # Extract station name and ID using regular expressions
        match = re.match(r"(station\[\d+\])_(.*)", filename)
        if match:
            station_part = match.group(1)  # e.g., "station[11]"
            # Extract the number from inside the brackets
            station_id = re.findall(r'\d+', station_part)[0]  # Extracts '11'

            # Add Station_ID column to the DataFrame and ensure it's treated as a string
            df['Station_ID'] = station_id
            df['Station_ID'] = df['Station_ID'].astype(str).str.strip()

        # Convert the 'DATETIME [YYYY-MM-DD HH:MM]' column to datetime type
        df['DATETIME [YYYY-MM-DD HH:MM]'] = pd.to_datetime(df['DATETIME [YYYY-MM-DD HH:MM]'], format='%Y-%m-%d %H:%M:%S')
        
        # Extract Year, Month, Day, Hour, and Minute into separate columns
        df['Year'] = df['DATETIME [YYYY-MM-DD HH:MM]'].dt.year
        df['Month'] = df['DATETIME [YYYY-MM-DD HH:MM]'].dt.month.apply(lambda x: f'{x:02}') 
        df['Day'] = df['DATETIME [YYYY-MM-DD HH:MM]'].dt.day.apply(lambda x: f'{x:02}') 
        df['Hour'] = df['DATETIME [YYYY-MM-DD HH:MM]'].dt.hour.apply(lambda x: f'{x:02}') 
        df['Minute'] = df['DATETIME [YYYY-MM-DD HH:MM]'].dt.minute.apply(lambda x: f'{x:02}')  # Format minutes as two digits

        # Merge the df with stations_df on Station_ID
        merged_df = pd.merge(df, stations_df, how='left', on='Station_ID')

        # Print the merged DataFrame to check if the merge worked
        print(merged_df.head())
        
        # Process df2 only if the merge was successful
        df2 = merged_df.copy()  # Create a copy of merged_df to work with
        df2["observation_value"] = merged_df["RH_2 [%]"]
        df2["report_type"] = "0"
        df2["date_time_meaning"] = "1"
        df2["observation_duration"] = "0"
        df2["platform_type"] = "0"
        df2["station_type"] = "1"
        df2["observation_id"] = ""
        df2["data_policy_licence"] = "9"
        df2["primary_station_id"] = merged_df["Station_ID"]
        df2["quality_flag"] = "3"
        df2["observed_variable"] = "38"
        #df2['observation_value'] = (df2['observation_value'] *100)
        #df2["observation_value"] = df2["observation_value"].map(int)
        df2["units"] = "300"
        df2["value_significance"] = "12"
        df2["observation_duration"] = "0"
        df2["source_id"] = "402"
        df2["record_number"] = "1"
        
        # Add timestamp to df and create report id
        df2["Timestamp2"] = df2["Year"].map(str) + "-" + df2["Month"].map(str) + "-" + df2["Day"].map(str)
        df2["Seconds"] = "00"  # Modify this line
        df2["date_time"] = df2["Timestamp2"].map(str) + " " + df2["Hour"].map(str) + ":" + df2["Minute"].map(str) + ":" + df2["Seconds"].map(str)
        df2["report_id1"] = df2["date_time"]

        # Rename df2 columns to cdm-core and create report_id
        df2["height_of_station_above_sea_level"] = df2["Elevation"]
        df2["report_timestamp"] = df2["date_time"] + '+00'
        df2["report_meaning_of_time_stamp"] = df2["date_time_meaning"]
        df2["report_duration"] = df2["observation_duration"]
        df2["latitude"] = df2["Latitude"]
        df2["longitude"] = df2["Longitude"]
        df2["station_name"] = df2["Station_name"]
        
        # Add observation id to dataframe
        df2["dates"] = ""
        df2["dates"] = df2["report_id1"].str[:-3]
        df2['observation_id'] = df2['primary_station_id'].astype(str) + '-' + df2['record_number'].astype(str) + '-' + df2['dates'].astype(str)
        df2['observation_id'] = df2['observation_id'].str.replace(r' ', '-')
        df2["observation_id"] = df2["observation_id"] + '-' + df2['observed_variable'] + '-' + df2['value_significance']

        # Function to extract substring before the second last '-'
        def extract_report_id(obs_id):
            parts = obs_id.split('-')
            report_id = '-'.join(parts[:-2])
            return report_id
        
        # Apply the function to create the new column report_id
        df2['report_id'] = df2['observation_id'].apply(extract_report_id)
        df2['latitude'] = df2['latitude'].str.strip()
        df2['longitude'] = df2['longitude'].str.strip()
        
        # Set up final columns
        df2 = df2[["station_name", "primary_station_id", "report_id", "observation_id",
                    "longitude", "latitude", "height_of_station_above_sea_level", "report_timestamp",
                    "report_meaning_of_time_stamp", "report_duration", "observed_variable",
                    "units", "observation_value", "quality_flag", "source_id", "data_policy_licence",
                    "report_type", "value_significance"]]
        
        # Convert station_id to string before using it in the file name
        station_id = str(df2['primary_station_id'].iloc[0])  # Extract Station_ID for output file name
        outname = os.path.join(OUTDIR1, station_id + "_relative_humidity_402.psv")
        
        # Save the dataframe to a PSV (pipe-separated values) file
        df2.to_csv(outname, index=False, sep="|")
        
    except pd.errors.EmptyDataError:
        print(f"File {filename} is empty and cannot be processed.")
    except Exception as e:
        print(f"An error occurred while processing {filename}: {e}")
        continue  # Continue to the next file if an error occurs
