PREFIX=$1
rm -rf ${PREFIX}canada/rawghcnd
mkdir -p ${PREFIX}canada/rawghcnd
for i in `ls ${PREFIX}canada/archive/por/rawghcnd`
do
gawk 'substr($0,12,6)<202401{print $0}' ${PREFIX}canada/archive/por/rawghcnd/$i > ${PREFIX}canada/rawghcnd/$i
done
for i in `ls ${PREFIX}canada/archive/upd/rawghcnd`
do
gawk 'substr($0,12,6)>=202401 {print $0}' ${PREFIX}canada/archive/upd/rawghcnd/$i >> ${PREFIX}canada/rawghcnd/$i
done
