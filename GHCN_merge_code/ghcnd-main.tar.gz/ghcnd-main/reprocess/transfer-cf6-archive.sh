#!/bin/sh
# This script is intended to transfer the downloaded CF6 daily summaries from the High Plains Regional Climate Center 
# from the GHCNd update server to the GHCNd reprocess server.  The transfer is necessary because the reprocess server
# does not download the CF6 summaries everyday
# Written February 2018 by Matt Menne

PREFIX=$1
cd ${PREFIX}cf6
tar czf cf6.archive.tar.gz archive

echo "open ncdcftp.ncdc.noaa.gov" > ftpin
echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
echo "cd upload/2days" >> ftpin
echo "bin" >> ftpin
echo "del cf6.archive.tar.gz" >> ftpin
echo "put cf6.archive.tar.gz" >> ftpin
echo "quit" >> ftpin
ftp -in < ftpin
