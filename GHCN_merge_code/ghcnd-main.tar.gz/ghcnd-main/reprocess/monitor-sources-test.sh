#!/bin/sh

datapath=$1
basedir=$2

y=`date -d "1 day ago" +%Y`
m=`date -d "1 day ago" +%m`
d=`date -d "1 day ago" +%d`
y2=`date -d "2 days ago" +%Y`
m2=`date -d "2 days ago" +%m`
d2=`date -d "2 days ago" +%d`
y3=`date -d "3 days ago" +%Y`
m3=`date -d "3 days ago" +%m`
d3=`date -d "3 days ago" +%d`
y4=`date -d "4 days ago" +%Y`
m4=`date -d "4 days ago" +%m`
d4=`date -d "4 days ago" +%d`
y5=`date -d "5 days ago" +%Y`
m5=`date -d "5 days ago" +%m`
d5=`date -d "5 days ago" +%d`
y6=`date -d "6 days ago" +%Y`
m6=`date -d "6 days ago" +%m`
d6=`date -d "6 days ago" +%d`
y7=`date -d "7 days ago" +%Y`
m7=`date -d "7 days ago" +%m`
d7=`date -d "7 days ago" +%d`

cd ${basedir}

rm -f extracted${y}-${m}.txt
rm -f extracted${y2}-${m2}.txt
rm -f extracted${y3}-${m3}.txt
rm -f extracted${y7}-${m7}.txt

${basedir}sources.sh ${y} ${m} ${d} ${datapath}  
${basedir}sources.sh ${y2} ${m2} ${d2} ${datapath} 
${basedir}sources.sh ${y3} ${m3} ${d3} ${datapath} 
${basedir}sources.sh ${y4} ${m4} ${d4} ${datapath} 
${basedir}sources.sh ${y5} ${m5} ${d5} ${datapath} 
${basedir}sources.sh ${y6} ${m6} ${d6} ${datapath} 
${basedir}sources.sh ${y7} ${m7} ${d7} ${datapath} 
${basedir}sources.sh ${y7} ${m7} 01 ${datapath}  

# Send message function

echo "FOR YESTERDAY:"
cat sources${y}-${m}-${d}.txt

echo "FOR THE DAY BEFORE YESTERDAY:"
cat sources${y2}-${m2}-${d2}.txt

echo "FOR 3 DAYS AGO:"
cat sources${y3}-${m3}-${d3}.txt

echo "FOR 4 DAYS AGO:"
cat sources${y4}-${m4}-${d4}.txt

echo "FOR 5 DAYS AGO:"
cat sources${y5}-${m5}-${d5}.txt

echo "FOR 6 DAYS AGO:"
cat sources${y6}-${m6}-${d6}.txt

echo "FOR ONE WEEK AGO:"
cat sources${y7}-${m7}-${d7}.txt

echo "FOR THE FIRST DAY OF THE MONTH THAT WAS CURRENT ONE WEEK AGO:"
cat sources${y7}-${m7}-01.txt

echo "Legend:
a = Australia
C = Environment Canada
D = CF6 Daily Summaries
G = Government-provided/GCOS
H = HPRCC
N = CoCoRaHS
R = CRN
S = GSOD
T = Snotel
U = RAWS
W = ISD Summary of the Day
7 = WX Coder III"

