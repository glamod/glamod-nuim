import logging
import os
import boto3
import pandas as pd
import awswrangler as wr
import duckdb
from typing import List, Tuple, Dict, Any
import shutil # --- ADDED: Import for checking disk usage ---

# --- STATIC CONFIG ---
OUTPUT_BUCKET = "ghcnh-mingled"
STATION_LIST_CSV = "ghcnh-station-list.csv"
PRIORITY_CSV = "ghcnh-mingle-list.csv"
MANIFEST_S3_PATH = "s3://ghcnh-mingled/manifests/ghcnh-file-manifest.parquet"
VARIABLES = ["temperature", "dew_point_temperature", "station_level_pressure", "sea_level_pressure", "wind_direction", "wind_speed", "wind_gust", "precipitation", "relative_humidity", "wet_bulb_temperature", "pres_wx_MW1", "pres_wx_MW2", "pres_wx_MW3", "pres_wx_AU1", "pres_wx_AU2", "pres_wx_AU3", "pres_wx_AW1", "pres_wx_AW2", "pres_wx_AW3", "snow_depth", "visibility", "altimeter", "pressure_3hr_change", "sky_condition", "sky_condition_baseht", "ceiling_height", "sky_cover_layer_1", "sky_cover_layer_2", "sky_cover_layer_3", "sky_cover_layer_4", "sky_cover_layer_baseht_1", "sky_cover_layer_baseht_2", "sky_cover_layer_baseht_3", "sky_cover_layer_baseht_4", "sky_cover_summation_1", "sky_cover_summation_2", "sky_cover_summation_3", "sky_cover_summation_4", "sky_cover_summation_baseht_1", "sky_cover_summation_baseht_2", "sky_cover_summation_baseht_3", "sky_cover_summation_baseht_4", "precipitation_5_minute", "precipitation_15_minute", "precipitation_3_hour", "precipitation_6_hour", "precipitation_9_hour", "precipitation_12_hour", "precipitation_15_hour", "precipitation_18_hour", "precipitation_21_hour", "precipitation_24_hour", "REM"]
STRING_OBSERVED_PREFIXES = ["REM", "sky_cover", "sky_summation", "sky_condition", "pres_wx", "wind_direction"]

# --- LOGGING ---
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# --- HELPER FUNCTIONS ---
def setup_duckdb_s3():
    con = duckdb.connect(database=":memory:")
    con.execute("SET home_directory='/tmp'")
    con.execute("SET temp_directory='/tmp'")
    con.execute("INSTALL httpfs; LOAD httpfs;")
    sess = boto3.Session()
    creds = sess.get_credentials().get_frozen_credentials()
    con.execute(f"SET s3_region='{sess.region_name}';")
    con.execute(f"SET s3_access_key_id='{creds.access_key}';")
    con.execute(f"SET s3_secret_access_key='{creds.secret_key}';")
    if creds.token:
        con.execute(f"SET s3_session_token='{creds.token}';")
    return con

def load_priority_map(path: str) -> Dict[str, List[Tuple[str, str, int]]]:
    df = pd.read_csv(
        path, header=None, names=['station','source_station','priority','source_id'],
        dtype={'station': str, 'source_station': str, 'priority': int, 'source_id': str}
    )
    df[['station','source_station']] = df[['station','source_station']].apply(lambda s: s.str.strip())
    df.sort_values('priority', inplace=True)
    mapping = df.groupby('station')[['source_id','source_station', 'priority']].apply(
        lambda g: list(zip(g.source_id, g.source_station, g.priority))
    ).to_dict()
    return mapping

def load_metadata(path: str) -> Dict[str, Dict[str, Any]]:
    df = pd.read_csv(path).set_index('GHCN_ID')
    return df[['NAME','LATITUDE','LONGITUDE','ELEVATION']].to_dict('index')

def process_and_write_chunk(station: str, priority_list: List[Tuple[str, str, int]], metadata: Dict[str, Dict[str, Any]], years_chunk: List[int], temp_output_prefix: str):
    logger.info(f"--- Processing chunk for station {station}: years {min(years_chunk)}-{max(years_chunk)} ---")
    con = setup_duckdb_s3()
    try:
        meta = metadata[station]
        priority_df_raw = pd.DataFrame(priority_list, columns=['source_id', 'source_station', 'priority'])
        con.register('priority_df_raw', priority_df_raw)

        temp_table_names = []
        for i, var in enumerate(VARIABLES):
            temp_table_name = f"temp_table_{i}"
            temp_table_names.append(temp_table_name)
            
            file_list_query = f"""
                WITH priority_df AS (
                    SELECT 
                        TRIM(CAST(source_id AS VARCHAR)) AS source_id, 
                        TRIM(CAST(source_station AS VARCHAR)) AS source_station,
                        priority
                    FROM priority_df_raw
                )
                SELECT m.s3_uri, p.priority
                FROM read_parquet('{MANIFEST_S3_PATH}') AS m
                INNER JOIN priority_df AS p
                    ON TRIM(m.source_id) = p.source_id 
                   AND TRIM(m.source_station) = p.source_station
                WHERE m.variable = '{var}'
            """
            uris_df = con.execute(file_list_query).df()
            logger.info(f"Diagnostic: For variable '{var}', found {len(uris_df)} files in manifest.")

            uris_df = uris_df.rename(columns={'priority': '__prio__'})
            initial_uris = list(zip(uris_df['__prio__'], uris_df['s3_uri']))

            valid_uris = []
            for prio, uri in initial_uris:
                try:
                    con.execute(f"SELECT 1 FROM read_parquet('{uri}') LIMIT 1")
                    valid_uris.append((prio, uri))
                except Exception as e:
                    logger.warning(f"Skipping corrupted file for variable '{var}'. Path: {uri}. Error: {e}")
                    continue
            
            uris = valid_uris
            if not uris:
                is_string_var = any(var.lower().startswith(p.lower()) for p in STRING_OBSERVED_PREFIXES)
                obs_type = "VARCHAR" if is_string_var else "DOUBLE"
                con.execute(f"""
                    CREATE OR REPLACE TEMPORARY TABLE "{temp_table_name}" AS SELECT
                        CAST(NULL AS BIGINT) AS Year, CAST(NULL AS BIGINT) AS Month, CAST(NULL AS BIGINT) AS Day,
                        CAST(NULL AS BIGINT) AS Hour, CAST(NULL AS BIGINT) AS Minute, CAST(NULL AS {obs_type}) AS "{var}",
                        CAST(NULL AS VARCHAR) AS "{var}_Measurement_Code", CAST(NULL AS VARCHAR) AS "{var}_Quality_Code",
                        CAST(NULL AS VARCHAR) AS "{var}_Report_Type", CAST(NULL AS VARCHAR) AS "{var}_Source_Code",
                        CAST(NULL AS VARCHAR) AS "{var}_Source_Station_ID"
                    WHERE 1=0
                """)
                continue

            union_selects = [f"SELECT Source_ID, Station_ID, Year, Month, Day, Hour, Minute, Observed_value, Measurement_code_1, Source_QC_flag, Report_type_code, {prio} AS __prio__ FROM read_parquet('{uri}') WHERE try_cast(Year as BIGINT) IN {tuple(years_chunk)}" for prio, uri in uris]
            minute_logic = "COALESCE(try_cast(Minute as BIGINT), 0)"
            partition_clause = f"PARTITION BY try_cast(Year AS BIGINT), try_cast(Month AS BIGINT), try_cast(Day AS BIGINT), try_cast(Hour AS BIGINT), {minute_logic}"
            order_by_clause = "ORDER BY __prio__ ASC, Source_ID ASC"
            if var == "REM":
                order_by_clause = "ORDER BY (CASE WHEN Source_ID = '220' THEN 0 WHEN Source_ID = '223' THEN 1 ELSE __prio__ + 10000 END) ASC, Source_ID ASC"

            deduplicated_raw_cte = f"deduplicated_raw AS (SELECT try_cast(Year AS BIGINT) AS Year, try_cast(Month AS BIGINT) AS Month, try_cast(Day AS BIGINT) AS Day, try_cast(Hour AS BIGINT) AS Hour, {minute_logic} as Minute, Observed_value, Measurement_code_1, Source_QC_flag, Report_type_code, Source_ID, Station_ID FROM ranked WHERE rn = 1)"
            if var in ['temperature', 'dew_point_temperature']:
                final_select = f"""SELECT Year, Month, Day, Hour, Minute, Observed_value AS "{var}", string_split(Measurement_code_1, '-')[1] AS "{var}_Measurement_Code", CASE WHEN trim(Source_QC_flag) = 'C' THEN '5' ELSE string_split(Source_QC_flag, '-')[1] END AS "{var}_Quality_Code", Report_type_code AS "{var}_Report_Type", Source_ID AS "{var}_Source_Code", Station_ID AS "{var}_Source_Station_ID" FROM deduplicated_raw"""
            else:
                final_select = f"""SELECT Year, Month, Day, Hour, Minute, Observed_value AS "{var}", string_split(Measurement_code_1, '-')[1] AS "{var}_Measurement_Code", string_split(Source_QC_flag, '-')[1] AS "{var}_Quality_Code", Report_type_code AS "{var}_Report_Type", Source_ID AS "{var}_Source_Code", Station_ID AS "{var}_Source_Station_ID" FROM deduplicated_raw"""

            con.execute(f"""
                CREATE OR REPLACE TEMPORARY TABLE "{temp_table_name}" AS
                WITH combined AS ({' UNION ALL '.join(union_selects)}),
                     ranked AS (SELECT *, ROW_NUMBER() OVER ({partition_clause} {order_by_clause}) AS rn FROM combined),
                     {deduplicated_raw_cte}
                {final_select}
            """)

        all_timestamps_union_queries = [f'SELECT DISTINCT Year, Month, Day, Hour, Minute FROM "{table_name}"' for table_name in temp_table_names]
        base_timestamp_cte_def = f"WITH all_ts AS ({' UNION '.join(all_timestamps_union_queries)})"
        
        record_count_result = con.execute(f"{base_timestamp_cte_def} SELECT COUNT(*) FROM all_ts WHERE Year IS NOT NULL").fetchone()
        record_count = record_count_result[0] if record_count_result else 0
        logger.info(f"Diagnostic: Final unique timestamp count for this chunk is {record_count}.")

        if record_count == 0:
            logger.warning(f"No data found for {station} in years {min(years_chunk)}-{max(years_chunk)}. No chunk file will be created.")
            return

        station_name_sql = meta["NAME"].replace("'", "''")
        date_logic = f"""
            CASE
                WHEN ts.Hour = 99 THEN NULL
                ELSE strftime(MAKE_TIMESTAMP(ts.Year, ts.Month, ts.Day, ts.Hour, 
                    CASE WHEN ts.Minute = 99 THEN 0 ELSE ts.Minute END, 0), '%Y-%m-%dT%H:%M:%S')
            END
        """
        
        select_list_agg = [f"'{station}' AS STATION", f"'{station_name_sql}' AS Station_name", f"{date_logic} AS DATE", "ts.Year", "ts.Month", "ts.Day", "ts.Hour", "ts.Minute", f'{meta["LATITUDE"]} AS LATITUDE', f'{meta["LONGITUDE"]} AS LONGITUDE', f'{meta["ELEVATION"]} AS ELEVATION']
        join_clauses = []
        for i, var in enumerate(VARIABLES):
            temp_table_name = f"temp_table_{i}"
            alias = f"t_{i}"
            select_list_agg.extend([f'MAX({alias}."{var}") AS "{var}"', f'MAX({alias}."{var}_Measurement_Code") AS "{var}_Measurement_Code"', f'MAX({alias}."{var}_Quality_Code") AS "{var}_Quality_Code"', f'MAX({alias}."{var}_Report_Type") AS "{var}_Report_Type"', f'MAX({alias}."{var}_Source_Code") AS "{var}_Source_Code"', f'MAX({alias}."{var}_Source_Station_ID") AS "{var}_Source_Station_ID"'])
            join_clauses.append(f'LEFT JOIN "{temp_table_name}" AS {alias} ON ts.Year={alias}.Year AND ts.Month={alias}.Month AND ts.Day={alias}.Day AND ts.Hour={alias}.Hour AND ts.Minute={alias}.Minute')

        group_by_keys = ["ts.Year", "ts.Month", "ts.Day", "ts.Hour", "ts.Minute"]
        final_agg_query = (f"WITH all_ts AS ({' UNION '.join(all_timestamps_union_queries)}) "
                           f"SELECT {', '.join(select_list_agg)} "
                           f"FROM all_ts ts {' '.join(join_clauses)} "
                           f"WHERE ts.Year IS NOT NULL AND ts.Hour BETWEEN 0 AND 23 AND ts.Minute BETWEEN 0 AND 59 "
                           f"GROUP BY {', '.join(group_by_keys)} "
                           f"ORDER BY ts.Year, ts.Month, ts.Day, ts.Hour, ts.Minute")

        chunk_file_name = f"{station}-{min(years_chunk)}-{max(years_chunk)}.parquet"
        
        try:
            final_row_count_result = con.execute(f"SELECT COUNT(*) FROM ({final_agg_query})").fetchone()
            final_row_count = final_row_count_result[0] if final_row_count_result else 0
            logger.info(f"Diagnostic: Final query will write {final_row_count} rows.")

            total, used, free = shutil.disk_usage("/tmp")
            logger.info(f"Diagnostic: Disk usage in /tmp: {used // (1024*1024)}MB used / {total // (1024*1024)}MB total.")

            if final_row_count > 0:
                # --- FIX: Write to local /tmp directory first, then upload with boto3 ---
                local_temp_path = f"/tmp/{chunk_file_name}"
                logger.info(f"Writing {final_row_count} rows to local path: {local_temp_path}")
                con.execute(f"COPY ({final_agg_query}) TO '{local_temp_path}' (FORMAT PARQUET, COMPRESSION SNAPPY, OVERWRITE_OR_IGNORE)")

                s3_client = boto3.client('s3')
                s3_key = temp_output_prefix.replace(f"s3://{OUTPUT_BUCKET}/", "") + f"/{chunk_file_name}"
                logger.info(f"Uploading local file to s3://{OUTPUT_BUCKET}/{s3_key}")
                s3_client.upload_file(local_temp_path, OUTPUT_BUCKET, s3_key)

                logger.info(f"Successfully wrote chunk parquet to S3.")
                os.remove(local_temp_path) # Clean up the local file
            else:
                logger.warning("Skipping file write because final query resulted in 0 rows.")

        except Exception as e:
            logger.error(f"FATAL error executing final aggregation and write for station {station}, chunk {years_chunk}. Error: {e}", exc_info=True)
            raise
    
    except Exception as e:
        logger.error(f"FATAL error in process_and_write_chunk for station {station}, chunk {years_chunk}. Error: {e}", exc_info=True)
        raise
    finally:
        con.close()

# --- LAMBDA HANDLER ---
def lambda_handler(event, context):
    station_id = event['station_id']
    year_chunk = event['year_chunk']
    job_id = event['job_id']['UUID']
    
    script_dir = os.environ.get("LAMBDA_TASK_ROOT", ".")
    priority_csv_path = os.path.join(script_dir, PRIORITY_CSV)
    station_list_csv_path = os.path.join(script_dir, STATION_LIST_CSV)

    temp_output_prefix = f"s3://{OUTPUT_BUCKET}/_temp/{job_id}"

    priority_map = load_priority_map(priority_csv_path)
    metadata = load_metadata(station_list_csv_path)
    
    plist = priority_map.get(station_id)
    if not plist:
        raise ValueError(f"No sources for station {station_id} in priority map")

    process_and_write_chunk(station_id, plist, metadata, year_chunk, temp_output_prefix)
    
    return { "status": "success", "processed_chunk": f"{min(year_chunk)}-{max(year_chunk)}" }

