for i in `cat canada.20080513.inv`
do
grep $i canada-allstations.txt | gawk '{print substr($0,1,38)substr($0,42,47)}' >> canada.station.list
done
