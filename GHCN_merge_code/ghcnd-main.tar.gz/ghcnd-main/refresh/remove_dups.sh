read stationlist

for i in `cat station.dups.newestids`
do
cp ${stationlist} tmp.txt
grep -v $i tmp.txt > ${stationlist}
done
