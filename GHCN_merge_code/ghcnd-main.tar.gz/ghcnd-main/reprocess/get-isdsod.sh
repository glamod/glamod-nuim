# Purpose: to retrieve the isd archive from ftp for years
# begyear to endyear and create summary of the day only files by year
# Created by Menne April 2013

PREFIX=$1
begyear=$2
endyear=$3

echo "Downloading ISD station files from $begyear to $endyear into ${PREFIX}download/wsod/tmp" `date`

rm -f ${PREFIX}get-isdsod.log

if [ ! -s ${PREFIX}download ]
then
echo "${PREFIX}download does not existing...exiting"
exit
fi

rm -rf ${PREFIX}download/wsod

mkdir -p ${PREFIX}download/wsod/tmp

cd /noaa

cp -p isd-history.txt /${PREFIX}download/wsod/tmp

#wget -a ${PREFIX}get-isdsod.log -P${PREFIX}download/wsod/tmp ftp://ftp0.ncdc.noaa.gov/pub/data/noaa/ish-history.txt

for (( year=${begyear}; ${year} <= ${endyear}; year=`expr ${year} + 1` ))
do
#rm -f ${PREFIX}list.tmp
echo ${year}
cd /noaa/${year}

ls * > ${PREFIX}list.tmp

#echo "open ftp0.ncdc.noaa.gov" > ftpin
#echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
#echo "cd /pub/data/noaa/${year}" >> ftpin
#echo "ls * ${PREFIX}list.tmp" >> ftpin
#echo "quit" >> ftpin
#ftp -in < ftpin
#echo "open ftp0.ncdc.noaa.gov" > ftpin
#echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
#echo "cd /pub/data/noaa/${year}" >> ftpin
#echo "lcd ${PREFIX}download/wsod/tmp" >> ftpin
for file in `gawk 'substr($0,7,5)!="99999" {print $0}' ${PREFIX}list.tmp`
do cp -p ${file} ${PREFIX}download/wsod/tmp
done
#echo "quit" >> ftpin
#ftp -in < ftpin
zcat ${PREFIX}download/wsod/tmp/*-${year}.gz | gawk 'substr($0,42,5)=="SOD  " {print $0}' > ${PREFIX}download/wsod/sod${year}.isd
done

