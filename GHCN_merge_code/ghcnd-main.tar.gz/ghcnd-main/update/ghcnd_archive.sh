mode=$1
run_status=$2
backup_dir=$3
version=`cat ${PREFIX}input4sys/version-number.txt`
cd $PREFIX
tar -czf ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz ghcnd_all input4sys/ghcnd-stations.txt
${lib_dir}gen1nmf.sh ${PREFIX} ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz
tar -cf ${lib_dir}ghcn-daily_v${version}-src_c${timestamp}.tar *.f95 *.sh 
${lib_dir}gen1nmf.sh ${PREFIX} ghcn-daily_v${version}-src_c${timestamp}.tar
if [ "${mode}" = "por" ]
then
cp -p check4timing.flags ${PREFIX}archive/check4timing_${mode}${timestamp}.flags
cp -p check4timing.log ${PREFIX}archive/check4timing_${mode}${timestamp}.log
cp -p ghcnd-inventory.txt ${PREFIX}archive/ghcnd-inventory${timestamp}.txt
rm -f ghcnd_clim.tar.gz
tar -czf ghcnd_clim.tar.gz clim
cp -p ghcnd_clim.tar.gz ${PREFIX}archive/ghcnd_clim${timestamp}.tar.gz
${PREFIX}backup-ghcnd.sh ${backup_dir}
fi
cp -p qc3.flags ${PREFIX}archive/qc3_${mode}${timestamp}.flags
cp -p qc3.log ${PREFIX}archive/qc3_${mode}${timestamp}.log
cp -p qc2.flags ${PREFIX}archive/qc2_${mode}${timestamp}.flags
cp -p qc2.log ${PREFIX}archive/qc2_${mode}${timestamp}.log
cp -p qc1.flags ${PREFIX}archive/qc1_${mode}${timestamp}.flags
cp -p qc1.log ${PREFIX}archive/qc1_${mode}${timestamp}.log
cp -p mingle.log ${PREFIX}archive/mingle_${mode}${timestamp}.log
cp -p format_check_pre.log ${PREFIX}archive/format_check_pre_${mode}${timestamp}.log
cp -p format_check_post.log ${PREFIX}archive/format_check_post_${mode}${timestamp}.log
#if [ "${run_status}" = "live" ]
#then
#echo "open gulp2.ncdc.noaa.gov" > ftpin
#echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
#echo "bin" >> ftpin
#echo "cd /pub/upload/Ingest/GHCND/" >> ftpin
#echo "put ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz" >> ftpin
#echo "put ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz.mnf" >> ftpin
#echo "put ghcn-daily_v${version}-src_c${timestamp}.tar" >> ftpin
#echo "put ghcn-daily_v${version}-src_c${timestamp}.tar.mnf" >> ftpin
#echo "quit" >> ftpin
#ftp -in < ftpin
#fi
if [ "${run_status}" = "live" ]
then
echo "open arrival-int-prod.ncdc.noaa.gov" > ftpin
echo "user anonymous Matthew.Menne@noaa.gov" >> ftpin
echo "bin" >> ftpin
echo "cd /pub/upload/Ingest/GHCND/" >> ftpin
echo "put ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz" >> ftpin
echo "put ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz.mnf" >> ftpin
#echo "put ghcn-daily_v${version}-src_c${timestamp}.tar" >> ftpin
#echo "put ghcn-daily_v${version}-src_c${timestamp}.tar.mnf" >> ftpin
echo "quit" >> ftpin
ftp -in < ftpin
fi
mv ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz ${PREFIX}archive
mv ghcn-daily_v${version}-${mode}.${timestamp}.tar.gz.mnf ${PREFIX}archive
mv ghcn-daily_v${version}-src.c${timestamp}.tar ${PREFIX}archive
mv ghcn-daily_v${version}-src.c${timestamp}.tar.mnf ${PREFIX}archive
cp -p ghcn-daily_v${version}-src_c${timestamp}.tar ${PREFIX}archive
cp -p ghcn-daily_v${version}-src_c${timestamp}.tar.mnf ${PREFIX}archive


