echo "Starting refresh-3201.sh on " `date`

refresh_dir=/home/mmenne/ghcnd/makelist/
data_dir=/home/mmenne/ghcnd2/3201/
list_dir=/home/mmenne/ghcnd/

${refresh_dir}compile-refresh-coop.sh ${refresh_dir}

cp -p ${list_dir}ghcnd-stations.txt ${refresh_dir}
cp -p ${list_dir}mingle-list.txt ${refresh_dir}

cd ${refresh_dir}

#Get the latest MASTER-STN-HIST.TXT file
${refresh_dir}get-mshr.sh ${refresh_dir}
#Keep a copy of last 3201 list of stations with data
cp -p ${refresh_dir}3201.inv ${refresh_dir}3201.inv.old
#Make a new 3201 list of stations with data
mv -f ${refresh_dir}3201-stations.txt ${refresh_dir}3201-stations.old
ls ${data_dir}rawdata > ${refresh_dir}3201.inv
echo "Starting gen-coop-station-info.exe on " `date`
${refresh_dir}gen-coop-stninfo.exe 3201 ${refresh_dir}
if [ ! -s ${refresh_dir}3201-stations.txt ]
then
echo "3201-stations.txt was not created...exiting script" `date`
exit
fi
echo "Starting pre_screen.exe on" `date`
${refresh_dir}pre_screen.exe ${data_dir} ${refresh_dir}3201-stations.txt 3201
cut -c12-15 ${data_dir}rawghcnd/* | sort -u > ${refresh_dir}3201-years.txt 
echo "Starting intrasource_dupchk.exe on" `date`
${refresh_dir}intrasource_dupchk.exe ${data_dir} ${refresh_dir}3201-stations-prescreened.txt 3201
echo "Starting strip_source.exe on" `date`
${refresh_dir}strip_source.exe 1
echo "Starting genCoopXref.exe on" `date`
${refresh_dir}genCoopXref.exe MASTER-STN-HIST.TXT ${refresh_dir}3201-stations-prescreened-dupchecked.txt ${refresh_dir}mingle-list-no-1.txt ${refresh_dir}3201.id.xref ${refresh_dir}3201.id.noxref
echo "Starting genDataXref.exe on" `date`
${refresh_dir}genDataXref.exe ${refresh_dir}ghcnd-stations-no-1.txt 1 /home/mmenne/ghcnd2/ghcnd_all/ ${data_dir}rawghcnd/ ${refresh_dir}3201.id.noxref ${refresh_dir}3201.data.xref
echo "catting 3201.id.xref and 3201.data.xref" `date`
cat ${refresh_dir}3201.id.xref ${refresh_dir}3201.data.xref > ${refresh_dir}3201.xref
echo "Starting add_stns.exe on" `date`
${refresh_dir}add_stns.exe ${refresh_dir}mingle-list-no-1.txt ${refresh_dir}ghcnd-stations-no-1.txt ${refresh_dir}3201-stations-prescreened-dupchecked.txt 1 ${refresh_dir}3201.xref
echo "Number of stations in ghcnd-stations" `wc ${refresh_dir}ghcnd-stations.txt | cut -c1-7`
echo "Finished refresh-3201.sh on " `date`

